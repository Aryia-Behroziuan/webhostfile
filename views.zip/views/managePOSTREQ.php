<?PHP 
if(! $user['piperAdmin'] == 1){
    die();
}
?>

<section class="py-4">
	<div class="container">


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between">
                            <?php
                            if(isset($_GET['res'])){
                                if($_GET['res'] == 1){
                                    ?>
                                    <h6>تایید نشده</h6>
                                    <?php
                                }elseif($_GET['res'] == 2){
                                    ?>
                                    <h6>گزارش ها</h6>
                                    <?php
                                }
                            }else{
                                ?>
                                <h6>تازه ها</h6>
                                <?php
                            }
                            ?>
							<!-- Search bar -->
							<div class="col-md-8">
								<form class="rounded position-relative">
									<input class="form-control bg-transparent" type="search" placeholder="Search" aria-label="Search">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>
							<!-- Tab buttons -->
							<div class="col-md-3">
								<!-- Tabs START -->
								<ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
									<!-- Grid tab -->
									<li class="nav-item">
										<a href="dashboard.php?content=managePOSTREQ" class="btn btn-dark-soft btn-xs">
											تازه ها
										</a>
									</li>
									<!-- List tab -->
									<li class="nav-item">
										<a href="dashboard.php?content=managePOSTREQ&res=1" class="btn btn-dark-soft btn-xs">
											تایید نشده 
										</a>
									</li>
                                    									<!-- List tab -->
                                    <li class="nav-item">
										<a href="dashboard.php?content=managePOSTREQ&res=2" class="btn btn-dark-soft btn-xs">
											گزارش 
										</a>
									</li>

								</ul>
								<!-- Tabs end -->
							</div>
						</div>
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						<!-- Tabs content START -->
						<div class="tab-content py-0 my-0">
                            <?php
                            if(isset($_GET['search'])){

                            }elseif(isset($_GET['res'])){
                                if($_GET['res'] == 1){
                                    $query_1212 = mysqli_query($con, 'select * from posts where published=0 order by dateEdit limit 0,1000');
                                    $file_hash = mysqli_query($con, 'select * from posts where published=0 order by dateEdit limit 0,1000');
                                }elseif($_GET['res'] == 2){
                     
                                    $query_1212 = mysqli_query($con, 'select * from session where name="report" limit 0,1000');
                                    $file_hash = mysqli_query($con, 'select * from session where name="report" limit 0,1000');
                                }
                            }else{
                                $query_1212 = mysqli_query($con, 'select * from posts where published=1 order by dateEdit Desc limit 0,1000');
                                $file_hash = mysqli_query($con, 'select * from posts where published=1 order by dateEdit Desc limit 0,1000');
                            }

                            $file = mysqli_fetch_assoc($query_1212);
                            if($file){
                                if(isset($_GET['res'])){
                                    if($_GET['res'] == 2){

                                        ?>
                                        <!-- Tabs content item START -->
                                        <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                            <!-- Table START -->
                                            <div class="table-responsive border-0">
                                                <table class="table align-middle p-4 mb-0 table-hover">
                                                    <!-- Table head -->
                                                    <thead class="table-dark">
                                                        <tr>
                                                            <th scope="col" class="border-0 rounded-start">نام پست</th>
                                                            <th scope="col" class="border-0">شناسه</th>
                                                            <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                        </tr>
                                                    </thead>
    
                                                    <!-- Table body START -->
                                                    <tbody class="border-top-0">
    
    
                                                    <?php
            
                                                    while($res=mysqli_fetch_assoc($file_hash)){
                                                        $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost='.$res['data'].''));

                                                            ?>
                                                            <!-- Table row -->
                                                            <tr>
                                                                <!-- Table data -->
                                                                <td>
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <!-- Image -->
                                                   
                                                                        <div class="mb-0 ms-2">
                                                                            <!-- Title -->
                                                                            <h6 class="mb-0"><a href="index.php?content=open&id=<?php echo $post['idPost']?>" class="stretched-link"><?php echo $post['title']?></a> 
                                                                            <?php
                                                                            if($res['payment'] == 1){
                                                                            }else{
                                                                                ?>
                                                                                <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشتری</font></font></span>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        
                                                                            </h6>
                                                                            <small><?php echo $res['wiki']?></small>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <!-- Table data -->
                                                                <td><?php echo $post['idPost']?></td>
                                                                <!-- Table data -->
                                                        
                                                    
                                                                <td>
                                                                    <div class="d-flex gap-2">
                                                                        <a href="dashboard.php?content=managePOSTREP&id=<?php echo $post['idPost']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
                                                                        <i class="bi bi-link-45deg"></i>
                                                                        </a>
                                                                        <a href="https://www.spacify.ir/Wizify/index.php?controller=user&method=profile&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-send"></i>
                                                                        </a>
                                                                        <a href="../../blogzine.webestica.com/rtl/dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-box-arrow-up-right"></i>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        
                                                    }
                                                    
                                                    ?>
                    
    
                                        
    
    
                                                    </tbody>
                                                    <!-- Table body END -->
                                                </table>
                                            </div>
                                            <!-- Table END -->
                                        </div>
                                        <!-- Tabs content item END -->
                                        <?php
                                    }else{
                                        ?>
                                        <!-- Tabs content item START -->
                                        <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                            <!-- Table START -->
                                            <div class="table-responsive border-0">
                                                <table class="table align-middle p-4 mb-0 table-hover">
                                                    <!-- Table head -->
                                                    <thead class="table-dark">
                                                        <tr>
                                                            <th scope="col" class="border-0 rounded-start">نام پست</th>
                                                            <th scope="col" class="border-0">شناسه</th>
                                                            <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                        </tr>
                                                    </thead>
    
                                                    <!-- Table body START -->
                                                    <tbody class="border-top-0">
    
    
                                                    <?php
            
                                                    while($res=mysqli_fetch_assoc($file_hash)){
                                                            ?>
                                                            <!-- Table row -->
                                                            <tr>
                                                                <!-- Table data -->
                                                                <td>
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <!-- Image -->
                                                                        <div class="avatar avatar-md">
                                                                            <img src="<?php echo $res['art']?>" class="rounded-circle" alt="">
                                                                        </div>
                                                                        <div class="mb-0 ms-2">
                                                                            <!-- Title -->
                                                                            <h6 class="mb-0"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link"><?php echo $res['title']?></a></h6>
                                                                            <small><?php echo $res['doc']?></small>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <!-- Table data -->
                                                                <td><?php echo $res['idPost']?></td>
                                                                <!-- Table data -->
                                                        
                                                    
                                                                <td>
                                                                    <div class="d-flex gap-2">
                                                                        <a href="dashboard.php?content=managePOST&id=<?php echo $res['idPost']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
                                                                        <i class="bi bi-link-45deg"></i>
                                                                        </a>
                                                                        <a href="https://www.spacify.ir/Wizify/index.php?controller=user&method=profile&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-send"></i>
                                                                        </a>
                                                                        <a href="../../blogzine.webestica.com/rtl/dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-box-arrow-up-right"></i>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        
                                                    }
                                                    
                                                    ?>
                    
    
                                        
    
    
                                                    </tbody>
                                                    <!-- Table body END -->
                                                </table>
                                            </div>
                                            <!-- Table END -->
                                        </div>
                                        <!-- Tabs content item END -->
                                        <?php
                                    }
                                }else{
                                    ?>
                                    <!-- Tabs content item START -->
                                    <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                        <!-- Table START -->
                                        <div class="table-responsive border-0">
                                            <table class="table align-middle p-4 mb-0 table-hover">
                                                <!-- Table head -->
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th scope="col" class="border-0 rounded-start">نام پست</th>
                                                        <th scope="col" class="border-0">شناسه</th>
                                                        <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                    </tr>
                                                </thead>

                                                <!-- Table body START -->
                                                <tbody class="border-top-0">


                                                <?php
		
                                                while($res=mysqli_fetch_assoc($file_hash)){
														?>
														<!-- Table row -->
														<tr>
															<!-- Table data -->
															<td>
																<div class="d-flex align-items-center position-relative">
																	<!-- Image -->
																	<div class="avatar avatar-md">
																		<img src="<?php echo $res['art']?>" class="rounded-circle" alt="">
																	</div>
																	<div class="mb-0 ms-2">
																		<!-- Title -->
																		<h6 class="mb-0"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link"><?php echo $res['title']?></a></h6>
                                                                        <small><?php echo $res['doc']?></small>
																	</div>
																</div>
															</td>
															<!-- Table data -->
															<td><?php echo $res['idPost']?></td>
															<!-- Table data -->
													
												
															<td>
																<div class="d-flex gap-2">
																	<a href="dashboard.php?content=managePOST&id=<?php echo $res['idPost']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
																	<i class="bi bi-link-45deg"></i>
																	</a>
																	<a href="https://www.spacify.ir/Wizify/index.php?controller=user&method=profile&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
																	<i class="bi bi-send"></i>
																	</a>
																	<a href="../../blogzine.webestica.com/rtl/dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
																	<i class="bi bi-box-arrow-up-right"></i>
																	</a>
																</div>
															</td>
														</tr>
														<?php
													
                                                }
                                                
                                                ?>
                

                                    


                                                </tbody>
                                                <!-- Table body END -->
                                            </table>
                                        </div>
                                        <!-- Table END -->
                                    </div>
                                    <!-- Tabs content item END -->
                                    <?php
                                }
                            }else{

                            }
                            ?>



						</div>
						<!-- Tabs content END -->
					</div>
					<!-- Card body END -->


				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    </div>
	</div>
</section>