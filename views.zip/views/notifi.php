<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center">
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/notification-5192262-4340267.mp4" type="video/mp4" autoplay="autoplay" style="width: 100px;" loop="loop"></video>  اعلان ها</font></font></h1>			
				</div>
			</div>
		</div>
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اعلان ها  </font></font>
							<?php
							if($user['notification'] == 0){

							}else{
							?>
							<span class="badge bg-danger bg-opacity-10 text-danger ms-2" id="showNoti1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['notification']?> اعلان جدید</font></font></span>

							<?php
							}
							?>
							</h5>


							<a class="small" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1">همه را پاک کن</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0">
              <ul style="height: 400px;" class="list-group list-unstyled list-group-flush scroll-example">
									
                  <?php
                  $query_1212 = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
                  $file_hash = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
                  $file = mysqli_fetch_assoc($query_1212);
                  if($file){
                    while($res=mysqli_fetch_assoc($file_hash)){
                      $some_time = strtotime($res['time']);

                      ?>
                      <!-- Notif item -->
                      <li>
                        <?PHP
                        if($res['link'] == '0'){
                          ?>
                          <a href="../../core/rtl/dashboard.php?content=openNotifi&id=<?PHP echo $res['idcomment']?>" class="list-group-item-action border-0 border-bottom d-flex p-3">
                          <?php
                        }else{
                          ?>
                          <a href="<?PHP echo $res['link']?>" class="list-group-item-action border-0 border-bottom d-flex p-3">
                          <?php
                        }
                        ?>
                          <div class="me-3">
                            <div class="icon-lg bg-warning bg-opacity-15 text-warning rounded-2 flex-shrink-0">
                              <i class="bi bi-bell"></i>
                            </div>
                          </div>
                          <div>
                            <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></h6>
                            <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('Y, d F', $some_time)?></font></font></span>
                          </div>
                        </a>
                      </li>
                      <?php
                    }
                  }else{
                    ?>
                    <section class="overflow-hidden">
                        <div class="container">
                            <div class="row">
                        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                            <!-- SVG shape START -->
                            <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                <g>
                                <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                </g>
                            </svg>
                            </figure>
                            <!-- SVG shape START -->
                            <!-- Content -->
                            <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                            <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اعلانی یافت نشد</font></font></h2>
                            
                        </div>
                        </div>
                        </div>
                    </section>
                    <?php
                  }
                  ?>
                                            <script>
                                            $('#deletenoti').click(function(event){
                                            event.preventDefault();
                                            $('#deletenoti').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=deleteNotifi",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#deletenoti').html('');
                                                $('#showNoti').html('');
                                                $('#displayNoti').html(data);
                                                })

                                            })
                                            </script>



								</ul>
							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>

											<script>
                                            $('#deletenoti1').click(function(event){
                                            event.preventDefault();
                                            $('#deletenoti1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=deleteNotifi",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#deletenoti1').html('');
                                                $('#showNoti1').html('');
                                                $('#displayNoti1').html(data);
                                                })

                                            })
                                            </script>