<?php
if(isset($_SESSION['id'])){
  header('location:core/rtl/index.php');
}
?>
<!DOCTYPE html>
<!-- saved from url=(0067)https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html -->
<html lang="fa-IR" dir=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!-- Required Meta Tags Always Come First -->
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Title -->
  <title>Piperline,LLC. - پیپرلاین شبکه اجتماعی توضیع خدمات و مخازن برخط</title>

  <!-- Favicon -->
  <link rel="shortcut icon" href="https://www.piperline.ir/public/img/logo/piperL.png">

  <!-- Font -->
  <link href="./Consulting _ Space - Multipurpose Responsive Template1_files/css2" rel="stylesheet">

  <!-- CSS Implementing Plugins -->
  <link rel="stylesheet" href="./views/Consulting _ Space - Multipurpose Responsive Template1_files/vendor.min.css">
  <link rel="stylesheet" href="./views/Consulting _ Space - Multipurpose Responsive Template1_files/bootstrap-icons.css">
  <link rel="stylesheet" href="./views/Consulting _ Space - Multipurpose Responsive Template1_files/aos.css">
  <style>
    
    @font-face {
        font-family: Vazir;
        src: url('Vazir.eot');
        src: url('Vazir.eot?#iefix') format('embedded-opentype'),
            url('Vazir.woff2') format('woff2'),
            url('Vazir.woff') format('woff'),
            url('Vazir.ttf') format('truetype');
        font-weight: normal;
        font-style: normal;
    }
    @font-face {
        font-family: Vazir;
        src: url('Vazir-Bold.eot');
        src: url('Vazir-Bold.eot?#iefix') format('embedded-opentype'),
            url('Vazir-Bold.woff2') format('woff2'),
            url('Vazir-Bold.woff') format('woff'),
            url('Vazir-Bold.ttf') format('truetype');
        font-weight: bold;
        font-style: normal;
    }
    @font-face {
        font-family: Vazir;
        src: url('Vazir-Black.eot');
        src: url('Vazir-Black.eot?#iefix') format('embedded-opentype'),
            url('Vazir-Black.woff2') format('woff2'),
            url('Vazir-Black.woff') format('woff'),
            url('Vazir-Black.ttf') format('truetype');
        font-weight: 900;
        font-style: normal;
    }
    @font-face {
        font-family: Vazir;
        src: url('Vazir-Medium.eot');
        src: url('Vazir-Medium.eot?#iefix') format('embedded-opentype'),
            url('Vazir-Medium.woff2') format('woff2'),
            url('Vazir-Medium.woff') format('woff'),
            url('Vazir-Medium.ttf') format('truetype');
        font-weight: 500;
        font-style: normal;
    }
    @font-face {
        font-family: Vazir;
        src: url('Vazir-Light.eot');
        src: url('Vazir-Light.eot?#iefix') format('embedded-opentype'),
            url('Vazir-Light.woff2') format('woff2'),
            url('Vazir-Light.woff') format('woff'),
            url('Vazir-Light.ttf') format('truetype');
        font-weight: 300;
        font-style: normal;
    }
    @font-face {
        font-family: Vazir;
        src: url('Vazir-Thin.eot');
        src: url('Vazir-Thin.eot?#iefix') format('embedded-opentype'),
            url('Vazir-Thin.woff2') format('woff2'),
            url('Vazir-Thin.woff') format('woff'),
            url('Vazir-Thin.ttf') format('truetype');
        font-weight: 100;
        font-style: normal;
    }
  </style>
  <!-- CSS Front Template -->
  <link rel="stylesheet" href="./views/Consulting _ Space - Multipurpose Responsive Template1_files/theme.min.css">
<style class="fslightbox-styles">.fslightbox-absoluted{position:absolute;top:0;left:0}.fslightbox-fade-in{animation:fslightbox-fade-in .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out{animation:fslightbox-fade-out .3s ease}.fslightbox-fade-in-strong{animation:fslightbox-fade-in-strong .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out-strong{animation:fslightbox-fade-out-strong .3s ease}@keyframes fslightbox-fade-in{from{opacity:.65}to{opacity:1}}@keyframes fslightbox-fade-out{from{opacity:.35}to{opacity:0}}@keyframes fslightbox-fade-in-strong{from{opacity:.3}to{opacity:1}}@keyframes fslightbox-fade-out-strong{from{opacity:1}to{opacity:0}}.fslightbox-cursor-grabbing{cursor:grabbing}.fslightbox-full-dimension{width:100%;height:100%}.fslightbox-open{overflow:hidden;height:100%}.fslightbox-flex-centered{display:flex;justify-content:center;align-items:center}.fslightbox-opacity-0{opacity:0!important}.fslightbox-opacity-1{opacity:1!important}.fslightbox-scrollbarfix{padding-right:17px}.fslightbox-transform-transition{transition:transform .3s}.fslightbox-container{font-family:Arial,sans-serif;position:fixed;top:0;left:0;background:linear-gradient(rgba(30,30,30,.9),#000 1810%);touch-action:pinch-zoom;z-index:1000000000;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.fslightbox-container *{box-sizing:border-box}.fslightbox-svg-path{transition:fill .15s ease;fill:#ddd}.fslightbox-nav{height:45px;width:100%;position:absolute;top:0;left:0}.fslightbox-slide-number-container{display:flex;justify-content:center;align-items:center;position:relative;height:100%;font-size:15px;color:#d7d7d7;z-index:0;max-width:55px;text-align:left}.fslightbox-slide-number-container .fslightbox-flex-centered{height:100%}.fslightbox-slash{display:block;margin:0 5px;width:1px;height:12px;transform:rotate(15deg);background:#fff}.fslightbox-toolbar{position:absolute;z-index:3;right:0;top:0;height:100%;display:flex;background:rgba(35,35,35,.65)}.fslightbox-toolbar-button{height:100%;width:45px;cursor:pointer}.fslightbox-toolbar-button:hover .fslightbox-svg-path{fill:#fff}.fslightbox-slide-btn-container{display:flex;align-items:center;padding:12px 12px 12px 6px;position:absolute;top:50%;cursor:pointer;z-index:3;transform:translateY(-50%)}@media (min-width:476px){.fslightbox-slide-btn-container{padding:22px 22px 22px 6px}}@media (min-width:768px){.fslightbox-slide-btn-container{padding:30px 30px 30px 6px}}.fslightbox-slide-btn-container:hover .fslightbox-svg-path{fill:#f1f1f1}.fslightbox-slide-btn{padding:9px;font-size:26px;background:rgba(35,35,35,.65)}@media (min-width:768px){.fslightbox-slide-btn{padding:10px}}@media (min-width:1600px){.fslightbox-slide-btn{padding:11px}}.fslightbox-slide-btn-container-previous{left:0}@media (max-width:475.99px){.fslightbox-slide-btn-container-previous{padding-left:3px}}.fslightbox-slide-btn-container-next{right:0;padding-left:12px;padding-right:3px}@media (min-width:476px){.fslightbox-slide-btn-container-next{padding-left:22px}}@media (min-width:768px){.fslightbox-slide-btn-container-next{padding-left:30px}}@media (min-width:476px){.fslightbox-slide-btn-container-next{padding-right:6px}}.fslightbox-down-event-detector{position:absolute;z-index:1}.fslightbox-slide-swiping-hoverer{z-index:4}.fslightbox-invalid-file-wrapper{font-size:22px;color:#eaebeb;margin:auto}.fslightbox-video{object-fit:cover}.fslightbox-youtube-iframe{border:0}.fslightbox-loader{display:block;margin:auto;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:67px;height:67px}.fslightbox-loader div{box-sizing:border-box;display:block;position:absolute;width:54px;height:54px;margin:6px;border:5px solid;border-color:#999 transparent transparent transparent;border-radius:50%;animation:fslightbox-loader 1.2s cubic-bezier(.5,0,.5,1) infinite}.fslightbox-loader div:nth-child(1){animation-delay:-.45s}.fslightbox-loader div:nth-child(2){animation-delay:-.3s}.fslightbox-loader div:nth-child(3){animation-delay:-.15s}@keyframes fslightbox-loader{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.fslightbox-source{position:relative;z-index:2;opacity:0}</style><script src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/clipboard.min.js.download"></script></head>

<body data-aos-easing="ease" data-aos-duration="650" data-aos-delay="0">
  <!-- ========== HEADER ========== -->
  <header id="header" class="navbar navbar-expand-lg navbar-floating navbar-end navbar-light navbar-scrolled" hsheader="true">
    <div class="container">
      <nav class="js-mega-menu navbar-nav-wrap navbar-floating-nav bg-white hs-menu-initialized hs-menu-horizontal">
        <!-- Default Logo -->
        <a class="navbar-brand" href="https://www.qitsource.ir" aria-label="Front">
          <img class="navbar-brand-logo" src="https://www.piperline.ir/core/rtl/assets/images/logo.png" alt="Logo">
        </a>
        <!-- End Default Logo -->

        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-default">
            <i class="bi-list"></i>
          </span>
          <span class="navbar-toggler-toggled">
            <i class="bi-x"></i>
          </span>
        </button>
        <!-- End Toggler -->

        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <!-- Landings -->


            <!-- Company -->
            <li class="hs-has-sub-menu nav-item">
              <a id="companyMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" role="button" aria-expanded="false">پلتفرم</a>

              <!-- Mega Menu -->
              <div class="hs-sub-menu dropdown-menu hs-sub-menu-desktop-lg fadeOut animated" aria-labelledby="companyMegaMenu" style="min-width: 14rem; display: none; animation-duration: 300ms; text-align: right;">
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=helpCenter">پایگاه دانش</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=news">اخبار زیست بوم</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=payment">مدیریت مالی</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=wallet">کیف پول</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=update">به روزرسانی ها</a>
                <a class="dropdown-item " href="https://support.webestica.com/">پشتیبانی</a>
                <a class="dropdown-item " href="core/docs/index.html">مستندات</a>

              </div>
              <!-- End Mega Menu -->
            </li>
            <!-- End Company -->

            <!-- Account -->
            <li class="hs-has-sub-menu nav-item">
              <a id="accountMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" role="button" aria-expanded="false">فضای کاری</a>

              <!-- Mega Menu -->
              <div class="hs-sub-menu dropdown-menu hs-sub-menu-desktop-lg animated fadeOut" aria-labelledby="accountMegaMenu" style="min-width: 14rem; display: none; animation-duration: 300ms; text-align: right;">


                <a class="dropdown-item " href="core/rtl/dashboard.php?content=listPost">توسعه دهندگان</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=cloud">فضای ابری</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=contact">مخاطبین</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=notifi">اعلان ها</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=profile">نمایه من</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=res">گزارشات</a>

              </div>
              <!-- End Mega Menu -->
            </li>
            <!-- End Account -->

            <!-- Pages -->
            <li class="hs-has-sub-menu nav-item">
              <a id="pagesMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" role="button" aria-expanded="false">صفحه ها</a>

              <!-- Mega Menu -->
              <div class="hs-sub-menu dropdown-menu hs-sub-menu-desktop-lg fadeOut animated" aria-labelledby="pagesMegaMenu" style="min-width: 14rem; display: none; animation-duration: 300ms; text-align: right;">
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=res">گزارشات</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=editProfile">ویرایش نمایه</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=payment">مدیریت مالی</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=wallet">کیف پول</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=apiDoc">مستندات توسعه دهندگان</a>

              </div>
              <!-- End Mega Menu -->
            </li>
            <!-- End Pages -->

            <!-- Blog -->
            <li class="hs-has-sub-menu nav-item">
              <a id="blogMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" role="button" aria-expanded="false">محتوا</a>

              <!-- Mega Menu -->
              <div class="hs-sub-menu dropdown-menu hs-sub-menu-desktop-lg fadeOut animated" aria-labelledby="blogMegaMenu" style="min-width: 14rem; display: none; animation-duration: 300ms; text-align: right;">
                <a class="dropdown-item " href="core/rtl/index.php?content=type&open=1">پست ها</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=type&open=2">دوره ها</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=type&open=3">فایل,منبع,مستند</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=type&open=4">ویدیو</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=type&open=5">سرویس,خدمات</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=listPost">مخازن شما</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=tags">هشتگ ها</a>
              </div>
              <!-- End Mega Menu -->
            </li>
            <!-- End Blog -->

            <!-- Portfolio -->
            <li class="hs-has-sub-menu nav-item">
              <a id="portfolioMegaMenu" class="hs-mega-menu-invoker nav-link dropdown-toggle " href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" role="button" aria-expanded="false">خانه</a>

              <!-- Mega Menu -->
              <div class="hs-sub-menu dropdown-menu hs-sub-menu-desktop-lg animated" aria-labelledby="portfolioMegaMenu" style="min-width: 14rem; display: none; animation-duration: 300ms; text-align: right;">
                <a class="dropdown-item " href="core/rtl/dashboard.php?content=listPost">داشبورد توسعه</a>
                <a class="dropdown-item " href="core/rtl/dashboard.php">خانه داشبورد</a>
                <a class="dropdown-item " href="core/rtl/index.php?content=homeACC">پیپرلاین خانه</a>
                <a class="dropdown-item " href="core/rtl/index.php">کاوش</a>
              </div>
              <!-- End Mega Menu -->
            </li>
            <!-- End Portfolio -->
            

								<?php
								            include './inc/vendor/autoload.php';

											// init configuration
											$clientID = '104536222073-4skbqtebb2m5arvq42fje2lc3s1rm8ds.apps.googleusercontent.com';
											$clientSecret = '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';
											$redirectUri = 'https://www.piperline.ir/index.php?controller=account&method=googleSignup';
											 
											// create Client Request to access Google API
											$client = new Google_Client();
											$client->setClientId($clientID);
											$client->setClientSecret($clientSecret);
											$client->setRedirectUri($redirectUri);
											$client->addScope("email");
											$client->addScope("profile");


								?>

            <!-- Button -->
            <li class="nav-item">
              <a class="btn btn-outline-primary btn-transition" href="<?php echo $client->createAuthUrl()?>" target="_blank"> حساب من <img style="width: 25px; height: 25px;" src="https://upload.wikimedia.org/wikipedia/commons/0/09/IOS_Google_icon.png" alt=""></a>
            </li>
            <!-- End Button -->
          </ul>
        </div>
        <!-- End Collapse -->
      </nav>
    </div>
  </header>
  

  <!-- ========== END HEADER ========== -->

  <!-- ========== MAIN CONTENT ========== -->
  <main id="content" role="main" class="overflow-hidden">
    <!-- Hero -->
    <div class="position-relative">
      <div class="container content-space-t-1 content-space-t-md-2 content-space-t-lg-5 content-space-b-2 content-space-b-sm-3 content-space-b-md-4 content-space-b-lg-0 content-space-b-xl-4">
        <div class="row">
          <div class="col-lg-5">
            <!-- Heading -->
            <div class="mb-5" style="text-align: right;">
            <img src="https://cdn3d.iconscout.com/3d/premium/thumb/victory-sign-6237542-5114803.png" style="width: 50px;" alt=""><img src="https://cdn3d.iconscout.com/3d/premium/thumb/hi-gesture-6597018-5466104.png?f=webp" style="width: 60px;" alt=""><img src="https://www.piperline.ir/public/img/logo/piperL.png" style="width: 50px;" alt="">
              <h1> پیپرلاین شبکه توضیع خدمات و مخزن های برخط </h1>
              <p class="lead">پلتفرم اجتماعی مخازن برخط و خدمات هر فایل برخط رشته ای جدید در محتوای توسعه دهندگان</p>
            </div>
            <!-- End Title & Description -->

            <div class="d-flex align-items-center mb-5" style="max-width: 25rem;">
              <div class="flex-shrink-0">
                <img class="avatar avatar-xss avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/figma-icon.svg" alt="Figma">
              </div>

              <div class="flex-grow-1 ms-2">
                <p class="small mb-0">Compatible with Figma <span class="badge bg-warning text-dark rounded-pill ms-1">نسخه آزمایشی</span></p>
              </div>
            </div>

            <div class="d-flex align-items-center gap-2 mb-8">
              <a class="btn btn-primary btn-transition me-2" href="core/rtl/index.php">
                شروع کنید<i class="bi-chevron-right small ms-1"></i>
              </a>

              <!-- Fancybox -->
              <a class="video-player btn btn-outline-primary btn-transition" href="https://www.youtube.com/watch?v=d4eDWc8g0e0" role="button" data-fslightbox="youtube-video">
                <i class="bi-play-circle-fill me-1"></i> Play video
              </a>
              <!-- End Fancybox -->
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>

      <!-- Gallery -->
      <div class="col-lg-7 position-lg-absolute top-0 end-0 transform-rotate-n40deg">
        <div class="row gx-3 align-items-end">
          <div class="col-3 mb-10">
            <div class="d-grid gap-3">
              <div data-aos="fade-up" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img6.jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="50" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img4.jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1.jpg" alt="Image Description">
              </div>
            </div>
          </div>
          <!-- End Col -->

          <div class="col-3">
            <div class="d-grid gap-3">
              <div data-aos="fade-up" data-aos-delay="150" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(1).jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="200" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(2).jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="250" class="aos-init aos-animate">
                <img class="img-fluid shadow-primary-lg rounded-2" src="./Consulting _ Space - Multipurpose Responsive Template1_files/img1(3).jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="300" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img5.jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="350" data-aos-offset="-50" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img9.jpg" alt="Image Description">
              </div>
            </div>
          </div>
          <!-- End Col -->

          <div class="col-3">
            <div class="d-grid gap-3">
              <div data-aos="fade-up" data-aos-delay="400" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img2.jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="450" class="aos-init aos-animate">
                <img class="img-fluid shadow-lg rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img3.jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="500" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img3(1).jpg" alt="Image Description">
              </div>
            </div>
          </div>
          <!-- End Col -->

          <div class="col-3 mb-10">
            <div class="d-grid gap-3">
              <div data-aos="fade-up" data-aos-delay="550" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(4).jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="600" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(5).jpg" alt="Image Description">
              </div>
              <div data-aos="fade-up" data-aos-delay="650" class="aos-init aos-animate">
                <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(2).jpg" alt="Image Description">
              </div>
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
      <!-- End Gallery -->
    </div>
    <!-- End Hero -->





    <div data-aos="fade-up" class="aos-init aos-animate">
          <a class="card card-transition bg-soft-warning shadow-none" href="https://www.qitsource.ir">
            <div class="card-body">
              <div class="row">
                <div class="col-lg-4 order-lg-2 mb-5 mb-lg-0">
                  <div class="d-flex flex-column h-100">
                    <div class="mb-7">
                      <h2 class="card-title h1"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
                          <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"/>
                          <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"/>
                          <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"/>
                          <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"/>
                          <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"/>
                        </svg> qitSource,Inc.</h2>
                      <p class="card-text text-body">The birth certificate of this service is created and supported by the knowledge-based company qitsource</p>
                    </div>

                    <!-- Testimonials -->
                    <div class="card shadow-none mt-auto">
                      <div class="card-body">
                        <!-- Blockquote -->
                        <figure>
                          <div class="mb-4">
                            <img class="avatar avatar-lg avatar-4x3" src="https://www.piperline.ir/core/rtl/assets/images/logo.png" style="width: 150px; height: 55px;" alt="Logo">
                          </div>

                          <blockquote class="blockquote">“ Social network for the distribution of online services and products or knowledge-based platform online services supported by qitsource. ”</blockquote>

                          <figcaption class="blockquote-footer">
                            <div class="d-flex align-items-center">
                              <div class="flex-shrink-0">
                                <img class="avatar avatar-circle" src="https://avatars.githubusercontent.com/u/72256856?v=4" alt="Image Description">
                              </div>

                              <div class="flex-grow-1 ms-3">
                                Aria Behrozian
                                <span class="blockquote-footer-source">Co-founder & CEO qitSource,Inc.</span>
                              </div>
                            </div>
                          </figcaption>
                        </figure>
                        <!-- End Blockquote -->
                      </div>
                    </div>
                    <!-- End Testimonials -->
                  </div>
                </div>
                <!-- End Col -->

                <div class="col-lg-8">
                  <div class="mb-5">
                    <img class="img-fluid rounded-2" src="https://www.piperline.ir/core/rtl/assets/images/logo.png" alt="Image Description">
                  </div>

                  <div class="row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                      <h4 class="card-title">Autonomy and attitude</h4>
                      <p class="card-text text-body">We're a team of self-starters who take serious pride in our work – and it shows.</p>
                    </div>
                    <!-- End Col -->

                    <div class="col-sm-6">
                      <h4 class="card-title">Teamwork makes the dream work</h4>
                      <p class="card-text text-body">We work together to bring our passions and expertise to make Teachable the best it can be.</p>
                    </div>
                    <!-- End Col -->
                  </div>
                  <!-- End Row -->
                </div>
                <!-- End Col -->
              </div>
              <!-- End Row -->
            </div>
          </a>
        </div>





    <div class="overflow-hidden">
      <div class="container content-space-t-2 content-space-t-lg-3 content-space-b-1 content-space-b-lg-3">
        <!-- Heading -->
        <div class="w-md-75 w-lg-50 text-center mx-md-auto mb-5 mb-md-9">
          <img src="https://cdn3d.iconscout.com/3d/premium/thumb/cross-chain-connection-7286413-6152104.png?f=avif" style="width: 100px;" alt="">
          <h2> مایکرو سرویس های پیپرلاین </h2>
          <p>مجموعه ای از مینی سرویس هایی که ما در پیپرلاین توسته میدهیم و جزو دایره سرویس های پیپرلاین میشوند</p>
        </div>
        <!-- End Heading -->

        <div class="row">
          <div class="col-lg-4 d-none d-lg-block">
            <!-- Card -->
            <div class="position-relative pe-lg-4">
              <a class="card card-transition shadow-none bg-img-start" href="#" style="background-image: url(https://www.piperline.ir/public/img/logo/piperL.png); min-height: 27rem;">
                <div class="card-body">
                  <h4 class="card-title">پیپرلاین</h4>
                  <p class="card-text text-body">ماکرو سرویس ها</p>
                </div>

                <div class="card-footer pt-0">
                  <span class="card-link">Browse tools <i class="bi-chevron-right small ms-1"></i></span>
                </div>
              </a>

              <!-- SVG Shape -->
              <div class="position-absolute bottom-0 start-0 zi-n1 mb-n7 ms-n7" style="width: 12rem;">
                <img class="w-100" src="./assets/svg/components/dots-lg.svg" alt="SVG">
              </div>
              <!-- End SVG Shape -->
            </div>
            <!-- End Card -->
          </div>
          <!-- End Col -->

          <div class="col-lg-8" style="text-align: right;">
            <div class="row">
              <div class="col-sm-6 mb-3 mb-sm-7">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path opacity="0.3" d="M10.9607 12.9128H18.8607C19.4607 12.9128 19.9607 13.4128 19.8607 14.0128C19.2607 19.0128 14.4607 22.7128 9.26068 21.7128C5.66068 21.0128 2.86071 18.2128 2.16071 14.6128C1.16071 9.31284 4.96069 4.61281 9.86069 4.01281C10.4607 3.91281 10.9607 4.41281 10.9607 5.01281V12.9128V12.9128Z" fill="#035A4B"></path>
                      <path d="M12.9607 10.9128V3.01281C12.9607 2.41281 13.4607 1.91281 14.0607 2.01281C16.0607 2.21281 17.8607 3.11284 19.2607 4.61284C20.6607 6.01284 21.5607 7.91285 21.8607 9.81285C21.9607 10.4129 21.4607 10.9128 20.8607 10.9128H12.9607V10.9128Z" fill="#035A4B"></path>
                    </svg>

                  </span>

                  <h3 class="h4">پیپرلاین اسمارت داشبورد</h3>
                  <p>داشبورد کاری هوشمند برای تعامل با محتوای شما و پیکربندی بهینه محتوا شما</p>
                </div>
                <!-- End Icon Blocks -->
              </div>

              <div class="col-sm-6 mb-3 mb-sm-7">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
                      <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"/>
                      <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"/>
                      <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"/>
                      <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"/>
                      <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"/>
                    </svg>

                  </span>

                  <h4>حساب یکپارچه QPassID</h4>
                  <p>تکنولوژی توسعه یافته توسط کوییت سورس برای مدیریت حساب های شما و اتصال یکپارچه و ایمن</p>
                  Powered by <strong><a href="https://www.qitsource.ir">qitSource,Inc.</a></strong>
                </div>
                <!-- End Icon Blocks -->
              </div>

              <div class="col-sm-6 mb-3 mb-sm-0">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-incognito" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="m4.736 1.968-.892 3.269-.014.058C2.113 5.568 1 6.006 1 6.5 1 7.328 4.134 8 8 8s7-.672 7-1.5c0-.494-1.113-.932-2.83-1.205a1.032 1.032 0 0 0-.014-.058l-.892-3.27c-.146-.533-.698-.849-1.239-.734C9.411 1.363 8.62 1.5 8 1.5c-.62 0-1.411-.136-2.025-.267-.541-.115-1.093.2-1.239.735Zm.015 3.867a.25.25 0 0 1 .274-.224c.9.092 1.91.143 2.975.143a29.58 29.58 0 0 0 2.975-.143.25.25 0 0 1 .05.498c-.918.093-1.944.145-3.025.145s-2.107-.052-3.025-.145a.25.25 0 0 1-.224-.274ZM3.5 10h2a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 1-3 0v-1a.5.5 0 0 1 .5-.5Zm-1.5.5c0-.175.03-.344.085-.5H2a.5.5 0 0 1 0-1h3.5a1.5 1.5 0 0 1 1.488 1.312 3.5 3.5 0 0 1 2.024 0A1.5 1.5 0 0 1 10.5 9H14a.5.5 0 0 1 0 1h-.085c.055.156.085.325.085.5v1a2.5 2.5 0 0 1-5 0v-.14l-.21-.07a2.5 2.5 0 0 0-1.58 0l-.21.07v.14a2.5 2.5 0 0 1-5 0v-1Zm8.5-.5h2a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 1-3 0v-1a.5.5 0 0 1 .5-.5Z"/>
                    </svg>

                  </span>

                  <h4>امنیت یکپارچه</h4>
                  <p>کوییت سورس با استفاده از تکنولوژی های یادگیری ماشینی امنیت را برای تمام حساب های کیوپس آیدی سرتاسر رمزنگاری کرده است</p>
                </div>
                <!-- End Icon Blocks -->
              </div>

              <div class="col-sm-6">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M15 19.5229C15 20.265 15.9624 20.5564 16.374 19.9389L22.2227 11.166C22.5549 10.6676 22.1976 10 21.5986 10H17V4.47708C17 3.73503 16.0376 3.44363 15.626 4.06106L9.77735 12.834C9.44507 13.3324 9.80237 14 10.4014 14H15V19.5229Z" fill="#035A4B"></path>
                      <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M3 6.5C3 5.67157 3.67157 5 4.5 5H9.5C10.3284 5 11 5.67157 11 6.5C11 7.32843 10.3284 8 9.5 8H4.5C3.67157 8 3 7.32843 3 6.5ZM3 18.5C3 17.6716 3.67157 17 4.5 17H9.5C10.3284 17 11 17.6716 11 18.5C11 19.3284 10.3284 20 9.5 20H4.5C3.67157 20 3 19.3284 3 18.5ZM2.5 11C1.67157 11 1 11.6716 1 12.5C1 13.3284 1.67157 14 2.5 14H6.5C7.32843 14 8 13.3284 8 12.5C8 11.6716 7.32843 11 6.5 11H2.5Z" fill="#035A4B"></path>
                    </svg>

                  </span>

                  <h4>Piperline Pay</h4>
                  <p>سرویس بانکی پیپرلاین برای انتقال ایمن و سریع پول بین حساب های پیپرلاین</p>
                </div>
                <!-- End Icon Blocks -->
              </div>

              <div class="col-sm-6 mb-3 mb-sm-0">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                      <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/>
                    </svg>
                  </span>

                  <h4>اعتماد دیجیتالی پیپرلاین</h4>
                  <p>با استفاده از ابزار های هوش مصنوعی و اتصال به سازمان ها و پلیس امنیت دیجیتالی کیفیت و صلاحیت مخزن ها مورد گفتگو بوده و تضمین اعتبار مخزن ها</p>
                </div>
                <!-- End Icon Blocks -->
              </div>


              <div class="col-sm-6">
                <!-- Icon Blocks -->
                <div class="pe-lg-6">
                  <span class="svg-icon text-primary mb-4">
                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path opacity="0.3" d="M16 0.200012H4C1.8 0.200012 0 2.00001 0 4.20001V16.2C0 18.4 1.8 20.2 4 20.2H16C18.2 20.2 20 18.4 20 16.2V4.20001C20 2.00001 18.2 0.200012 16 0.200012ZM15 10.2C15 10.9 14.8 11.6 14.6 12.2H18V16.2C18 17.3 17.1 18.2 16 18.2H12V14.8C11.4 15.1 10.7 15.2 10 15.2C9.3 15.2 8.6 15 8 14.8V18.2H4C2.9 18.2 2 17.3 2 16.2V12.2H5.4C5.1 11.6 5 10.9 5 10.2C5 9.50001 5.2 8.80001 5.4 8.20001H2V4.20001C2 3.10001 2.9 2.20001 4 2.20001H8V5.60001C8.6 5.30001 9.3 5.20001 10 5.20001C10.7 5.20001 11.4 5.40001 12 5.60001V2.20001H16C17.1 2.20001 18 3.10001 18 4.20001V8.20001H14.6C14.8 8.80001 15 9.50001 15 10.2Z" fill="#035A4B"></path>
                      <path d="M12 1.40002C15.4 2.20002 18 4.80003 18.8 8.20003H14.6C14.1 7.00003 13.2 6.10003 12 5.60003V1.40002V1.40002ZM5.40001 8.20003C5.90001 7.00003 6.80001 6.10003 8.00001 5.60003V1.40002C4.60001 2.20002 2.00001 4.80003 1.20001 8.20003H5.40001ZM14.6 12.2C14.1 13.4 13.2 14.3 12 14.8V19C15.4 18.2 18 15.6 18.8 12.2H14.6V12.2ZM8.00001 14.8C6.80001 14.3 5.90001 13.4 5.40001 12.2H1.20001C2.00001 15.6 4.60001 18.2 8.00001 19V14.8V14.8Z" fill="#035A4B"></path>
                    </svg>

                  </span>

                  <h4>کیف پول دیجیتال</h4>
                  <p>ولت توسعه یافته متصل به ارز های دیجیتال و ارز های بانکی معتبر با پشتوانه ارز دیجیتال سیفای کوین</p>
                </div>
                <!-- End Icon Blocks -->
              </div>
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
    </div>


    <div class="container">
      <!-- Heading -->
      <div class="w-md-75 w-lg-50 text-center mx-md-auto mb-5 mb-md-9">
        <span class="text-cap">هدف های مارکتینگ ما</span>
        <h2>سرویس های مبتنی بر مارکت</h2>
      </div>
      <!-- End Heading -->

      <div class="row mb-5 mb-md-9" style="text-align: right;">
        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.302 11.35L12.002 20.55H21.202C21.802 20.55 22.202 19.85 21.902 19.35L17.302 11.35Z" fill="#035A4B"></path>
                  <path opacity="0.3" d="M12.002 20.55H2.802C2.202 20.55 1.80202 19.85 2.10202 19.35L6.70203 11.45L12.002 20.55ZM11.302 3.45L6.70203 11.35H17.302L12.702 3.45C12.402 2.85 11.602 2.85 11.302 3.45Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">انتشار خدمات و سرویس ها</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>افزاد و سازمان های مختلف مکان های مختلف خدمات و سرویس های گوناگونی برای اراعه داند که میتوان آنها را برخط اراعه داد پیپرلاین پلتفرمی قابل انعطاف برای این کار است</p>
        </div>
        <!-- End Col -->

        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" d="M21 2H13C12.4 2 12 2.4 12 3V13C12 13.6 12.4 14 13 14H21C21.6 14 22 13.6 22 13V3C22 2.4 21.6 2 21 2ZM15.7 8L14 10.1V5.80005L15.7 8ZM15.1 4H18.9L17 6.40002L15.1 4ZM17 9.59998L18.9 12H15.1L17 9.59998ZM18.3 8L20 5.90002V10.2L18.3 8ZM9 2H3C2.4 2 2 2.4 2 3V21C2 21.6 2.4 22 3 22H9C9.6 22 10 21.6 10 21V3C10 2.4 9.6 2 9 2ZM4.89999 12L4 14.8V9.09998L4.89999 12ZM4.39999 4H7.60001L6 8.80005L4.39999 4ZM6 15.2L7.60001 20H4.39999L6 15.2ZM7.10001 12L8 9.19995V14.9L7.10001 12Z" fill="#035A4B"></path>
                  <path d="M21 18H13C12.4 18 12 17.6 12 17C12 16.4 12.4 16 13 16H21C21.6 16 22 16.4 22 17C22 17.6 21.6 18 21 18ZM19 21C19 20.4 18.6 20 18 20H13C12.4 20 12 20.4 12 21C12 21.6 12.4 22 13 22H18C18.6 22 19 21.6 19 21Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">مدیریت پروژه</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>فریلنسر ها و یا افراد مختلفی که در زمینه های خاصتی تخصص دارند میتواننند بر بستر پلتفرم پیپرلاین تخصص خود را انتشار داده و از سراسر دنیا درخواست های همکاری دریافت کنند</p>
        </div>
        <!-- End Col -->

        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7 mb-md-0">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M4.85714 1H11.7364C12.0911 1 12.4343 1.12568 12.7051 1.35474L17.4687 5.38394C17.8057 5.66895 18 6.08788 18 6.5292V19.0833C18 20.8739 17.9796 21 16.1429 21H4.85714C3.02045 21 3 20.8739 3 19.0833V2.91667C3 1.12612 3.02045 1 4.85714 1ZM7 13C7 12.4477 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13C16 13.5523 15.5523 14 15 14H8C7.44772 14 7 13.5523 7 13ZM8 16C7.44772 16 7 16.4477 7 17C7 17.5523 7.44772 18 8 18H11C11.5523 18 12 17.5523 12 17C12 16.4477 11.5523 16 11 16H8Z" fill="#035A4B"></path>
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M6.85714 3H14.7364C15.0911 3 15.4343 3.12568 15.7051 3.35474L20.4687 7.38394C20.8057 7.66895 21 8.08788 21 8.5292V21.0833C21 22.8739 20.9796 23 19.1429 23H6.85714C5.02045 23 5 22.8739 5 21.0833V4.91667C5 3.12612 5.02045 3 6.85714 3ZM7 13C7 12.4477 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13C16 13.5523 15.5523 14 15 14H8C7.44772 14 7 13.5523 7 13ZM8 16C7.44772 16 7 16.4477 7 17C7 17.5523 7.44772 18 8 18H11C11.5523 18 12 17.5523 12 17C12 16.4477 11.5523 16 11 16H8Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">دانشنامه پیپرلاین</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>بستری برای محققان و پژوهشگران تا بتوانند طرح ها و مقالات و یا کتاب های برخط خود را به جامعه خود اراعه دهند و به شکل ایمن آنها را به انتشار و فروش برسانند</p>
        </div>
        <!-- End Col -->

        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7 mb-md-0">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="#035A4B"></path>
                  <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">محصولات برخط</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>در دنیا محصولات و مخزن های زیادی وجود دارند که به صورت برخط اراعه میشوند پلتفرم پیپرلاین بستر خوبی برای اراعه محصولات دیجیتالی میتواند باشد</p>
        </div>
        <!-- End Col -->

        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7 mb-md-0">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M15 19.5229C15 20.265 15.9624 20.5564 16.374 19.9389L22.2227 11.166C22.5549 10.6676 22.1976 10 21.5986 10H17V4.47708C17 3.73503 16.0376 3.44363 15.626 4.06106L9.77735 12.834C9.44507 13.3324 9.80237 14 10.4014 14H15V19.5229Z" fill="#035A4B"></path>
                  <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M3 6.5C3 5.67157 3.67157 5 4.5 5H9.5C10.3284 5 11 5.67157 11 6.5C11 7.32843 10.3284 8 9.5 8H4.5C3.67157 8 3 7.32843 3 6.5ZM3 18.5C3 17.6716 3.67157 17 4.5 17H9.5C10.3284 17 11 17.6716 11 18.5C11 19.3284 10.3284 20 9.5 20H4.5C3.67157 20 3 19.3284 3 18.5ZM2.5 11C1.67157 11 1 11.6716 1 12.5C1 13.3284 1.67157 14 2.5 14H6.5C7.32843 14 8 13.3284 8 12.5C8 11.6716 7.32843 11 6.5 11H2.5Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">آکادمی آموزشی</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>موسسه ها و یا حتی افراد مختلفی توان آموزش دادن مهارت های خود را به دیگران دارند و یا مخزن های متعددی در این حوضه ئجود دارد پیپرلاین بستری را برای اراعه این نوع محصولات آموزشی فراهم کرده است که جامعه دانشکاهی میتوانند از آن استفاده کنند</p>
        </div>
        <!-- End Col -->

        <div class="col-sm-6 col-md-4">
          <!-- Icon Block -->
          <div class="d-flex align-items-center mb-2">
            <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="#035A4B"></path>
                  <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="#035A4B"></path>
                </svg>

              </span>
            </div>

            <div class="flex-grow-1 ms-3">
              <h4 class="mb-0">جامعه دانشگاهی و متخصص پیپرلاین</h4>
            </div>
          </div>
          <!-- End Icon Block -->

          <p>متخصصین و مهندسین مختلف برای راهبری و اجرای پروژه های کاری و یا دانشجویی خود نیاز به مخازن زیادی در حوضه کاری خود دارند تا بتوانند پروژه های خود را انجام دهند پیپرلاین با این سرویس بستری امن برای انتشار فایل های مختلف و فروش آنها را برای کاربران توسعه دهنده خود فراهم کرده است</p>
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->

      <div class="text-center">
        <div class="d-grid d-sm-flex justify-content-center gap-2 mb-3">
          <a class="btn btn-primary btn-transition" href="index.php?controller=account&method=login">به جمع توسعه دهندگان پیپرلاین بپیوندید</a>
          <a class="btn btn-link" href="#">Let's Talk <i class="bi-chevron-right small ms-1"></i></a>
        </div>

        <p class="small">Start free trial. * No credit card required.</p>
      </div>
      
    </div>



    <div class="container content-space-2 content-space-t-lg-3">
      <!-- Heading -->
      <div class="w-md-75 w-lg-50 text-center mx-md-auto mb-5 mb-md-9">
        <h2>Join 14,000+ agencies and businesses using Front today!</h2>
      </div>
      <!-- End Heading -->

      <!-- Swiper Slider -->
      <div class="js-swiper-hero-clients swiper text-center swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
        <div class="swiper-wrapper" id="swiper-wrapper-4da056ab27679313" aria-live="polite" style="transform: translate3d(0px, 0px, 0px);">
          <!-- Slide -->
          <div class="swiper-slide swiper-slide-active" role="group" aria-label="1 / 6" style="width: 144.5px;">
            <img class="avatar avatar-lg avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/capsule-dark.svg" alt="Logo">
          </div>
          <!-- End Slide -->

          <div class="swiper-slide swiper-slide-next" role="group" aria-label="2 / 6" style="width: 144.5px;">
            <img class="avatar avatar-lg avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/fitbit-dark.svg" alt="Logo">
          </div>
          <!-- End Slide -->

          <div class="swiper-slide" role="group" aria-label="3 / 6" style="width: 144.5px;">
            <img class="avatar avatar-lg avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/forbes-dark.svg" alt="Logo">
          </div>
          <!-- End Slide -->

          <div class="swiper-slide" role="group" aria-label="4 / 6" style="width: 144.5px;">
            <img class="avatar avatar-lg avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/mailchimp-dark.svg" alt="Logo">
          </div>
          <!-- End Slide -->

          <div class="swiper-slide" role="group" aria-label="5 / 6" style="width: 144.5px;">
            <img class="avatar avatar-lg avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/layar-dark.svg" alt="Logo">
          </div>
          <!-- End Slide -->


        </div>
      <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
      <!-- End Swiper Slider -->
    </div>



    <div class="container content-space-1 content-space-b-lg-3">
      <div class="row align-items-lg-center">
        <div class="col-lg-5 mb-5 mb-lg-0">
          <div class="pe-lg-6">
            <div class="mb-4">
              <h2 class="h1">All-in-one</h2>
            </div>

            <div class="d-flex gap-3 mb-4">
              <img class="avatar avatar-xss avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/slack-icon.svg" alt="Logo">
              <img class="avatar avatar-xss avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/jira-icon.svg" alt="Logo">
              <img class="avatar avatar-xss avatar-4x3" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/gitlab-icon.svg" alt="Logo">
            </div>

            <div class="mb-4">
              <p>Front is a collaboration hub for work, no matter what work you do. It's a place where conversations happen, decisions are made, and information is always at your fingertips. With Front, your team is better connected.</p>
            </div>

            <a class="link" href="#">Get started <i class="bi-chevron-right small ms-1"></i></a>
          </div>
        </div>
        <!-- End Col -->

        <div class="col-lg-7">
          <!-- Browser Device -->
          <figure class="device-browser">
            <div class="device-browser-header">
              <div class="device-browser-header-btn-list">
                <span class="device-browser-header-btn-list-btn"></span>
                <span class="device-browser-header-btn-list-btn"></span>
                <span class="device-browser-header-btn-list-btn"></span>
              </div>
              <div class="device-browser-header-browser-bar">www.piperline.ir</div>
            </div>

            <div class="device-browser-frame">
              <img class="device-browser-img" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/Screenshot (34).png" alt="Image Description">
            </div>
          </figure>
          <!-- End Browser Device -->
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->
    </div>





    <div class="bg-dark rounded-2 mx-3 mx-xl-10" style="background-image: url(./assets/svg/components/wave-pattern-light.svg);">
      <div class="container-xl container-fluid content-space-1 content-space-md-2 px-4 px-md-8 px-lg-10">
        <!-- Heading -->
        <div class="text-center mx-md-auto mb-5 mb-md-9">
          <h2 class="h1 text-white">خواصیت های سازمان یافته </h2>
        </div>
        <!-- End Heading -->

        <!-- Swiper Slider -->
        <div class="js-swiper-card-blocks swiper swiper-equal-height mb-7 swiper-initialized swiper-horizontal swiper-backface-hidden">
          <div class="swiper-wrapper" id="swiper-wrapper-738732f5b1696c110" aria-live="polite" style="transform: translate3d(0px, 0px, 0px);">
            <!-- Slide -->
            <div class="swiper-slide swiper-slide-active" role="group" aria-label="1 / 3" style="width: 276.333px; margin-right: 15px;">
              <!-- Card -->
              <div class="card text-center">
                <div class="card-body">
                  <div class="mb-4">
                    <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/oc-looking-for-answers.svg" alt="Image Description" style="height: 12rem;">
                  </div>

                  <h3 class="card-title">بهینه سازی</h3>
                  <p class="card-text">ما سرتاسر پلتفرممان را طوری بهینه کرده ایم که همه شانس دیده شدن و فروش بالا را دارند و با الگوریتم های توسعه یافته به آنها کمک کرده ایم تا افراد نیاز هایشان را زودتر پیدا کنند</p>
                </div>
              </div>
              <!-- End Card -->
            </div>
            <!-- End Slide -->

            <!-- Slide -->
            <div class="swiper-slide swiper-slide-next" role="group" aria-label="2 / 3" style="width: 276.333px; margin-right: 15px;">
              <!-- Card -->
              <div class="card text-center">
                <div class="card-body">
                  <div class="mb-4">
                    <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/oc-growing.svg" alt="Image Description" style="height: 12rem;">
                  </div>

                  <h3 class="card-title">امنیت</h3>
                  <p class="card-text">ما امنیت را طوری بر پلتفرممان حاکم کرده ایم که کاربرانمان نگرانی اعتبار سنجی و کیفیت را نخواهند داشت ما از گام اول تا بهره برداری همراه شما هستیم همچنین برای توسعه دهندگان هم حمایت های توسعه یافته ای انجام میدهیم</p>
                </div>
              </div>
              <!-- End Card -->
            </div>
            <!-- End Slide -->

            <!-- Slide -->
            <div class="swiper-slide" role="group" aria-label="3 / 3" style="width: 276.333px; margin-right: 15px;">
              <!-- Card -->
              <div class="card text-center">
                <div class="card-body">
                  <div class="mb-4">
                    <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/oc-chatting.svg" alt="Image Description" style="height: 12rem;">
                  </div>

                  <h3 class="card-title">همایت ها</h3>
                  <p class="card-text">شما از وقتی همکاری با مارا شروع میکنید محتوای شما مورد حمایت ما خواهد بود و ما برای بهینه سازی آن به شما کمک خواهیم کرد و شما در این مسیر تنها نیستید</p>
                </div>
              </div>
              <!-- End Card -->
            </div>
            <!-- End Slide -->
          </div>

          <!-- Swiper Pagination -->
          <div class="js-swiper-card-blocks-pagination swiper-pagination swiper-pagination-light d-lg-none swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal swiper-pagination-bullets-dynamic swiper-pagination-lock" style="width: 40px;"><span class="swiper-pagination-bullet swiper-pagination-bullet-active swiper-pagination-bullet-active-main" tabindex="0" role="button" aria-label="Go to slide 1" aria-current="true" style="left: 0px;"></span></div>
        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
        <!-- End Swiper Slider -->

        <div class="text-center">
          <p class="text-white">See Help Front in action. <a class="link link-warning" href="#">Get a demo <i class="bi-arrow-right-circle-fill align-middle fs-3 ms-1"></i></a></p>
        </div>
      </div>
    </div>

    <br>


    <div class="container content-space-2 content-space-t-lg-4 content-space-b-lg-3">
      <!-- Heading -->
      <div class="w-lg-50 text-center mx-lg-auto mb-5">
        <h2>پرداخت ایمن پیپرلاین</h2>
        <p>ما با استفاده از سرویس پرداخت ایمن همه پرداخت های شمارا پوشش میدهیم و دادو ستد را در پلتفرم خودمان آسان کرده ایم</p>
      </div>
      <!-- End Heading -->

      <!-- Fancybox -->
      <div class="text-center mb-10">
        <a class="video-player btn btn-outline-primary" href="https://www.youtube.com/watch?v=d4eDWc8g0e0" role="button" data-fslightbox="youtube-video">
          <i class="bi-play-circle-fill me-1"></i> Watch and learn how it works
        </a>
      </div>
      <!-- End Fancybox -->

      <div class="w-lg-75 mx-lg-auto mb-10">
        <div class="row justify-content-md-center">
          <div class="col-sm-4 mb-5 mb-sm-0">
            <div class="text-center px-sm-4">
              <span class="svg-icon text-primary mb-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM12 7C10.3 7 9 8.3 9 10C9 11.7 10.3 13 12 13C13.7 13 15 11.7 15 10C15 8.3 13.7 7 12 7Z" fill="#035A4B"></path>
                  <path d="M12 22C14.6 22 17 21 18.7 19.4C17.9 16.9 15.2 15 12 15C8.8 15 6.09999 16.9 5.29999 19.4C6.99999 21 9.4 22 12 22Z" fill="#035A4B"></path>
                </svg>

              </span>
              <h4>ولت دیجیتال</h4>
            </div>
          </div>
          <!-- End Col -->

          <div class="col-sm-4 mb-5 mb-sm-0">
            <div class="text-center px-sm-4">
              <span class="svg-icon text-primary mb-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 19.725V18.725C20 18.125 19.6 17.725 19 17.725H5C4.4 17.725 4 18.125 4 18.725V19.725H3C2.4 19.725 2 20.125 2 20.725V21.725H22V20.725C22 20.125 21.6 19.725 21 19.725H20Z" fill="#035A4B"></path>
                  <path opacity="0.3" d="M22 6.725V7.725C22 8.325 21.6 8.725 21 8.725H18C18.6 8.725 19 9.125 19 9.725C19 10.325 18.6 10.725 18 10.725V15.725C18.6 15.725 19 16.125 19 16.725V17.725H15V16.725C15 16.125 15.4 15.725 16 15.725V10.725C15.4 10.725 15 10.325 15 9.725C15 9.125 15.4 8.725 16 8.725H13C13.6 8.725 14 9.125 14 9.725C14 10.325 13.6 10.725 13 10.725V15.725C13.6 15.725 14 16.125 14 16.725V17.725H10V16.725C10 16.125 10.4 15.725 11 15.725V10.725C10.4 10.725 10 10.325 10 9.725C10 9.125 10.4 8.725 11 8.725H8C8.6 8.725 9 9.125 9 9.725C9 10.325 8.6 10.725 8 10.725V15.725C8.6 15.725 9 16.125 9 16.725V17.725H5V16.725C5 16.125 5.4 15.725 6 15.725V10.725C5.4 10.725 5 10.325 5 9.725C5 9.125 5.4 8.725 6 8.725H3C2.4 8.725 2 8.325 2 7.725V6.725L11 2.225C11.6 1.925 12.4 1.925 13.1 2.225L22 6.725ZM12 3.725C11.2 3.725 10.5 4.425 10.5 5.225C10.5 6.025 11.2 6.725 12 6.725C12.8 6.725 13.5 6.025 13.5 5.225C13.5 4.425 12.8 3.725 12 3.725Z" fill="#035A4B"></path>
                </svg>

              </span>
              <h4>اتصال به شبکه بانکی</h4>
            </div>
          </div>
          <!-- End Col -->

          <div class="col-sm-4">
            <div class="text-center px-sm-4">
              <span class="svg-icon text-primary mb-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M4 4L11.6314 2.56911C11.875 2.52343 12.125 2.52343 12.3686 2.56911L20 4V11.9033C20 15.696 18.0462 19.2211 14.83 21.2313L12.53 22.6687C12.2057 22.8714 11.7943 22.8714 11.47 22.6687L9.17001 21.2313C5.95382 19.2211 4 15.696 4 11.9033L4 4Z" fill="#035A4B"></path>
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M11.175 14.75C10.9354 14.75 10.6958 14.6542 10.5042 14.4625L8.58749 12.5458C8.20415 12.1625 8.20415 11.5875 8.58749 11.2042C8.97082 10.8208 9.59374 10.8208 9.92915 11.2042L11.175 12.45L14.3375 9.2875C14.7208 8.90417 15.2958 8.90417 15.6792 9.2875C16.0625 9.67083 16.0625 10.2458 15.6792 10.6292L11.8458 14.4625C11.6542 14.6542 11.4146 14.75 11.175 14.75Z" fill="#035A4B"></path>
                </svg>

              </span>
              <h4>اتصال به ارزدیجیتال</h4>
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>

      <div class="mx-auto aos-init aos-animate" style="max-width: 25rem;" data-aos="fade-up">
        <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/visa-card.svg" alt="Image Description">
      </div>
    </div>




    <div id="aboutSection" class="container content-space-t-2 content-space-t-lg-3">
      <!-- Heading -->
      <div class="w-lg-75 text-center mx-auto mb-5 mb-sm-9">
        <h2 class="h1">What we do?</h2>
        <p>A flexible theme for modern SaaS businesses</p>
      </div>
      <!-- End Heading -->

      <div class="row">
        <div class="col-md-4 mb-7">
          <!-- Icon Blocks -->
          <div class="text-center px-lg-3">
            <span class="svg-icon svg-icon-lg text-primary mb-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.6 5.59998L20.9 10.9C21.3 11.3 21.3 11.9 20.9 12.3L17.6 15.6L11.6 9.59998L15.6 5.59998ZM2.3 12.3L7.59999 17.6L11.6 13.6L5.59999 7.59998L2.3 10.9C1.9 11.3 1.9 11.9 2.3 12.3Z" fill="#035A4B"></path>
                <path opacity="0.3" d="M17.6 15.6L12.3 20.9C11.9 21.3 11.3 21.3 10.9 20.9L7.59998 17.6L13.6 11.6L17.6 15.6ZM10.9 2.3L5.59998 7.6L9.59998 11.6L15.6 5.6L12.3 2.3C11.9 1.9 11.3 1.9 10.9 2.3Z" fill="#035A4B"></path>
              </svg>

            </span>

            <h3>Industry-leading designs</h3>
            <p>Achieve virtually any design and layout from within the one template.</p>
          </div>
          <!-- End Icon Blocks -->
        </div>
        <!-- End Col -->

        <div class="col-md-4 mb-7">
          <!-- Icon Blocks -->
          <div class="text-center px-lg-3">
            <span class="svg-icon svg-icon-lg text-primary mb-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M4.85714 1H11.7364C12.0911 1 12.4343 1.12568 12.7051 1.35474L17.4687 5.38394C17.8057 5.66895 18 6.08788 18 6.5292V19.0833C18 20.8739 17.9796 21 16.1429 21H4.85714C3.02045 21 3 20.8739 3 19.0833V2.91667C3 1.12612 3.02045 1 4.85714 1ZM7 13C7 12.4477 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13C16 13.5523 15.5523 14 15 14H8C7.44772 14 7 13.5523 7 13ZM8 16C7.44772 16 7 16.4477 7 17C7 17.5523 7.44772 18 8 18H11C11.5523 18 12 17.5523 12 17C12 16.4477 11.5523 16 11 16H8Z" fill="#035A4B"></path>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M6.85714 3H14.7364C15.0911 3 15.4343 3.12568 15.7051 3.35474L20.4687 7.38394C20.8057 7.66895 21 8.08788 21 8.5292V21.0833C21 22.8739 20.9796 23 19.1429 23H6.85714C5.02045 23 5 22.8739 5 21.0833V4.91667C5 3.12612 5.02045 3 6.85714 3ZM7 13C7 12.4477 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13C16 13.5523 15.5523 14 15 14H8C7.44772 14 7 13.5523 7 13ZM8 16C7.44772 16 7 16.4477 7 17C7 17.5523 7.44772 18 8 18H11C11.5523 18 12 17.5523 12 17C12 16.4477 11.5523 16 11 16H8Z" fill="#035A4B"></path>
              </svg>

            </span>

            <h3>Learn from the docs</h3>
            <p>Whether you're a startup or a global enterprise, learn how to integrate with Front.</p>
          </div>
          <!-- End Icon Blocks -->
        </div>
        <!-- End Col -->

        <div class="col-md-4 mb-7">
          <!-- Icon Blocks -->
          <div class="text-center px-lg-3">
            <span class="svg-icon svg-icon-lg text-primary mb-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15 19.5229C15 20.265 15.9624 20.5564 16.374 19.9389L22.2227 11.166C22.5549 10.6676 22.1976 10 21.5986 10H17V4.47708C17 3.73503 16.0376 3.44363 15.626 4.06106L9.77735 12.834C9.44507 13.3324 9.80237 14 10.4014 14H15V19.5229Z" fill="#035A4B"></path>
                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M3 6.5C3 5.67157 3.67157 5 4.5 5H9.5C10.3284 5 11 5.67157 11 6.5C11 7.32843 10.3284 8 9.5 8H4.5C3.67157 8 3 7.32843 3 6.5ZM3 18.5C3 17.6716 3.67157 17 4.5 17H9.5C10.3284 17 11 17.6716 11 18.5C11 19.3284 10.3284 20 9.5 20H4.5C3.67157 20 3 19.3284 3 18.5ZM2.5 11C1.67157 11 1 11.6716 1 12.5C1 13.3284 1.67157 14 2.5 14H6.5C7.32843 14 8 13.3284 8 12.5C8 11.6716 7.32843 11 6.5 11H2.5Z" fill="#035A4B"></path>
              </svg>

            </span>

            <h3>Accelerate your business</h3>
            <p>We help power millions of businesses to built and run smoothly.</p>
          </div>
          <!-- End Icon Blocks -->
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->
    </div>



    <div class="container">
      <div class="w-75 mx-auto mb-7">
        <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/three-pointers.svg" alt="SVG Arrow">
      </div>

      <!-- Heading -->
      <div class="w-md-60 w-lg-50 text-center mx-auto mb-7">
        <p><span class="text-dark fw-semibold">It is fast and easy.</span> Create your first and ongoing website with Front.</p>
      </div>
      <!-- End Heading -->

      <!-- Devices -->
      <div class="devices">
        <!-- Mobile Device -->
        <figure class="device-mobile rotated-3d-right">
          <div class="device-mobile-frame">
            <img class="device-mobile-img" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/Screenshot (37).png" alt="Image Description">
          </div>
        </figure>
        <!-- End Mobile Device -->

        <!-- Browser Device -->
        <figure class="device-browser">
          <div class="device-browser-header">
            <div class="device-browser-header-btn-list">
              <span class="device-browser-header-btn-list-btn"></span>
              <span class="device-browser-header-btn-list-btn"></span>
              <span class="device-browser-header-btn-list-btn"></span>
            </div>
            <div class="device-browser-header-browser-bar">www.piperline.ir</div>
          </div>

          <div class="device-browser-frame">
            <img class="device-browser-img" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/Screenshot (35).png" alt="Image Description">
          </div>
        </figure>
        <!-- End Browser Device -->
      </div>
      <!-- End Devices -->

      <div class="text-center mx-auto" style="max-width: 20rem;">
        <p class="small">We are launching soon. Join the priority list for information and early access.</p>
      </div>
    </div>



    <div class="container content-space-2 content-space-lg-3">
      <div class="text-center mb-5">
        <span class="avatar avatar-xl avatar-circle">
          <img class="avatar-img" src="https://avatars.githubusercontent.com/u/72256856?v=4" alt="Image Description">
        </span>

      </div>

      <!-- Blockquote -->
      <figure class="w-md-75 text-center mx-md-auto">
        <blockquote class="blockquote">“ بشر تا کنون برای دستیابی یکجا به داده جنگیده و کنکاش کرده تا شاید بتواند داده هارا منظم تر ترتیب دهد پلتفرم پیپرلاین این بستر را فراهم کرده که به تمامی داده های مفید به شکل یک شبکه اجتماعی دست پیدا کنیم و با ساختار پلتفرمی بتوانیم به آنها دسترسی داشته باشیم به نظر من داشتن یک صفحه شخصی در پیپرلاین به درد هر فردی از هر طبقه ای می آید ”</blockquote>

        <figcaption class="blockquote-footer text-center">
          Aria Behrozian
          <span class="blockquote-footer-source">بنیانگذار و مدیر عامل کوییت سورس</span>
        </figcaption>
      </figure>
      <!-- End Blockquote -->
    </div>


    <!-- Icon Block -->
    <div class="container content-space-t-lg-5 content-space-b-2 content-space-b-lg-3">
      <!-- Heading -->
      <div class="w-lg-50 text-center mx-lg-auto mb-5">
        <span class="text-cap">مخزن های خود را بسازید</span>
      </div>
      <!-- End Heading -->

      <div class="mx-auto mb-5" style="max-width: 40rem;">
        <div class="row gx-3">
          <div class="col-sm-4 mb-3 mb-sm-0">
            <!-- Card -->
            <div class="card card-dashed shadow-none text-center rounded-2">
              <div class="card-body">
                <span class="svg-icon text-primary mb-3">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17.302 11.35L12.002 20.55H21.202C21.802 20.55 22.202 19.85 21.902 19.35L17.302 11.35Z" fill="#035A4B"></path>
                    <path opacity="0.3" d="M12.002 20.55H2.802C2.202 20.55 1.80202 19.85 2.10202 19.35L6.70203 11.45L12.002 20.55ZM11.302 3.45L6.70203 11.35H17.302L12.702 3.45C12.402 2.85 11.602 2.85 11.302 3.45Z" fill="#035A4B"></path>
                  </svg>

                </span>

                <h2 class="card-title h3 mb-0">300+</h2>
                <p class="card-text">فضای ابری</p>
              </div>
            </div>
            <!-- End Card -->
          </div>

          <div class="col-sm-4 mb-3 mb-sm-0">
            <!-- Card -->
            <div class="card card-dashed shadow-none text-center rounded-2">
              <div class="card-body">
                <span class="svg-icon text-primary mb-3">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path opacity="0.3" d="M21.25 18.525L13.05 21.825C12.35 22.125 11.65 22.125 10.95 21.825L2.75 18.525C1.75 18.125 1.75 16.725 2.75 16.325L4.04999 15.825L10.25 18.325C10.85 18.525 11.45 18.625 12.05 18.625C12.65 18.625 13.25 18.525 13.85 18.325L20.05 15.825L21.35 16.325C22.35 16.725 22.35 18.125 21.25 18.525ZM13.05 16.425L21.25 13.125C22.25 12.725 22.25 11.325 21.25 10.925L13.05 7.62502C12.35 7.32502 11.65 7.32502 10.95 7.62502L2.75 10.925C1.75 11.325 1.75 12.725 2.75 13.125L10.95 16.425C11.65 16.725 12.45 16.725 13.05 16.425Z" fill="#035A4B"></path>
                    <path d="M11.05 11.025L2.84998 7.725C1.84998 7.325 1.84998 5.925 2.84998 5.525L11.05 2.225C11.75 1.925 12.45 1.925 13.15 2.225L21.35 5.525C22.35 5.925 22.35 7.325 21.35 7.725L13.05 11.025C12.45 11.325 11.65 11.325 11.05 11.025Z" fill="#035A4B"></path>
                  </svg>

                </span>

                <h3 class="card-title mb-0">270+</h3>
                <p class="card-text">اراعه بربستر پیپرلاین</p>
              </div>
            </div>
            <!-- End Card -->
          </div>

          <div class="col-sm-4">
            <!-- Card -->
            <div class="card card-dashed shadow-none text-center rounded-2">
              <div class="card-body">
                <span class="svg-icon text-primary mb-3">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15.6 5.59998L20.9 10.9C21.3 11.3 21.3 11.9 20.9 12.3L17.6 15.6L11.6 9.59998L15.6 5.59998ZM2.3 12.3L7.59999 17.6L11.6 13.6L5.59999 7.59998L2.3 10.9C1.9 11.3 1.9 11.9 2.3 12.3Z" fill="#035A4B"></path>
                    <path opacity="0.3" d="M17.6 15.6L12.3 20.9C11.9 21.3 11.3 21.3 10.9 20.9L7.59998 17.6L13.6 11.6L17.6 15.6ZM10.9 2.3L5.59998 7.6L9.59998 11.6L15.6 5.6L12.3 2.3C11.9 1.9 11.3 1.9 10.9 2.3Z" fill="#035A4B"></path>
                  </svg>

                </span>

                <h3 class="card-title mb-0">450+</h3>
                <p class="card-text">هوش مصنوعی</p>
              </div>
            </div>
            <!-- End Card -->
          </div>
        </div>
        <!-- End Row -->
      </div>

      <div class="w-lg-50 text-center mx-lg-auto mb-10">
        <p>مخازن جدید ایجاد کنید و آنها را به افزونه های قابل نصب پیوند دهید و رشته های جدید از مخزن و اراعه خدمات بسازید و بر حسب نیاز خود شخصی سازی کنید</p>
      </div>

   
    </div>
    <!-- End Icon Block -->


    <!-- Gallery -->
    <div class="content-space-1">
      <div class="container-fluid px-lg-9">
        <div class="row gx-3 align-items-center">
          <div class="col-md d-none d-md-inline-block">
            <div class="d-grid gap-3">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img6.jpg" alt="Image Description">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(2).jpg" alt="Image Description">
            </div>
          </div>
          <!-- End Col -->

          <div class="col">
            <div class="d-grid gap-3">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img4.jpg" alt="Image Description">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(3).jpg" alt="Image Description">
            </div>
          </div>
          <!-- End Col -->

          <div class="col">
            <div class="d-grid gap-3">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img5.jpg" alt="Image Description">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img3.jpg" alt="Image Description">
            </div>
          </div>
          <!-- End Col -->

          <div class="col">
            <div class="d-grid gap-3">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(4).jpg" alt="Image Description">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(5).jpg" alt="Image Description">
            </div>
          </div>
          <!-- End Col -->

          <div class="col-md d-none d-md-inline-block">
            <div class="d-grid gap-3">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(1).jpg" alt="Image Description">
              <img class="img-fluid shadow rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img2.jpg" alt="Image Description">
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
    </div>
    <!-- End Gallery -->

    <!-- FAQ -->
    <div class="container content-space-b-1 content-space-b-lg-2">
      <div class="w-lg-75 mx-lg-auto">
        <div class="row" style="text-align: right;"> 
          <div class="col-md-6 mb-3 mb-md-5">
            <div class="pe-md-4" >
              <h4>پیپرلاین چیست؟</h4>
              <p>پیپرلاین شبکه اجتماعی یا بستری برای توضیع محتوا است اما با این تفاوت که مخزن شما هر چیزی میتواند باشد مانند فایل دوراه آموزشی یا حتی نوبت دهی آنلاین یا حتی پروژه فریلنسری اینجا یک شبکه اجتماعی کاربردیست که افراد خدمات و سرویس ها را به شکل برخط اراعه میدهند</p>
            </div>
          </div>

          <div class="col-md-6 mb-3 mb-md-5">
            <div class="ps-md-4">
              <h4>چطور میتونم به جامعه توسعه دهندگان پیپرلاین بپیوندم</h4>
              <p>با ثبت نام و ایجاد یک پروفایل کاربری کامل و ایجاد اولین مخزن خود میتوانید به پیپرلاین توسعه دهندگان بپیوندید</p>
            </div>
          </div>

          <div class="w-100"></div>

          <div class="col-md-6 mb-3 mb-md-5">
            <div class="pe-md-4">
              <h4> مینوانم پیپرلاین را به وبسایت خودم متصل کنم؟</h4>
              <p>بله اگر شما توسعه دهنده ای هستید که خود وبسایت تجاری دارید میتوانید با سرویس  پیپرلاین را به سایت خود متصل کنید و از طریق سایت خود مدیریت مشتریان و مخزن های خود را به دست بگیرید</p>
            </div>
          </div>

          <div class="col-md-6 mb-3 mb-md-5">
            <div class="ps-md-4">
              <h4>ایا مخزن ها در پیپرلاین معتبر و ارزشمند است؟</h4>
              <p>در اولین گام ما برای کنترل کیفیت در مرحله انسانی مخزن هارا برسی میکنیم و بعد از تایید در مرحله انسانی مخزن منتشر شده و مادامی که در پلتفرم این مخزن منتشر میشوشد با الگوریتم های هوش مصنوعی معیار های کیفیت را روی آن اعمال میکنیم و آن را لحظه به لحظه رسد میکنیم</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End FAQ -->

    <div class="border-top mx-auto" style="max-width: 25rem;"></div>

    <!-- Card Grid -->
    <div class="container content-space-2 content-space-lg-3">
      <!-- Heading -->
      <div class="w-lg-50 text-center mx-lg-auto mb-7">
        <span class="text-cap">API Service for connect to your web site</span>
        <h2>اتصال پیپرلاین به ویسایت های دیگر</h2>
      </div>
      <!-- End Heading -->

      <div class="row mb-5 mb-sm-5" style="text-align: right;">
        <div class="col-md-5 mb-3 mb-md-5">
          <!-- Card -->
          <a class="card card-transition h-100 aos-init aos-animate" href="core/rtl/dashboard.php?content=apiDoc" data-aos="fade-up">
            <div class="card-pinned">
              <img class="card-img-top" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/card-7.svg" alt="Image Description">

              <span class="card-pinned-top-start">
                <span class="badge bg-primary rounded-pill">Free</span>
              </span>
            </div>

            <div class="card-body">
              <h3 class="card-title text-inherit">API Config</h3>
              <p class="card-text text-body">این سرویس برای جامعه توسعه دهندگان است که میتوانید مدیریت هر مخزن و داده ستد های آن را به وبسایت خود متصل کرده و از طریق وبسایت خود آنها را مدیریت کنید</p>
            </div>

            <div class="card-footer pt-0">
              <span class="card-link"> بیشتر بدانید <i class="bi-chevron-right small ms-1"></i></span>
            </div>
          </a>
          <!-- End Card -->
        </div>
        <!-- End Col -->

        <div class="col-md mb-3 mb-md-5">
          <!-- Card -->
          <a class="card card-transition h-100 aos-init aos-animate" href="core/rtl/dashboard.php?content=apiDoc" data-aos="fade-up" data-aos-delay="150">
            <div class="card-pinned">
              <img class="card-img-top" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/card-8.svg" alt="Image Description">

              <span class="card-pinned-top-start">
                <span class="badge bg-primary rounded-pill">$99</span>
              </span>
            </div>

            <div class="card-body">
              <h3 class="card-title text-inherit">خودکار سازی</h3>
              <p class="card-text text-body">میتوانید فرآیند های فروش و خرید کاربران ثبت سفارش و بقیه اعمال را از طریق این سرویس به سایت خود متصل کرده و وقتی کاربر خرید انجام میدهد داده های خرید را دریافت و مدیریت کنید </p>
            </div>

            <div class="card-footer pt-0">
              <span class="card-link">بیشتر بدانید <i class="bi-chevron-right small ms-1"></i></span>
            </div>
          </a>
          <!-- End Card -->
        </div>
        <!-- End Col -->

        <div class="col-md mb-3 mb-md-5">
          <!-- Card -->
          <a class="card card-transition h-100 aos-init aos-animate" href="core/rtl/dashboard.php?content=apiDoc" data-aos="fade-up" data-aos-delay="200">
            <div class="card-pinned">
              <img class="card-img-top" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/card-9.svg" alt="Image Description">

              <span class="card-pinned-top-start">
                <span class="badge bg-primary rounded-pill">Free</span>
              </span>
            </div>

            <div class="card-body">
              <h3 class="card-title text-inherit">مستندات توسعه</h3>
              <p class="card-text text-body">داده های ورودی کاربر موقع سفارش را خودتان تایین میکنید و در سایت خود موقع خرید دریافت خواهید کرد</p>
            </div>

            <div class="card-footer pt-0">
              <span class="card-link">بیشتر بدانید <i class="bi-chevron-right small ms-1"></i></span>
            </div>
          </a>
          <!-- End Card -->
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->

      <!-- Card Info -->
      <div class="text-center">
        <div class="card card-info-link card-sm">
          <div class="card-body">
            Want to learn more? <a class="card-link ms-2" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">View all tutorials <span class="bi-chevron-right small ms-1"></span></a>
          </div>
        </div>
      </div>
      <!-- End Card Info -->
    </div>
    <!-- End Card Grid -->


    <div class="overflow-hidden">
      <div class="container content-space-2 content-space-lg-3">
        <div class="row justify-content-lg-between align-items-lg-center">
          <div class="col-lg-6 mb-9 mb-lg-0">
            <div class="position-relative mx-auto" style="max-width: 20rem;">
              <!-- Mobile Device -->
              <figure class="device-mobile mx-auto">
                <div class="device-mobile-frame">
                  <img class="device-mobile-img" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img5 (1).jpg" alt="Image Description">
                </div>
              </figure>
              <!-- End Mobile Device -->

              <!-- Image -->
              <div class="position-absolute top-0 end-0 zi-2 me-n10 mt-9" style="width: 16rem;">
                <img class="img-fluid shadow-lg rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img1(2).jpg" alt="Image Description">
              </div>
              <!-- End Image -->

              <!-- Image -->
              <div class="position-absolute bottom-0 start-0 zi-2 ms-n10 mb-10" style="width: 16rem;">
                <img class="img-fluid shadow-lg rounded-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/img26.jpg" alt="Image Description">
              </div>
              <!-- End Image -->

              <!-- SVG Shape -->
              <div class="position-absolute bottom-0 end-0 zi-n1 mx-auto" style="width: 20rem;">
                <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/shape-1.svg" alt="SVG">
              </div>
              <!-- End SVG Shape -->
            </div>
          </div>
          <!-- End Col -->

          <div class="col-lg-5" style="text-align: right;">
            <!-- Heading -->
            <div class="mb-5">
              <h2>ویژگی های منحصر به فرد به مخزن خود اضافه کنید</h2>
            </div>
            <!-- End Heading -->

            <!-- Step -->
            <ul class="step step-dashed mb-7">
              <li class="step-item">
                <div class="step-content-wrapper">
                  <span class="step-icon step-icon-xs step-icon-soft-primary">1</span>
                  <div class="step-content">
                    <h4 class="step-title">فرم و یا پرسمان</h4>
                    <p>میتوانید فرم یا پرسمان درست کنید و آن را به مخزن خود پیوند دهید تا کاربران موقع خرید آن فرم را پر کنند حتی میتوانید اطلاعات فرم را به سایت خود متصل کنید</p>
                  </div>
                </div>
              </li>

              <li class="step-item mb-0">
                <div class="step-content-wrapper">
                  <span class="step-icon step-icon-xs step-icon-soft-primary">2</span>
                  <div class="step-content">
                    <h4 class="step-title">افزونه نصب کنید</h4>
                    <p class="mb-0">افزونه های مختلف متناسب با نیاز خود از بازار افزونه ها بر روی مخزن های خود نصب کنید و آنها زا شخصی سازی کنید متناسب با نیاز خودتان</p>
                  </div>
                </div>
              </li>
            </ul>
            <!-- End Step -->

            <a class="btn btn-primary btn-transition" href="#">Request demo</a>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
    </div>

    <!--
    <div class="container content-space-2">
     
      <div class="w-lg-50 text-center mx-lg-auto mb-5 mb-md-9">
        <span class="text-cap">نماد ها</span>
        <h2>نماد های سازمانی ما</h2>
      </div>
     

      <div class="d-grid gap-2 w-lg-75 mx-lg-auto">
        
        <div class="card card-sm aos-init aos-animate" data-aos="fade-up">
          <div class="card-body">
            <div class="row align-items-sm-center">
              <div class="col">
                <h4 class="card-title">نماد اعتماد الکترونیک</h4>
              </div>
             

              <div class="col">
       
                <a referrerpolicy="origin" target="_blank" href="https://trustseal.enamad.ir/?id=377455&amp;Code=XXsRD0YGIO72bsk7XVuh"><img referrerpolicy="origin" src="https://Trustseal.eNamad.ir/logo.aspx?id=377455&amp;Code=XXsRD0YGIO72bsk7XVuh" alt="" style="cursor:pointer" id="XXsRD0YGIO72bsk7XVuh"></a>
              </div>
             

              <div class="col">
                <p class="card-text mb-0"><a href="https://www.enamad.ir">Enamad</a></p>
              </div>

              <div class="col-12 col-sm-4 col-xl-3 mt-3 mt-sm-0">
                <div class="d-grid">
                  <a class="btn btn-outline-primary" href="https://www.enamad.ir">enamad.ir</a>
                </div>
              </div>
            </div>
          </div>
        </div>



        <div class="text-center">
          <div class="card card-info-link card-sm">
            <div class="card-body">
              سایز نماد های سازمانی <a class="card-link ms-2" href="core/rtl/index.php?content=namads">مشاهده<span class="bi-chevron-right small ms-1"></span></a>
            </div>
          </div>
        </div>
  
      </div>
    </div>-->


  </main>
  <!-- ========== END MAIN CONTENT ========== -->

  <!-- ========== FOOTER ========== -->
  <footer class="bg-dark">
    <div class="container content-space-t-2 content-space-b-1">
      <div class="row mb-9">
        <div class="col-lg-3 mb-5 mb-lg-0">
          <!-- Logo -->
          <a href="https://htmlstream.com/preview/front-v4.3.1/index.html" aria-label="Front">
            <img class="brand" src="https://www.piperline.ir/core/rtl/assets/images/logo.png" alt="Logo">
          </a>
          <!-- End Logo -->
        </div>
        <!-- End Col -->

        <div class="col-6 col-md-3 col-lg-2 mb-5 mb-md-0">
          <h5 class="text-white">Help and advice</h5>

          <!-- Links -->
          <ul class="list-unstyled list-py-1 mb-0">
            <li><a class="link-sm link-light" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">Contact us</a></li>
            <li><a class="link-sm link-light" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">FAQ</a></li>
            <li><a class="link-sm link-light" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">Legal &amp; Privacy</a></li>
          </ul>
          <!-- End Links -->
        </div>
        <!-- End Col -->

        <div class="col-6 col-md-3 col-lg-2 mb-5 mb-md-0">
          <h5 class="text-white">About us</h5>

          <!-- Nav Links -->
          <ul class="list-unstyled list-py-1 mb-0">
            <li><a class="link-sm link-light" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">About Spec</a></li>
            <li><a class="link-sm link-light" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">Careers</a></li>
          </ul>
          <!-- End Nav Links -->
        </div>
        <!-- End Col -->

        <div class="col-md-6 col-lg-5">
          <!-- Form -->
          <form>
            <h5 class="text-white">Stay up to date</h5>

            <!-- Input Card -->
            <div class="input-card mt-3">
              <div class="input-card-form">
                <input type="text" class="form-control" placeholder="Enter email" aria-label="Enter email">
              </div>
              <button type="button" class="btn btn-primary">Submit</button>
            </div>
            <!-- End Input Card -->
          </form>
          <!-- End Form -->

          <p class="form-text text-white-70">New UI kits or big discounts. Never spam.</p>
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->

      <div class="row align-items-center">
        <div class="col">
          <p class="text-white-70 small mb-0">© piperline,LLC. 2023 qitSource,Inc. All rights reserved.</p>
        </div>
        <!-- End Col -->

        <div class="col-auto">
          <!-- Socials -->
          <ul class="list-inline mb-0">
            <li class="list-inline-item">
              <a class="btn btn-ghost-light btn-sm btn-icon" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <i class="bi-facebook"></i>
              </a>
            </li>

            <li class="list-inline-item">
              <a class="btn btn-ghost-light btn-sm btn-icon" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <i class="bi-google"></i>
              </a>
            </li>

            <li class="list-inline-item">
              <a class="btn btn-ghost-light btn-sm btn-icon" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <i class="bi-twitter"></i>
              </a>
            </li>

            <li class="list-inline-item">
              <a class="btn btn-ghost-light btn-sm btn-icon" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <i class="bi-github"></i>
              </a>
            </li>

            <li class="list-inline-item">
              <a class="btn btn-ghost-light btn-sm btn-icon" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <i class="bi-linkedin"></i>
              </a>
            </li>
          </ul>
          <!-- End Socials -->
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->
    </div>
  </footer>
  <!-- ========== END FOOTER ========== -->

  <!-- ========== SECONDARY CONTENTS ========== -->
  <!-- Sign Up -->
  <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <!-- Header -->
        <div class="modal-close">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <!-- End Header -->

        <!-- Body -->
        <div class="modal-body">
          <!-- Log in -->
          <div id="signupModalFormLogin" style="display: none; opacity: 0;">
            <!-- Heading -->
            <div class="text-center mb-7">
              <h2>Log in</h2>
              <p>Don't have an account yet?
                <a class="js-animation-link link" href="javascript:;" role="button" data-hs-show-animation-options="{
                         &quot;targetSelector&quot;: &quot;#signupModalFormSignup&quot;,
                         &quot;groupName&quot;: &quot;idForm&quot;
                       }">Sign up</a>
              </p>
            </div>
            <!-- End Heading -->

            <div class="d-grid gap-2">
              <a class="btn btn-white btn-lg" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <span class="d-flex justify-content-center align-items-center">
                  <img class="avatar avatar-xss me-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/google-icon.svg" alt="Image Description">
                  Log in with Google
                </span>
              </a>

              <a class="js-animation-link btn btn-primary btn-lg" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" data-hs-show-animation-options="{
                       &quot;targetSelector&quot;: &quot;#signupModalFormLoginWithEmail&quot;,
                       &quot;groupName&quot;: &quot;idForm&quot;
                     }">Log in with Email</a>
            </div>
          </div>
          <!-- End Log in -->

          <!-- Log in with Modal -->
          <div id="signupModalFormLoginWithEmail" style="display: none; opacity: 0;">
            <!-- Heading -->
            <div class="text-center mb-7">
              <h2>Log in</h2>
              <p>Don't have an account yet?
                <a class="js-animation-link link" href="javascript:;" role="button" data-hs-show-animation-options="{
                         &quot;targetSelector&quot;: &quot;#signupModalFormSignup&quot;,
                         &quot;groupName&quot;: &quot;idForm&quot;
                       }">Sign up</a>
              </p>
            </div>
            <!-- End Heading -->

            <form class="js-validate needs-validation" novalidate="">
              <!-- Form -->
              <div class="mb-3">
                <label class="form-label" for="signupModalFormLoginEmail">Your email</label>
                <input type="email" class="form-control form-control-lg" name="email" id="signupModalFormLoginEmail" placeholder="email@site.com" aria-label="email@site.com" required="">
                <span class="invalid-feedback">Please enter a valid email address.</span>
              </div>
              <!-- End Form -->

              <!-- Form -->
              <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center">
                  <label class="form-label" for="signupModalFormLoginPassword">Password</label>

                  <a class="js-animation-link form-label-link" href="javascript:;" data-hs-show-animation-options="{
                       &quot;targetSelector&quot;: &quot;#signupModalFormResetPassword&quot;,
                       &quot;groupName&quot;: &quot;idForm&quot;
                     }">Forgot Password?</a>
                </div>

                <input type="password" class="form-control form-control-lg" name="password" id="signupModalFormLoginPassword" placeholder="8+ characters required" aria-label="8+ characters required" required="" minlength="8">
                <span class="invalid-feedback">Please enter a valid password.</span>
              </div>
              <!-- End Form -->

              <div class="d-grid mb-3">
                <button type="submit" class="btn btn-primary form-control-lg">Log in</button>
              </div>
            </form>
          </div>
          <!-- End Log in with Modal -->

          <!-- Sign up -->
          <div id="signupModalFormSignup">
            <!-- Heading -->
            <div class="text-center mb-7">
              <h2>Sign up</h2>
              <p>Already have an account?
                <a class="js-animation-link link" href="javascript:;" role="button" data-hs-show-animation-options="{
                         &quot;targetSelector&quot;: &quot;#signupModalFormLogin&quot;,
                         &quot;groupName&quot;: &quot;idForm&quot;
                       }">Log in</a>
              </p>
            </div>
            <!-- End Heading -->

            <div class="d-grid gap-3">
              <a class="btn btn-white btn-lg" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">
                <span class="d-flex justify-content-center align-items-center">
                  <img class="avatar avatar-xss me-2" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/google-icon.svg" alt="Image Description">
                  Sign up with Google
                </span>
              </a>

              <a class="js-animation-link btn btn-primary btn-lg" href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#" data-hs-show-animation-options="{
                       &quot;targetSelector&quot;: &quot;#signupModalFormSignupWithEmail&quot;,
                       &quot;groupName&quot;: &quot;idForm&quot;
                     }">Sign up with Email</a>

              <div class="text-center">
                <p class="small mb-0">By continuing you agree to our <a href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">Terms and Conditions</a></p>
              </div>
            </div>
          </div>
          <!-- End Sign up -->

          <!-- Sign up with Modal -->
          <div id="signupModalFormSignupWithEmail" style="display: none; opacity: 0;">
            <!-- Heading -->
            <div class="text-center mb-7">
              <h2>Sign up</h2>
              <p>Already have an account?
                <a class="js-animation-link link" href="javascript:;" role="button" data-hs-show-animation-options="{
                         &quot;targetSelector&quot;: &quot;#signupModalFormLogin&quot;,
                         &quot;groupName&quot;: &quot;idForm&quot;
                       }">Log in</a>
              </p>
            </div>
            <!-- End Heading -->

            <form class="js-validate need-validate" novalidate="">
              <!-- Form -->
              <div class="mb-3">
                <label class="form-label" for="signupModalFormSignupEmail">Your email</label>
                <input type="email" class="form-control form-control-lg" name="email" id="signupModalFormSignupEmail" placeholder="email@site.com" aria-label="email@site.com" required="">
                <span class="invalid-feedback">Please enter a valid email address.</span>
              </div>
              <!-- End Form -->

              <!-- Form -->
              <div class="mb-3">
                <label class="form-label" for="signupModalFormSignupPassword">Password</label>
                <input type="password" class="form-control form-control-lg" name="password" id="signupModalFormSignupPassword" placeholder="8+ characters required" aria-label="8+ characters required" required="">
                <span class="invalid-feedback">Your password is invalid. Please try again.</span>
              </div>
              <!-- End Form -->

              <!-- Form -->
              <div class="mb-3" data-hs-validation-validate-class="">
                <label class="form-label" for="signupModalFormSignupConfirmPassword">Confirm password</label>
                <input type="password" class="form-control form-control-lg" name="confirmPassword" id="signupModalFormSignupConfirmPassword" placeholder="8+ characters required" aria-label="8+ characters required" required="" data-hs-validation-equal-field="#signupModalFormSignupPassword">
                <span class="invalid-feedback">Password does not match the confirm password.</span>
              </div>
              <!-- End Form -->

              <div class="d-grid mb-3">
                <button type="submit" class="btn btn-primary form-control-lg">Sign up</button>
              </div>

              <div class="text-center">
                <p class="small mb-0">By continuing you agree to our <a href="https://htmlstream.com/preview/front-v4.3.1/landing-app-ui-kit.html#">Terms and Conditions</a></p>
              </div>
            </form>
          </div>
          <!-- End Sign up with Modal -->

          <!-- Reset Password -->
          <div id="signupModalFormResetPassword" style="display: none; opacity: 0;">
            <!-- Heading -->
            <div class="text-center mb-7">
              <h2>Forgot password?</h2>
              <p>Enter the email address you used when you joined and we'll send you instructions to reset your password.</p>
            </div>
            <!-- En dHeading -->

            <form class="js-validate need-validate" novalidate="">
              <div class="mb-3">
                <!-- Form -->
                <div class="d-flex justify-content-between align-items-center">
                  <label class="form-label" for="signupModalFormResetPasswordEmail" tabindex="0">Your email</label>

                  <a class="js-animation-link form-label-link" href="javascript:;" data-hs-show-animation-options="{
                         &quot;targetSelector&quot;: &quot;#signupModalFormLogin&quot;,
                         &quot;groupName&quot;: &quot;idForm&quot;
                       }">
                    <i class="bi-chevron-left small"></i> Back to Log in
                  </a>
                </div>

                <input type="email" class="form-control form-control-lg" name="email" id="signupModalFormResetPasswordEmail" tabindex="1" placeholder="Enter your email address" aria-label="Enter your email address" required="">
                <span class="invalid-feedback">Please enter a valid email address.</span>
                <!-- End Form -->
              </div>

              <div class="d-grid">
                <button type="submit" class="btn btn-primary form-control-lg">Submit</button>
              </div>
            </form>
          </div>
          <!-- End Reset Password -->
        </div>
        <!-- End Body -->

        <!-- Footer -->
        <div class="modal-footer d-block text-center py-sm-5">
          <small class="text-cap mb-4">Trusted by the world's best teams</small>

          <div class="w-85 mx-auto">
            <div class="row justify-content-between">
              <div class="col">
                <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/gitlab-gray.svg" alt="Logo">
              </div>
              <!-- End Col -->

              <div class="col">
                <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/fitbit-gray.svg" alt="Logo">
              </div>
              <!-- End Col -->

              <div class="col">
                <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/flow-xo-gray.svg" alt="Logo">
              </div>
              <!-- End Col -->

              <div class="col">
                <img class="img-fluid" src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/layar-gray.svg" alt="Logo">
              </div>
              <!-- End Col -->
            </div>
          </div>
          <!-- End Row -->
        </div>
        <!-- End Footer -->
      </div>
    </div>
  </div>

  <!-- Go To -->
  <a class="js-go-to go-to position-fixed animated hs-go-to-prevent-event fadeInUp" href="javascript:;" style="right: 2rem; bottom: 2rem;" data-hs-go-to-options="{
       &quot;offsetTop&quot;: 700,
       &quot;position&quot;: {
         &quot;init&quot;: {
           &quot;right&quot;: &quot;2rem&quot;
         },
         &quot;show&quot;: {
           &quot;bottom&quot;: &quot;2rem&quot;
         },
         &quot;hide&quot;: {
           &quot;bottom&quot;: &quot;-2rem&quot;
         }
       }
     }">
    <i class="bi-chevron-up"></i>
  </a>
  <!-- ========== END SECONDARY CONTENTS ========== -->

  <!-- JS Implementing Plugins -->
  <script src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/vendor.min.js.download"></script>
  <script src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/aos.js.download"></script>

  <!-- JS Front -->
  <script src="./views/Consulting _ Space - Multipurpose Responsive Template1_files/theme.min.js.download"></script>

  <!-- JS Plugins Init. -->
  <script>
    (function() {
      // INITIALIZATION OF HEADER
      // =======================================================
      new HSHeader('#header').init()


      // INITIALIZATION OF MEGA MENU
      // =======================================================
      new HSMegaMenu('.js-mega-menu', {
          desktop: {
            position: 'left'
          }
        })


      // INITIALIZATION OF GO TO
      // =======================================================
      new HSGoTo('.js-go-to')


      // INITIALIZATION OF AOS
      // =======================================================
      AOS.init({
        duration: 650,
        once: true
      });
    })()
  </script>

</body></html>