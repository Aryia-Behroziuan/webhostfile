<?php
    $post_hash = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
    $post = mysqli_fetch_assoc($post_hash);
    if(! $post){
        die();
    }
?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center">
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/achievement-network-badge-5248703-4396762.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video>  مشتریان</font></font></h1>			
				</div>
			</div>
		</div>
		<div class="row g-4">
			

			

        <div class="bg-light rounded-3 p-4 mb-3">
							<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
							<hr>
		</div>
				    <!-- Grid START -->
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> پیام ها و سفارشات</font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">105</font></font></span></h5>
							<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک پست ایجاد کنید</font></font></a>
						</div>
					</div>
					<!-- Card header END -->




					<!-- Card body START -->
					<div class="card-body p-3">
                        <h5><img src="https://cdn3d.iconscout.com/3d/premium/thumb/search-tool-3316932-2761487.png" style="width: 30px;" alt=""> فیلتر کنید</h5>
                        <a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>" class="btn btn-dark btn-sm">پیش فرض</a>
                        <a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>&filter=seen" class="btn btn-dark btn-sm">دیده شده</a>
                        <a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>" class="btn btn-dark btn-sm">دیده نشده</a>
						<?php
						if($post['type'] == 5){
							if($post['inter'] == 1){
								?>
								<a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>&filter=enter" class="btn btn-dark btn-sm">تایید شده</a>
								<a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>&filter=cancel" class="btn btn-dark btn-sm">کنسل شده</a>
	
								<?php
							}
	
						}
						?>
                        <br>
                        <br>
						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							<div class="col-md-8">
								<form action="" method="POST" class="rounded position-relative">
									<input name="search" class="form-control pe-5 bg-transparent" type="search" placeholder="جستجو کردن شناسه توضیحات نام و هر اطلاعاتی" aria-label=" کردن">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>

							<!-- Select option -->
							<div class="col-md-3">
								<!-- Short by filter -->
								<form>
									<select class="form-select z-index-9 bg-transparent" aria-label=".form-sect-sm">
										<option value="">مرتب سازی بر اساس</option>
										<option>رایگان</option>
										<option>جدیدترین</option>
										<option>قدیمی ترین</option>
									</select>
								</form>
							</div>
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						<div class="table-responsive border-0">
							<table class="table table-dark-gray align-middle p-4 mb-0 table-hover table-shrink">
								<!-- Table head -->
								<thead>
									<tr>
										<th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> شناسه سفارش</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام مشتری</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحان</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وضعیت</font></font></th>
										<th scope="col" class="border-0 rounded-end"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عمل</font></font></th>
									</tr>
								</thead>

								<!-- Table body START -->
								<tbody>

                                


                                <?php
                                if(! isset($_GET['id'])){
                                    die();
                                }
                                $post_hash = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
                                $post = mysqli_fetch_assoc($post_hash);
                                if($post){
                                    if(! isset($_GET['filter'])){
                                        if($post['type'] == 5){
                                            $query_1212 = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="0"');
                                            $file_hash = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="0"');
                                            $file = mysqli_fetch_assoc($query_1212);
                                        }else{
                                            $query_1212 = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and seen="0"');
                                            $file_hash = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and seen="0"');
                                            $file = mysqli_fetch_assoc($query_1212);
                                        }
                                    }elseif(isset($_POST['search'])){
                                    	$query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE (`id` LIKE "%'.$_POST['search'].'%" or `createDate` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%" or `wiki` LIKE "%'.$_POST['search'].'%") and piperline="'.$_GET['id'].'" and name="order" order by createDate Desc');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE (`id` LIKE "%'.$_POST['search'].'%" or `createDate` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%" or `wiki` LIKE "%'.$_POST['search'].'%") and piperline="'.$_GET['id'].'" and name="order" order by createDate Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
									}else{
                                        if($_GET['filter'] == 'seen'){
                                            $query_1212 = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and seen="1"');
                                            $file_hash = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and seen="1"');
                                            $file = mysqli_fetch_assoc($query_1212);
                                        }elseif($_GET['filter'] == 'enter'){
                                            $query_1212 = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="1"');
                                            $file_hash = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="1"');
                                            $file = mysqli_fetch_assoc($query_1212);
                                        }elseif($_GET['filter'] == 'cancel'){
                                            $query_1212 = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="2"');
                                            $file_hash = mysqli_query($con, 'select * from session where piperline="'.$_GET['id'].'" and name="order" and status="2"');
                                            $file = mysqli_fetch_assoc($query_1212);
                                        }
                                    }
                                }
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $user_hash = mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"');
                                        $userOne = mysqli_fetch_assoc($user_hash);
                                ?>
                                    <!-- Table item -->
                                    <tr>
                                    <!-- Table data -->
                                    <td>
                                        <h6 class="course-title mt-2 mt-md-0 mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['id']?> </font></font></a></h6>
                                    </td>

                       
                                    <td>
                                        <a href="../../core/rtl/dashboard.php?content=profile&id=<?php echo $userOne['iduser']?>" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $userOne['username']?></font></font></a>
                                    </td>

                                    <td>
                                        <p><?php echo $res['wiki']?></p>
                                    </td>

									<td>
										<?php
										if($post['type'] == 5){
											if($res['status'] == '0'){
												$alert = 'در انتظار تایید';
											}elseif($res['status'] == '1'){
												$alert =  'تایید شده';
	
											}elseif($res['status'] == '2'){
												$alert =  'کنسل شده';
	
											}
										}else{
											$alert =  'خرید موفق';
										}
										?>
                                        <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $alert?></font></font></span>
                      				</td>

                                    <td>
                                        <div class="d-flex gap-2">
                                        <?php
                                        
                                            if($post['type'] == 5){
												if($post['inter'] == 1){
													if($res['status'] == '0'){
														?>
														<a href="../../index.php?controller=create&method=cancelOrder&id=<?php echo $res['id']?>" class="btn btn-danger btn-sm">کنسل کردن</a>
														<?php
													}
	
													if($res['status'] == '0'){
														?>
														<a href="../../index.php?controller=create&method=enterOrder&id=<?php echo $res['id']?>" class="btn btn-success btn-sm">تایید</a>
														<?php
													}
												}
                          
                                            }
                                        
                                        ?>
                                        <a href="../../core/rtl/dashboard.php?content=openOrder&id=<?php echo $res['id']?>" class="btn btn-outline-dark btn-sm"> مشاهده </a>
                                        </div>
                                    </td>
                                    </tr>
                                <?php
                                    }
                                }
                                ?>















								</tbody>
								<!-- Table body END -->
							</table>
						</div>
						<!-- Blog list table END -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>