<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center">
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/document-6073625-4996997.png" style="width: 60px;" alt=""> <font style="vertical-align: inherit;"> پست های شما</font></font>					<a href="../../core/rtl/dashboard.php?content=createPost" class="btn btn-sm btn-primary mb-0" style="color: #ffffff;"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک پست اضافه کنید</font></font></a>
          </h1>			
          <a href="dashboard.php?content=txtEdit" class="btn btn-light btn-sm">

          <img src="https://seeklogo.com/images/M/microsoft-365-logo-6D6E233C94-seeklogo.com.png" style="width: 20px;" alt="Avatar">

          ویرایشگر متن ...
          </a>
        </div>

			</div>
		</div>
		<div class="row">
			<div class="col-12">
          <div class="row g-4 mb-4">
            <div class="col-sm-4 col-lg-2">
              <!-- Card START -->
              <div class="card card-body border h-100">
                <!-- Icon -->
                <div class="fs-3 text-start text-success">
                  <i class="bi bi-file-earmark-text"></i>
                </div>
                <!-- Content -->
                <div class="ms-0">
                  <h3 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">305</font></font></h3>
                  <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سند</font></font></h6>
                </div>
              </div>
              <!-- Card END -->
            </div>
            <div class="col-sm-4 col-lg-2">
              <!-- Card START -->
              <div class="card card-body border h-100">
                <!-- Icon -->
                <div class="fs-3 text-start text-success">
                  <i class="bi bi-camera-reels"></i>
                </div>
                <!-- Content -->
                <div class="ms-0">
                  <h3 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">120</font></font></h3>
                  <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فیلم های</font></font></h6>
                </div>
              </div>
              <!-- Card END -->
            </div>
            <div class="col-sm-4 col-lg-2">
              <!-- Card START -->
              <div class="card card-body border h-100">
                <!-- Icon -->
                <div class="fs-3 text-start text-success">
                  <i class="bi bi-image"></i>
                </div>
                <!-- Content -->
                <div class="ms-0">
                  <h3 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">475</font></font></h3>
                  <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تصاویر</font></font></h6>
                </div>
              </div>
              <!-- Card END -->
            </div>
            <div class="col-lg-6">
              <!-- Card START -->
              <div class="card card-body border h-100">
                 <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فضای ذخیره سازی</font></font></h3>
                 <div>
                  <div class="d-flex">
                    <h6 class="mt-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره سازی 80%</font></font></h6>
                    <span class="ms-auto"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">6.80 گیگابایت از 10 گیگابایت</font></font></span>
                  </div>
                  <div class="progress progress-percent-bg progress-md">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <!-- Card END -->
                </div>
              </div>
            </div>
          </div>
          <!-- Post list table START -->
          <div class="card border bg-transparent rounded-3">

            <!-- Card body START -->
            <div class="card-body p-3">

              <!-- Search and select START -->
              <div class="row g-3 align-items-center justify-content-between mb-3">
                <!-- Search -->
                <div class="col-md-8">
                  <form action="" method="POST" class="rounded position-relative">
                    <input name="search" class="form-control pe-5 bg-transparent" type="search" placeholder="جستجو کردن" aria-label="جستجو کردن">
                    <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                  </form>
                </div>

                <!-- Select option -->
                <div class="col-md-3">
                  <!-- Short by filter -->
                  <form>
                    <select class="form-select z-index-9 bg-transparent" aria-label=".form-sect-sm">
                      <option value=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرتب سازی بر اساس</font></font></option>
                      <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">رایگان</font></font></option>
                      <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">جدیدترین</font></font></option>
                      <option><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قدیمی ترین</font></font></option>
                    </select>
                  </form>
                </div>
              </div>
              <!-- Search and select END -->

              <!-- Post list table START -->
              <div class="table-responsive border-0">
                <table class="table align-middle p-4 mb-0 table-hover table-shrink">
                  <!-- Table head -->
                  <thead class="table-dark">
                    <tr>
                      <th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></th>
                      <th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">الگوریتم ها</font></font></th>
                      <th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ انتشار</font></font></th>
                      <th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دسته بندی</font></font></th>
                      <th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وضعیت</font></font></th>
                      <th scope="col" class="border-0 rounded-end"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عمل</font></font></th>
                    </tr>
                  </thead>

                  <!-- Table body START -->
                  <tbody class="border-top-0">

                  <?php
                  if(isset($_POST['search'])){
                    $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE (`idPost` LIKE "%'.$_POST['search'].'%" or `title` LIKE "%'.$_POST['search'].'%" or `doc` LIKE "%'.$_POST['search'].'%" or `category` LIKE "%'.$_POST['search'].'%" or `date` LIKE "%'.$_POST['search'].'%") and idUser="'.$_SESSION['id'].'" order by date Desc');
                    $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE (`idPost` LIKE "%'.$_POST['search'].'%" or `title` LIKE "%'.$_POST['search'].'%" or `doc` LIKE "%'.$_POST['search'].'%" or `category` LIKE "%'.$_POST['search'].'%" or `date` LIKE "%'.$_POST['search'].'%") and idUser="'.$_SESSION['id'].'" order by date Desc');
                    $file = mysqli_fetch_assoc($query_1212);
                  }else{
                    $query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$user['iduser'].'" order by date Desc');
                    $file_hash = mysqli_query($con, 'select * from posts where idUser="'.$user['iduser'].'" order by date Desc');
                    $file = mysqli_fetch_assoc($query_1212);
                  }
                  if($file){
                    while($res=mysqli_fetch_assoc($file_hash)){
                  ?>
                    <!-- Table item -->
                    <tr>
                      <!-- Table data -->
                      <td>
                        <h6 class="course-title mt-2 mt-md-0 mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?> </font></font></a></h6>
                      </td>
                      <!-- Table data -->
                      <td>
                        <?php
                        if($res['top'] == 1){
                          $top = 'بازاریابی';
                        }else{
                          $top = '';
                        }
                        if($res['SEO'] == 1){
                          $SEO = 'سئو و برندینگ';
                        }else{
                          $SEO = '';
                        }
                        ?>
                        <h6 class="mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        پست ساده<br/>
                        <?PHP echo $top?><br/>
                        <?PHP echo $SEO?>
                        </font></font></a></h6>
                      </td>
                      <!-- Table data -->
                      <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $res['date']?> </font></font></td>
                      <!-- Table data -->
                      <td>
                        <a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل اصلی</font></font></a>
                      </td>
                      <!-- Table data -->
                      <td>
                        <?php
                        if($res['published'] == 0){
                          $status = 'در حال برسی';
                        }elseif($res['published'] == 1){
                          $status = 'انتشار';
                        }elseif($res['published'] == -1){
                          $status = 'پیش نویس';
                        }elseif($res['published'] == 2){
                          $status = 'تایید نشد';
                        }else{
                          $status = 'نامشخص';
                        }
                        ?>
                        <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $status?></font></font></span>
                      </td>
                      <!-- Table data -->
                      <td>
                        <div class="d-flex gap-2">
                          <a href="../../core/rtl/dashboard.php?content=createPost&Edit=<?php echo $res['idPost']?>" class="btn btn-outline-dark btn-sm">ویرایش فایل</a>
                          <a href="../../core/rtl/dashboard.php?content=createPost&id=<?php echo $res['idPost']?>" class="btn btn-outline-dark btn-sm">ویرایش افزودنی ها</a>
                          <a href="../../core/rtl/dashboard.php?content=openFile&id=<?php echo $res['idPost']?>" class="btn btn-outline-dark btn-sm"> داشبورد پست</a>
                        </div>
                      </td>
                    </tr>
                  <?php
                    }
                  }
                  ?>

                    
                  </tbody>
                  <!-- Table body END -->
                </table>
              </div>
              <!-- Post list table END -->

              <!-- Pagination START -->
              <div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
                <!-- Content -->
                <p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
                <!-- Pagination -->
                <nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
                  <ul class="pagination pagination-sm pagination-bordered mb-0">
                    <li class="page-item disabled">
                      <a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
                    <li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
                    <li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
                    <li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
                    <li class="page-item">
                      <a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
                    </li>
                  </ul>
                </nav>
              </div>
              <!-- Pagination END -->
            </div>
          </div>
          <!-- Post list table END -->
      </div>
    </div>
  </div>
</section>