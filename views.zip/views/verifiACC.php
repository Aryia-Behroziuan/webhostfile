<section class="py-4">
	<div class="container">
    <div class="row pb-4">
        

    
                    


                    <div class="bg-light rounded-5 p-1 mb-1" style="text-align: left;" >
                        <div class="bg-light rounded-5 p-1 mb-1" style="text-align: left;">
            

                        <nav class="navbar bg-body-tertiary">
                        <div class="container-fluid">
                        <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action"> QPassID <strong><i class="bi bi-link-45deg"></i> Connected</strong> <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
                        <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
                        <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
                        <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
                        <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
                        <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
                        </svg></a>
                        </div>
                        </nav>
            
                         </div>                               
                    </div>

                    <nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active">کنترل حساب</li>
							<li class="breadcrumb-item active">اعتبار سنجی حساب</li>
						</ol>
					</nav>

            <div class="list-group" style="text-align: left;">
              
              <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action">

                <style>
                #redsquare {
                    
                   
                    position: absolute;
                    left: 50%;
                    top: 50%;
                    transform: translate(-50%, -50%);
                }
                </style>
                <ul class="avatar-group" id="redsquare">
                    <li class="avatar">
                        <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                    </li>
                    <li class="avatar">
                        <img class="avatar-img rounded-circle" src="https://up.20script.ir/file/bd66-Screenshot-26-.png" alt="avatar">
                    </li>
              
                    <li class="avatar">
                        <div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
                    </li>
                </ul>
                

              </a>
              <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action"> Account Center <strong>QP<?php echo $user['iduser']?></strong><img style="with: 45px; height: 45px;" src="https://up.20script.ir/file/bd66-Screenshot-26-.png" alt=""></a>
              <a href="https://myaccount.google.com/?utm_source=account-marketing-page&amp;utm_medium=go-to-account-button&amp;pli=1" class="list-group-item list-group-item-action"> Google Account center <img style="with: 30px; height: 30px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/1200px-Google_%22G%22_Logo.svg.png" alt=""></a>
              <a href="dashboard.php?content=verifiACC" class="list-group-item list-group-item-action"> Account verification <i class="bi bi-patch-check-fill text-info" style="font-size: 22px;"></i></a>
              <a href="dashboard.php?content=verifiACC" class="list-group-item list-group-item-action"> Privacy policy <i class="bi bi-incognito" style="font-size: 22px;"></i></a>
              <button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.qitsource.ir">qitSource,LLC</a></button>
            </div>

            


            
                
            
            
			<div class="col-12">
                <br>
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center"> 
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;" style="text-align: left;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/free/thumb/free-bytom-3443554-2879649.png?f=webp" style="width: 50px;" alt=""> حریم خصوصی </font></font></h1>			
				</div>
			</div>
		</div>

        <div class="accordion" id="accordionExample">
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    داده های این صفحه به کجا فرستاده میشود
                </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    شرکت کوییت سورس با ساختن تکنولوژی کیوپس آیدی با استفاده از این سرویس حساب های کاربری مربوط به شرکت خود را پشتیبانی میکند و شما با ثبت نام در سایت رسمی کوییت سورس و ثبت نام در هر یک از سرویس های شرکت ما مالک یک شناسه کیوپس آیدی میشوید و سپس تمامی داده های مربوط به حساب شما برای حساب مادر در دیتاسنتر کوییت سورس فرستاده میشود و اعمالی همچو تایید و خدماتی دیگر فقط توسط سایت کیوپس آیدی امکان پذیر است پس ما این دادگان را از شما دریافت کرده و به دیتاسنتر سرویس والد اکانت شما ارسال میکنیم تا مراحل را از آنجا طی کند اگر مایل باشید میتوانید خودتان هم این کار را بکنید و برای مدیریت حساب خود به اکانت سنتر مرکزی در کیوپس آیدی مراجعه کنید
                    <br>
                    <strong>مالکیت فناوری کیوپس آیدی مال خودمان است و اطلاعات شما به شرکت شخص ثالثی ارسال نمیگردد بلکه به دیتاسنتر مرکزی خودمان میرود</strong>
                    <br>
                    <strong><a href="https://www.qitsource.ir">مدیریت حساب</a></strong>  
                    ,
                    <strong><a href="dashboard.php?content=verifiACCdoc">شرایط و قوانین انجمن ما</a></strong>  
        
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    اعتبار سنجی حساب 
                </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ما همانند همه پلتفرم های دیجیتال خط مشی ها و قوانینی داریم که توسط انجمن هیعت مدیره ما تصویب شده است و کاربرنی که خواستار آن هستند باید از خط مشی ها و قوانین پلتفرم ما به شکل تام تبعیت کنند ما روی این نوع موضوع بسیار حساسیم تا بتوانیم افرادی را گرد هم جمع کنیم که دارای ارزش گذاری صحیح و کارامد باشند و این شروع تعهدیست که متقابلا به مشتریان و توسعه دهندگانمان داریم

                    <strong><a href="dashboard.php?content=verifiACCdoc">شرایط و قوانین انجمن ما</a></strong>  
                </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    داده ها سرتاسر رمزگذاری شده
                </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ما روی امنیت پلتفرم خودمان به شدت حساسیم و دادگان را سرتاسر سرویس های خود رمزگذاری میکنیم با روش های نوین رمزگذاری و به خوبی از داده هایتان محافظت خواهیم کرد میتوانید به ما اعتماد کنید تا بتوانیم شروع به یک دوستی و رشد جمعی کنیم دادگان شما تک تک مسیر هایی که طی میکند ما آن را در اختیار  شما میگذاریم و هر زمان بخواهید آن را در هر مرحله ای به شکل کامل غیر قابل بازیابی خواهیم کرد
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree1" aria-expanded="false" aria-controls="collapseThree">
                    هزینه این کار چقدر است برای چه شامل هزینه میشود
                </button>
                </h2>
                <div id="collapseThree1" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    مانند هر پلتفرمی در سرویس ماهم خدمات تایید حساب شامل مبلغی هزینه میشود این بدان معنا نیست که تایید حساب را میتوان با پول خرید در پلتفرم ما ابتدا در انجمن تایید میشوید و اعتبار سنجی انجام میشود و در صورت داشتن شرایط لازم دستورالعمل حسابتان تایید میشود و مبلغ از شما کسر میشود

                    <br>
                    <br>
                    مبلغ مصوب انجمن ما برای این کار 200,000 تومان میباشد که به صورت پس پرداخت از شما کسر خواهد شد
                </div>
                </div>
            </div>
            </div>

            <br>


            <div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مراحل تایید حساب</font></font></h5>
							<a href="dashboard.php?content=editProfile" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مدیریت حساب</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0">
								


                            <div class="row">
                            <div class="col-4 col-sm-3">
                                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">تکمیل اطلاعات حساب</a>
                                <a class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">اطلاعات هویتی</a>
                                <a class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">استعلام اطلاعات</a>
                                <a class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">نظر انجمن</a>
                                </div>
                            </div>
                            <div class="col-8 col-sm-9">
                                <div class="tab-content pt-0" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    قبل از هر چیزی اطلاعات حساب کاربری خود را از جمله نام حقیقی و درباره شما و اطلاعات مربوط به شرکت و ایالات  خود را وارد کنید تا ما بهتر بتوانیم شمارا بشناسیم و شرکت و جامعه تان را درک کنیم سعی کنید اطلاعات خود را به درستی وارد کنید چون اگر اطلاعات شما رد شود چند ماهی تعلیق میشوید
                                    <br>
                                    در قدم اول به قسمت تکمیل اطلاعات سرویس پیپرلاین بروید و اطلاعات خود را کامل کنید
                                    <br>
                                    
                                    <strong><a href="dashboard.php?content=editProfile">مدیریت محلی حساب</a></strong>
                                    <br>
                                    <br>
                                    درگام دوم به وبسایت کیوپس آیدی رفته و به حساب خود متصل شوید و در قسمت اکانت سنتر اطلاعات بیشتر مانند شرکت و محل کار و تحصیلات و دانشگاه و... را پر کنید 
                                    <br>
                                    
                                    <strong><a href="https://www.qitsource.ir">مدیریت حساب</a></strong>
                                    <br>
                                    <br>
                                    <strong>نواقص حساب شما</strong>
                                    <br>
                                    <?php
                                    $strok = 0;
                                    if(strlen($user['phoneNumber']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا شماره موبایل خود را به درستی وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['title']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا نام حقیقی و اصلی خود را وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['loc']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا ایالات خود را وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['job']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                           لطفا عنوان شغلی خود را وارد کنید     
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['about']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                           لطفا در باره خود کمی توضیحات به ما بدهید  
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['url']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا وبسایت شخصی خود را وارد کنید و یا اگر وبسایت ندارید آدرس وبلاگ یا یکی از شبکه اجتماعی های معتبر را بدهید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['codefoxs']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا لینک رزومه خود را وارد کنید تا بتوانیم حقیق کاری و علمی را درباره شما بدانیم اگر رزومه ندارید مانعی نیست آن فیلد را با یک لینک از شبکه های اجتماعی خود پر کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    
                                    ?>

                                    <?php
                                    if($strok == 0){
                                        ?>
                                        <strong style="color: #4387FF;">تبریک میگوییم حساب شما هیچ نقصی جهت اقدام به شروع مراحل تایید حساب ندارد اکنون میتوانید مراحل بعد را طی کنید</strong>

                                        <?php
                                    }else{
                                        ?>
                                        <strong style="color: #E35959;">حساب کاربری شما <?php echo $strok?> نقص دارد که از شما خواهشمندیم آن را مطالعه و تصحیح کنید و از صحت آن اطمینان حاصل کنید زیرا اگر اطلاعات ورودی شما نادرست باشد از درخواست مجدد برای دریافت تاییده تا شش ماه منبع خواهید شد پس لطفا جدی بگیرید</strong>
                                        <?php
                                    }
                                    ?>
                                    </div>
                                    
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    در این قسمت شما باید مدارک هویتی خود را برای ما بارگذاری کنید تا ما بتوانیم بهتر شمارا بشناسیم و برای تایید ما باید نشانه هایی از شهرت و یا مشروهیت این بدان معنی نیست که فقط افراد مشهور میتوانند تایید شوند شما میتوانید یک انسان کاملا متفاوت باشید اما تایید شوید همه چیز به نظر انجمن در باره شما بستگی دارد
                                    <br>
                                    <br>
                                    <strong>اطلاعات هویتی به شرح زیر است</strong> 
                                    <br>
                                    <small>درگام نخست یک عکس از صفحه اصلی شناسنامه محلی خود در هر ایالات و یا کشوری که هستید برای ما ارسال میکنید</small>    
                                    <br>
                                    <br>
                                    <small>در گام دوم عکس کارت ملی و یا پاسپورت خود را ارسال کنید برای افرادی که در ایالات ممنوعه زندگی  میکنند و یا زیر سن قانونی هستند در این بخش همان عکس شناسنامه خود را ارسال کنند</small>
                                    <br>
                                    <br>
                                    <small> درگام سوم شما باید شناسنامه و یا کارت ملی و یا پاسپورت خود را در کنار صورت خود گرفته و به شکلی که محتوای کارت هویتی و صورت شما در عکس کاملا واضح بیفتد</small>&nbsp<small>ارسال کنید</small>
                                    <br>
                                    <br>
                                    <small>گام چهارم مخصوص صاحبان شرکت است که بر روی یک کاغذ نمونه ای از امضای خود را کشیده و عکس گرفته و ارسال کنید افرادی که اشخاص حقیق هستند لازم به ارسال این مدرک ندارد و فیلد آن را خالی بگذارید</small>
                                </div>
                                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                    ما در این مرحله پیشینه و استعداد ها و هر اطلاعاتی که در اختیار داریم را تحلیل کرده و سپس از تایید به انجمن میروید
                                    </div>
                                <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                    در این قسمت ما در یک انجمن چند نفره راجب شما گفتگو میکنیم و در صورت تایید حساب شما تایید خواهد شد فراموش نکنید که فرایند تایید سرویس ما فقط یک فرآیند تایید نیست بلکه یک فرآنید دوست یابی و همکاری اسن و ما برای همکاری هم روی شما حساب میکنیم
                                </div>
                                </div>
                            </div>
                            </div>



							</div>
							<!-- Button -->

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
                            <br>
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ارسال مدارک </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">105</font></font></span></h5>
							<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک پست ایجاد کنید</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0" id="display1">
                            
                            <?php
                            if($user['admin'] == 1){
                                ?>
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-patch-check-fill text-info"></i></font></font></h1>
                                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب شما تایید شد</font></font></h2>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تبریک میگوییم جساب شما تایید شد و از اکنون میتوانید فعالیت خود را آغاز کنید طبق دستورالعمل و به فعالیت های تحاری و حقیق خود بپیوندید ممنون از انتخاب شما </font></font></p>
                                        <a href="dashboard.php?content=editProfile" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت صفحه حساب  </font></font></a>
                                    </div>
                                    </div>
                                    </div>
                                </section>
                                <?php
                            }elseif($user['admin'] == 3){
                                ?>
                                <div class="alert alert-dark" role="alert">
                                درخواست تایید سابق شما متاسفانه پذیرفته نشد بع دلیل دتورالعمل های انجمن اما ما شمارا محدود نکردیم و با اصلاح اطلاعات میتوانید دوباره درخواست صادر کنید با تشکر
                                </div>
                                <?php
                                if($strok == 0){
                                    ?>
                                    <style>
                                        body {
                                            margin-top:40px;
                                        }
                                        .stepwizard-step p {
                                            margin-top: 10px;
                                        }
                                        .stepwizard-row {
                                            display: table-row;
                                        }
                                        .stepwizard {
                                            display: table;
                                            width: 50%;
                                            position: relative;
                                        }
                                        .stepwizard-step button[disabled] {
                                            opacity: 1 !important;
                                            filter: alpha(opacity=100) !important;
                                        }
                                        .stepwizard-row:before {
                                            top: 14px;
                                            bottom: 0;
                                            position: absolute;
                                            content: " ";
                                            width: 100%;
                                            height: 1px;
                                            background-color: #ccc;
                                            z-order: 0;
                                        }
                                        .stepwizard-step {
                                            display: table-cell;
                                            text-align: center;
                                            position: relative;
                                        }
                                        .btn-circle {
                                            width: 30px;
                                            height: 30px;
                                            text-align: center;
                                            padding: 6px 0;
                                            font-size: 12px;
                                            line-height: 1.428571429;
                                            border-radius: 15px;
                                        }
                                    </style>
                                    <script>
                                        $(document).ready(function () {
                                        var navListItems = $('div.setup-panel div a'),
                                                allWells = $('.setup-content'),
                                                allNextBtn = $('.nextBtn'),
                                                allPrevBtn = $('.prevBtn');
    
                                        allWells.hide();
    
                                        navListItems.click(function (e) {
                                            e.preventDefault();
                                            var $target = $($(this).attr('href')),
                                                    $item = $(this);
    
                                            if (!$item.hasClass('disabled')) {
                                                navListItems.removeClass('btn-primary').addClass('btn-default');
                                                $item.addClass('btn-primary');
                                                allWells.hide();
                                                $target.show();
                                                $target.find('input:eq(0)').focus();
                                            }
                                        });
                                        
                                        allPrevBtn.click(function(){
                                            var curStep = $(this).closest(".setup-content"),
                                                curStepBtn = curStep.attr("id"),
                                                prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");
    
                                                prevStepWizard.removeAttr('disabled').trigger('click');
                                        });
    
                                        allNextBtn.click(function(){
                                            var curStep = $(this).closest(".setup-content"),
                                                curStepBtn = curStep.attr("id"),
                                                nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                                                curInputs = curStep.find("input[type='text'],input[type='url']"),
                                                isValid = true;
    
                                            $(".form-group").removeClass("has-error");
                                            for(var i=0; i<curInputs.length; i++){
                                                if (!curInputs[i].validity.valid){
                                                    isValid = false;
                                                    $(curInputs[i]).closest(".form-group").addClass("has-error");
                                                }
                                            }
    
                                            if (isValid)
                                                nextStepWizard.removeAttr('disabled').trigger('click');
                                        });
    
                                        $('div.setup-panel div a.btn-primary').trigger('click');
                                        });
                                    </script>
                                    <div class="container"></div>,<div class="container">
                                    
                                    <div class="stepwizard col-md-offset-3">
                                        <div class="stepwizard-row setup-panel">
                                            <div class="stepwizard-step">
                                            <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
                                            <p>مرحله اول</p>
                                            </div>
                                            <div class="stepwizard-step">
                                            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                                            <p>مرحله دوم</p>
                                            </div>
                                            <div class="stepwizard-step">
                                            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                                            <p>مرحله سوم</p>
                                            </div>
                                        </div>
                                        </div>
                                        
                                        <form role="form" action="" method="post" id="formgetData">
                                        <div class="row setup-content" id="step-1">
                                            <div class="col-xs-6 col-md-offset-3">
                                            <div class="col-md-12">
                                                <h3>ارسال مدارک متنی</h3>
                                                <small>فایل های تصویری خود را در این سایت آپلود کنید و سپس لینک فایل را کپی کرده و در این قسمت های مشخص شده بزنید <a href="https://up.20script.ir/index.php" target="_blank">آپلود عکس ها</a></small>
                                                <br>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس از صفحه اصلی شناسنامه</label>
                                                <input maxlength="200" type="text" name="data1" required="required" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>یک عکس از صفحه اصلی شناسنامه محلی خود در هر ایالات و یا کشوری که هستید برای ما ارسال میکنید</small>
                                                </div>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس از کارت ملی یا پاسپورت</label>
                                                <input maxlength="200" type="text" name="data2" required="required" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>عکس کارت ملی و یا پاسپورت خود را ارسال کنید برای افرادی که در ایالات ممنوعه زندگی میکنند و یا زیر سن قانونی هستند در این بخش همان عکس شناسنامه خود را ارسال کنند</small>
                                                </div>
                                                <br>
                                             
                                                <button class="btn btn-primary nextBtn btn-lg pull-right" type="button">بعدی</button>
                                            </div>
                                            </div>
                                        </div>
                                        <div class="row setup-content" id="step-2">
                                            <div class="col-xs-6 col-md-offset-3">
                                            <div class="col-md-12">
                                                <h3> اعتبار سنجی مدارک</h3>
                                                <small>فایل های تصویری خود را در این سایت آپلود کنید و سپس لینک فایل را کپی کرده و در این قسمت های مشخص شده بزنید <a href="https://up.20script.ir/index.php" target="_blank">آپلود عکس ها</a></small>
                                                <br>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس خود به همراه کارت ملی یا پاسپورت</label>
                                                <input maxlength="200" type="text" required="required" name="data3" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>شما باید شناسنامه و یا کارت ملی و یا پاسپورت خود را در کنار صورت خود گرفته و به شکلی که محتوای کارت هویتی و صورت شما در عکس کاملا واضح بیفتد ارسال کنید</small>
                                                </div>
                                                <div class="form-group">
                                                <label class="control-label">عکس امضاع شما</label>
                                                <input maxlength="200" type="text" class="form-control" name="data4" placeholder="لینک عکس را وارد کنید">
                                                <small>خصوص صاحبان شرکت است که بر روی یک کاغذ نمونه ای از امضای خود را کشیده و عکس گرفته و ارسال کنید افرادی که اشخاص حقیق هستند لازم به ارسال این مدرک ندارد و فیلد آن را خالی بگذارید</small>
                                                </div>
                                                <br>
                                            </div>
                                        <div id="displayError"></div>
                                        <button class="btn btn-primary prevBtn btn-lg pull-left" type="button">قبلی</button>
                                        <button class="btn btn-primary btn-lg pull-left" id="submitBTN" type="submit">ارسال</button>
                                        </form>
                                        <script>
                                                $(document).ready(function(){
                                                    $("#formgetData").on("submit", function(event){
                                                        event.preventDefault();
                                                        $('#submitBTN').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
    
                                                        var formValues= $('#formgetData').serialize();
    
                                                        $.post("../../index.php?controller=account&method=edit&mode=6", formValues, function(data){
                                                            // Display the returned data in browser
                                                            $('#displayError').html(data);
                                                            $('#submitBTN').html('ارسال شد');
    
                                                        });
                                                    });
                                                });
                                        </script>
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <section class="overflow-hidden">
                                        <div class="container">
                                            <div class="row">
                                        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                            <!-- SVG shape START -->
                                            <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                <g>
                                                <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                </g>
                                            </svg>
                                            </figure>
                                            <!-- SVG shape START -->
                                            <!-- Content -->
                                            <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-link-45deg"></i></font></font></h1>
                                            <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات تکمیل نیست</font></font></h2>
                                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لطفا نواقص حساب خود را که در بالا به آن اشاره کرده ایم را بخوانید و تصحیح کنید تا قسمت بارگذاری مدارک برایتان بارگذاری شود</font></font></p>
                                            <a href="dashboard.php?content=editProfile" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت به صفحه مدیریت</font></font></a>
                                        </div>
                                        </div>
                                        </div>
                                    </section>
                                    <?php
                                }
                            }elseif($user['admin'] == 2){
                                ?>
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درحال برسی انجمن</font></font></h2>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">انجمن ما طبق دستور العمل گفته شده در بالا عمل میکند و به دنبال برسی حساب شما هستیم ممکن است کمی طول بکشد ممنونیم از همراهی شما ما در تلاشیم تا حسابتان را تایید کنیم مبلغ مذکور را از حسابتان کم نکردیم تا زمانی که تایید شوید اگر مشکلی پیش آمد به ما بگویید </font></font></p>
                                        <a href="index.php" class="btn btn-danger-soft mt-3" id="cancelRep"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو درخواست</font></font></a>
                                        <script>
                                            $('#cancelRep').click(function(event){
                                            event.preventDefault();
                                            $('#cancelRep').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=edit&mode=7",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#display1').html(data);
                                                })

                                            })
                                        </script>
                                    </div>
                                    </div>
                                    </div>
                                </section>
                                <?php
                            }else{
                                if($strok == 0){
                                    ?>
                                    <style>
                                        body {
                                            margin-top:40px;
                                        }
                                        .stepwizard-step p {
                                            margin-top: 10px;
                                        }
                                        .stepwizard-row {
                                            display: table-row;
                                        }
                                        .stepwizard {
                                            display: table;
                                            width: 50%;
                                            position: relative;
                                        }
                                        .stepwizard-step button[disabled] {
                                            opacity: 1 !important;
                                            filter: alpha(opacity=100) !important;
                                        }
                                        .stepwizard-row:before {
                                            top: 14px;
                                            bottom: 0;
                                            position: absolute;
                                            content: " ";
                                            width: 100%;
                                            height: 1px;
                                            background-color: #ccc;
                                            z-order: 0;
                                        }
                                        .stepwizard-step {
                                            display: table-cell;
                                            text-align: center;
                                            position: relative;
                                        }
                                        .btn-circle {
                                            width: 30px;
                                            height: 30px;
                                            text-align: center;
                                            padding: 6px 0;
                                            font-size: 12px;
                                            line-height: 1.428571429;
                                            border-radius: 15px;
                                        }
                                    </style>
                                    <script>
                                        $(document).ready(function () {
                                        var navListItems = $('div.setup-panel div a'),
                                                allWells = $('.setup-content'),
                                                allNextBtn = $('.nextBtn'),
                                                allPrevBtn = $('.prevBtn');
    
                                        allWells.hide();
    
                                        navListItems.click(function (e) {
                                            e.preventDefault();
                                            var $target = $($(this).attr('href')),
                                                    $item = $(this);
    
                                            if (!$item.hasClass('disabled')) {
                                                navListItems.removeClass('btn-primary').addClass('btn-default');
                                                $item.addClass('btn-primary');
                                                allWells.hide();
                                                $target.show();
                                                $target.find('input:eq(0)').focus();
                                            }
                                        });
                                        
                                        allPrevBtn.click(function(){
                                            var curStep = $(this).closest(".setup-content"),
                                                curStepBtn = curStep.attr("id"),
                                                prevStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");
    
                                                prevStepWizard.removeAttr('disabled').trigger('click');
                                        });
    
                                        allNextBtn.click(function(){
                                            var curStep = $(this).closest(".setup-content"),
                                                curStepBtn = curStep.attr("id"),
                                                nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                                                curInputs = curStep.find("input[type='text'],input[type='url']"),
                                                isValid = true;
    
                                            $(".form-group").removeClass("has-error");
                                            for(var i=0; i<curInputs.length; i++){
                                                if (!curInputs[i].validity.valid){
                                                    isValid = false;
                                                    $(curInputs[i]).closest(".form-group").addClass("has-error");
                                                }
                                            }
    
                                            if (isValid)
                                                nextStepWizard.removeAttr('disabled').trigger('click');
                                        });
    
                                        $('div.setup-panel div a.btn-primary').trigger('click');
                                        });
                                    </script>
                                    <div class="container"></div>,<div class="container">
                                    
                                    <div class="stepwizard col-md-offset-3">
                                        <div class="stepwizard-row setup-panel">
                                            <div class="stepwizard-step">
                                            <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
                                            <p>مرحله اول</p>
                                            </div>
                                            <div class="stepwizard-step">
                                            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                                            <p>مرحله دوم</p>
                                            </div>
                                            <div class="stepwizard-step">
                                            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                                            <p>مرحله سوم</p>
                                            </div>
                                        </div>
                                        </div>
                                        
                                        <form role="form" action="" method="post" id="formgetData">
                                        <div class="row setup-content" id="step-1">
                                            <div class="col-xs-6 col-md-offset-3">
                                            <div class="col-md-12">
                                                <h3>ارسال مدارک متنی</h3>
                                                <small>فایل های تصویری خود را در این سایت آپلود کنید و سپس لینک فایل را کپی کرده و در این قسمت های مشخص شده بزنید <a href="https://up.20script.ir/index.php" target="_blank">آپلود عکس ها</a></small>
                                                <br>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس از صفحه اصلی شناسنامه</label>
                                                <input maxlength="200" type="text" name="data1" required="required" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>یک عکس از صفحه اصلی شناسنامه محلی خود در هر ایالات و یا کشوری که هستید برای ما ارسال میکنید</small>
                                                </div>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس از کارت ملی یا پاسپورت</label>
                                                <input maxlength="200" type="text" name="data2" required="required" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>عکس کارت ملی و یا پاسپورت خود را ارسال کنید برای افرادی که در ایالات ممنوعه زندگی میکنند و یا زیر سن قانونی هستند در این بخش همان عکس شناسنامه خود را ارسال کنند</small>
                                                </div>
                                                <br>
                                             
                                                <button class="btn btn-primary nextBtn btn-lg pull-right" type="button">بعدی</button>
                                            </div>
                                            </div>
                                        </div>
                                        <div class="row setup-content" id="step-2">
                                            <div class="col-xs-6 col-md-offset-3">
                                            <div class="col-md-12">
                                                <h3> اعتبار سنجی مدارک</h3>
                                                <small>فایل های تصویری خود را در این سایت آپلود کنید و سپس لینک فایل را کپی کرده و در این قسمت های مشخص شده بزنید <a href="https://up.20script.ir/index.php" target="_blank">آپلود عکس ها</a></small>
                                                <br>
                                                <br>
                                                <div class="form-group">
                                                <label class="control-label">عکس خود به همراه کارت ملی یا پاسپورت</label>
                                                <input maxlength="200" type="text" required="required" name="data3" class="form-control" placeholder="لینک عکس را وارد کنید">
                                                <small>شما باید شناسنامه و یا کارت ملی و یا پاسپورت خود را در کنار صورت خود گرفته و به شکلی که محتوای کارت هویتی و صورت شما در عکس کاملا واضح بیفتد ارسال کنید</small>
                                                </div>
                                                <div class="form-group">
                                                <label class="control-label">عکس امضاع شما</label>
                                                <input maxlength="200" type="text" class="form-control" name="data4" placeholder="لینک عکس را وارد کنید">
                                                <small>خصوص صاحبان شرکت است که بر روی یک کاغذ نمونه ای از امضای خود را کشیده و عکس گرفته و ارسال کنید افرادی که اشخاص حقیق هستند لازم به ارسال این مدرک ندارد و فیلد آن را خالی بگذارید</small>
                                                </div>
                                                <br>
                                            </div>
                                        <div id="displayError"></div>
                                        <button class="btn btn-primary prevBtn btn-lg pull-left" type="button">قبلی</button>
                                        <button class="btn btn-primary btn-lg pull-left" id="submitBTN" type="submit">ارسال</button>
                                        </form>
                                        <script>
                                                $(document).ready(function(){
                                                    $("#formgetData").on("submit", function(event){
                                                        event.preventDefault();
                                                        $('#submitBTN').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
    
                                                        var formValues= $('#formgetData').serialize();
    
                                                        $.post("../../index.php?controller=account&method=edit&mode=6", formValues, function(data){
                                                            // Display the returned data in browser
                                                            $('#displayError').html(data);
                                                            $('#submitBTN').html('ارسال شد');
    
                                                        });
                                                    });
                                                });
                                        </script>
                                    </div>
                                    <?php
                                }else{
                                    ?>
                                    <section class="overflow-hidden">
                                        <div class="container">
                                            <div class="row">
                                        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                            <!-- SVG shape START -->
                                            <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                <g>
                                                <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                </g>
                                            </svg>
                                            </figure>
                                            <!-- SVG shape START -->
                                            <!-- Content -->
                                            <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-link-45deg"></i></font></font></h1>
                                            <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات تکمیل نیست</font></font></h2>
                                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لطفا نواقص حساب خود را که در بالا به آن اشاره کرده ایم را بخوانید و تصحیح کنید تا قسمت بارگذاری مدارک برایتان بارگذاری شود</font></font></p>
                                            <a href="dashboard.php?content=editProfile" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت به صفحه مدیریت</font></font></a>
                                        </div>
                                        </div>
                                        </div>
                                    </section>
                                    <?php
                                }
                            }
                            ?>





							</div>
							<!-- Button -->

					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>