<?php
if(! isset($_GET['id'])){
    echo "<script type='text/javascript'>window.location.href='dashboard.php?content=profile&id=".$_SESSION['id']."'</script>";
    die();
}
$query_1212 = mysqli_query($con, 'select * from user where iduser="'.$_GET['id'].'"');
$user1 = mysqli_fetch_assoc($query_1212);
if(! $user1){
    die();
}
?>

<title><?php echo $user1['username']?> - <?php echo $user1['job']?> | پیپرلاین</title>

<section class="py-4">
	<div class="container">
	 
    <div class="row g-4">
      <!-- Profile cover and info START -->
      <div class="col-12">
        <div class="card mb-4 position-relative z-index-9">
          <!-- Cover image -->
          <?php
          if(strlen($user1['isport']) < 1){
            ?>
            <div class="py-5 h-200 rounded" style="background-image:url(https://www.spacify.ir/public/img/logo/card-3.svg); background-position: center bottom; background-size: cover; background-repeat: no-repeat;">
            <?php
          }else{
            ?>
            <div class="py-5 h-200 rounded" style="background-image:url(<?php echo $user1['isport']?>); background-position: center bottom; background-size: cover; background-repeat: no-repeat;">
            <?php
          }
          
          ?>
          </div>
          <div class="card-body pt-3 pb-0">
            <div class="row d-flex justify-content-between">
              <!-- Avatar -->
              <div class="col-sm-12 col-md-auto text-center text-md-start">
                <div class="avatar avatar-xxl mt-n5">
                  <img class="avatar-img rounded-circle border border-white border-3 shadow" src="<?php echo $user1['avatar']?>" alt="">
                </div>
              </div>
              <!-- Profile info -->
              <div class="col-sm-12 col-md text-center text-md-start d-md-flex justify-content-between align-items-center">
                <div>

                <?php
                            $followed = 0;
                            $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_GET['id'].'" order by list Desc');
                            $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_GET['id'].'" order by list Desc');
                            $file = mysqli_fetch_assoc($query_1212);
                            if($file){

                              while($res=mysqli_fetch_assoc($file_hash)){
                              
                                $followed = $followed+1;
                              }
                            }


                ?>
                <?php
                if($user1['enabled'] == 0){
                  ?>
                  <a href="#" class="btn btn-sm btn-danger-soft btn-xs"><i class="bi bi-exclamation-circle-fill"></i> حساب معلق است</a>
                  <?php
                }elseif($user1['enabled'] == 2){
                  ?>
                  <a href="#" class="btn btn-sm btn-danger-soft btn-xs"><i class="bi bi-exclamation-circle-fill"></i> حساب محدود شده</a>
                  <?php
                }
                ?>
                  <h4 class="my-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user1['username']?></font></font> <?php
                                                                        if($user1['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></h4>
                                  <?php
                    if($user1['EZip_code'] == 1){
                      ?>
                     <img src="https://cdn-icons-png.flaticon.com/512/6784/6784655.png" style="width: 22px;" alt="">

                      <?php
                    }
                  ?>
                  <a href="https://spacify.ir/index.php?controller=user&method=profile&id=<?php echo $user1['iduser']?>"><span class="badge bg-primary rounded-pill"><font style="vertical-align: inherit;">QPassID<?php echo $user1['iduser']?>@</font></span></a>
  
                  <small><?php echo $user1['about']?></small>
                  <ul class="list-inline">
                  <a href="dashboard.php?content=follower&id=<?php echo $_GET['id']?>" class="btn btn-light btn-xs"><li class="list-inline-item"><i class="bi bi-person-fill me-1"></i> <?php echo number_format($user1['follower'] , 0 , "." , "," )?></li></a>
                  <a href="dashboard.php?content=followed&id=<?php echo $_GET['id']?>" class="btn btn-light btn-xs"><li class="list-inline-item"><i class="bi bi-person-fill me-1"></i> <?php echo number_format($followed , 0 , "." , "," )?> دنبال</li></a>
                    <li class="list-inline-item"><i class="bi bi-geo-alt me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایران</font></font></li>
                    <li class="list-inline-item"><i class="bi bi-briefcase"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $user1['job']?></font></font></li>
                    <li class="list-inline-item"><i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <a href="<?php echo $user1['url']?>"><?php echo $user1['url']?></a></font></font></li>
                    <?php 
                    if(strlen($user1['codefoxs']) > 5){
                      ?>
                      <li class="list-inline-item"><i class="bi bi-file-earmark-text"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <a href="<?php echo $user1['codefoxs']?>"  class="btn btn-link" style="color: black;">@رزومه</a></font></font></li>

                      <?php
                    }
            
                    ?>
                  </ul>
                  <p class="m-0"></p>
                </div>

       
                <!-- Links -->
                <div class="d-flex align-items-center justify-content-center justify-content-md-end">
                <?php

                $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$_GET['id'].'"');
                $follow = mysqli_fetch_assoc($file_hash);
                if($follow){
                    ?>
                    <a id="follow" href="#" class="btn btn-primary-soft me-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                    <?php
                }else{
                    ?>
                    <a id="follow" href="#" class="btn btn-primary-soft me-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                    <?php
                }
                ?>   
                
                <script>
                    $('#follow').click(function(event){
                      event.preventDefault();
                      $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                      $.ajax({
                        method: "POST",
                        url: "../../index.php?controller=create&method=follow&id=<?php echo $_GET['id']?>",
                        data: { code: "1"}
                      })
                        .done(function(data){
                          $('#follow').html(data);
                        })

                    })
                </script>
                  <a href="dashboard.php?content=sendMessage&id=<?php echo $user1['iduser']?>" class="btn btn-dark-soft me-3"><font style="vertical-align: inherit;"><img style="width: 20px; height: 20px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" alt=""><font style="vertical-align: inherit;"> پیام</font></font></a>
                  <!-- Card action START -->
                  <div class="dropdown ms-3">
                    <a class="text-secondary" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                      <!-- Dropdown Icon -->
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle fill="currentColor" cx="3" cy="12" r="2.5"></circle>
                        <circle fill="currentColor" opacity="0.5" cx="12" cy="12" r="2.5"></circle>
                        <circle fill="currentColor" opacity="0.3" cx="21" cy="12" r="2.5"></circle>
                      </svg>
                    </a>               
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                      <li><a class="dropdown-item" href="dashboard.php?content=share&idAccount=<?php echo $_GET['id']?>"><i class="bi bi-share me-2 fw-icon"></i>اشتراک گذاری نمایه</a></li>
                      <li><a class="dropdown-item" href="#"><i class="bi bi-volume-mute me-2 fw-icon"></i>خاموش کردن اعلان</a></li>
                      <li><a class="dropdown-item text-danger" href="#"><i class="bi bi-slash-circle me-2 fw-icon"></i>بلاک کاربر</a></li>
                      <li><hr class="dropdown-divider"></li>

                      <?php
                      if(strlen($user1['instagram']) > 5){
                        ?>
                        <li><a class="dropdown-item" href="<?php echo $user1['instagram']?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                            <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                          </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-meta" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8.217 5.243C9.145 3.988 10.171 3 11.483 3 13.96 3 16 6.153 16.001 9.907c0 2.29-.986 3.725-2.757 3.725-1.543 0-2.395-.866-3.924-3.424l-.667-1.123-.118-.197a54.944 54.944 0 0 0-.53-.877l-1.178 2.08c-1.673 2.925-2.615 3.541-3.923 3.541C1.086 13.632 0 12.217 0 9.973 0 6.388 1.995 3 4.598 3c.319 0 .625.039.924.122.31.086.611.22.913.407.577.359 1.154.915 1.782 1.714Zm1.516 2.224c-.252-.41-.494-.787-.727-1.133L9 6.326c.845-1.305 1.543-1.954 2.372-1.954 1.723 0 3.102 2.537 3.102 5.653 0 1.188-.39 1.877-1.195 1.877-.773 0-1.142-.51-2.61-2.87l-.937-1.565ZM4.846 4.756c.725.1 1.385.634 2.34 2.001A212.13 212.13 0 0 0 5.551 9.3c-1.357 2.126-1.826 2.603-2.581 2.603-.777 0-1.24-.682-1.24-1.9 0-2.602 1.298-5.264 2.846-5.264.091 0 .181.006.27.018Z"/>
                          </svg> نمایه در Meta</a></li>
                        <?php
                      }
                      ?>

                      <?php
                      if(strlen($user1['facebook']) > 5){
                        ?>
 
                        <li><a class="dropdown-item" href="<?php echo $user1['facebook']?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                          <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                        </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-messenger" viewBox="0 0 16 16">
                          <path d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.639.639 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.639.639 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76zm5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z"/>
                        </svg> نمایه در Facebook</a></li>
                        <?php
                      }
                      ?>

                      <?php
                      if(strlen($user1['linkdin']) > 5){
                        ?>
 
                        <li><a class="dropdown-item" href="<?php echo $user1['linkdin']?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
                          <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/>
                        </svg> نمایه در Linkedin</a></li>
                        <?php
                      }
                      ?>

                      <?php
                      if(strlen($user1['towitter']) > 5){
                        ?>
 
          
                        <li><a class="dropdown-item" href="<?php echo $user1['towitter']?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                          <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                        </svg> نمایه  در Twitter</a></li>
                        <?php
                      }
                      ?>


                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="https://www.spacify.ir/index.php?controller=user&method=profile&id=<?php echo $_GET['id']?>"><img src="https://www.spacify.ir/public/img/logo/wizify.png" style="width: 25px;" alt=""> نمایه اسپیسیفای</a></li>
                      <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-flag me-2 fw-icon"></i>گزارش</a></li>
                    </ul>
                  </div>
                  <!-- Card action END -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Profile info END -->
    </div>





    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel" id="sendReporBox"><i class="bi bi-flag me-2 fw-icon"></i>گزارش </h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
            
            <div class="list-group" id="displayReport">
              
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn"><i class="bi bi-trash2"></i> هرزنامه</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn1"><i class="bi bi-behance"></i> جعل هویت</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn2"><i class="bi bi-bug-fill"></i> ربات مخرب</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn3"><i class="bi bi-emoji-angry"></i> خشونت آمیز</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn4"><i class="bi bi-emoji-angry"></i> کودک آزاری</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn5"><i class="bi bi-heart-pulse"></i> نژاد پرستی</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn6"><i class="bi bi-hand-thumbs-down-fill"></i> مستهجن</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn7"><i class="bi bi-globe"></i> خلاف قوانین ایالاتی</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn8"><i class="bi bi-incognito"></i> خطر امنیتی</a>
              <a href="#" class="list-group-item list-group-item-action" id="reportBtn9"><i class="bi bi-file-earmark-ruled"></i> تقاضای خارج از قزاداد</a>
            
            </div>

                                            <script>
                                            $('#reportBtn').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                              <script>
                                            $('#reportBtn1').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn2').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn3').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn4').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn5').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn6').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn7').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>
                                                                                        <script>
                                            $('#reportBtn8').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>

                                           <script>
                                            $('#reportBtn9').click(function(event){
                                            event.preventDefault();
                                            $('#sendReporBox').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=sendReport&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendReporBox').html('<i class="bi bi-flag me-2 fw-icon"></i> ارسال شد ');
                                                $('#displayReport').html(data);
                                                })

                                            })
                                            </script>



        </div>
      </div>
    </div>




















    <ul class="nav">
      <div class="nav my-3 my-xl-0 px-4 px-lg-1 flex-nowrap align-items-center">
					<div class="nav-item w-100">
						<form action="dashboard.php?content=profile&id=<?php echo $_GET['id']?>" method="POST" class="position-relative">
							<input name="search" class="form-control pe-5 bg-transparent" type="search" placeholder="Search /@<?php echo $user1['username']?>" aria-label="Search">
							<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
						</form>
					</div>
			</div>
      <li class="nav-item">
        <a class="nav-link active" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>"><i class="bi bi-cloud-haze2-fill"></i> پیپرپست ها</a>
      </li>

      <li class="nav-item">
        <a class="nav-link active" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&page=6"><i class="bi bi-plus-square-dotted"></i> پیپرز</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&page=2"><i class="bi bi-file-earmark-richtext-fill"></i> دوره ها</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&page=3"><i class="bi bi-git"></i> فایل و منبع</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&page=4"><i class="bi bi-gpu-card"></i> ویدیو ها</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&page=5"><i class="bi bi-grid"></i> پیپرسرویس ها</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#"><i class="bi bi-globe-americas"></i> کامیونیتی </a>
      </li>
 

    </ul>
    <hr>

    


    <div class="row g-4">
      <!-- Left sidebar START -->
      
      <!-- Left sidebar END -->








      <section class="position-relative pt-0">
        <div class="container">

        
          <div class="row g-4">


          <?php
          if(isset($_GET['page'])){
            if($_GET['page'] == '6'){
              $query_1212 = mysqli_query($con, 'select * from blogs where userId="'.$_GET['id'].'" and published="1" order by createDate Desc');
              $file_hash = mysqli_query($con, 'select * from blogs where userId="'.$_GET['id'].'" and published="1" order by createDate Desc');
              $file = mysqli_fetch_assoc($query_1212);
              if($file){
                while($res=mysqli_fetch_assoc($file_hash)){
                  $some_time = strtotime($res['createDate']);
                  
                  ?>

                  <div class="card" id="display<?php echo $res['idBlog']?>">
                    <div class="card-body" style="border: dashed black 2px; border-radius: 5px;  outline: #999 solid 1px;" >
                      <?php 
                      if($_GET['id'] == $_SESSION['id']){
                        ?>

                        <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm" id="deletePost<?php echo $res['idBlog']?>">

                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar2-x" viewBox="0 0 16 16">
                          <path d="M6.146 8.146a.5.5 0 0 1 .708 0L8 9.293l1.146-1.147a.5.5 0 1 1 .708.708L8.707 10l1.147 1.146a.5.5 0 0 1-.708.708L8 10.707l-1.146 1.147a.5.5 0 0 1-.708-.708L7.293 10 6.146 8.854a.5.5 0 0 1 0-.708z"/>
                          <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H2z"/>
                          <path d="M2.5 4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H3a.5.5 0 0 1-.5-.5V4z"/>
                        </svg>
                        حذف
                        </a>

                                            <script>
                                            $('#deletePost<?php echo $res['idBlog']?>').click(function(event){
                                            event.preventDefault();
                                            $('#deletePost<?php echo $res['idBlog']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');
                                        
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=deletePiper&id=<?php echo $res['idBlog']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){

                                                document.getElementById("display<?php echo $res['idBlog']?>").style.display = 'none';
                                                })

                                            })
                                            </script>

                        
                        <a href="dashboard.php?content=createblog&id=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">

                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16" style="color: black;">
                          <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                        </svg>
                        ویرایش
                        </a>
                        <?php
                      }
                      ?>
                      <small><?php echo date('Y, d F', $some_time)?></small>
                      <h5 class="card-title"><?php echo $res['title']?></h5>
                      <?php
                      if(strlen($res['descrip']) > 5){
                        ?>
                        <p class="card-text"><?php echo $res['descrip']?></p>
                        <?php
                      }else{

            

                        $text = $res['blog'];
                        ?>
                        <p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
                        <?php
                      }
                      ?>

                          <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">

													<img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">

													بازکردن با ...
													</a>
                    </div>
                  </div>

                  <?php
                }
              }else{
                ?>
                <section class="overflow-hidden">
                  <div class="container">
                    <div class="row">
                      <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                        <!-- SVG shape START -->
                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                          <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                            <g>
                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                            </g>
                          </svg>
                        </figure>
                        <!-- SVG shape START -->
                        <!-- Content -->
                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی یافت نشد</font></font></h2>
                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی با این مشخصات وجود ندارد یا محدود شده است که نمیتوانید آن را ببینید</font></font></p>
                      </div>
                    </div>
                  </div>
                </section>
                <?php
              }
            }else{
              if($_GET['id'] == $_SESSION['id']){
                $query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and type="'.$_GET['page'].'" order by date Desc');
                $file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and type="'.$_GET['page'].'" order by date Desc');
              }else{
                $query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and published="1" and type="'.$_GET['page'].'" order by date Desc');
                $file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and published="1" and type="'.$_GET['page'].'" order by date Desc');
              }
              $file = mysqli_fetch_assoc($query_1212);
              if($file){
                while($res=mysqli_fetch_assoc($file_hash)){
                  $some_time = strtotime($res['date']);

                  ?>
                  <div class="col-sm-6">
                    <div class="card">
                      <!-- Card img -->
                      <div class="position-relative">
                        <img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
                        <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                          <!-- Card overlay bottom -->
                          <div class="w-100 mt-auto">
                            <!-- Card category -->
                            <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['category']?></a>
                          </div>
                        </div>
                      </div>
                      <div class="card-body px-0 pt-3">
                        <h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h4>
                        <p class="card-text"><?php echo $res['doc']?></p>
                        <!-- Card info -->
                        <ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
                          <li class="nav-item">
                            <div class="nav-link">
                              <div class="d-flex align-items-center position-relative">
                                <div class="avatar avatar-xs">
                                  <img class="avatar-img rounded-circle" src="<?php echo $user1['avatar']?>" alt="avatar">
                                </div>
                                <span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link"><?php echo $user1['username']?></a></span>
                              </div>
                            </div>
                          </li>
                          <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
                        </ul>
                      </div>
                    </div>
                  </div>
  
                  <?php
                }
              }else{
                ?>
                  <section class="overflow-hidden">
                    <div class="container">
                      <div class="row">
                        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                          <!-- SVG shape START -->
                          <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                              <g>
                              <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                              <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                              <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                              <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                              <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                              <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                              <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                              <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                              <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                              <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                              </g>
                            </svg>
                          </figure>
                          <!-- SVG shape START -->
                          <!-- Content -->
                          <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                          <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی یافت نشد</font></font></h2>
                          <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی با این مشخصات وجود ندارد یا محدود شده است که نمیتوانید آن را ببینید</font></font></p>
                        </div>
                      </div>
                    </div>
                  </section>
                <?php
              }
            }

            
          }elseif(isset($_POST['search'])){
            $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE idUser="'.$_GET['id'].'" and (`doc` LIKE "%'.$_POST['search'].'%" or `idPost` LIKE "%'.$_POST['search'].'%" or `title` LIKE "%'.$_POST['search'].'%" or `date` LIKE "%'.$_POST['search'].'%") and published="1" order by date Desc limit 0,1000');
            $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE idUser="'.$_GET['id'].'" and (`doc` LIKE "%'.$_POST['search'].'%" or `idPost` LIKE "%'.$_POST['search'].'%" or `title` LIKE "%'.$_POST['search'].'%" or `date` LIKE "%'.$_POST['search'].'%") and published="1" order by date Desc limit 0,1000');
            $file = mysqli_fetch_assoc($query_1212);
            if($file){
              while($res=mysqli_fetch_assoc($file_hash)){
                $some_time = strtotime($res['date']);

                ?>
                <div class="col-sm-6">
                  <div class="card">
                    <!-- Card img -->
                    <div class="position-relative">
                      <img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
                      <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                        <!-- Card overlay bottom -->
                        <div class="w-100 mt-auto">
                          <!-- Card category -->
                          <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['category']?></a>
                        </div>
                      </div>
                    </div>
                    <div class="card-body px-0 pt-3">
                      <h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h4>
                      <p class="card-text"><?php echo $res['doc']?></p>
                      <!-- Card info -->
                      <ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
                        <li class="nav-item">
                          <div class="nav-link">
                            <div class="d-flex align-items-center position-relative">
                              <div class="avatar avatar-xs">
                                <img class="avatar-img rounded-circle" src="<?php echo $user1['avatar']?>" alt="avatar">
                              </div>
                              <span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link"><?php echo $user1['username']?></a></span>
                            </div>
                          </div>
                        </li>
                        <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
                      </ul>
                    </div>
                  </div>
                </div>

                <?php
              }
            }else{
              ?>
                <section class="overflow-hidden">
                  <div class="container">
                    <div class="row">
                      <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                        <!-- SVG shape START -->
                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                          <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                            <g>
                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                              c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                            </g>
                          </svg>
                        </figure>
                        <!-- SVG shape START -->
                        <!-- Content -->
                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی یافت نشد</font></font></h2>
                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی با این مشخصات وجود ندارد یا محدود شده است که نمیتوانید آن را ببینید</font></font></p>
                      </div>
                    </div>
                  </div>
                </section>
              <?php
            }
          }else{
              ?>
              <div class="list-group" style="text-align: left;">
                
          
                <a href="dashboard.php?content=profile&id=<?php echo $_GET['id']?>&collect=true" class="list-group-item list-group-item-action">  Collections <i class="bi bi-link-45deg" style="font-size: 22px;"></i><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"></path>
                <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"></path>
                </svg></a>

              </div>
              <?php
              if(! isset($_GET['collect'])){
                $query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and published="1" order by date Desc');
                $file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and published="1" order by date Desc');
                $file = mysqli_fetch_assoc($query_1212);
                if($file){
                  while($res=mysqli_fetch_assoc($file_hash)){
                    $some_time = strtotime($res['date']);
                    
                    ?>
                          <?phP
                          if($res['type'] == '1'){
                            $type = 'پست';
                          }elseif($res['type'] == '2'){
                            $type = 'دوره اموزشی';
                          }elseif($res['type'] == '3'){
                            $type = 'فایل و منبع';
                          }elseif($res['type'] =='4'){
                            $type = 'ویدیو';
                          }elseif($res['type'] == '5'){
                            $type = 'سرویس یا خدمات';
                          }else{
                            $type = 'مشخض نیست';
                          }
                          
                          ?>
                      <!-- Card item START -->
                      <div class="col-sm-6 col-lg-4">
                        <div class="card card-overlay-bottom card-img-scale">
                          <!-- Card featured -->
                          <span class="card-featured" title="Featured post"><i class="fas fa-star"></i></span>
                          <!-- Card Image -->
                          <img src="<?php echo $res['art']?>" alt="">
                          <!-- Card Image overlay -->
                          <div class="card-img-overlay d-flex flex-column p-3 p-md-4"> 
                            <div>
                              <!-- Card category -->
                              <a href="#" class="badge text-bg-warning"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['category']?></a>
                              <a href="#" class="badge text-bg-warning"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
                            </div>
                            <div class="w-100 mt-auto">
                              
                              <!-- Card title -->
                              <h4 class="text-white"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link"><?php echo $res['title']?></a></h4>
                              <!-- Card info -->
                              <ul class="nav nav-divider text-white-force align-items-center small">
                                <li class="nav-item position-relative">
                                  <div class="nav-link">code: <a href="#" class="stretched-link text-reset btn-link"><?php echo $res['idPost']?></a>
                                  </div>
                                </li>
                                <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <!-- Card item END -->
    
                    <?php
                  }
                }else{
                  $query_1212 = mysqli_query($con, 'select * from blogs where userId="'.$_GET['id'].'" and published="1" order by createDate Desc');
                  $file_hash = mysqli_query($con, 'select * from blogs where userId="'.$_GET['id'].'" and published="1" order by createDate Desc');
                  $file = mysqli_fetch_assoc($query_1212);
                  if($file){
                    while($res=mysqli_fetch_assoc($file_hash)){
                      $some_time = strtotime($res['createDate']);
                      
                      ?>
    
                      <div class="card" id="display<?php echo $res['idBlog']?>">
                        <div class="card-body" style="border: dashed black 2px; border-radius: 5px;  outline: #999 solid 1px;" >
                          <?php 
                          if($_GET['id'] == $_SESSION['id']){
                            ?>
    
                            <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm" id="deletePost<?php echo $res['idBlog']?>">
    
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar2-x" viewBox="0 0 16 16">
                              <path d="M6.146 8.146a.5.5 0 0 1 .708 0L8 9.293l1.146-1.147a.5.5 0 1 1 .708.708L8.707 10l1.147 1.146a.5.5 0 0 1-.708.708L8 10.707l-1.146 1.147a.5.5 0 0 1-.708-.708L7.293 10 6.146 8.854a.5.5 0 0 1 0-.708z"/>
                              <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H2z"/>
                              <path d="M2.5 4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H3a.5.5 0 0 1-.5-.5V4z"/>
                            </svg>
                            حذف
                            </a>
    
                                                <script>
                                                $('#deletePost<?php echo $res['idBlog']?>').click(function(event){
                                                event.preventDefault();
                                                $('#deletePost<?php echo $res['idBlog']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');
                                            
                                                $.ajax({
                                                    method: "POST",
                                                    url: "../../index.php?controller=create&method=deletePiper&id=<?php echo $res['idBlog']?>",
                                                    data: { code: "1"}
                                                })
                                                    .done(function(data){
    
                                                    document.getElementById("display<?php echo $res['idBlog']?>").style.display = 'none';
                                                    })
    
                                                })
                                                </script>
    
                            
                            <a href="dashboard.php?content=createblog&id=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">
    
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16" style="color: black;">
                              <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                            </svg>
                            ویرایش
                            </a>
                            <?php
                          }
                          ?>
                          <small><?php echo date('Y, d F', $some_time)?></small>
                          <h5 class="card-title"><?php echo $res['title']?></h5>
                          <?php
                          if(strlen($res['descrip']) > 5){
                            ?>
                            <p class="card-text"><?php echo $res['descrip']?></p>
                            <?php
                          }else{
    
                
    
                            $text = $res['blog'];
                            ?>
                            <p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
                            <?php
                          }
                          ?>
    
                              <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">
    
                              <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
    
                              بازکردن با ...
                              </a>
                        </div>
                      </div>
    
                      <?php
                    }
                  }else{
                    ?>
                    <section class="overflow-hidden">
                      <div class="container">
                        <div class="row">
                          <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                            <!-- SVG shape START -->
                            <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                              <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                <g>
                                <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                  c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                  c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                </g>
                              </svg>
                            </figure>
                            <!-- SVG shape START -->
                            <!-- Content -->
                            <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                            <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی یافت نشد</font></font></h2>
                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مخزنی با این مشخصات وجود ندارد یا محدود شده است که نمیتوانید آن را ببینید</font></font></p>
                          </div>
                        </div>
                      </div>
                    </section>
                    <?php
                  }
                }
              }else{
                $query_12121 = mysqli_query($con, 'select * from session where userId="'.$_GET['id'].'" and name="collect" order by createDate Desc');
                $collect_hash = mysqli_query($con, 'select * from session where userId="'.$_GET['id'].'" and name="collect" order by createDate Desc');
                $collect = mysqli_fetch_assoc($query_12121);

                ?>
                <h3><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"></path>
                <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"></path>
                </svg> کالکشن ها</h3>
                <div class="list-group" style="text-align: left;">
                <?php
                if($collect){
                  while($res=mysqli_fetch_assoc($collect_hash)){
                    $query_121214 = mysqli_query($con, 'select * from posts where idUser="'.$_GET['id'].'" and collect='.$res['id'].' and published="1" and status="1" order by date Desc');
                    $postCo = mysqli_fetch_assoc($query_121214);
                    if($postCo){
                      ?>
                      <a href="index.php?content=collection&id=<?php echo $res['id']?>&collect=true" class="list-group-item list-group-item-action">  <?php echo $res['data']?> <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                        <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"></path>
                        <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"></path>
                        </svg></a>
                      <?php
                    }
                  }
                }else{
                  ?>
                  <section class="overflow-hidden">
                    <div class="container">
                      <div class="row">
                        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                          <!-- SVG shape START -->
                          <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                              <g>
                              <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                              <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                              <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                              <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                              <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                              <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                              <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                              <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                              <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                              <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                              </g>
                            </svg>
                          </figure>
                          <!-- SVG shape START -->
                          <!-- Content -->
                          <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                            <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
                            <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
                          </svg></font></font></h1>
                          <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> یافت نشد!</font></font></h2>
                        </div>
                      </div>
                    </div>
                  </section>
                  <?php
                }
                ?>
            


                </div>
                <?php
              }
           
            ?>


            <?php
          }
          ?>





          </div> <!-- Row end -->

        </div>
      </section>













      <!-- Right sidebar START -->
      
    </div>
	</div>
</section>