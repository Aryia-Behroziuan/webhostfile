<?php
if(isset($_GET['alert'])){
	?>
	<audio controls autoplay style="display: none;">
			<source src="https://www.qitsource.ir/public/audio.mp3" type="audio/mpeg">
	</audio>
	<?php
}

?>
<?php
if(isset($_SESSION['ACC-KEY'])){
  ?>
  <script type='text/javascript'>window.location.href='dashboard.php?content=ACCError'</script>
  <?php
  die();
}
?>
<ection class="pt-3 pt-lg-5">
	<div class="container">
		<div class="row">
      <!-- Title -->
      <div class="mb-4">
        <h2 class="m-0"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/cloudy-weather-5568712-4644429.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video> فضای ابری شما</h2>
      </div>
			
	  <?php 
		if(isset($_GET['alert'])){
			?>

			<audio controls autoplay style="display: none;">
			<source src="https://www.qitsource.ir/public/audio.mp3" type="audio/mpeg">
			</audio>

			<div class="alert alert-primary alert-dismissible fade show" role="alert">
				<strong>پیغام </strong> <?php echo $_GET['alert']?>
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
			<?php
		} 
	  ?>
			<!-- Filter START -->
			<aside class="col-xl-4 col-xxl-3">
				<!-- Responsive offcanvas body START -->
				<div class="offcanvas-xl offcanvas-end" tabindex="-1" id="offcanvasSidebar" aria-labelledby="offcanvasSidebarLabel">
					<div class="offcanvas-header bg-light">
						<h5 class="offcanvas-title" id="offcanvasSidebarLabel">Advance Filter</h5>
						<button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar" aria-label="Close"></button>
					</div>
					<div class="offcanvas-body flex-column p-3 p-xl-0">
						<form class="border rounded-2">
							<!-- Availability START -->
								<!-- Title -->
								<h6 class="mb-3">گزینه ها</h6>
								<hr>

								<div class="list-group">
								
								
								<a class="list-group-item list-group-item-action" href="dashboard.php?content=cloud&page=all"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/internet-4029216-3337894.png" style="width: 40px;" alt="">همه مخزن ها</a>
								<a class="list-group-item list-group-item-action" href="dashboard.php?content=cloud&page=update"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/backup-4029226-3337925.png" style="width: 40px;" alt="">در حال به روز رسانی</a>

								<a class="list-group-item list-group-item-action" href="dashboard.php?content=cloud&page=not"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/block-layer-4029203-3337905.png" style="width: 40px;" alt="">مخازن تعلیق شده</a>
								<a class="list-group-item list-group-item-action" href="dashboard.php?content=cloud&page=sub"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/color-palette-4029197-3337901.png" style="width: 40px;" alt="">اشتراک ها</a>

								</div>
							
							<!-- Availability END -->

		
						</form><!-- Form End -->
					</div>
					<!-- Buttons -->
					<div class="d-flex justify-content-between p-2 p-xl-0 mt-xl-3">
						<button class="btn btn-link p-0 mb-0">Clear all</button>
						<button class="btn btn-primary mb-0">Filter Result</button>
					</div>
				</div>
				<!-- Responsive offcanvas body END -->
			</aside>
			<!-- Filter END -->

			<!-- Main part START -->
			<div class="col-xl-9">

				<!-- Search filter START -->
				<form action="" method="POST" class="row g-2 g-xl-4 mb-4">
					<!-- Search -->
					<div class="col-xl-6">
            			<div class="rounded position-relative">
							<input name="search" class="form-control pe-5" type="search" placeholder="Search products by name or keyword..." aria-label="Search">
							<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="bi bi-search fs-5"> </i></button>
						</div>
					</div>

					<!-- Select -->
					<div class="col-md-4 col-xl-3">
						<select class="form-select" aria-label="Default select example">
							<option selected="">Filter</option>
							<option value="1">T-shirts</option>
							<option value="2">Shoes</option>
							<option value="3">Tracking bags</option>
						</select>
					</div>

					<!-- Select -->
					<div class="col-md-4 col-xl-3">
						<select class="form-select" aria-label="Default select example">
							<option selected="">Sort by</option>
							<option value="1">Name</option>
							<option value="2">Low to High Price</option>
							<option value="3">Heigh to Low Price</option>
						</select>
					</div>

          <div class="col-md-4 col-xl-3 d-grid d-xl-none">
            <!-- Filter offcanvas button -->
						<button class="btn btn-primary-soft btn-primary-check mb-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar" aria-controls="offcanvasSidebar">
							<i class="fas fa-sliders-h me-1"></i> Show filter
						</button>
          </div>
				</form>
				<!-- Search filter END -->

				<!-- Product START -->
				<div class="row g-4">

					<!-- Adv START -->
					<div class="col-12">
						<div class="rounded-2 bg-dark-overlay-5 overflow-hidden p-4 p-md-5" style="background-image: url(assets/images/shop/bg-offer.jpg);">
							<div class="d-md-flex justify-content-between align-items-center">
								<h4 class="text-white mb-2 mb-md-0">Save up to 40% with orders above $100</h4>
								<a href="#" class="btn btn-primary mb-0">Shop Now</a>
							</div>
						</div>
					</div>
					<!-- Adv END -->

	
					<?php


					$query_1212 = mysqli_query($con, 'select * from session where userId="'.$user['iduser'].'" and name="order" order by createDate Desc');
					$file_hash = mysqli_query($con, 'select * from session where userId="'.$user['iduser'].'" and name="order" order by createDate Desc');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
							if(isset($_GET['page'])){
								if($_GET['page'] == 'update'){
									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'" and published="0"'));

								}elseif($_GET['page'] == 'all'){
									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'" and (`type` = "1" or `type` = "2" or `type` = "3" or `type` = "4")'));

								}elseif($_GET['page'] == 'not'){
									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'" and published="2"'));
								}elseif($_GET['page'] == 'order'){
									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'" and type="5"'));
								}else{
									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'"'));
								}
							}else{
								$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'" and (`type` = "1" or `type` = "2" or `type` = "3" or `type` = "4")'));
								
								
							
							
							}
							
							if($post){
								?>
								
								
								<!-- Product item START -->
								<div class="col-sm-6 col-md-4">
									<div class="card border p-3 h-100">
										<!-- Image -->
										<a href="shop-detail.html"><img class="card-img" src="<?php echo $post['art']?>" alt=""></a>
					
										<!-- Card body -->
										<div class="card-body text-center p-3 px-0">
											<!-- Badge and price -->
											<div class="d-flex justify-content-center mb-2">
												<ul class="list-inline mb-0">
													<li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
													<li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
													<li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
													<li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
													<li class="list-inline-item me-0 small"><i class="fas fa-star-half-alt text-warning"></i></li>
												</ul>
											</div>
											<!-- Title -->
											<h5 class="card-title"><a href="shop-detail.html"><?php echo $post['title']?></a></h5>
											<?php
											if($post['type'] == 5){
												if($post['inter'] == 1){
													if($res['status'] == '1'){
														if($post['published'] == '0'){
															$alert = 'در حال به روز رسانی';
														}elseif($post['published'] == '2'){
															$alert = 'سرویس تعلیق است';
														}else{
															$alert = '';
														}
														?>
	
														<h6 class="mb-0 text-success"><?php echo $alert?></h6>
														</div>
						
														<!-- Card footer -->
														<div class="card-footer text-center p-0">
															<!-- Button -->
															<a href="dashboard.php?content=open&id=<?php echo $post['idPost']?>" class="btn btn-sm btn-primary-soft mb-0"><i class="bi bi-link-45deg"></i> باز کنید..</a>
														</div>
														<?php
													}elseif($res['status'] == '2'){
														?>
														<h6 class="mb-0 text-success">تایید نشد و مبلغ به کیف پول شما بازگشت</h6>
														</div>
						
														<!-- Card footer -->
														<div class="card-footer text-center p-0">
															<!-- Button -->
														</div>
														<?php
													}else{
														?>
														<h6 class="mb-0 text-success">در انتظار تایید</h6>
														</div>
						
														<!-- Card footer -->
														<div class="card-footer text-center p-0">
															<!-- Button -->
														</div>
														<?php
													}
												}else{
													?>
													<?php
													if($post['published'] == '0'){
														$alert = 'در حال به روز رسانی';
														?>
														<h6 class="mb-0 text-success"><?php echo $alert?></h6>
														<?php
													}elseif($post['published'] == '2'){
														$alert = 'سرویس تعلیق است';
														?>
														<h6 class="mb-0" style="color: #6D0000;"><?php echo $alert?></h6>
														<?php
													}
													?>

													<h6 class="mb-0 text-success"></h6>
													</div>
					
													<!-- Card footer -->
													<div class="card-footer text-center p-0">
														<!-- Button -->
														<a href="dashboard.php?content=open&id=<?php echo $post['idPost']?>" class="btn btn-sm btn-primary-soft mb-0"><i class="bi bi-link-45deg"></i> باز کنید..</a>
													</div>
												
													<?php
												}

											}else{
												?>
													<?php
													if($post['published'] == '0'){
														$alert = 'در حال به روز رسانی';
														?>
														<h6 class="mb-0 text-success"><?php echo $alert?></h6>
														<?php
													}elseif($post['published'] == '2'){
														$alert = 'سرویس تعلیق است';
														?>
														<h6 class="mb-0" style="color: #6D0000;"><?php echo $alert?></h6>
														<?php
													}
													?>

													<h6 class="mb-0 text-success"></h6>
													</div>
					
													<!-- Card footer -->
													<div class="card-footer text-center p-0">
														<!-- Button -->
														<a href="dashboard.php?content=open&id=<?php echo $post['idPost']?>" class="btn btn-sm btn-primary-soft mb-0"><i class="bi bi-link-45deg"></i> باز کنید..</a>
													</div>
												
												<?php
											}
											
											?>

									</div>
								</div>
								<!-- Product item END -->
								<?php
							}
						}
					}else{
						?>
								<div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 id="sppiner_se" class="display-1 text-primary"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/notification-5192262-4340267.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video></h1>
                                        <h2 id="sppiner_se1">مخزنی یافت نشد در فضای شما</h2>
                                        <p id="sppiner_se2">به نظر میرسد شما هنوز از پیپرلاین خریدی انجام نداده اید تا ما ان را در فضای کاری شما پردازش کنیم تا بتوانید از ان استفاده کنید</p>
                                    </div>
                                </div>
						<?php
					}
					?>

		


					<!-- Pagination START -->
					<div class="col-12">
						<nav class="d-flex justify-content-center" aria-label="navigation">
							<!-- Pagination 1 2 3  -->
							<ul class="pagination pagination-bordered justify-content-center d-inline-block d-lg-flex">
								<li class="page-item">
									<a class="page-link" href="#">First</a>
								</li>
								<li class="page-item"><a class="page-link" href="#">1</a></li>
								<li class="page-item active"><a class="page-link" href="#">2</a></li>
								<li class="page-item disabled"><a class="page-link" href="#">..</a></li>
								<li class="page-item"><a class="page-link" href="#">22</a></li>
								<li class="page-item"><a class="page-link" href="#">23</a></li>
								<li class="page-item">
									<a class="page-link" href="#">Last</a>
								</li>
							</ul>
						</nav>
					</div>
					<!-- Pagination END -->
				</div>
				<!-- Product END -->

			</div>
			<!-- Main part END -->
		</div>
	</div>
</section>