<section class="py-4">
	<div class="container">
		<div class="row g-4">


		<?php
		if($user['piperAdmin'] == 1){
			?>
			<a class="btn btn-dark-soft" href="dashboard.php?content=manageACC">مدیریت حساب ها</a>
			<a class="btn btn-dark-soft" href="dashboard.php?content=managePOSTREQ">مدیریت پست ها</a>
			<a class="btn btn-dark-soft" href="dashboard.php?content=ManageMany">مدیریت </a>
			<?php
		}
		
		?>

			<div class="col-12">
				<!-- Counter START -->
				<div class="row g-4">
					
					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="dashboard.php?content=follower&id=<?php echo $user['iduser']?>">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
									<i class="bi bi-people-fill"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo number_format($user['follower'] , 0 , "." , "," )?></h3>
									<h6 class="mb-0">دنبال کنندگان</h6>
								</div>
							</div>
						</div>
						</a>
					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="dashboard.php?content=payment">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-primary bg-opacity-10 rounded-3 text-primary">
                                    <i class="bi bi-currency-dollar"></i>								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo number_format($user['Income'] , 0 , "." , "," )?> تومان</h3>
									<h6 class="mb-0">درامد</h6>
								</div>
							</div>
						</div>
						</a>
					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
					<a href="dashboard.php?content=bys">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
									<i class="bi bi-suit-heart-fill"></i>
								</div>

								<?php 
								$num = 0;
								$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
								$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
									$num = $num+$res['by'];
									}
								}
								?>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $num?></h3>
									<h6 class="mb-0">تعداد عرضه</h6>
								</div>
							</div>
						</div>
					</a>
					</div>

                    					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
					<a href="dashboard.php?content=listPost">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
									<i class="bi bi-life-preserver"></i>
								</div>
								<?php 
								$num1 = 0;
								$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
								$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
									$num1 = $num1+1;
									}
								}
								?>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $num1?></h3>
									<h6 class="mb-0">عرضه ها</h6>
								</div>
							</div>
						</div>
					</a>
					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
					<a href="dashboard.php?content=profile&id=42&page=6">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-primary bg-opacity-10 rounded-3 text-primary">
								<i class="bi bi-plus-square-dotted"></i>								</div>
								<!-- Content -->
								<?php 
								$num2 = 0;
								$query_1212 = mysqli_query($con, 'select * from blogs where userId="'.$_SESSION['id'].'" and published="1" order by createDate Desc');
								$file_hash = mysqli_query($con, 'select * from blogs where userId="'.$_SESSION['id'].'" and published="1" order by createDate Desc');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
									$num2 = $num2+1;
									}
								}
								?>
								<div class="ms-3">
									<h3><?php echo $num2?></h3>
									<h6 class="mb-0">پیپرز</h6>
								</div>
							</div>
						</div>
					</a>

					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="dashboard.php?content=club">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
									<i class="bi bi-award"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $user['clubPiper']?></h3>
									<h6 class="mb-0">امتیازات پیپرکلاب</h6>
								</div>
							</div>
						</div>
						</a>
					</div>
					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=wallet">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
								<img style="width: 60px; height: 60px;" src="https://www.spacify.ir/public/img/logo/wizify.png" alt="Logo">
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo number_format($user['club'] , 0 , "." , "," )?> CifyCoin</h3>
									<h6 class="mb-0">ولت اسپیسیفای</h6>
								</div>
							</div>
						</div>
						</a>
					</div>
                    					<!-- Counter item -->
					
                    <div class="col-sm-6 col-lg-3">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
									<i class="bi bi-suit-heart-fill"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3>2150</h3>
									<h6 class="mb-0">درامد شما </h6>
								</div>
							</div>
						</div>
					</div>

				</div>
				<!-- Counter END -->
			</div>

			

			<div class="col-md-6 col-xxl-4">
				<!-- Latest blog START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom d-flex justify-content-between align-items-center  p-3">
						<h5 class="card-header-title mb-0"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/push-pin-3711808-3105282.png" style="width: 30px;" alt=""> پست های اخیر </h5>
						<!-- Dropdown button --> 
						<div class="dropdown text-end">
							<a href="#" class="btn border-0 p-0 mb-0" role="button" id="dropdownShare3" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="bi bi-three-dots fa-fw"></i>
							</a>
							<!-- dropdown button -->
							<ul class="dropdown-menu dropdown-w-sm dropdown-menu-end min-w-auto shadow rounded" aria-labelledby="dropdownShare3">
								<li><a class="dropdown-item" href="dashboard.php?content=listPost"><i class="bi bi-box-arrow-up-left"></i> بازکردن با...</a></li>
								<li><a class="dropdown-item" href="#"><i class="bi bi-trash fa-fw me-2"></i> حذف افزونه</a></li>
							</ul>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<div class="custom-scrollbar h-350 os-host os-theme-dark os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-scrollbar-horizontal-hidden os-host-transition os-host-foreign os-host-rtl"><div class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: auto; right: 0px;"></div><div class="os-resize-observer"></div></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: right;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;"><div class="os-content" style="padding: 0px; height: 100%; width: 100%;">

						<div class="row">


							<?php 
							$num1 = 0;
							$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$some_time = strtotime($res['date']);
									?>
									<!-- Blog item -->
									<div class="col-12">
										<div class="d-flex align-items-center position-relative">
											<img class="w-60 rounded" src="<?php echo $res['art']?>" alt="product">
											<div class="ms-3">
												<a href="dashboard.php?content=openFile&id=<?php echo $res['idPost']?>" class="h6 stretched-link"><?php echo $res['title']?></a>
												<p class="small mb-0"><?php echo date('Y, d F', $some_time)?></p>
											</div>
										</div>
									</div>

									<!-- Divider -->
									<hr class="my-3">


									<?php
								}
							}else{
								?>
								<section class="overflow-hidden">
									<div class="container">
										<div class="row">
									<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
										<!-- SVG shape START -->
										<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
										<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
											<g>
											<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
											<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
											<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
											<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
											<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
											<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
											<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
											<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
											<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
											<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
											</g>
										</svg>
										</figure>
										<!-- SVG shape START -->
										<!-- Content -->
										<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
										<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عرضه ای یافت نشد</font></font></h2>
										
									</div>
									</div>
									</div>
								</section>
								<?php
							}
							?>




						</div>
						</div></div></div><div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="width: 95.7143%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="height: 91.3838%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></div>

					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
						<a href="dashboard.php?content=listPost">مشاهده همه</a>
					</div>

				</div>
				<!-- Latest blog END -->
			</div>

			<div class="col-md-6 col-xxl-4">
				<!-- Recent comment START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom d-flex justify-content-between align-items-center  p-3">
						<h5 class="card-header-title mb-0"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/chat-5590408-4652800.png?f=webp" style="width: 30px;" alt=""> تعاملات اخیر </h5>
						<!-- Dropdown button -->
						<div class="dropdown text-end">
							<a href="#" class="btn border-0 p-0 mb-0" role="button" id="dropdownShare3" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="bi bi-three-dots fa-fw"></i>
							</a>
							<!-- dropdown button -->
							<ul class="dropdown-menu dropdown-w-sm dropdown-menu-end min-w-auto shadow rounded" aria-labelledby="dropdownShare3">
								<li><a class="dropdown-item" href="dashboard.php?content=comments"><i class="bi bi-box-arrow-up-left"></i> بازکردن با...</a></li>
								<li><a class="dropdown-item" href="#"><i class="bi bi-trash fa-fw me-2"></i> حذف افزونه</a></li>
							</ul>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<div class="custom-scrollbar h-350 os-host os-theme-dark os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-scrollbar-horizontal-hidden os-host-transition os-host-foreign os-host-rtl"><div class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: auto; right: 0px;"></div><div class="os-resize-observer"></div></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: right;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;"><div class="os-content" style="padding: 0px; height: 100%; width: 100%;">

						<div class="row">


							<?php 
							$posts = '1';
							$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$posts = $posts.','.$res['idPost'];
								}
							}
							?>

							<?php 
						
							$query_12121 = mysqli_query($con, 'select * from comment where piperlinePost IN ('.$posts.') order by time Desc limit 0,900');
							$file_hash1 = mysqli_query($con, 'select * from comment where piperlinePost IN ('.$posts.') order by time Desc limit 0,1000');
							$file1 = mysqli_fetch_assoc($query_12121);
							if($file1){
								while($res=mysqli_fetch_assoc($file_hash1)){
									$some_time = strtotime($res['time']);

									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost='.$res['piperlinePost'].''));
									$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));

									?>
									<!-- Comment item -->
									<div class="col-12">
										<div class="d-flex align-items-center position-relative">
											<!-- Avatar -->
											<div class="avatar avatar-lg flex-shrink-0">
												<img class="avatar-img rounded-2" src="<?php echo $us['avatar']?>" alt="avatar">
											</div>
											<!-- Info -->
											<div class="ms-3">
												<small><?php echo date('Y, d F', $some_time)?></small>
												<p class="mb-1"> <a class="h6 fw-normal stretched-link" href="dashboard.php?content=messages&id=<?php echo $post['idPost']?>"><?php echo $us['username']?> بر روی "<?php echo $post['title']?>" نوشت</a></p>
												<div class="d-flex justify-content-between">
													<p class="small mb-0"><?php echo $res['comment']?></p>
													s
												</div>
											</div>
										</div>
									</div>

									<!-- Divider -->
									<hr class="my-3">

									<?php
								}
							}else{
								?>
								<section class="overflow-hidden">
									<div class="container">
										<div class="row">
									<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
										<!-- SVG shape START -->
										<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
										<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
											<g>
											<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
											<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
											<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
											<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
											<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
											<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
											<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
											<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
											<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
											<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
											</g>
										</svg>
										</figure>
										<!-- SVG shape START -->
										<!-- Content -->
										<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
										<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تعاملی یافت نشد</font></font></h2>
										
									</div>
									</div>
									</div>
								</section>
								<?php
							}
							?>


			
						</div>
						</div></div></div><div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="width: 95.7143%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="height: 91.3838%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></div>

					</div>
					<!-- Card body END -->
				</div>
				<!-- Recent comment END -->
			</div>

			<div class="col-md-6 col-xxl-4">
				<!-- Notice board START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom d-flex justify-content-between align-items-center  p-3">
						<h5 class="card-header-title mb-0"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-3994308-3307642.png?f=webp" style="width: 30px;" alt=""> اعلان ها</h5>
            			<!-- Dropdown button -->
						<div class="dropdown text-end">
							<a href="#" class="btn border-0 p-0 mb-0" role="button" id="dropdownShare3" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="bi bi-three-dots fa-fw"></i>
							</a>
							<!-- dropdown button -->
							<ul class="dropdown-menu dropdown-w-sm dropdown-menu-end min-w-auto shadow rounded" aria-labelledby="dropdownShare3">
								<li><a class="dropdown-item" href="dashboard.php?content=notifi"><i class="bi bi-box-arrow-up-left"></i> بازکردن با...</a></li>
								<li><a class="dropdown-item" href="#"><i class="bi bi-trash fa-fw me-2"></i> حذف افزونه</a></li>
							</ul>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<div class="custom-scrollbar h-350 os-host os-theme-dark os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-scrollbar-horizontal-hidden os-host-transition os-host-foreign os-host-rtl"><div class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: auto; right: 0px;"></div><div class="os-resize-observer"></div></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: right;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;"><div class="os-content" style="padding: 0px; height: 100%; width: 100%;">
							<div class="row">


							<?php
								$query_1212 = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
								$file_hash = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
									$some_time = strtotime($res['time']);

									?>
									<!-- Notif item -->
								
										<?PHP
										if($res['link'] == '0'){
										?>
										<a href="../../core/rtl/dashboard.php?content=openNotifi&id=<?PHP echo $res['idcomment']?>">
										<?php
										}else{
										?>
										<a href="<?PHP echo $res['link']?>" >
										<?php
										}
										?>
										<!-- Notice board item -->
										<div class="col-12">
											<div class="d-flex justify-content-between position-relative">
												<div class="d-sm-flex">
													<div class="icon-lg bg-warning bg-opacity-15 text-warning rounded-2 flex-shrink-0">
														<i class="bi bi-bell"></i>
													</div>
													<!-- Info -->
													<div class="ms-0 ms-sm-3 mt-2 mt-sm-0">
														<h6 class="mb-0"><?php echo $res['title']?></h6>
														<small style="color: black;"><?php echo date('Y, d F', $some_time)?></small>
													</div>
												</div>
											</div>
										</div>

										<!-- Divider -->
										<hr class="my-3">
										</a>
									
									<?php
									}
								}else{
									?>
									<section class="overflow-hidden">
										<div class="container">
											<div class="row">
										<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
											<!-- SVG shape START -->
											<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
											<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
												<g>
												<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
												<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
												<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
												<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
												<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
												<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
												<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
												<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
												<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
												<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
												</g>
											</svg>
											</figure>
											<!-- SVG shape START -->
											<!-- Content -->
											<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
											<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اعلانی یافت نشد</font></font></h2>
											
										</div>
										</div>
										</div>
									</section>
									<?php
								}
								?>
								<!-- Notice board item -->
								<div class="col-12">
									<div class="d-flex justify-content-between position-relative">
										<div class="d-sm-flex">
											<div class="icon-lg bg-warning bg-opacity-15 text-warning rounded-2 flex-shrink-0">
												<i class="fas fa-user-tie fs-5"></i>
											</div>
											<!-- Info -->
											<div class="ms-0 ms-sm-3 mt-2 mt-sm-0">
												<h6 class="mb-0"><a href="#" class="stretched-link">Join New Author</a></h6>
												<p class="mb-0">Amongst moments do in arrived Fat weddings believed prospect</p>
												<span class="small">5 min ago</span>
											</div>
										</div>
									</div>
								</div>

								<!-- Divider -->
								<hr class="my-3">

								<!-- Notice board item -->
								<div class="col-12">
									<div class="d-flex justify-content-between position-relative">
										<div class="d-sm-flex">
											<div class="icon-lg bg-success bg-opacity-10 text-success rounded-2 flex-shrink-0">
												<i class="bi bi-chat-left-quote-fill fs-5"></i>
											</div>
											<!-- Info -->
											<div class="ms-0 ms-sm-3 mt-2 mt-sm-0">
												<h6 class="mb-0"><a href="#" class="stretched-link">Add 5 New Blogs</a></h6>
												<p class="mb-0">Arrived Fat weddings believed prospect</p>
												<span class="small">4 hour ago</span>
											</div>
										</div>
									</div>
								</div>

								<!-- Divider -->
								<hr class="my-3">

								<!-- Notice board item -->
								<div class="col-12">
									<div class="d-flex justify-content-between position-relative">
										<div class="d-sm-flex">
											<div class="icon-lg bg-danger bg-opacity-10 text-danger rounded-2 flex-shrink-0">
												<i class="bi bi-bell-fill fs-5"></i>
											</div>
											<!-- Info -->
											<div class="ms-0 ms-sm-3 mt-2 mt-sm-0">
												<h6 class="mb-0"><a href="#" class="stretched-link">5 New Subscribers</a></h6>
												<p class="mb-0">Weddings believed prospect Arrived</p>
												<span class="small">4 hour ago</span>
											</div>
										</div>
									</div>
								</div>

								<!-- Divider -->
								<hr class="my-3">

								<!-- Notice board item -->
								<div class="col-12">
									<div class="d-flex justify-content-between position-relative">
										<div class="d-sm-flex">
											<div class="icon-lg bg-primary bg-opacity-10 text-primary rounded-2 flex-shrink-0"><i class="fas fa-globe fs-5"></i></div>
											<!-- Info -->
											<div class="ms-0 ms-sm-3 mt-2 mt-sm-0">
												<h6 class="mb-0"><a href="#" class="stretched-link">Update New Feature</a></h6>
												<span class="small">3 days ago</span>
											</div>
										</div>
									</div>
								</div>


							</div><!-- Row END -->
						</div></div></div><div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="width: 95.7143%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="height: 91.3838%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></div>
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
						<a href="#">View all Notice List</a>
					</div>

				</div>
				<!-- Notice board END -->
			</div>


			<div class="col-md-6 col-xxl-4">
				<!-- Latest blog START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom d-flex justify-content-between align-items-center  p-3">
						<h5 class="card-header-title mb-0"><img src="https://cdn3d.iconscout.com/3d/free/thumb/free-alert-5658942-4715748.png?f=avif" style="width: 30px;" alt=""> گزارشات</h5>
						<!-- Dropdown button --> 
						<div class="dropdown text-end">
							<a href="#" class="btn border-0 p-0 mb-0" role="button" id="dropdownShare3" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="bi bi-three-dots fa-fw"></i>
							</a>
							<!-- dropdown button -->
							<ul class="dropdown-menu dropdown-w-sm dropdown-menu-end min-w-auto shadow rounded" aria-labelledby="dropdownShare3">
								<li><a class="dropdown-item" href="dashboard.php?content=reports"><i class="bi bi-box-arrow-up-left"></i> بازکردن با...</a></li>
								<li><a class="dropdown-item" href="#"><i class="bi bi-trash fa-fw me-2"></i> حذف افزونه</a></li>
							</ul>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<div class="custom-scrollbar h-350 os-host os-theme-dark os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-scrollbar-horizontal-hidden os-host-transition os-host-foreign os-host-rtl"><div class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: auto; right: 0px;"></div><div class="os-resize-observer"></div></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: right;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px; width: 334px; height: 349px;"></div><div class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;"><div class="os-content" style="padding: 0px; height: 100%; width: 100%;">

						<div class="row">


								<?php
                                $query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                        $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['data'].'"'));
                                        $order = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where name="order" and userId='.$res['userId'].' and piperline='.$post['idPost'].''));
                                        if($order){
                                            $cos = 'مشتری';
                                        }else{
                                            $cos = '';
                                        }
                                        ?>
                        
                                        <!-- Notif item -->
											<a href="dashboard.php?content=openRep&id=<?php echo $post['idPost']?>" style="color: black;"><small><?php echo $post['title']?></small></a>

                                            <div class="list-group-item-action border-0 border-bottom d-flex p-3">
												
                                            <div class="me-3">
                                                <div class="avatar avatar-sm">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                                    <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                                                    </svg>                           
                                                </div>
                                            </div>
											
                                            <div>
                                                <?php
                                                if($res['rol'] == '1'){
                                                    $status = 'برسی شده';
                                                }elseif($res['rol'] == '2'){
                                                    $status = 'مجددا کاربر اعلام مشکل کرد';
                                                }else{
                                                    $status = '';
                                                } 
                                                ?>
                                                <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">"<a href='index.php?content=profile&id=<?php echo $us['iduser']?>'><?php echo $us['username']?></a>"</font> گزارشی برای مخزن شما نوشت</font><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" ><?php echo $cos?></font></font></span> <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="status<?php echo $res['id']?>"><?php echo $status?></font></font></span></h6>
                                                <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?> </font></font></span>
                                                <?php
                                                $message = 'سلام من '.$user['username'].' هستم بابت گزارشتون روی مخزن '.$post['title'].' مزاحمتون میشم:';
                                                
                                                ?>
                                                <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">

                                                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                            نوشتن پیام
                                                </a>
                                                <?php
                                                if($res['rol'] == '1'){
                                                }else{
                                                    ?>
                                                    <a id="inter<?php echo $res['id']?>" href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">

                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-eyeglasses" viewBox="0 0 16 16">
                                                        <path d="M4 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm2.625.547a3 3 0 0 0-5.584.953H.5a.5.5 0 0 0 0 1h.541A3 3 0 0 0 7 8a1 1 0 0 1 2 0 3 3 0 0 0 5.959.5h.541a.5.5 0 0 0 0-1h-.541a3 3 0 0 0-5.584-.953A1.993 1.993 0 0 0 8 6c-.532 0-1.016.208-1.375.547zM14 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                                                        </svg>
                                                    رسیدگی شد 
                                                    </a>

                                                    
                                                    <script>
                                                    $('#inter<?php echo $res['id']?>').click(function(event){
                                                    event.preventDefault();
                                                    $('#inter<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                    
                                                    $.ajax({
                                                        method: "POST",
                                                        url: "../../index.php?controller=message&method=seeRep&id=<?php echo $res['id']?>",
                                                        data: { code: "1"}
                                                    })
                                                        .done(function(data){
                                                        $('#status<?php echo $res['id']?>').html(data);
                                                        $('#inter<?php echo $res['id']?>').html('');

                                                        })

                                                    })
                                                    </script>
                                                    <?php
                                                } 
                                                ?>
                                    
                                                </div>
												
    
                                            </div>
                                        <!-- Notif item -->
                                        <?php

                                    }
                                }else{
									?>
									<section class="overflow-hidden">
										<div class="container">
											<div class="row">
										<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
											<!-- SVG shape START -->
											<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
											<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
												<g>
												<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
												<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
												<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
												<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
												<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
												<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
												<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
												<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
												<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
												<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
												</g>
											</svg>
											</figure>
											<!-- SVG shape START -->
											<!-- Content -->
											<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
											<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارشی یافت نشد</font></font></h2>
											
										</div>
										</div>
										</div>
									</section>
									<?php
								}
                                ?>




						</div>
						</div></div></div><div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="width: 95.7143%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden"><div class="os-scrollbar-track os-scrollbar-track-off"><div class="os-scrollbar-handle" style="height: 91.3838%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></div>

					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
						<a href="dashboard.php?content=listPost">مشاهده همه</a>
					</div>

				</div>
				<!-- Latest blog END -->
			</div>


			<div class="col-md-6 col-xxl-4">
				<div class="card border h-100">

					<!-- Card header -->
					<div class="card-header border-bottom d-flex justify-content-between align-items-center p-3">
						<h5 class="card-header-title mb-0">Traffic sources</h5>
						<a href="#" class="btn btn-sm btn-link p-0 mb-0 text-reset">View all</a>
					</div>

					<!-- Card body START -->
					<div class="card-body p-4">
						<!-- Chart -->
						<div class=" mx-auto" style="position: relative;">
							<div id="apexChartTrafficSources" style="min-height: 298.7px;"><div id="apexchartsln0x0d9ni" class="apexcharts-canvas apexchartsln0x0d9ni apexcharts-theme-light" style="width: 303px; height: 298.7px;"><svg id="SvgjsSvg1359" width="303" height="298.70000000000005" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG1361" class="apexcharts-inner apexcharts-graphical" transform="translate(14.5, 20)"><defs id="SvgjsDefs1360"><clipPath id="gridRectMaskln0x0d9ni"><rect id="SvgjsRect1363" width="282" height="300" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskln0x0d9ni"></clipPath><clipPath id="nonForecastMaskln0x0d9ni"></clipPath><clipPath id="gridRectMarkerMaskln0x0d9ni"><rect id="SvgjsRect1364" width="280" height="302" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><g id="SvgjsG1365" class="apexcharts-pie"><g id="SvgjsG1366" transform="translate(0, 0) scale(1)"><circle id="SvgjsCircle1367" r="96.47560975609758" cx="138" cy="138" fill="transparent"></circle><g id="SvgjsG1368" class="apexcharts-slices"><g id="SvgjsG1369" class="apexcharts-series apexcharts-pie-series" seriesName="Search" rel="1" data:realIndex="0"><path id="SvgjsPath1370" d="M 138 9.365853658536565 A 128.63414634146343 128.63414634146343 0 0 1 264.3169346988693 162.3058761059669 L 232.737701024152 156.22940707947518 A 96.47560975609758 96.47560975609758 0 0 0 138 41.52439024390242 L 138 9.365853658536565 z" fill="rgba(33,99,232,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-0" index="0" j="0" data:angle="100.89171974522293" data:startAngle="0" data:strokeWidth="0" data:value="44" data:pathOrig="M 138 9.365853658536565 A 128.63414634146343 128.63414634146343 0 0 1 264.3169346988693 162.3058761059669 L 232.737701024152 156.22940707947518 A 96.47560975609758 96.47560975609758 0 0 0 138 41.52439024390242 L 138 9.365853658536565 z"></path></g><g id="SvgjsG1371" class="apexcharts-series apexcharts-pie-series" seriesName="Direct" rel="2" data:realIndex="1"><path id="SvgjsPath1372" d="M 264.3169346988693 162.3058761059669 A 128.63414634146343 128.63414634146343 0 0 1 43.913188969446296 225.7178180023757 L 67.43489172708472 203.7883635017818 A 96.47560975609758 96.47560975609758 0 0 0 232.737701024152 156.22940707947518 L 264.3169346988693 162.3058761059669 z" fill="rgba(12,188,135,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-1" index="0" j="1" data:angle="126.11464968152865" data:startAngle="100.89171974522293" data:strokeWidth="0" data:value="55" data:pathOrig="M 264.3169346988693 162.3058761059669 A 128.63414634146343 128.63414634146343 0 0 1 43.913188969446296 225.7178180023757 L 67.43489172708472 203.7883635017818 A 96.47560975609758 96.47560975609758 0 0 0 232.737701024152 156.22940707947518 L 264.3169346988693 162.3058761059669 z"></path></g><g id="SvgjsG1373" class="apexcharts-series apexcharts-pie-series" seriesName="Social" rel="3" data:realIndex="2"><path id="SvgjsPath1374" d="M 43.913188969446296 225.7178180023757 A 128.63414634146343 128.63414634146343 0 0 1 57.081252627413775 38.00550050803493 L 77.31093947056033 63.004125381026185 A 96.47560975609758 96.47560975609758 0 0 0 67.43489172708472 203.7883635017818 L 43.913188969446296 225.7178180023757 z" fill="rgba(214,41,62,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-2" index="0" j="2" data:angle="94.01273885350315" data:startAngle="227.00636942675158" data:strokeWidth="0" data:value="41" data:pathOrig="M 43.913188969446296 225.7178180023757 A 128.63414634146343 128.63414634146343 0 0 1 57.081252627413775 38.00550050803493 L 77.31093947056033 63.004125381026185 A 96.47560975609758 96.47560975609758 0 0 0 67.43489172708472 203.7883635017818 L 43.913188969446296 225.7178180023757 z"></path></g><g id="SvgjsG1375" class="apexcharts-series apexcharts-pie-series" seriesName="Displayxads" rel="4" data:realIndex="3"><path id="SvgjsPath1376" d="M 57.081252627413775 38.00550050803493 A 128.63414634146343 128.63414634146343 0 0 1 137.97754910627245 9.365855617746632 L 137.98316182970433 41.52439171330997 A 96.47560975609758 96.47560975609758 0 0 0 77.31093947056033 63.004125381026185 L 57.081252627413775 38.00550050803493 z" fill="rgba(247,195,46,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-3" index="0" j="3" data:angle="38.980891719745216" data:startAngle="321.0191082802547" data:strokeWidth="0" data:value="17" data:pathOrig="M 57.081252627413775 38.00550050803493 A 128.63414634146343 128.63414634146343 0 0 1 137.97754910627245 9.365855617746632 L 137.98316182970433 41.52439171330997 A 96.47560975609758 96.47560975609758 0 0 0 77.31093947056033 63.004125381026185 L 57.081252627413775 38.00550050803493 z"></path></g></g></g></g><line id="SvgjsLine1377" x1="0" y1="0" x2="276" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine1378" x1="0" y1="0" x2="276" y2="0" stroke-dasharray="0" stroke-width="0" class="apexcharts-ycrosshairs-hidden"></line></g><g id="SvgjsG1362" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend"></div><div class="apexcharts-tooltip apexcharts-theme-dark"><div class="apexcharts-tooltip-series-group" style="order: 1;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(33, 99, 232);"></span><div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group" style="order: 2;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(12, 188, 135);"></span><div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group" style="order: 3;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(214, 41, 62);"></span><div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group" style="order: 4;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(247, 195, 46);"></span><div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div></div></div>
						<div class="resize-triggers"><div class="expand-trigger"><div style="width: 304px; height: 300px;"></div></div><div class="contract-trigger"></div></div><div class="resize-triggers"><div class="expand-trigger"><div style="width: 304px; height: 300px;"></div></div><div class="contract-trigger"></div></div></div>
						<!-- Content -->
						<ul class="list-inline text-center mt-3">
							<li class="list-inline-item pe-2"><i class="text-primary fas fa-circle pe-1"></i> Search </li>
							<li class="list-inline-item pe-2"><i class="text-success fas fa-circle pe-1"></i> Direct </li>
							<li class="list-inline-item pe-2"><i class="text-danger fas fa-circle pe-1"></i> Social </li>
							<li class="list-inline-item pe-2"><i class="text-warning fas fa-circle pe-1"></i> Display ads </li>
						</ul>
					</div>
				</div>
			</div>

			
		</div>
	</div>
</section>