<?php
if(! isset($_GET['id'])){
    die();
}
$query = mysqli_query($con, 'select * from user where iduser="'.$_GET['id'].'"');
$us = mysqli_fetch_assoc($query);
if(! $us){
    die();
}
if(! strlen($us['ACC-KEY']) > 10){
    die();
}

?>
<div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <div class="avatar avatar-xxl">
                            <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-link" viewBox="0 0 16 16">
                        <path d="M6.354 5.5H4a3 3 0 0 0 0 6h3a3 3 0 0 0 2.83-4H9c-.086 0-.17.01-.25.031A2 2 0 0 1 7 10.5H4a2 2 0 1 1 0-4h1.535c.218-.376.495-.714.82-1z"/>
                        <path d="M9 5.5a3 3 0 0 0-2.83 4h1.098A2 2 0 0 1 9 6.5h3a2 2 0 1 1 0 4h-1.535a4.02 4.02 0 0 1-.82 1H12a3 3 0 1 0 0-6H9z"/>
                        </svg>
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-security-5000473-4164979.png?f=avif" style="width: 150px;" alt="">
                        
                        <h2>اتصال به سازمان <?php echo $us['username']?></h2>
                        <small>میتوانید به حساب سازمانی متصل شوید و به عنوان کارمندان یک سازمان کار کنید شما اکنون توسط <?php echo $us['username']?> دعوت به اتصال به سازمان شده اید اکنون اطلاعات امنیتی را کامل کنید تا بتوانید وارد شوید</small>
                        </div>
                        <!-- End Title -->
                        <br>

                        <form action="" method="POST" id="GETDATAFORMACCKEY">
                        <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-lock"></i><i class="bi bi-key"></i><i class="bi bi-link-45deg"></i> کلید امنیتی</font></font></label>
                            <input required="" id="con-name" name="key" type="text" class="form-control" placeholder="کلید امنیتی را وارد کنید">
                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کلید امنیتی که از رعیس سازمان در یافت کرده اید را وارد کنید</font></font></small>
                        </div>
                        </div>
                        <div id="displayLoginAccKey"></div>
                        <br>
                        <br>
                        

                        <div class="col-md-12 text-start">
                        <button class="btn btn-primary w-100" id="sendDateForKey" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-link-45deg"></i> اتصال </font></font></button>
                        </div>
                        
                        </form>

                        <script>
                                $(document).ready(function(){
                                    $("#GETDATAFORMACCKEY").on("submit", function(event){
                                        event.preventDefault();
                                        $('#sendDateForKey').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                        var formValues= $('#GETDATAFORMACCKEY').serialize();

                                        $.post("../../index.php?controller=account&method=loginToACC&id=<?php echo $us['iduser']?>", formValues, function(data){
                                            // Display the returned data in browser
                                            $('#sendDateForKey').html('<i class="bi bi-link-45deg"></i> اتصال ');
                                            $('#displayLoginAccKey').html(data);
                                        });
                                    });
                                });
                        </script>

                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
            
                        </div>
                    </div>