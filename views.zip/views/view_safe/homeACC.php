<?php
if(! isset($_SESSION['id'])){
	?>
      <script type = "text/javascript">
		window.location.replace("../../index.php?controller=account&method=login");
      </script>
	<?php
}

?>
<section class="pb-3 pb-lg-5">
	<div class="container">
		<div class="row">
			<div class="col-12">
        <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Lifestyle</a>
				<h1><img style="width: 50px;" src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" alt=""> خانه</h1>
			</div>
			 <p class="lead">در اینجا پست های دوستانتان را که به آنها پیام میدهید یا آنها را دنیال میکنید خواهید دید</p>
		</div>
	</div>
</section>

		<!-- Meta Tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Webestica.com">
		<meta name="description" content="Bootstrap based News, Magazine and Blog Theme">

		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">

		<!-- Google Font -->
		<link rel="preconnect" href="https://fonts.gstatic.com/">
		<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&amp;family=Rubik:wght@400;500;700&amp;display=swap" rel="stylesheet">

		<!-- Plugins CSS -->
		<link rel="stylesheet" type="text/css" href="assets/vendor/font-awesome/css/all.min.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/tiny-slider/tiny-slider.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/plyr/plyr.css">

		<!-- Theme CSS -->
		<link id="style-switch" rel="stylesheet" type="text/css" href="assets/css/style-rtl.css">
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-XZ4W34ZJ0L"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());

			gtag('config', 'G-XZ4W34ZJ0L');
		</script>




<section class="pt-0">
	<div class="container position-relative" data-sticky-container="">
		<div class="row">
			<!-- Left sidebar START -->
			<div class="col-lg-2">
				<div class="text-start text-lg-center mb-5" data-sticky="" data-margin-top="80" data-sticky-for="991" style="">
					<!-- Author info -->
					<div class="position-relative">
						
						<ul style="text-align: right;" class="list-group list-group-flush">
							<li class="list-group-item"><div class="avatar">
								<img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
							</div> <?php echo $user['username']?></li>
			
						</ul>
					</div>
			
					<div style="text-align: right;" class="list-group">

						<a href="index.php?content=homeACC" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" alt=""> خانه</a>
						<a href="index.php?content=homeACC&method=piper" class="list-group-item list-group-item-action">
						<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16">
						<path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
						</svg> پیپرها</a>
						<a href="index.php" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://3dicons.sgp1.cdn.digitaloceanspaces.com/v1/dynamic/gradient/blender-dynamic-gradient.png" alt=""> کاوش</a>

						<a href="index.php?content=search" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/search-4080643-3379756.png" alt=""> جستجو</a>
						<a href="index.php?content=tags" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/hashtag-5625122-4690598.png?f=webp" alt=""> هشتگ</a>
						<a href="index.php?content=type&open=1" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/content-idea-7378923-6041262.png?f=avif" alt=""> محتوا</a>
						<a href="dashboard.php" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/dashboard-5591015-4653018.png?f=avif" alt=""> توسعه دهندگان</a>
						<a href="index.php?content=profile&id=<?php echo $_SESSION['id']?>" class="list-group-item list-group-item-action"><img style="width: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/profile-6335655-5220669.png?f=webp" alt="">نمایه من</a>
		

					</div>
		
				</div>
			</div>
			<!-- Left sidebar END -->
			<!-- Main Content START -->
			<div class="col-lg-7 mb-5">
      



			
			<?php
			$accounts = '1,42';
			$query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
			$file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
			$follow = mysqli_fetch_assoc($query_1212);
			if($follow){
				while($res=mysqli_fetch_assoc($file_hash)){
					$accounts = $accounts.','.$res['user_follow_id'].'';
				}
			}else{
				?>
				<section class="overflow-hidden">
					<div class="container">
						<div class="row">
					<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
						<!-- SVG shape START -->
						<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
						<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
							<g>
							<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
							<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
							<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
							<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
							<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
							<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
							<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
							<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
							c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
							<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
							<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
							c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
							</g>
						</svg>
						</figure>
						<!-- SVG shape START -->
						<!-- Content -->
						<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><img style="width: 100px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" alt=""></font></h1>
						<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کننده ای ندارید</font></font></h2>
						<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما هنوز حسابی  را دنبال نکرده اید اگر تمایل دارید ما میتوانیم لیستی از حساب های فعال و کارامد جامعه خود را به شما معرفی کنیم</font></font></p>
						<a href="index.php?content=topACC" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به صفحه منتخب ها بروید</font></font></a>
					</div>
					</div>
					</div>
				</section>


					
				<?php
			}
			
			
			if(isset($_GET['method'])){
				$query_1212 = mysqli_query($con, 'select * from blogs where published="1" order by RAND(),createDate Desc limit 0,25');
				$file_hash = mysqli_query($con, 'select * from blogs where published="1" order by RAND(),createDate Desc limit 0,25');
				?>
					<a class="btn btn-dark-soft w-100" href="dashboard.php?content=createblog"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16">
					<path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
					</svg> نوشتن پیپر</font></font></a>
				<?php
			
				$file = mysqli_fetch_assoc($query_1212);
				if($file){
					while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
						$some_time = strtotime($res['createDate']);
						?>
				
	
									<div class="row g-4">
											<div class="col-12">
												<!-- Card START -->
												<div class="card border">
													<!-- Card header START -->
													<div class="card-header border-bottom p-3">
														<!-- Search and select START -->
														
							
															
														<div class="d-sm-flex justify-content-sm-between align-items-center">
	
															<h5 class="mb-2 mb-sm-0"><div class="nav-link">
																<div class="d-flex align-items-center position-relative">
																	<div class="avatar avatar-xs">
																		<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
																	</div>
																	<span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>      <?php
																			if($us['admin'] == 1){
																				?>
																				<i class="bi bi-patch-check-fill text-info small"></i>
																				<?php
																			}
																			?></a><br><small><?php echo $us['job']?></small></span>
																</div>
															</div>
															</h5>
	
															<?php
	
															$follow_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
															$follow = mysqli_fetch_assoc($follow_hash);
															if($follow){
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
																<?php
															}else{
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
																<?php 
															}
															?>   
	
															<script>
																$('#follow<?php echo $us['iduser']?>').click(function(event){
																event.preventDefault();
																$('#follow<?php echo $us['iduser']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
	
																$.ajax({
																	method: "POST",
																	url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
																	data: { code: "1"}
																})
																	.done(function(data){
																	$('#follow<?php echo $us['iduser']?>').html(data);
																	})
	
																})
															</script>
															<a href="dashboard.php?content=share&idPost=<?php echo $res['idPost']?>" class="btn mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
															<path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>
															</svg></a>
	
														</div>	
														
														<!-- Search and select END -->
													</div>
													<!-- Card header END -->
	
													<!-- Card body START -->
													<div class="card-body p-3 pb-0">
	
							
														
														
														<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیپر</font></font></a>
														<a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['visit']?> بازدید</a>
														<a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $res['idBlog']?></a>
														<!-- Tabs content START -->
														<br/>
														<small><i class="bi bi-calendar-plus"></i>&nbsp<?php echo date('Y, d F', $some_time)?></small>
														<a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>"><h5><?php echo $res['title']?></h5></a>
														<?php
														if(strlen($res['descrip']) > 5){
															?>
															<p class="card-text"><?php echo $res['descrip']?></p>
															<?php
														}else{

												

															$text = $res['blog'];
															?>
															<p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
															<?php
														}
														?>	
														<hr>
	
														<?php
																					$test_array = explode(" ", $res['label']);
	
	
																					foreach( $test_array as $name ){
																			
																						?>
																						<li class="list-inline-item">
																							<a class="text-body" href="index.php?content=search&search=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
																						</li>                            
																						<?PHP
																						
																					} 
														?>
														&nbsp
	
														&nbsp
														<a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">
	
														<img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
	
														بازکردن با ...
														</a>
													</div>
													<!-- Card body END -->
	
												</div>
												<!-- Card END -->
											</div>
											
									
									</div>
									<br>
	
						<?php
					}

					?>
					<div id="addNowCode"></div>
					<button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
					
											<script>
											
											var loadBox = 0;
                                            $('#loadMore').click(function(event){
                                            event.preventDefault();
                                            $('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
											var z = Math.random()*10;
											var code = '<div id="'+String(z)+'"></div>';
											document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=home&method=loadPiper",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
												document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
												document.getElementById(z).innerHTML = data;
                                               
                                                })

                                            })
                                            </script>
					<?php
				}
			}elseif(isset($_GET['idBlog'])){
				$query121212 = mysqli_query($con, 'select * from blogs where idBlog='.$_GET['idBlog'].' and published=1;');
				$blog = mysqli_fetch_assoc($query121212);
				if(! $blog){
				  die();
				}
				$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$blog['userId'].'"'));
				$some_time = strtotime($blog['createDate']);

				?>
				<title><?php echo $blog['title']?> - <?php echo $us['username']?> | piperline</title>

									<div class="row g-4">
											<div class="col-12">
												<!-- Card START -->
												<div class="card border">
													<!-- Card header START -->
													<div class="card-header border-bottom p-3">
														<!-- Search and select START -->
														
							
															
														<div class="d-sm-flex justify-content-sm-between align-items-center">
	
															<h5 class="mb-2 mb-sm-0"><div class="nav-link">
																<div class="d-flex align-items-center position-relative">
																	<div class="avatar avatar-xs">
																		<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
																	</div>
																	<span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>      <?php
																			if($us['admin'] == 1){
																				?>
																				<i class="bi bi-patch-check-fill text-info small"></i>
																				<?php
																			}
																			?></a><br><small><?php echo $us['job']?></small></span>
																</div>
															</div>
															</h5>
	
															<?php
	
															$follow_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
															$follow = mysqli_fetch_assoc($follow_hash);
															if($follow){
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
																<?php
															}else{
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
																<?php 
															}
															?>   
	
															<script>
																$('#follow<?php echo $us['iduser']?>').click(function(event){
																event.preventDefault();
																$('#follow<?php echo $us['iduser']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
	
																$.ajax({
																	method: "POST",
																	url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
																	data: { code: "1"}
																})
																	.done(function(data){
																	$('#follow<?php echo $us['iduser']?>').html(data);
																	})
	
																})
															</script>
															<a href="dashboard.php?content=share&idPost=<?php echo $res['idPost']?>" class="btn mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
															<path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>
															</svg></a>
	
														</div>	
														
														<!-- Search and select END -->
													</div>
													<!-- Card header END -->
	
													<!-- Card body START -->
													<div class="card-body p-3 pb-0">
	
							
														
														
														<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیپر</font></font></a>
														<a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $blog['visit']?> بازدید</a>
														<a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $blog['idBlog']?></a>
														<!-- Tabs content START -->
														<br/>
														<small><i class="bi bi-calendar-plus"></i>&nbsp<?php echo date('Y, d F', $some_time)?></small>
														<a href="index.php?content=homeACC&id=<?php echo $blog['idBlog']?>"><h5><?php echo $blog['title']?></h5></a>
														<?php
														if(strlen($blog['descrip']) > 5){
															?>
															<p class="card-text"><?php echo $blog['descrip']?></p>
															<br>
															<?php
														}

												

															$text = $blog['blog'];
															?>
															<div><?php echo $text?></div>
															<?php
														
														?>	
														<hr>
	
														<?php
																					$test_array = explode(" ", $blog['label']);
	
	
																					foreach( $test_array as $name ){
																			
																						?>
																						<li class="list-inline-item">
																							<a class="text-body" href="index.php?content=search&search=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
																						</li>                            
																						<?PHP
																						
																					} 
														?>
														&nbsp
	
														&nbsp
														<a href="index.php?content=homeACC&id=<?php echo $blog['idBlog']?>" class="btn btn-light btn-sm">
	
														<img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
	
														بازکردن با ...
														</a>
													</div>


													<section class="py-4">
													<div class="container">
													
														<div class="row g-4">
															

															

															
													
															

															

															
															

															
															
															<div class="col-12">
																<!-- Blog list table START -->
																<div class="card border bg-transparent rounded-3">
																	<!-- Card header START -->
																	<div class="card-header bg-transparent border-bottom p-3">
																		<div class="d-sm-flex justify-content-sm-between align-items-center">
																			<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شروع به نوشتن کنید</font></font></h5>
																			<form action="" method="POST" id="sendComment" class="row g-3 mt-2">
																			<Button type="submit" id="subComment" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست کردن</font></font></button>
																		</div>
																	</div>
																	<!-- Card header END -->

																		<!-- Card body START -->
																		<div class="card-body p-3">
																		<style>
																		.scroll-example {
																			overflow: auto;
																			scrollbar-width: none; /* Firefox */
																			-ms-overflow-style: none; /* IE 10+ */
																		}

																		.scroll-example::-webkit-scrollbar {
																			width: 0px;
																			background: transparent; /* Chrome/Safari/Webkit */
																		}
																		</style>
																			<div class="card-body p-0">

													
																			<?php
																			if(isset($_SESSION['id'])){
																				?>

																				<div>
																					<h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پاسخ دهید</font></font></h3>
																					
																					
																					
																					
																					<!-- custom checkbox -->
																					<input type="text" value="<?php echo $_GET['idBlog']?>" name="idBlog" style="display: none;">
																					<div class="col-12">
																						<label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظر شما *</font></font></label>
																						<textarea name="comment" class="form-control" rows="3"></textarea>
																					</div>
																					
																					</form>
																				</div>
																				<?php
																			}else{

																			}
																			?>



																			</div>
																			<!-- Button -->

												
																	</div>
																</div>
																<!-- Blog list table END -->
															</div>
														</div>
													</div>
												</section>

												<script>
														$(document).ready(function(){
															$("#sendComment").on("submit", function(event){
																event.preventDefault();
																$('#subComment').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

																var formValues= $('#sendComment').serialize();

																$.post("../../index.php?controller=message&method=sendCommentBlog", formValues, function(data){
																	// Display the returned data in browser
																	$('#subComment').html('ذخیره شد');
																	document.getElementById('displayComment').innerHTML = document.getElementById('displayComment').innerHTML + data;
																});
															});
														});
												</script>

													<!-- Card body END -->
													<section class="py-4">
														<div class="container">
														
															<div class="row g-4">
																

																

																
														
																

																
																

																
																
																<div class="col-12">
																	<!-- Blog list table START -->
																	<div class="card border bg-transparent rounded-3">
																		<!-- Card header START -->
																		<div class="card-header bg-transparent border-bottom p-3">
																			<div class="d-sm-flex justify-content-sm-between align-items-center">
																				<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظرات</font></font></h5>
																			</div>
																		</div>
																		<!-- Card header END -->

																			<!-- Card body START -->
																			<div class="card-body p-3">
																			<style>
																			.scroll-example {
																				overflow: auto;
																				scrollbar-width: none; /* Firefox */
																				-ms-overflow-style: none; /* IE 10+ */
																			}

																			.scroll-example::-webkit-scrollbar {
																				width: 0px;
																				background: transparent; /* Chrome/Safari/Webkit */
																			}
																			</style>

																				<div>
																					<!-- Comment level 1-->
																					
																						<!-- Comment children level 2 -->
																							<!-- Comment children level 3 -->
																							<div class="card-body p-0" id="displayComment">

																						<!-- Comment level 2 -->
																						

																					<?php
																					$query_1212 = mysqli_query($con, 'select * from comment where blogId="'.$_GET['idBlog'].'" and privet="0" order by time Desc limit 0,100');
																					$file_hash = mysqli_query($con, 'select * from comment where blogId="'.$_GET['idBlog'].'" and privet="0" order by time Desc limit 0,100');
																					$file = mysqli_fetch_assoc($query_1212);
																					if($file){
																						while($res=mysqli_fetch_assoc($file_hash)){
																							$us1 = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));
																							$some_time1 = strtotime($res['time']);
																							?>

																							<!-- Comment level 1 -->
																							<div class="my-4" id="comment<?php echo $res['idcomment']?>">
																							<img class="avatar avatar-md rounded-circle float-start me-3" src="<?php echo $us1['avatar']?>" alt="avatar">
																							<div>
																								<div class="mb-2">
																									<h5 class="m-0"><?php echo $us1['username']?></h5>
																									<a href="index.php?content=profile&amp;id=<?php echo $us1['iduser']?>" class="btn btn-light btn-sm">

																									<img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

																									بازکردن با... 
																									</a>
																									<?php
																									if($res['creatorId'] == $_SESSION['id']){
																										?>
																										<a href="#" id="deleteComment<?php echo $res['idcomment']?>" class="btn btn-light btn-sm">

																										<i class="bi bi-trash"></i>
																										حذف
																										</a>
																										<?php
																									}
																									?>
																									<span class="me-3 small"><?php echo date('Y, d F', $some_time1)?></span>
																									<a href="#" class="text-body fw-normal">پاسخ</a>

																								</div>
																								<p><?php echo $res['comment']?></p>
																							</div>
																							</div>

																							<script>
																							$('#deleteComment<?php echo $res['idcomment']?>').click(function(event){
																							event.preventDefault();
																							$('#deleteComment<?php echo $res['idcomment']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');
																						
																							$.ajax({
																								method: "POST",
																								url: "../../index.php?controller=message&method=deleteComment1&id=<?php echo $res['idcomment']?>",
																								data: { code: "1"}
																							})
																								.done(function(data){
																								document.getElementById("comment<?php echo $res['idcomment']?>").style.display = 'none';
																								})

																							})
																							</script>
																							
																							<?php
																						}
																					}
																					?>




																				</div>

																				</div>
																				<!-- Button -->

																		
																		</div>
																	</div>
																	<!-- Blog list table END -->
																</div>
															</div>
														</div>
													</section>
												</div>
												<!-- Card END -->
											</div>

							
											
									
									</div>
									<br>


									<div id="addNowCode"></div>
									<button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
					
											<script>
											
											var loadBox = 0;
                                            $('#loadMore').click(function(event){
                                            event.preventDefault();
                                            $('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
											var z = Math.random()*10;
											var code = '<div id="'+String(z)+'"></div>';
											document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=home&method=loadPiper",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
												document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
												document.getElementById(z).innerHTML = data;
                                               
                                                })

                                            })
                                            </script>
				<?php
			}else{
			
				$query_1212 = mysqli_query($con, 'select * from posts where published="1" and status="1" and idUser IN ('.$accounts.') order by date Desc limit 0,200');
				$file_hash = mysqli_query($con, 'select * from posts where published="1" and status="1" and idUser IN ('.$accounts.') order by date Desc limit 0,200');
	
			
				$file = mysqli_fetch_assoc($query_1212);
				if($file){
					while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
	
						?>
				
	
									<div class="row g-4">
											<div class="col-12">
												<!-- Card START -->
												<div class="card border">
													<!-- Card header START -->
													<div class="card-header border-bottom p-3">
														<!-- Search and select START -->
														
							
															
														<div class="d-sm-flex justify-content-sm-between align-items-center">
	
															<h5 class="mb-2 mb-sm-0"><div class="nav-link">
																<div class="d-flex align-items-center position-relative">
																	<div class="avatar avatar-xs">
																		<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
																	</div>
																	<span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>      <?php
																			if($us['admin'] == 1){
																				?>
																				<i class="bi bi-patch-check-fill text-info small"></i>
																				<?php
																			}
																			?></a><br><small><?php echo $us['job']?></small></span>
																</div>
															</div>
															</h5>
	
															<?php
	
															$follow_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
															$follow = mysqli_fetch_assoc($follow_hash);
															if($follow){
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
																<?php
															}else{
																?>
																<a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
																<?php 
															}
															?>   
	
															<script>
																$('#follow<?php echo $us['iduser']?>').click(function(event){
																event.preventDefault();
																$('#follow<?php echo $us['iduser']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
	
																$.ajax({
																	method: "POST",
																	url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
																	data: { code: "1"}
																})
																	.done(function(data){
																	$('#follow<?php echo $us['iduser']?>').html(data);
																	})
	
																})
															</script>
															<a href="dashboard.php?content=share&idPost=<?php echo $res['idPost']?>" class="btn mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
															<path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>
															</svg></a>
	
														</div>	
														
														<!-- Search and select END -->
													</div>
													<!-- Card header END -->
	
													<!-- Card body START -->
													<div class="card-body p-3 pb-0">
	
														<?phP
														if($res['type'] == '1'){
															$type = 'پست';
														}elseif($res['type'] == '2'){
															$type = 'دوره اموزشی';
														}elseif($res['type'] == '3'){
															$type = 'فایل و منبع';
														}elseif($res['type'] =='4'){
															$type = 'ویدیو';
														}elseif($res['type'] == '5'){
															$type = 'سرویس یا خدمات';
														}else{
															$type = 'مشخض نیست';
														}
														
														?>
														<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $type?></font></font></a>
														<a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['views']?> بازدید</a>
														<a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $res['idPost']?></a>
														<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['by']?> خرید</a>
														<!-- Tabs content START -->
														<a href="<?php echo $res['art']?>"><img style="width: 100%;" src="<?php echo $res['art']?>" alt=""></a>
														<br/>
														<a href="index.php?content=open&id=<?php echo $res['idPost']?>"><h5><?php echo $res['title']?></h5></a>
														<p><?php echo $res['doc']?></p>
	
														<hr>
	
														<?php
																					$test_array = explode(" ", $res['tag']);
	
	
																					foreach( $test_array as $name ){
																			
																						?>
																						<li class="list-inline-item">
																							<a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
																						</li>                            
																						<?PHP
																						
																					} 
														?>
														&nbsp
	
														&nbsp
														<a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn btn-light btn-sm">
	
														<img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
	
														بازکردن با ...
														</a>
													</div>
													<!-- Card body END -->
	
												</div>
												<!-- Card END -->
											</div>
											
									
									</div>
									<br>
	
						<?php
					}
				}
			}

			?>





			</div>
			<!-- Main Content END -->
			
			<!-- Right sidebar START -->
			<div class="col-lg-3">
				<div data-sticky="" data-margin-top="80" data-sticky-for="991" style="">
	   





					<div class="mt-4">
					<div class="col-12">
									<!-- Title -->
								
				
									

								<div class="row g-4">
										<div class="col-12">
											<!-- Card START -->
											<div class="card border">
												<!-- Card header START -->
												<div class="card-header border-bottom p-3">
													<!-- Search and select START -->
													

													

													<h5><img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar"> مخاطبین شما</h5>
													
													
													<!-- Search and select END -->
												</div>
												<!-- Card header END -->

												<!-- Card body START -->
												<div class="card-body p-3 pb-0" style="height:200px; overflow-y:scroll;">
													<!-- Tabs content START -->
													<div class="tab-content py-0 my-0">
														<?php

														$query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc limit 0,100');
														$file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc limit 0,100');
														$file = mysqli_fetch_assoc($query_1212);
														if($file){
															?>
																<!-- Tabs content item START -->
																<div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
																	<!-- Table START -->
																	<div class="table-responsive border-0">
																		<table class="table align-middle p-4 mb-0 table-hover">
																

																			<!-- Table body START -->
																			<tbody class="border-top-0">
																					<!-- Table row -->

																			<?php
									
																			while($res=mysqli_fetch_assoc($file_hash)){
																				$userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
																				if($userData){
																					?>
																					<!-- Table row -->
																					<tr>
																						<!-- Table data -->
																						<td>
																							<div class="d-flex align-items-center position-relative">
																								<!-- Image -->
																								<div class="avatar avatar-md">
																									<img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
																								</div>
																								<div class="mb-0 ms-2">
																									<!-- Title -->
																									<h6 class="mb-0"><a href="index.php?content=profile&id=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a>      <?php
																									if($userData['admin'] == 1){
																										?>
																										<i class="bi bi-patch-check-fill text-info small"></i>
																										<?php
																									}
																									?></h6>
																								</div>
																							</div>
																						</td>
																			
																				
																			
																			
																					</tr>
																					<?php
																				}else{
								
																				}
																			}
																			
																			?>
											

																


																			</tbody>
																			<!-- Table body END -->
																		</table>
																	</div>
																	<!-- Table END -->
																</div>
																<!-- Tabs content item END -->
															<?php
														}else{
															?>
																<div class="container">
										
																		<!-- Content -->
																		<h1 class="text-primary"><font style="vertical-align: inherit;"><img style="width: 100px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" alt=""></font></h1>
																		<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کننده ای ندارید</font></font></h2>
																</div>
															<?php
														}
														?>


									

													</div>
													<!-- Tabs content END -->
												</div>
												<!-- Card body END -->

											</div>
											<!-- Card END -->
										</div>
										
								
								</div>


								<br>
								<div class="row g-4">
										<div class="col-12">
											<!-- Card START -->
											<div class="card border">
												<!-- Card header START -->
												<div class="card-header border-bottom p-3">
													<!-- Search and select START -->
													

													

													<h5><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar"> پیامرسان</h5>
													
													
													<!-- Search and select END -->
												</div>
												<!-- Card header END -->

												<!-- Card body START -->
												<div class="card-body p-3 pb-0" style="height:200px; overflow-y:scroll;">
													<!-- Tabs content START -->
													<div class="tab-content py-0 my-0">
														<?php

															$query_1212 = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
															$file_hash = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
															$file = mysqli_fetch_assoc($query_1212);
															if($file){
															?>
																<!-- Tabs content item START -->
																<div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
																	<!-- Table START -->
																	<div class="table-responsive border-0">
																		<table class="table align-middle p-4 mb-0 table-hover">
																

																			<!-- Table body START -->
																			<tbody class="border-top-0">
																					<!-- Table row -->

																			<?php
									
																			while($res=mysqli_fetch_assoc($file_hash)){
																				$userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
																				if($userData){
																					?>
																					<!-- Table row -->
																					<tr>
																						<!-- Table data -->
																						<td>
																							<div class="d-flex align-items-center position-relative">
																								<!-- Image -->
																								<div class="avatar avatar-md">
																									<img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
																								</div>
																								<div class="mb-0 ms-2">
																									<!-- Title -->
																									<h6 class="mb-0"><a href="dashboard.php?content=chats&pv=<?php echo $res['id']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
																								</div>
																							</div>
																						</td>
																			
																				
																			
																			
																					</tr>
																					<?php
																				}else{
								
																				}
																			}
																			
																			?>
											

																


																			</tbody>
																			<!-- Table body END -->
																		</table>
																	</div>
																	<!-- Table END -->
																</div>
																<!-- Tabs content item END -->
															<?php
														}else{
															?>

															<div class="container">
																	
																	<!-- Content -->
																	<h1 class="text-primary"><font style="vertical-align: inherit;"><img style="width: 100px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" alt=""></font></h1>
																	<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سابقه یافت نشد</font></font></h2>
															</div>

															<?php
														}
														?>


									

													</div>
													<!-- Tabs content END -->
												</div>
												<!-- Card body END -->

											</div>
											<!-- Card END -->
										</div>
										
								
								</div>

					</div>
					</div>


				</div>
			</div>
			<!-- Right sidebar END -->
		</div>
	</div>
</section>


<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Vendors -->
<script src="assets/vendor/tiny-slider/tiny-slider-rtl.js"></script>
<script src="assets/vendor/sticky-js/sticky.min.js"></script>
<script src="assets/vendor/plyr/plyr.js"></script>

<!-- Template Functions -->
<script src="assets/js/functions.js"></script>
