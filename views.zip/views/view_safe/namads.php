<title>نماد های سازمانی پیپرلاین</title>
<section class="pt-4 pb-0">
	<div class="container">
		<div class="row">
      <div class="col-xl-9 mx-auto">
        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-award-fill" viewBox="0 0 16 16">
            <path d="m8 0 1.669.864 1.858.282.842 1.68 1.337 1.32L13.4 6l.306 1.854-1.337 1.32-.842 1.68-1.858.282L8 12l-1.669-.864-1.858-.282-.842-1.68-1.337-1.32L2.6 6l-.306-1.854 1.337-1.32.842-1.68L6.331.864 8 0z"/>
            <path d="M4 11.794V16l4-1 4 1v-4.206l-2.018.306L8 13.126 6.018 12.1 4 11.794z"/>
            </svg> نماد های سازمانی ما</font></font></h2>
        
        
        
        
        <div class="row pt-5">
			<!-- Footer Widget -->
			<div class="col-md-6 col-lg-4 mb-4">
                    <div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><a referrerpolicy="origin" target="_blank" href="https://trustseal.enamad.ir/?id=377455&amp;Code=XXsRD0YGIO72bsk7XVuh"><img referrerpolicy="origin" src="https://Trustseal.eNamad.ir/logo.aspx?id=377455&amp;Code=XXsRD0YGIO72bsk7XVuh" alt="" style="cursor:pointer" id="XXsRD0YGIO72bsk7XVuh"></a></font><span class="badge bg-primary bg-opacity-10 text-primary"></span></h5>
						</div>
					</div>
			</div>

			<div class="col-md-6 col-lg-3 mb-4">
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><a href="https://www.qitsource.ir"><img src="../../public/img/logo/namad1.png" alt=""></a></font><span class="badge bg-primary bg-opacity-10 text-primary"></span></h5>
						</div>
					</div>
			</div>

			<div class="col-md-6 col-lg-3 mb-4">
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><a href="https://www.qitsource.ir"><img src="../../public/img/logo/namad2.png" alt=""></a></font><span class="badge bg-primary bg-opacity-10 text-primary"></span></h5>
						</div>
					</div>
			</div>


		
			
		</div>
        
        <!-- Service END -->
      </div>  <!-- Col END -->
     </div>
  </div>
</section>