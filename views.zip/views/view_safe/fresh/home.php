
		<!-- Meta Tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Webestica.com">
		<meta name="description" content="Bootstrap based News, Magazine and Blog Theme">

		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">

		<!-- Google Font -->
		<link rel="preconnect" href="https://fonts.gstatic.com/">
		<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&amp;family=Rubik:wght@400;500;700&amp;display=swap" rel="stylesheet">

		<!-- Plugins CSS -->
		<link rel="stylesheet" type="text/css" href="assets/vendor/font-awesome/css/all.min.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/tiny-slider/tiny-slider.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/plyr/plyr.css">

		<!-- Theme CSS -->
		<link id="style-switch" rel="stylesheet" type="text/css" href="assets/css/style-rtl.css">
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-XZ4W34ZJ0L"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());

			gtag('config', 'G-XZ4W34ZJ0L');
		</script>


<section class="py-4 card-grid">
	<div class="container">

	<h5><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-binoculars" viewBox="0 0 16 16">
		<path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h1A1.5 1.5 0 0 1 7 2.5V5h2V2.5A1.5 1.5 0 0 1 10.5 1h1A1.5 1.5 0 0 1 13 2.5v2.382a.5.5 0 0 0 .276.447l.895.447A1.5 1.5 0 0 1 15 7.118V14.5a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 14.5v-3a.5.5 0 0 1 .146-.354l.854-.853V9.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.793l.854.853A.5.5 0 0 1 7 11.5v3A1.5 1.5 0 0 1 5.5 16h-3A1.5 1.5 0 0 1 1 14.5V7.118a1.5 1.5 0 0 1 .83-1.342l.894-.447A.5.5 0 0 0 3 4.882V2.5zM4.5 2a.5.5 0 0 0-.5.5V3h2v-.5a.5.5 0 0 0-.5-.5h-1zM6 4H4v.882a1.5 1.5 0 0 1-.83 1.342l-.894.447A.5.5 0 0 0 2 7.118V13h4v-1.293l-.854-.853A.5.5 0 0 1 5 10.5v-1A1.5 1.5 0 0 1 6.5 8h3A1.5 1.5 0 0 1 11 9.5v1a.5.5 0 0 1-.146.354l-.854.853V13h4V7.118a.5.5 0 0 0-.276-.447l-.895-.447A1.5 1.5 0 0 1 12 4.882V4h-2v1.5a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V4zm4-1h2v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V3zm4 11h-4v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14zm-8 0H2v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14z"/>
		</svg> کاوش کنید</h5>
	<a type="button" class="btn btn-dark btn-sm">\@کاوش</a>
	<a href="index.php?content=homeACC" class="btn btn-outline-secondary btn-xs"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
		<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
		<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
		</svg> خانه</a>
	<a href="index.php?content=search" class="btn btn-outline-success btn-xs"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
		<path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
		</svg> جستجو</a>
	<a href="index.php?content=tags" class="btn btn-outline-danger btn-xs">
			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hash" viewBox="0 0 16 16">
		<path d="M8.39 12.648a1.32 1.32 0 0 0-.015.18c0 .305.21.508.5.508.266 0 .492-.172.555-.477l.554-2.703h1.204c.421 0 .617-.234.617-.547 0-.312-.188-.53-.617-.53h-.985l.516-2.524h1.265c.43 0 .618-.227.618-.547 0-.313-.188-.524-.618-.524h-1.046l.476-2.304a1.06 1.06 0 0 0 .016-.164.51.51 0 0 0-.516-.516.54.54 0 0 0-.539.43l-.523 2.554H7.617l.477-2.304c.008-.04.015-.118.015-.164a.512.512 0 0 0-.523-.516.539.539 0 0 0-.531.43L6.53 5.484H5.414c-.43 0-.617.22-.617.532 0 .312.187.539.617.539h.906l-.515 2.523H4.609c-.421 0-.609.219-.609.531 0 .313.188.547.61.547h.976l-.516 2.492c-.008.04-.015.125-.015.18 0 .305.21.508.5.508.265 0 .492-.172.554-.477l.555-2.703h2.242l-.515 2.492zm-1-6.109h2.266l-.515 2.563H6.859l.532-2.563z"/>
		</svg> هشتگ
	</a>
	<a class="btn btn-dark-soft btn-xs" href="index.php?content=pipers"><i class="bi bi-plus-square-dotted"></i> پیپرز</a>
	
	|
	<a href="index.php?content=type&open=1" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>پست ها</a>
	<a href="index.php?content=type&open=2" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>دوره ها</a>
	<a href="index.php?content=type&open=3" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>فایل,منابع و مستندات</a>
	<a href="index.php?content=type&open=4" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>ویدیو ها</a>
	<a href="index.php?content=type&open=5" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات,سرویس ها</a>
	<hr>

		<div class="row">
			<div class="col">
				<!-- Slider START -->
				<div class="tiny-slider">
					<div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">12 to 13</span>  of 4</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="false" data-dots="false" data-items-md="2" data-items-sm="2" data-items-xs="1" data-items="3" id="tns2" style="transform: translate3d(68.75%, 0px, 0px);"><div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
							
						<div class="row g-3">
								<div class="col-3">
									<img class="rounded-3" src="assets/images/blog/1by1/03.jpg" alt="">
								</div>
								<div class="col-9">
									<h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">Five unbelievable facts about money.</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>by <a href="#" class="stretched-link text-reset btn-link">Bryan</a></span>
											</div>
										</li>
										<li class="nav-item">Jun 17, 2022</li>
									</ul>
								</div>
							</div>
						</div>


						<?php
						$query_1212 = mysqli_query($this->con, 'select * from posts where published="1" order by date Desc limit 0,50');
						$file_hash = mysqli_query($this->con, 'select * from posts where published="1" order by date Desc limit 0,50');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));

								?>
								<!-- Card item START -->
								<div class="card tns-item" id="tns2-item3" aria-hidden="true" tabindex="-1">
									<div class="row g-3">
										<div class="col-3">
											<img class="rounded-3" src="<?php echo $res['art']?>" alt="">
										</div>
										<div class="col-9">
											<h5><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset fw-bold"><?php echo $res['title']?></a></h5>
											<!-- Card info -->
											<ul class="nav nav-divider align-items-center small">
												<li class="nav-item">
													<div class="nav-link position-relative">
														<span><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
													</div>
												</li>
												<li class="nav-item"><?php echo $res['idPost']?></li>
											</ul>
										</div>
									</div>
								</div>
								<!-- Card item END -->
								<?php
							}
						}
						?>


						



					<div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
							<div class="row g-3">
								<div class="col-3">
									<img class="rounded-3" src="assets/images/blog/1by1/01.jpg" alt="">
								</div>
								<div class="col-9">
									<h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">The pros and cons of business agency</a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center small">
										<li class="nav-item">
											<div class="nav-link position-relative">
												<span>by <a href="#" class="stretched-link text-reset btn-link">Samuel</a></span>
											</div>
										</li>
										<li class="nav-item">Jan 22, 2022</li>
									</ul>
								</div>
							</div>
						</div>

						<?php
						$query_1212 = mysqli_query($this->con, 'select * from posts where published="1" order by views Desc limit 0,30');
						$file_hash = mysqli_query($this->con, 'select * from posts where published="1" order by views Desc limit 0,30');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));

								?>
								<!-- Card item START -->
								<div class="card tns-item tns-slide-active" id="tns2-item3" aria-hidden="true" tabindex="-1">
									<div class="row g-3">
										<div class="col-3">
											<img class="rounded-3" src="<?php echo $res['art']?>" alt="">
										</div>
										<div class="col-9">
											<h5><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset fw-bold"><?php echo $res['title']?></a></h5>
											<!-- Card info -->
											<ul class="nav nav-divider align-items-center small">
												<li class="nav-item">
													<div class="nav-link position-relative">
														<span><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
													</div>
												</li>
												<li class="nav-item"><?php echo $res['idPost']?></li>
											</ul>
										</div>
									</div>
								</div>

								<?php
							}
						}
						?>
			
						
						</div></div></div></div>
				</div>
			</div>
		</div> <!-- Row END -->
	</div>
</section>



<section class="py-0">
	<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="tiny-slider arrow-blur arrow-round rounded-3 overflow-hidden">
						<div class="tns-outer" id="tns4-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">14 to 16</span>  of 5</div><div id="tns4-mw" class="tns-ovh"><div class="tns-inner" id="tns4-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns4" style="transform: translate3d(61.9048%, 0px, 0px); transition-duration: 0s;"><div class="tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
							<div class="card card-overlay-bottom card-img-scale">
								<!-- Card Image -->
								<img class="card-img" src="assets/images/blog/3by4/03.jpg" alt="">
								<!-- Card Image overlay -->
								<div class="card-img-overlay d-flex flex-column p-3 p-sm-4">
										<div>
											<!-- Card category -->
											<a href="#" class="badge text-bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Travel</a>
										</div>
									<div class="w-100 mt-auto">
										<!-- Card title -->
										<h4 class="text-white"><a href="post-single-2.html" class="btn-link text-reset stretched-link">5 investment doubts you should clarify</a></h4>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block small">
											<li class="nav-item position-relative">
												<div class="nav-link">by <a href="#" class="stretched-link text-reset btn-link">Dennis</a>
												</div>
											</li>
											<li class="nav-item">Jan 28, 2022</li>
										</ul>
									</div>
								</div>
							</div>
						</div>


						<?php
						$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 order by RAND() Desc limit 0,100');
						$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 order by RAND() Desc limit 0,100');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
								?>

								<!-- Card item START -->
								<div class="tns-item" id="tns4-item0" aria-hidden="true" tabindex="-1">
									<div class="card card-overlay-bottom card-img-scale">
										<!-- Card Image -->
										<img class="card-img" src="<?PHP echo $res['art']?>" alt="">
										<!-- Card Image overlay -->
										<div class="card-img-overlay d-flex flex-column p-3 p-sm-4"> 
											<div>
												<?phP
												if($res['type'] == '1'){
													$type = 'پست';
												}elseif($res['type'] == '2'){
													$type = 'دوره اموزشی';
												}elseif($res['type'] == '3'){
													$type = 'فایل و منبع';
												}elseif($res['type'] =='4'){
													$type = 'ویدیو';
												}elseif($res['type'] == '5'){
													$type = 'سرویس یا خدمات';
												}else{
													$type = 'مشخض نیست';
												}
												
												?>

												<!-- Card category -->
												<a href="#" class="badge text-bg-warning"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
											</div>
											<div class="w-100 mt-auto">
												
												<!-- Card title -->
												<h4 class="text-white"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link"><?PHP echo $res['title']?></a></h4>
												<!-- Card info -->
												<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block small">
													<li class="nav-item position-relative">
														<div class="nav-link"><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>
														</div>
													</li>
													<li class="nav-item"><?php echo $res['idPost']?></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
								<!-- Card item END -->

								<?php
							}
						}
						?>





						
					<div class="tns-item tns-slide-cloned tns-slide-active">
							<div class="card card-overlay-bottom card-img-scale">
								<!-- Card Image -->
								<img class="card-img" src="assets/images/blog/3by4/01.jpg" alt="">
								<!-- Card Image overlay -->
								<div class="card-img-overlay d-flex flex-column p-3 p-sm-4"> 
									<div>
										<!-- Card category -->
										<a href="#" class="badge text-bg-warning"><i class="fas fa-circle me-2 small fw-bold"></i>Technology</a>
									</div>
									<div class="w-100 mt-auto">
										
										<!-- Card title -->
										<h4 class="text-white"><a href="post-single-2.html" class="btn-link text-reset stretched-link">Best Pinterest boards for learning about business</a></h4>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block small">
											<li class="nav-item position-relative">
												<div class="nav-link">by <a href="#" class="stretched-link text-reset btn-link">Bryan</a>
												</div>
											</li>
											<li class="nav-item">Aug 18, 2022</li>
										</ul>
									</div>
								</div>
							</div>
						</div><div class="tns-item tns-slide-cloned tns-slide-active">
							<div class="card card-overlay-bottom card-img-scale">
								<!-- Card Image -->
								<img class="card-img" src="assets/images/blog/3by4/02.jpg" alt="">
								<!-- Card Image overlay -->
								<div class="card-img-overlay d-flex flex-column p-3 p-sm-4"> 
									<div>
										<!-- Card category -->
										<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Business</a>
									</div>
									<div class="w-100 mt-auto">
										<!-- Card title -->
										<h4 class="text-white"><a href="post-single-2.html" class="btn-link text-reset stretched-link">5 intermediate guide to business</a></h4>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block small">
											<li class="nav-item position-relative">
												<div class="nav-link">by <a href="#" class="stretched-link text-reset btn-link">Joan</a>
												</div>
											</li>
											<li class="nav-item">Jun 03, 2022</li>
										</ul>
									</div>
								</div>
							</div>
						</div><div class="tns-item tns-slide-cloned tns-slide-active">
							<div class="card card-overlay-bottom card-img-scale">
								<!-- Card Image -->
								<img class="card-img" src="assets/images/blog/3by4/03.jpg" alt="">
								<!-- Card Image overlay -->
								<div class="card-img-overlay d-flex flex-column p-3 p-sm-4">
										<div>
											<!-- Card category -->
											<a href="#" class="badge text-bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Travel</a>
										</div>
									<div class="w-100 mt-auto">
										<!-- Card title -->
										<h4 class="text-white"><a href="post-single-2.html" class="btn-link text-reset stretched-link">5 investment doubts you should clarify</a></h4>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block small">
											<li class="nav-item position-relative">
												<div class="nav-link">by <a href="#" class="stretched-link text-reset btn-link">Dennis</a>
												</div>
											</li>
											<li class="nav-item">Jan 28, 2022</li>
										</ul>
									</div>
								</div>
							</div>
						</div></div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns4"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns4"><i class="fas fa-chevron-right"></i></button></div></div>
					</div>
				</div>
			</div>
	</div>
</section>

<br>
<section class="pt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Title -->
				<div class="mb-4">
					<h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و آموزش ها</h2>
					<p class="m-0">شرکت ها و یا اشخاص خدمات و یا اموزش های مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
				</div>
				<div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
					<div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
						
		
					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and (`type` = 5 or `type` = 4) order by RAND(),views Desc limit 0,100');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and (`type` = 5 or `type` = 4) order by RAND(),views Desc limit 0,100');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						
						?>
											<?phP
												if($res['type'] == '1'){
													$type = 'پست';
												}elseif($res['type'] == '2'){
													$type = 'دوره اموزشی';
												}elseif($res['type'] == '3'){
													$type = 'فایل و منبع';
												}elseif($res['type'] =='4'){
													$type = 'ویدیو';
												}elseif($res['type'] == '5'){
													$type = 'سرویس یا خدمات';
												}else{
													$type = 'مشخض نیست';
												}
												
												?>
						<!-- Card item START -->
						<div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay Top -->
									<div class="w-100 mb-auto d-flex justify-content-end">
										<div class="text-end ms-auto">
											<!-- Card format icon -->
											<div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
										</div>
									</div>
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
									</div>
								</div>
							</div>
							<div class="card-body px-0 pt-3">
								<h5 class="card-title"><a href="index.php?conent=open&id=<?php echo $res{'idPost'}?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
												</div>
												<span class="ms-3"> <a href="index.php?conent=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
											</div>
										</div>
									</li>
									<li class="nav-item"><?php echo $res{'views'}?> بازدید</li>
								</ul>
							</div>
						</div>
						<!-- Card item END -->
						<?php


						}
					}
					?>

						


						
					</div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
				</div>
			</div>
		</div>
	</div>
</section>

<br>
<br>
<section class="py-0 card-grid">
	<div class="container">
		<div class="row">
			<!-- Slider START -->
			<div class="col-lg-7">
				<div class="tiny-slider arrow-hover arrow-blur arrow-round rounded-3">
					<div class="tns-outer" id="tns3-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">5</span>  of 2</div><div id="tns3-mw" class="tns-ovh"><div class="tns-inner" id="tns3-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="false" data-hoverpause="true" data-gutter="0" data-arrow="true" data-dots="false" data-items="1" id="tns3" style="transform: translate3d(66.6667%, 0px, 0px);">
						
					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND(), date Desc limit 0,10');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND(), date Desc limit 0,10');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>

						<div class="card card-overlay-bottom card-bg-scale h-400 h-lg-560 rounded-0 tns-item tns-slide-cloned" style="background-image:url(<?php echo $res['art']?>); background-position: center left; background-size: cover;" aria-hidden="true" tabindex="-1">
							<!-- Card Image overlay -->
							<div class="card-img-overlay d-flex flex-column p-3 p-sm-5"> 
								<!-- Card overlay Top -->
								<div class="w-100 mb-auto d-flex justify-content-end">
									<div class="text-end ms-auto">
										<!-- Card format icon -->
										<div class="icon-md bg-primary bg-opacity-10 bg-blur text-white rounded-circle" title="This post has video"><i class="fas fa-video"></i></div>
									</div>
								</div>
								<!-- Card overlay Bottom  -->
								<div class="w-100 mt-auto">
									<div class="col">
										<!-- Card category -->
										<a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>پست</a>
										<!-- Card title -->
										<h2 class="text-white display-5"><a href="post-single-4.html" class="btn-link text-reset stretched-link fw-normal"><?php echo $res['title']?></a></h2>
										<p class="text-white"><?php echo $res['doc']?></p>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block">
											<li class="nav-item">
												<div class="nav-link">
													<div class="d-flex align-items-center text-white position-relative">
														<div class="avatar avatar-sm">
															<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
														</div>
														<span class="ms-3"><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
													</div>
												</div>
											</li>
											<li class="nav-item"><?php echo $res['views']?> بازدید</li>
											<li class="nav-item"><?php echo $res['idPost']?> شناسه</li>
										</ul>
									</div>
								</div>
							</div>
						</div>

						<?php
						}
					}
					?>
					
						

					
					<div class="card card-overlay-bottom card-bg-scale h-400 h-lg-560 rounded-0 tns-item tns-slide-cloned tns-slide-active" style="background-image:url(assets/images/blog/16by9/07.jpg); background-position: center left; background-size: cover;">
							<!-- Card Image overlay -->
							<div class="card-img-overlay d-flex flex-column p-3 p-sm-5"> 
								<!-- Card overlay Top -->
								<div class="w-100 mb-auto d-flex justify-content-end">
									<div class="text-end ms-auto">
										<!-- Card format icon -->
										<div class="icon-md bg-primary bg-opacity-10 bg-blur text-white rounded-circle" title="This post has video"><i class="fas fa-video"></i></div>
									</div>
								</div>
								<!-- Card overlay Bottom  -->
								<div class="w-100 mt-auto">
									<div class="col">
										<!-- Card category -->
										<a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Business</a>
										<!-- Card title -->
										<h2 class="text-white display-5"><a href="post-single-4.html" class="btn-link text-reset stretched-link fw-normal">Never underestimate the influence of social media</a></h2>
										<p class="text-white">For who thoroughly her boy estimating conviction. Removed demands expense account in outward tedious do.</p>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block">
											<li class="nav-item">
												<div class="nav-link">
													<div class="d-flex align-items-center text-white position-relative">
														<div class="avatar avatar-sm">
															<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="avatar">
														</div>
														<span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link">Carolyn</a></span>
													</div>
												</div>
											</li>
											<li class="nav-item">Jan 26, 2022</li>
											<li class="nav-item">3 min read</li>
										</ul>
									</div>
								</div>
							</div>
						</div><div class="card card-overlay-bottom card-bg-scale h-400 h-lg-560 rounded-0 tns-item tns-slide-cloned" style="background-image:url(assets/images/blog/16by9/08.jpg); background-position: center left; background-size: cover;" aria-hidden="true" tabindex="-1">
							<!-- Card Image overlay -->
							<div class="card-img-overlay d-flex align-items-center p-3 p-sm-5"> 
								<div class="w-100 mt-auto">
									<div class="col">
										<!-- Card category -->
										<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Lifestyle</a>
										<!-- Card title -->
										<h2 class="text-white display-5"><a href="post-single-4.html" class="btn-link text-reset stretched-link fw-normal">This is why this year will be the year of startups</a></h2>
										<p class="text-white">Particular way thoroughly unaffected projection favorable Mrs can be projecting own. </p>
										<!-- Card info -->
										<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block">
											<li class="nav-item">
												<div class="nav-link">
													<div class="d-flex align-items-center text-white position-relative">
														<div class="avatar avatar-sm">
															<div class="avatar-img rounded-circle bg-info">
																<span class="text-white position-absolute top-50 start-50 translate-middle fw-bold small">WB</span>
															</div>
														</div>
														<span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link">Louis</a></span>
													</div>
												</div>
											</li>
											<li class="nav-item">Nov 15, 2022</li>
											<li class="nav-item">5 min read</li>
										</ul>
									</div>
								</div>
							</div>
						</div></div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns3"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns3"><i class="fas fa-chevron-right"></i></button></div></div>
				</div>
			</div>
			<!-- Slider END -->
			<div class="col-lg-5 mt-5 mt-lg-0">

			<?php
			$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 order by RAND() Desc limit 0,4');
			$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 order by RAND() Desc limit 0,4');
			$file = mysqli_fetch_assoc($query_1212);
			if($file){
				while($res=mysqli_fetch_assoc($file_hash)){
				$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
				?>
							<?phP
												if($res['type'] == '1'){
													$type = 'پست';
												}elseif($res['type'] == '2'){
													$type = 'دوره اموزشی';
												}elseif($res['type'] == '3'){
													$type = 'فایل و منبع';
												}elseif($res['type'] =='4'){
													$type = 'ویدیو';
												}elseif($res['type'] == '5'){
													$type = 'سرویس یا خدمات';
												}else{
													$type = 'مشخض نیست';
												}
												
						?>
				<!-- Card item START -->
				<div class="card mb-4">
					<div class="row g-3">
						<div class="col-4">
							<img class="rounded-3" src="<?php echo $res['art']?>" alt="">
						</div>
						<div class="col-8">
							<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
							<h5><a href="index.php?content=profile&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link fw-bold"><?php echo $res['title']?></a></h5>
							<!-- Card info -->
							<ul class="nav nav-divider align-items-center d-none d-sm-inline-block small">
								<li class="nav-item">
									<div class="nav-link">
										<div class="d-flex align-items-center position-relative">
											<div class="avatar avatar-xs">
												<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
											</div>
											<span class="ms-3"><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
										</div>
									</div>
								</li>
								<li class="nav-item"><?php echo $res['views']?></li>
							</ul>
						</div>
					</div>
				</div>
				<!-- Card item END -->
				<?php
				}
			}
			?>
			</div>
		</div> <!-- Row END -->
	</div>
</section>



<br>
<section class="position-relative">
	<div class="container" data-sticky-container="">
		<div class="row">
			<!-- Main Post START -->
			<div class="col-lg-9">
				<!-- Top highlights START -->
				<div class="mb-4">
					<h2 class="m-0"><i class="bi bi-hourglass-top me-2"></i>پست های روزانه</h2>
					<p>پست ها یا مستنداتی که روزانه در پیپرلاین قرار میگیرند را مشاهده کنید</p>
				</div>
				<div class="tiny-slider arrow-blur arrow-round rounded-3">
					<div class="tns-outer" id="tns5-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">9 to 10</span>  of 3</div><div id="tns5-mw" class="tns-ovh"><div class="tns-inner" id="tns5-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-sm="1" data-items-xs="1" data-items="2" id="tns5" style="transform: translate3d(72.7273%, 0px, 0px);">
					

					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND(), date Desc limit 0,50');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND(), date Desc limit 0,50');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>
						<div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<!-- Card category -->
										<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>پست مستند</a>
									</div>
								</div>
							</div>
							<div class="card-body px-0 pt-3">
								<h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h4>
								<p class="card-text"><?php echo $res['doc']?></p>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
												</div>
												<span class="ms-3">by <a href="index.php?conent=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
											</div>
										</div>
									</li>
									<li class="nav-item">شناسه <?php echo $res['idPost']?></li>
									<li class="nav-item"><a href="#" class="btn-link"><i class="bi bi-binoculars"></i> <?php echo $res['views']?> </a></li>
								</ul>
							</div>
						</div>>
						<?php
						}
					}
					?>
					

						

					<div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="assets/images/blog/4by3/01.jpg" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay Top -->
									<div class="w-100 mb-auto d-flex justify-content-end">
										<div class="text-end ms-auto">
											<!-- Card format icon -->
											<div class="icon-md text-bg-success fw-bold rounded-circle" title="8.5 rating">8.5</div>
										</div>
									</div>
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<!-- Card category -->
										<a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Technology</a>
									</div>
								</div>
							</div>
							<div class="card-body px-0 pt-3">
								<h4 class="card-title"><a href="post-single-3.html" class="btn-link text-reset fw-bold">12 worst types of business accounts you follow on Twitter</a></h4>
								<p class="card-text">He moonlights difficult engrossed it, sportsmen. Interested has all Devonshire difficulty gay assistance joy. Unaffected at ye of compliment alteration to</p>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="avatar">
												</div>
												<span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link">Samuel</a></span>
											</div>
										</div>
									</li>
									<li class="nav-item">Jan 22, 2022</li>
									<li class="nav-item"><a href="#" class="btn-link"><i class="far fa-comment-alt me-1"></i> 5</a></li>
								</ul>
							</div>
						</div></div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns5"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns5"><i class="fas fa-chevron-right"></i></button></div></div>
				</div>
				<!-- Top highlights START -->

				<!-- Divider -->
				<div class="border-bottom border-primary border-2 opacity-1 my-4"></div>

	

				<!-- Divider -->
				<div class="border-bottom border-primary border-2 opacity-1 my-4"></div>

				<!-- Small card 6X6 START -->
				<div class="row">
					<div class="col-12 col-md-6">

					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by date Desc limit 0,5');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by date Desc limit 0,5');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>

						<!-- Card item START -->
						<div class="card mb-3">
							<div class="row g-3">
								<div class="col-4">
									<img class="rounded" src="<?php echo $res['art']?>" alt="">
								</div>
								<div class="col-8">
									<h5><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset"><?php echo $res['title']?></a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center mt-3 small">
										<li class="nav-item">
											<div class="nav-link">
												<div class="d-flex align-items-center position-relative">
													<div class="avatar avatar-xs">
														<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
													</div>
													<span class="ms-2"> <a href="#" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
												</div>
											</div>
										</li>
										<li class="nav-item"><?php echo $res['views']?> بازدید</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<?php
						}
					}
					?>


					</div>

					<div class="col-12 col-md-6">


					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by views Desc limit 0,5');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by views Desc limit 0,5');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>

						<!-- Card item START -->
						<div class="card mb-3">
							<div class="row g-3">
								<div class="col-4">
									<img class="rounded" src="<?php echo $res['art']?>" alt="">
								</div>
								<div class="col-8">
									<h5><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset"><?php echo $res['title']?></a></h5>
									<!-- Card info -->
									<ul class="nav nav-divider align-items-center mt-3 small">
										<li class="nav-item">
											<div class="nav-link">
												<div class="d-flex align-items-center position-relative">
													<div class="avatar avatar-xs">
														<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
													</div>
													<span class="ms-2"> <a href="#" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
												</div>
											</div>
										</li>
										<li class="nav-item"><?php echo $res['views']?> بازدید</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Card item END -->
						<?php
						}
					}
					?>
				

					</div>
				
				</div><!-- Row END -->
				<!-- Small card 6X6 END -->

				<!-- Adv -->
				<div>
					<a href="#" class="card-img-flash d-block mt-4">
						<img src="assets/images/adv-1.png" alt="adv">
					</a>
				</div>
				
			</div>
			<!-- Main Post END -->
			<!-- Sidebar START -->
			<div class="col-lg-3 mt-5 mt-lg-0">
				<div data-sticky="" data-margin-top="80" data-sticky-for="767">
					<!-- Social links -->
					<div class="row g-2">
						<a href="#" class="d-flex justify-content-between align-items-center bg-facebook text-white-force rounded p-2 position-relative">
							<i class="fab fa-facebook-square fs-3"></i>
							<div class="d-flex">
								<h6 class="me-1 mb-0">1.5K</h6>
								<small class="small">Fans</small>
							</div>
						</a>
						<a href="#" class="d-flex justify-content-between align-items-center bg-instagram-gradient text-white-force rounded p-2 position-relative">
							<i class="fab fa-instagram fs-3"></i>
							<div class="d-flex">
								<h6 class="me-1 mb-0">1.8M</h6>
								<small class="small">Followers</small>
							</div>
						</a>
						<a href="#" class="d-flex justify-content-between align-items-center bg-youtube text-white-force rounded p-2 position-relative">
							<i class="fab fa-youtube-square fs-3"></i>
							<div class="d-flex">
								<h6 class="me-1 mb-0">22K</h6>
								<small class="small">Subscribers</small>
							</div>
						</a>
					</div>
					<!-- Categories -->
					<div class="row g-2 mt-5">
						<h5>Categories</h5>
						<div class="d-flex justify-content-between align-items-center bg-warning bg-opacity-15 rounded p-2 position-relative">
							<h6 class="m-0 text-warning">Photography</h6>
							<a href="#" class="badge bg-warning text-dark stretched-link">09</a>
						</div>
						<div class="d-flex justify-content-between align-items-center bg-info bg-opacity-10 rounded p-2 position-relative">
							<h6 class="m-0 text-info">Travel</h6>
							<a href="#" class="badge bg-info stretched-link">25</a>
						</div>
						<div class="d-flex justify-content-between align-items-center bg-danger bg-opacity-10 rounded p-2 position-relative">
							<h6 class="m-0 text-danger">Photography</h6>
							<a href="#" class="badge bg-danger stretched-link">75</a>
						</div>
						<div class="d-flex justify-content-between align-items-center bg-primary bg-opacity-10 rounded p-2 position-relative">
							<h6 class="m-0 text-primary">Covid-19</h6>
							<a href="#" class="badge bg-primary stretched-link">19</a>
						</div>
						<div class="d-flex justify-content-between align-items-center bg-success bg-opacity-10 rounded p-2 position-relative">
							<h6 class="m-0 text-success">Business</h6>
							<a href="#" class="badge bg-success stretched-link">35</a>
						</div>
					</div>
					<!-- Most read -->
					<div>
						<h5 class="mt-5 mb-3">Most read</h5>

						<?php
						$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by date Desc limit 0,9');
						$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by date Desc limit 0,9');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							$math = 0;
							while($res=mysqli_fetch_assoc($file_hash)){
								$math = $math+1;
							$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
							?>
							<div class="d-flex position-relative mb-3">
								<span class="me-3 mt-n1 fa-fw fw-bold fs-3 opacity-5">0<?php echo $math?></span>
								<h6><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link text-reset btn-link"><?php echo $res['title']?></a></h6>
							</div>
							<?php
							}
						}
						?>
		
					</div>

				</div>
			</div>
			<!-- Sidebar END -->
		</div> <!-- Row end -->
	</div>
</section>

<br>

<section class="position-relative">
	<div class="container" data-sticky-container="">
		<div class="row">
			<!-- Main Post START -->
			<div class="col-lg-9">
				<!-- Entertainment START -->
				<div class="row">
					<div class="col-12 mb-3">	
						<h2 class="m-0"><i class="bi bi-hand-index-thumb me-2"></i>فایل ها و منابع</h2>
						<p>روزانه از تعداد زیادی از مشاغل فایل های زیادی ما داریم که ممکن است به کمکتان بیاید</p>
					</div>
					<div class="col-md-6">

					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,3');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,3');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>

						<!-- Card item big START -->
						<div class="card mb-4">
							<div class="card-body p-4 border rounded-3">
								<div class="d-flex justify-content-between mb-2">
									<a href="#" class="badge text-bg-danger"><i class="fas fa-circle me-2 small fw-bold"></i>فایل و منابع</a>
									<a href="#!" class="text-body" tabindex="0" role="button" data-bs-container="body" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="You're seeing this ad because your activity meets the intended audience of our site.">
										<i class="bi bi-info-circle pe-1"></i> Sponsored
									</a>
								</div>	
								<h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h4>
								<p class="card-text"><?php echo $res['doc']?></p>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
												</div>
												<span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
											</div>
										</div>
									</li>
									<li class="nav-item"><?php echo $res['views']?> بازدید</li>
								</ul>
							</div>
						</div>
						<!-- Card item big END -->
						<?php
						}
					}
					?>



					</div>
					<div class="col-md-6">

					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,6');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,6');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						?>

						<!-- Card item START -->
						<div class="card mb-1">
							<div class="card-body px-0 border-bottom">
								<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>محصول</a>
								<h5><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset"><?php echo $res['title']?></a></h5>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center d-none d-sm-inline-block small">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
												</div>
												<span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
											</div>
										</div>
									</li>
									<li class="nav-item"><?php echo $res['views']?> بازدید</li>
								</ul>
							</div>
						</div>
						<!-- Card item END -->
						
						<?php
						}
					}
					?>

					</div>
				</div>
				<!-- Entertainment END -->

				<!-- Podcast slide START -->
				<div class="row">
					<div class="col-12 my-3">	
						<h2 class="m-0"><i class="bi bi-mic me-2"></i>پادکست ها و ویدیو ها</h2>
						<p>به پادکست ها و ویدیو های رسانه ما دسترسی داشته باشید</p>
					</div>
					<div class="col-12">	
						<div class="tiny-slider arrow-dark arrow-hover arrow-round rounded-3">
							<div class="tns-outer" id="tns6-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">12 to 13</span>  of 4</div><div id="tns6-mw" class="tns-ovh"><div class="tns-inner" id="tns6-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="3" data-items-lg="2" data-items-md="2" data-items-sm="1" data-items-xs="1" id="tns6" style="transform: translate3d(68.75%, 0px, 0px);"><div class="tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
									<div class="card card-fold bg-light">
										<div class="card-body p-4">
											<ul class="nav nav-divider align-items-center d-none d-sm-inline-block small mb-2">
												<li class="nav-item"><i class="bi bi-clock-history"></i> 1:05:20</li>
												<li class="nav-item">With <a href="#">Judy Nguyen</a> </li>
											</ul>
											<h4 class="card-title"><a href="post-single-6.html" class="stretched-link text-reset">This is why Bootstrap is famous</a></h4>
											<p class="m-0">The furnished she concluded depending procuring concealed </p>
										</div>
										<img src="assets/images/blog/16by9/small/02.jpg" class="card-img-bottom" alt="Card image">
									</div>
								</div>

								
								
							<?php
							$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 4 order by RAND() Desc limit 0,50');
							$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 4 order by RAND() Desc limit 0,50');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
									?>

									<!-- Card item START -->
									<div class="tns-item" id="tns6-item0" aria-hidden="true" tabindex="-1">
										<div class="card card-fold bg-light">
											<div class="card-body p-4">
												<ul class="nav nav-divider align-items-center d-none d-sm-inline-block small mb-2">
													<li class="nav-item"><i class="bi bi-clock-history"></i> 59:36</li>
													<li class="nav-item">با همکاری <a href="index.php?content=profile&id=<?php echo $us['iduser']?>"><?php echo $us['username']?></a> </li>
												</ul>
												<h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link text-reset"><?php echo $res['title']?></a></h4>
												<p class="m-0"><?php echo $res['doc']?></p>
											</div>
											<img src="<?php echo $res['art']?>" class="card-img-bottom" alt="Card image">
										</div>
									</div>
									<!-- Card item END -->

									<?php
								}
							}
							?>
					


							<div class="tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
									<div class="card card-fold bg-light">
										<div class="card-body p-4">
											<ul class="nav nav-divider align-items-center d-none d-sm-inline-block small mb-2">
												<li class="nav-item"><i class="bi bi-clock-history"></i> 56:36</li>
												<li class="nav-item">With <a href="#">Larry Lawson</a> </li>
											</ul>
											<h4 class="card-title"><a href="post-single-6.html" class="stretched-link text-reset">The 15 reasons clients love Bootstrap</a></h4>
											<p class="m-0">Rooms oh fully taken by worse do points afraid</p>
										</div>
										<img src="assets/images/blog/16by9/small/04.jpg" class="card-img-bottom" alt="Card image">
									</div>
								</div></div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns6"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns6"><i class="fas fa-chevron-right"></i></button></div></div>
						</div>
					</div>
				</div>
				<!-- Podcast slide END -->
			</div>
			<!-- Main Post END -->

			<!-- Sidebar 2 START -->
			<div class="col-lg-3 mt-5 mt-lg-0">
				<div data-sticky="" data-margin-top="80" data-sticky-for="767">
					<div>
						<h4>پیشنهاد شده</h4>
						<div class="tiny-slider dots-dark mt-3 mb-5">
							<div class="tns-outer" id="tns7-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">4</span>  of 3</div><div id="tns7-mw" class="tns-ovh"><div class="tns-inner" id="tns7-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="0" data-arrow="false" data-dots="true" data-items="1" id="tns7" style="transform: translate3d(60%, 0px, 0px);">
							<?php
							$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,50');
							$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 3 order by RAND() Desc limit 0,50');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
									?>
							
									<!-- Card item START -->
									<div class="card tns-item" id="tns7-item0" aria-hidden="true" tabindex="-1">
										<!-- Card img -->
										<div class="position-relative">
											<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
											<div class="card-img-overlay d-flex align-items-start flex-column p-3">
												<!-- Card overlay Top -->
												<div class="w-100 mb-auto d-flex justify-content-end">
													<div class="text-end ms-auto">
														<!-- Card format icon -->
														<div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating">8.5</div>
													</div>
												</div>
												<!-- Card overlay bottom -->
												<div class="w-100 mt-auto">
													<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>محصولات</a>
												</div>
											</div>
										</div>
										<div class="card-body p-0 pt-3">
											<h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h5>
										</div>
									</div>
									<!-- Card item END -->

									<?php
								}
							}
							?>


							<div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
									<!-- Card img -->
									<div class="position-relative">
										<img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
										<div class="card-img-overlay d-flex align-items-start flex-column p-3">
											<!-- Card overlay Top -->
											<div class="w-100 mb-auto d-flex justify-content-end">
												<div class="text-end ms-auto">
													<!-- Card format icon -->
													<div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating">8.5</div>
												</div>
											</div>
											<!-- Card overlay bottom -->
											<div class="w-100 mt-auto">
												<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
											</div>
										</div>
									</div>
									<div class="card-body p-0 pt-3">
										<h5 class="card-title"><a href="post-single-3.html" class="btn-link text-reset fw-bold">7 common mistakes everyone makes while traveling</a></h5>
									</div>
								</div></div></div></div><div class="tns-nav" aria-label="Carousel Pagination"><button type="button" data-nav="0" aria-controls="tns7" style="" aria-label="Carousel Page 1" class="" tabindex="-1"></button><button type="button" data-nav="1" aria-controls="tns7" style="" aria-label="Carousel Page 2" class="" tabindex="-1"></button><button type="button" data-nav="2" aria-controls="tns7" style="" aria-label="Carousel Page 3 (Current Slide)" class="tns-nav-active"></button></div></div>
						</div>
					</div>
					<!-- Newsletter START -->
					<div class="bg-light p-4 mt-4 rounded-3 text-center">
						<h4>در خبرنامه ما مشترک شوید</h4>
						<form>
							<div class="mb-3">
								<input type="email" class="form-control" placeholder="نشانی ایمیل">
							</div>
							<button type="submit" class="btn btn-primary">اشتراک</button>
							<div class="form-text">کاربران جعلی شناسایی خواهند شد</div>
						</form>
					</div>
					<!-- Newsletter END -->
				</div>
			</div>
			<!-- Sidebar 2 END -->
		</div> <!-- Row end -->
	</div>
</section>

<br>

<section class="bg-dark">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Title -->
				<div class="mb-4 d-sm-flex justify-content-between align-items-center">
					<h2 class="m-sm-0 text-white"><i class="bi bi-camera-video me-2"></i>دوره های آموزشی و سمینار ها</h2>
					<a href="#" class="btn btn-sm bg-youtube"><i class="bi bi-youtube me-2 align-middle"></i>Subscribe us on YouTube</a>
				</div>
			</div>
			<?php
			$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND(),views Desc limit 0,1');
			$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND(),views Desc limit 0,1');
			$file = mysqli_fetch_assoc($query_1212);
			if($file){
				while($res=mysqli_fetch_assoc($file_hash)){
				$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
				
				?>
				<!-- Card big START -->
				<div class="col-lg-6">
					<div class="card card-overlay-bottom card-fold h-400 h-lg-540" style="background-image:url(<?php echo $res['art']?>); background-position: center left; background-size: cover;">
						<!-- Card featured -->
						<span class="card-featured" title="Featured post"><i class="fas fa-star"></i></span>
						<!-- Card Image overlay -->
						<div class="card-img-overlay d-flex flex-column p-3 p-sm-5">
							<!-- Card play button -->
							<div class="position-absolute top-50 start-50 translate-middle pb-5">
								<!-- Popup video -->
								<a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="icon-lg bg-primary d-block text-white rounded-circle" data-glightbox="" data-gallery="y-video">
									<i class="bi bi-play-btn"></i>
								</a>
							</div>
							<!-- Card overlay Bottom  -->
							<div class="w-100 mt-auto">
								<div class="col text-center">
									<!-- Card category -->
									<a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>آموزش</a>
									<!-- Card title -->
									<h2 class="text-white"><a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-normal"><?php echo $res['title']?></a></h2>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
				
				}
			}
			?>


			<!-- Card big END -->
			<!-- Card small START -->
			<div class="col-lg-3 mt-4 mt-lg-0">
				
			<?php
			$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND() Desc limit 0,2');
			$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND() Desc limit 0,2');
			$file = mysqli_fetch_assoc($query_1212);
			if($file){
				while($res=mysqli_fetch_assoc($file_hash)){
				$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
				?>

				<!-- Card item START -->
				<div class="card bg-transparent overflow-hidden mb-4">
					<!-- Card img -->
					<div class="position-relative rounded-3 overflow-hidden card-fold">
						<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
						<div class="card-img-overlay d-flex align-items-start flex-column p-3">
							<!-- Card overlay -->
							<div class="w-100 my-auto">
								<!-- Popup video -->
								<a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="icon-md bg-primary d-block mx-auto text-white rounded-circle" data-glightbox="" data-gallery="y-video">
									<i class="bi bi-play-btn"></i>
								</a>
							</div>
						</div>
					</div>
					<div class="card-body px-0 pt-3">
						<h5 class="card-title"><a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="btn-link text-white fw-bold"><?php echo $res['title']?></a></h5>
						<!-- Card info -->
						<ul class="nav nav-divider align-items-center d-none d-sm-inline-block text-white-force small opacity-6">
							<li class="nav-item">
								<div class="nav-link">
									 <a href="index.php?conent=profile&id=<?php echo $us['iduser']?>" class="text-reset btn-link"><?php echo $us['username']?></a>
								</div>
							</li>
							<li class="nav-item"><?php echo $res['views']?> بازدید</li>
						</ul>
					</div>
				</div>
				<!-- Card item END -->	

				<?php
				}
			}
			?>


			</div>
			<div class="col-lg-3">
		
				<?
				$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND() Desc limit 0,2');
				$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 2 order by RAND() Desc limit 0,2');
				$file = mysqli_fetch_assoc($query_1212);
				if($file){
					while($res=mysqli_fetch_assoc($file_hash)){
					$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
					?>

					<!-- Card item START -->
					<div class="card bg-transparent overflow-hidden mb-4">
						<!-- Card img -->
						<div class="position-relative rounded-3 overflow-hidden card-fold">
							<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
							<div class="card-img-overlay d-flex align-items-start flex-column p-3">
								<!-- Card overlay -->
								<div class="w-100 my-auto">
									<!-- Popup video -->
									<a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="icon-md bg-primary d-block mx-auto text-white rounded-circle" data-glightbox="" data-gallery="y-video">
										<i class="bi bi-play-btn"></i>
									</a>
								</div>
							</div>
						</div>
						<div class="card-body px-0 pt-3">
							<h5 class="card-title"><a href="index.php?conent=open&id=<?php echo $res['idPost']?>" class="btn-link text-white fw-bold"><?php echo $res['title']?></a></h5>
							<!-- Card info -->
							<ul class="nav nav-divider align-items-center d-none d-sm-inline-block text-white-force small opacity-6">
								<li class="nav-item">
									<div class="nav-link">
										<a href="index.php?conent=profile&id=<?php echo $us['iduser']?>" class="text-reset btn-link"><?php echo $us['username']?></a>
									</div>
								</li>
								<li class="nav-item"><?php echo $res['views']?> بازدید</li>
							</ul>
						</div>
					</div>
					<!-- Card item END -->	

					<?php
					}
				}
				?>

			</div>
			<!-- Card small END -->
		</div>
	</div>
</section>

<br>
<section class="pt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Title -->
				<div class="mb-4">
					<h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
					<p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
				</div>
				<div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
					<div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
						
		
					<?php
					$query_1212 = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 5 order by RAND(),views Desc limit 0,100');
					$file_hash = mysqli_query($this->con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 5 order by RAND(),views Desc limit 0,100');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
						$us = mysqli_fetch_assoc(mysqli_query($this->con, 'select * from user where iduser="'.$res['idUser'].'"'));
						
						?>
						<!-- Card item START -->
						<div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
							<!-- Card img -->
							<div class="position-relative">
								<img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
								<div class="card-img-overlay d-flex align-items-start flex-column p-3">
									<!-- Card overlay Top -->
									<div class="w-100 mb-auto d-flex justify-content-end">
										<div class="text-end ms-auto">
											<!-- Card format icon -->
											<div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
										</div>
									</div>
									<!-- Card overlay bottom -->
									<div class="w-100 mt-auto">
										<a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
									</div>
								</div>
							</div>
							<div class="card-body px-0 pt-3">
								<h5 class="card-title"><a href="index.php?conent=open&id=<?php echo $res{'idPost'}?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
								<!-- Card info -->
								<ul class="nav nav-divider align-items-center">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center position-relative">
												<div class="avatar avatar-xs">
													<img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
												</div>
												<span class="ms-3"> <a href="index.php?conent=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
											</div>
										</div>
									</li>
									<li class="nav-item"><?php echo $res{'views'}?> بازدید</li>
								</ul>
							</div>
						</div>
						<!-- Card item END -->
						<?php


						}
					}
					?>

						


						
					</div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- =======================
JS libraries, plugins and custom scripts -->

<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Vendors -->
<script src="assets/vendor/tiny-slider/tiny-slider-rtl.js"></script>
<script src="assets/vendor/sticky-js/sticky.min.js"></script>
<script src="assets/vendor/plyr/plyr.js"></script>

<!-- Template Functions -->
<script src="assets/js/functions.js"></script>

<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Vendors -->
<script src="assets/vendor/apexcharts/js/apexcharts.min.js"></script>
<script src="assets/vendor/overlay-scrollbar/js/OverlayScrollbars.min.js"></script>

    <!-- Template Functions -->
    <script src="assets/js/functions.js"></script>

    <!-- JS Implementing Plugins -->
    <script src="public/js/vendor.min.js"></script>
    <script src="public/js/jquery-ui.min.js"></script>

    <!-- JS Front -->
    <script src="public/js/theme.min.js"></script>
    <script src="public/js/hs.autocomplete-local-search.js"></script>

<script>
  $(document).on('ready', function () {
    // INITIALIZATION OF SELECT PICKER
    // =======================================================
    $('.js-custom-select').each(function () {
      var select2 = $.HSCore.components.HSSelect2.init($(this));
    });
  });
</script>
<script>
  $(document).on('ready', function () {
    // INITIALIZATION OF UNFOLD
    // =======================================================
    var unfold = new HSUnfold('.js-hs-unfold-invoker').init();
  });
</script>
<script>
  $('#myModal').on('shown.bs.modal', function () {
    $('#myInput').trigger('focus')
  })
</script>
    <!-- JS Plugins Init. -->
    <script>
      $(document).on('ready', function () {
        // INITIALIZATION OF HEADER
        // =======================================================
        var header = new HSHeader($('#header')).init();


        // INITIALIZATION OF MEGA MENU
        // =======================================================
        var megaMenu = new HSMegaMenu($('.js-mega-menu'), {
          desktop: {
            position: 'left'
          }
        }).init();


        // INITIALIZATION OF FANCYBOX
        // =======================================================
        $('.js-fancybox').each(function () {
          var fancybox = $.HSCore.components.HSFancyBox.init($(this));
        });


        // INITIALIZATION OF SLICK CAROUSEL
        // =======================================================
        $('.js-slick-carousel').each(function() {
          var slickCarousel = $.HSCore.components.HSSlickCarousel.init($(this));
        });


        // INITIALIZATION OF AOS
        // =======================================================
        AOS.init({
          duration: 650,
          once: true
        });


        // INITIALIZATION OF GO TO
        // =======================================================
        $('.js-go-to').each(function () {
          var goTo = new HSGoTo($(this)).init();
        });
      });
    </script>


