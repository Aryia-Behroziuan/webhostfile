<?phP
												if($_GET['open'] == '1'){
													$type = 'پست ها';
													$typeQ = 1;
												}elseif($_GET['open'] == '2'){
													$type = 'دوره';
                                                    $typeQ = 2;
												}elseif($_GET['open'] == '3'){
													$type = 'فایل,منبع,مستندات';
                                                    $typeQ = 3;
												}elseif($_GET['open'] =='4'){
													$type = 'ویدیو';
                                                    $typeQ = 4;
												}elseif($_GET['open'] == '5'){
													$type = 'سرویس,خدمات';
                                                    $typeQ = 5;
												}else{
													$type = 'مشخض نیست';
                                                    $typeQ = 1;
												}
												
												?>




<section class="pt-4">
	<div class="container">
    <h5><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-binoculars" viewBox="0 0 16 16">
		<path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h1A1.5 1.5 0 0 1 7 2.5V5h2V2.5A1.5 1.5 0 0 1 10.5 1h1A1.5 1.5 0 0 1 13 2.5v2.382a.5.5 0 0 0 .276.447l.895.447A1.5 1.5 0 0 1 15 7.118V14.5a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 14.5v-3a.5.5 0 0 1 .146-.354l.854-.853V9.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.793l.854.853A.5.5 0 0 1 7 11.5v3A1.5 1.5 0 0 1 5.5 16h-3A1.5 1.5 0 0 1 1 14.5V7.118a1.5 1.5 0 0 1 .83-1.342l.894-.447A.5.5 0 0 0 3 4.882V2.5zM4.5 2a.5.5 0 0 0-.5.5V3h2v-.5a.5.5 0 0 0-.5-.5h-1zM6 4H4v.882a1.5 1.5 0 0 1-.83 1.342l-.894.447A.5.5 0 0 0 2 7.118V13h4v-1.293l-.854-.853A.5.5 0 0 1 5 10.5v-1A1.5 1.5 0 0 1 6.5 8h3A1.5 1.5 0 0 1 11 9.5v1a.5.5 0 0 1-.146.354l-.854.853V13h4V7.118a.5.5 0 0 0-.276-.447l-.895-.447A1.5 1.5 0 0 1 12 4.882V4h-2v1.5a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V4zm4-1h2v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V3zm4 11h-4v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14zm-8 0H2v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14z"/>
		</svg> کاوش کنید</h5>
	<a type="button" class="btn btn-dark btn-sm">\@کاوش</a>
	<a type="button" class="btn btn-outline-secondary btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
		<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
		<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
		</svg> خانه</a>
	<a type="button" class="btn btn-outline-success btn-sm"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
		<path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
		</svg> جستجو</a>
	<a href="index.php?content=tags" class="btn btn-outline-danger btn-sm">
			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hash" viewBox="0 0 16 16">
		<path d="M8.39 12.648a1.32 1.32 0 0 0-.015.18c0 .305.21.508.5.508.266 0 .492-.172.555-.477l.554-2.703h1.204c.421 0 .617-.234.617-.547 0-.312-.188-.53-.617-.53h-.985l.516-2.524h1.265c.43 0 .618-.227.618-.547 0-.313-.188-.524-.618-.524h-1.046l.476-2.304a1.06 1.06 0 0 0 .016-.164.51.51 0 0 0-.516-.516.54.54 0 0 0-.539.43l-.523 2.554H7.617l.477-2.304c.008-.04.015-.118.015-.164a.512.512 0 0 0-.523-.516.539.539 0 0 0-.531.43L6.53 5.484H5.414c-.43 0-.617.22-.617.532 0 .312.187.539.617.539h.906l-.515 2.523H4.609c-.421 0-.609.219-.609.531 0 .313.188.547.61.547h.976l-.516 2.492c-.008.04-.015.125-.015.18 0 .305.21.508.5.508.265 0 .492-.172.554-.477l.555-2.703h2.242l-.515 2.492zm-1-6.109h2.266l-.515 2.563H6.859l.532-2.563z"/>
		</svg> هشتگ
	</a>
	
	|
	<a href="index.php?content=type&open=1" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>پست ها</a>
	<a href="index.php?content=type&open=2" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>دوره ها</a>
	<a href="index.php?content=type&open=3" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>فایل,منابع و مستندات</a>
	<a href="index.php?content=type&open=4" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>ویدیو ها</a>
	<a href="index.php?content=type&open=5" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات,سرویس ها</a>
	<hr>
		<div class="row">
      <div class="col-12">
				<div class="bg-success bg-opacity-10 text-center rounded-3 p-4"> 
					<h1 class="text-success"><?php echo $type?></h1>
					<nav class="d-flex justify-content-center" aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots mb-0">
							<li class="breadcrumb-item"><a href="index-2.html"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active"><?php echo $type?></li>
						</ol>
					</nav>
				</div>
      </div>
    </div>
	</div>
</section>
<section class="position-relative pt-0">
	<div class="container">
		<div class="row">




        <?php
		$query_1212 = mysqli_query($con, 'select * from posts where published="1" and status="1" and type="'.$typeQ.'" order by date Desc limit 0,25');
		$file_hash = mysqli_query($con, 'select * from posts where published="1" and status="1" and type="'.$typeQ.'" order by date Desc limit 0,25');
		$file = mysqli_fetch_assoc($query_1212);
		if($file){
		    while($res=mysqli_fetch_assoc($file_hash)){
			$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
			mysqli_query($con, "
			UPDATE posts
			SET
			  `saged` = `saged`+10,
			  `sagedAd` = `sagedAd`+7
			  
			WHERE
			  idPost = ".$res['idPost'].";
			");
			?>
			<!-- Card item START -->
			<div class="col-sm-6 col-lg-3">
				<div class="card mb-4">
					<!-- Card img -->
					<div class="card-fold position-relative">
						<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
					</div>
					<div class="card-body px-0 pt-3">
						<h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link fw-bold"><?php echo $res['title']?></a></h4>
						<!-- Card info -->
						<ul class="nav nav-divider align-items-center text-uppercase small">
							<li class="nav-item">
								<a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="nav-link text-reset btn-link"><?php echo $us['username']?></a>
							</li>
							<li class="nav-item"><?php echo $res['views']?> بازید</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- Card item END -->
			
            <?php

            }

			?>
					<div id="addNowCode"></div>
					<button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
					
											<script>
											
											var loadBox = 0;
                                            $('#loadMore').click(function(event){
                                            event.preventDefault();
                                            $('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
											var z = Math.random()*10;
											var code = '<div id="'+String(z)+'"></div>';
											document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=home&method=loadCate&open=<?php echo $_GET['open']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
												document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
												document.getElementById(z).innerHTML = data;
                                               
                                                })

                                            })
                                            </script>
			<?php
        }
        ?>



		</div> <!-- Row end -->

    <!-- Pagination START -->
    <nav class="mb-5 d-flex justify-content-center" aria-label="navigation">
      <ul class="pagination pagination-bordered ">
        <li class="page-item disabled">
          <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Prev</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item active"><a class="page-link" href="#">2</a></li>
        <li class="page-item disabled"><a class="page-link" href="#">..</a></li>
        <li class="page-item"><a class="page-link" href="#">15</a></li>
        <li class="page-item">
          <a class="page-link" href="#">Next</a>
        </li>
      </ul>
    </nav>
    <!-- Pagination END -->
	</div>
</section>