<?php
if(! isset($_GET['search'])){
    ?>
    <section class="pt-4">
        <div class="container">
            <div class="row">
        <div class="col-lg-9 mx-auto text-center py-5">
            <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موتور جستجو پیپرلاین</font></font></span>
            <h2 class="display-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img class="navbar-brand-item light-mode-item" style="width: 180px; height: 70px;" src="assets/images/logo.png" alt="لوگو"></font></font></h2>
            <span class="lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاوش را شروع کنید</font></font></span>
            <!-- Search -->
            <div class="row">
                <div class="col-sm-8 col-md-6 col-lg-12 mx-auto">
                <form class="input-group mt-4" action="" method="GET">
                    <div class="input-group">
                        <input type="text" value="search" name="content" style="display: none;">
                        <input type="text" class="form-control" name="search" placeholder="در اینجا جستجو کنید" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                            </svg></button>
                            <button class="btn btn-outline-secondary" type="button"><img style="width: 20px; height: 20px;" src="https://static.vecteezy.com/system/resources/previews/012/871/371/original/google-search-icon-google-product-illustration-free-png.png" alt=""></button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
        </div>
        </div>
    </section>

    <section class="overflow-hidden">
        <div class="container">
            <div class="row">
        <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
            <!-- SVG shape START -->
            <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
            <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                <g>
                <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                </g>
            </svg>
            </figure>
            <!-- SVG shape START -->
            <!-- Content -->
            <h1 class="display-1 text-primary">کاوش</h1>
            <h2>مشاهده نتایج جستجو</h2>
            <p>تلاش کنید بهترین واژه ها را برای جستجو به کار ببرید ما ما از الگو های موتور های جستجو پشتیبانی میکنیم</p>
            <a href="index.php" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>برگشت به صفحه اصلی</a>
        </div>
        </div>
        </div>
    </section>
    <?php
}else{


    ?>
    <section class="pt-4">
        <div class="container">
            <div class="row">
        <div class="col-lg-9 mx-auto text-center py-5">
            <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موتور جستجو پیپرلاین</font></font></span>
            <h2 class="display-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img class="navbar-brand-item light-mode-item" style="width: 180px; height: 70px;" src="assets/images/logo.png" alt="لوگو"></font></font></h2>
            <span class="lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $_GET['search']?></font></font></span>
            <!-- Search -->
            <div class="row">
                <div class="col-sm-8 col-md-6 col-lg-12 mx-auto">
                <form class="input-group mt-4" action="" method="GET">
                    <div class="input-group">
                        <input type="text" value="search" name="content" style="display: none;">
                        <input type="text" class="form-control" name="search" placeholder="در اینجا جستجو کنید" aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                            </svg></button>
                            <button class="btn btn-outline-secondary" type="button"><img style="width: 20px; height: 20px;" src="https://static.vecteezy.com/system/resources/previews/012/871/371/original/google-search-icon-google-product-illustration-free-png.png" alt=""></button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
                    <div class="col-sm-8 col-md-6 col-lg-12 mx-auto">
						<a class="btn btn-primary-soft" href="index.php?content=search&search=<?php echo $_GET['search']?>"><i class="bi bi-life-preserver"></i> همه</a>
						<a class="btn btn-dark-soft" href="index.php?content=search&search=<?php echo $_GET['search']?>&page=1"><i class="bi bi-bullseye"></i> حساب ها</a>
						<a class="btn btn-success-soft" href="index.php?content=search&search=<?php echo $_GET['search']?>&page=2"><i class="bi bi-airplane-engines"></i> عرضه ها</a>
						<a class="btn btn-danger-soft" href="index.php?content=search&search=<?php echo $_GET['search']?>&page=3"><i class="bi bi-briefcase"></i> پیپرها</a>

						<br>

															

																		

																		

																		

																		

																		

																		

																		

																		

																		

									
					</div>
        </div>
        </div>
        </div>
    </section>

    <?php
    if(strlen($_GET['search'])<4){
        ?>
        <section class="overflow-hidden">
            <div class="container">
                <div class="row">
            <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                <!-- SVG shape START -->
                <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                    <g>
                    <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                    <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                    <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                    <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                    <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                    <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                    <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                    <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                    <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                    <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                    </g>
                </svg>
                </figure>
                <!-- SVG shape START -->
                <!-- Content -->
                <h1 class="display-1 text-primary">نتیجه</h1>
                <h2>خطا در جستجو شما</h2>
                <p>تلاش کنید تعداد کاراکتر های بیشتر به ما بدهید و کلمات معنی دار را جستجو کنید</p>
                <a href="index.php?content=search" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>بازگشت</a>
            </div>
            </div>
            </div>
        </section>
        <?php
        
    }else{
        $value = $_GET['search'];
        $value = str_replace(" ", "%", $value);
        $value_replace  = str_replace(" ", "%", $value);
        $value_hash = explode("%", $value_replace);


        $url = mysqli_fetch_assoc(mysqli_query($con, 'SELECT * FROM `user` WHERE (`iduser` LIKE "%'.$value.'%" or `username` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `about` LIKE "%'.$value.'%" or `instagram` LIKE "%'.$value.'%" or `email` LIKE "%'.$value.'%") order by RAND() Desc limit 0,100'));
        $url_for_while = mysqli_query($con, 'SELECT * FROM `user` WHERE (`iduser` LIKE "%'.$value.'%" or `username` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `about` LIKE "%'.$value.'%" or `instagram` LIKE "%'.$value.'%" or `email` LIKE "%'.$value.'%") order by RAND() Desc limit 0,100');
        

        
        $blog = mysqli_fetch_assoc(mysqli_query($con, 'SELECT * FROM `blogs` WHERE (`idBlog` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `descrip` LIKE "%'.$value.'%" or `blog` LIKE "%'.$value.'%" or `label` LIKE "%'.$value.'%" or `userId` LIKE "%'.$value.'%" or `categoryId` LIKE "%'.$value.'%") order by RAND() Desc limit 0,500'));
        $blog_for_while = mysqli_query($con, 'SELECT * FROM `blogs` WHERE (`idBlog` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `descrip` LIKE "%'.$value.'%" or `blog` LIKE "%'.$value.'%" or `label` LIKE "%'.$value.'%" or `userId` LIKE "%'.$value.'%" or `categoryId` LIKE "%'.$value.'%") order by RAND() Desc limit 0,500');
        

        $post = mysqli_fetch_assoc(mysqli_query($con, 'SELECT * FROM `posts` WHERE (`idUser` LIKE "%'.$value.'%" or `idPost` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `doc` LIKE "%'.$value.'%" or `draft` LIKE "%'.$value.'%" or `tag` LIKE "%'.$value.'%" or `category` LIKE "%'.$value.'%") order by RAND() Desc limit 0,2000'));
        $post_for_while = mysqli_query($con, 'SELECT * FROM `posts` WHERE (`idUser` LIKE "%'.$value.'%" or `idPost` LIKE "%'.$value.'%" or `title` LIKE "%'.$value.'%" or `doc` LIKE "%'.$value.'%" or `draft` LIKE "%'.$value.'%" or `tag` LIKE "%'.$value.'%" or `category` LIKE "%'.$value.'%") order by RAND() Desc limit 0,2000');
        

        if(isset($_GET['page'])){
            if($_GET['page'] == '1'){
                $math = 0; 
                if(! $url){
                    $math = 1;
                }
            }elseif($_GET['page'] == '2'){
                $math = 0; 
                if(! $post){
                    $math = 1;
                }
            }elseif($_GET['page'] == '3'){
                $math = 0; 
                if(! $blog){
                    $math = 1;
                }
            }else{
                $math = 1;  
            }
            
        }else{
            if(! $url){
                $math = 0;
                if(! $post){
                    $math = 0;
                    if(! $blog){
                        $math = 1;
    
                    }
                }
            }
            if(! $post){
                $math = 0;
                if(! $url){
                    $math = 0;
                    if(! $blog){
                        $math = 1;
    
                    }
                }
            }
            if(! $blog){
                $math = 0;
                if(! $post){
                    $math = 0;
                    if(! $url){
                        $math = 1;
    
                    }
                }
            }
        }
        if($math == 1){
            ?>
            <section class="overflow-hidden">
                <div class="container">
                    <div class="row">
                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                    <!-- SVG shape START -->
                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                        <g>
                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                        </g>
                    </svg>
                    </figure>
                    <!-- SVG shape START -->
                    <!-- Content -->
                    <h1 class="display-1 text-primary">نتیجه</h1>
                    <h2>نتیجه ای یافت نشد</h2>
                    <p>لطفا کمی از تکنیک های جستجو استفاده کنید و یا از گوگل استفاده کنید</p>
                    <a href="index.php?content=search" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>بازگشت</a>
                </div>
                </div>
                </div>
            </section>
            <?php
        }else{
            ?>
            <section class="position-relative pt-0">
                <div class="container">
                    <div class="row">

                    
                    <title><?php echo $_GET['search']?> | piperline,Inc.</title>
                    <?php
                    if(isset($_GET['page'])){
                        if($_GET['page'] == '1'){
                           
                            while($res=mysqli_fetch_assoc($url_for_while)){
                                ?>
                                <!-- Main Post START -->
                                <div class="col-lg-9 mx-auto">
                                    <!-- Card item START -->
                                    <div class="card border rounded-3 up-hover p-4 mb-4">
                                        <div class="row g-3">
                                            <div class="col-sm-9">
                                        
                                                <!-- Avatar -->
                                                <div class=" me-0 me-md-4">
                                                    <div class="avatar avatar-xxl">
                                                    <img class="avatar-img rounded-circle" src="<?php echo $res['avatar']?>" alt="آواتار">
                                                    </div>
                                                    <!-- Post count -->
                                                   
                                                </div>
                                                            <!-- Info -->
                                                            <div>
                                                    <h2 class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['username']?></font>      <?php
                                                                            if($res['admin'] == 1){
                                                                                ?>
                                                                                <i class="bi bi-patch-check-fill text-info small"></i>
                                                                                <?php
                                                                            }
                                                                            ?></font></h2>
                         
                                                                <p class="my-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['about']?></p>
                                                                <!-- Social icons -->
                                                                <ul class="nav justify-content-center justify-content-md-start">
                                                                    <li class="nav-item">
                                                                        <a href="index.php?content=profile&amp;id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">
    
                                                                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">
    
                                                                        بازکردن با... 
                                                                        </a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a href="dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">
    
                                                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">
    
                                                                        پیام
                                                                        </a>
                                                                    </li>
                                                                
                                                                </ul>					
                                                            </div>
    
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Card item END -->
                    
                
             
                                </div>
                                <!-- Main Post END -->
                                <?php
                            }

                        }elseif($_GET['page'] == '2'){
                          
                            while($res=mysqli_fetch_assoc($post_for_while)){
                                $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                mysqli_query($con, "
                                UPDATE posts
                                SET
                                  `saged` = `saged`+10,
                                  `sagedAd` = `sagedAd`+7,
                                  `sagedSearch` = `sagedSearch`+1
                                WHERE
                                  idPost = ".$res['idPost'].";
                                ");
                                ?>
                                <!-- Main Post START -->
                                <div class="col-lg-9 mx-auto">
                                    <!-- Card item START -->
                                    <div class="card border rounded-3 up-hover p-4 mb-4">
                                        <div class="row g-3">
                                            <div class="col-sm-9">
                                                <!-- Categories -->
                                                <?php 
                                                        $test_array = explode(" ", $res['tag']);
    
    
                                                        foreach( $test_array as $name ){
                                                
                                                            ?>
                                                            <a href="index.php?content=tags&tag=<?PHP echo $name?>" class="badge text-bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?PHP echo $name?></font></font></a>
    
                                                            <?PHP
                                                            
                                                        } 
                                                ?>
                                                <!-- Title -->
                                                <h3 class="card-title">
                                                    <a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></a>
                                                </h3>
                                                <!-- Card info -->
                                                <ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
                                                    <li class="nav-item">
                                                        <div class="nav-link">
                                                            <div class="d-flex align-items-center position-relative">
                                                                <div class="avatar avatar-xs">
                                                                    <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="آواتار">
                                                                </div>
                                                                <span class="ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط </font></font><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['username']?></font>      <?php
                                                                            if($us['admin'] == 1){
                                                                                ?>
                                                                                <i class="bi bi-patch-check-fill text-info small"></i>
                                                                                <?php
                                                                            }
                                                                            ?></font></a></span>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="nav-item"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه <?php echo $res['idPost']?></font></font></li>
                                                    <a href="index.php?content=profile&amp;id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">
    
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-link-45deg" viewBox="0 0 16 16">
                                                        <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z"/>
                                                        <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z"/>
                                                        </svg>
                                                    بازکردن با... 
                                                    </a>
                                                </ul>
                                            </div>
                                            <!-- Image -->
                                            <div class="col-sm-3">
                                                <img class="rounded-3" src="<?php echo $res['art']?>" alt="تصویر کارت">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Card item END -->
                                    <!-- Card item START -->
                        
                                </div>
                                <!-- Main Post END -->
                                <?php
                            }

                        }elseif($_GET['page'] == '3'){
                            while($res=mysqli_fetch_assoc($blog_for_while)){
                                $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                $some_time = strtotime($res['createDate']);
                                
                                ?>
                                <br>
                                <div class="card" id="display<?php echo $res['idBlog']?>">
                                    <div class="card-body" style="border: dashed black 2px; border-radius: 5px;  outline: #999 solid 1px;" >
                                    <small><?php echo date('Y, d F', $some_time)?></small>
                                    <h5 class="card-title"><?php echo $res['title']?></h5>
                                    <?php
                                    if(strlen($res['descrip']) > 5){
                                        ?>
                                        <p class="card-text"><?php echo $res['descrip']?></p>
                                        <?php
                                    }else{
    
                            
    
                                        $text = $res['blog'];
                                        ?>
                                        <p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
                                        <?php
                                    }
                                    ?>
    
                                        <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">
    
                                                                    <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
    
                                                                    بازکردن با ...
                                                                    </a>
                                    </div>
                                </div>
                                <br>
                                <?php
                            }
                            



                        }else{
                            
                            
                        }

                    }else{
                       
                        while($res=mysqli_fetch_assoc($url_for_while)){
                            ?>
                            <!-- Main Post START -->
                            <div class="col-lg-9 mx-auto">
                                <!-- Card item START -->
                                <div class="card border rounded-3 up-hover p-4 mb-4">
                                    <div class="row g-3">
                                        <div class="col-sm-9">
                                    
                                            <!-- Avatar -->
                                            <div class=" me-0 me-md-4">
                                                <div class="avatar avatar-xxl">
                                                <img class="avatar-img rounded-circle" src="<?php echo $res['avatar']?>" alt="آواتار">
                                                </div>
                                                <!-- Post count -->
                                               
                                            </div>
                                                        <!-- Info -->
                                                        <div>
                                                <h2 class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['username']?></font>      <?php
                                                                        if($res['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></font></h2>
                     
                                                            <p class="my-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['about']?></p>
                                                            <!-- Social icons -->
                                                            <ul class="nav justify-content-center justify-content-md-start">
                                                                <li class="nav-item">
                                                                    <a href="index.php?content=profile&amp;id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                                    بازکردن با... 
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                                    پیام
                                                                    </a>
                                                                </li>
                                                            
                                                            </ul>					
                                                        </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- Card item END -->
                
            
         
                            </div>
                            <!-- Main Post END -->
                            <?php
                        }
                        ?>
       


                        <?php
                        while($res=mysqli_fetch_assoc($post_for_while)){
                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                            mysqli_query($con, "
                            UPDATE posts
                            SET
                              `saged` = `saged`+10,
                              `sagedAd` = `sagedAd`+7,
                              `sagedSearch` = `sagedSearch`+1
                            WHERE
                              idPost = ".$res['idPost'].";
                            ");
                            ?>
                            <!-- Main Post START -->
                            <div class="col-lg-9 mx-auto">
                                <!-- Card item START -->
                                <div class="card border rounded-3 up-hover p-4 mb-4">
                                    <div class="row g-3">
                                        <div class="col-sm-9">
                                            <!-- Categories -->
                                            <?php 
                                                    $test_array = explode(" ", $res['tag']);


                                                    foreach( $test_array as $name ){
                                            
                                                        ?>
                                                        <a href="index.php?content=tags&tag=<?PHP echo $name?>" class="badge text-bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?PHP echo $name?></font></font></a>

                                                        <?PHP
                                                        
                                                    } 
                                            ?>
                                            <!-- Title -->
                                            <h3 class="card-title">
                                                <a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></a>
                                            </h3>
                                            <!-- Card info -->
                                            <ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
                                                <li class="nav-item">
                                                    <div class="nav-link">
                                                        <div class="d-flex align-items-center position-relative">
                                                            <div class="avatar avatar-xs">
                                                                <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="آواتار">
                                                            </div>
                                                            <span class="ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط </font></font><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['username']?></font>      <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></font></a></span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="nav-item"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه <?php echo $res['idPost']?></font></font></li>
                                                <a href="index.php?content=profile&amp;id=<?php echo $res['iduser']?>" class="btn btn-light btn-sm">

                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-link-45deg" viewBox="0 0 16 16">
                                                    <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z"/>
                                                    <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z"/>
                                                    </svg>
                                                بازکردن با... 
                                                </a>
                                            </ul>
                                        </div>
                                        <!-- Image -->
                                        <div class="col-sm-3">
                                            <img class="rounded-3" src="<?php echo $res['art']?>" alt="تصویر کارت">
                                        </div>
                                    </div>
                                </div>
                                <!-- Card item END -->
                                <!-- Card item START -->
                    
                            </div>
                            <!-- Main Post END -->
                            <?php
                        }
                        ?>


                        <?php
                        while($res=mysqli_fetch_assoc($blog_for_while)){
                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                            $some_time = strtotime($res['createDate']);
                            
                            ?>
                            <br>
                            <div class="card" id="display<?php echo $res['idBlog']?>">
                                <div class="card-body" style="border: dashed black 2px; border-radius: 5px;  outline: #999 solid 1px;" >
                                <small><?php echo date('Y, d F', $some_time)?></small>
                                <h5 class="card-title"><?php echo $res['title']?></h5>
                                <?php
                                if(strlen($res['descrip']) > 5){
                                    ?>
                                    <p class="card-text"><?php echo $res['descrip']?></p>
                                    <?php
                                }else{

                        

                                    $text = $res['blog'];
                                    ?>
                                    <p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
                                    <?php
                                }
                                ?>

                                    <a href="index.php?content=homeACC&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">

                                                                <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">

                                                                بازکردن با ...
                                                                </a>
                                </div>
                            </div>
                            <br>
                            <?php
                        }
                        
                    }
                    
                    ?>


    

                        <!-- Load more -->
                        <button type="button" class="btn btn-primary-soft w-100"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بارگذاری پست بیشتر</font></font><i class="bi bi-arrow-down-circle ms-2 align-middle"></i></button>
        
                    </div> <!-- Row end -->
                </div>
            </section>
            <?php
        }

    }

}
?>