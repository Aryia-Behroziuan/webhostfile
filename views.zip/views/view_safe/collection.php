<?php
if(! isset($_GET['id'])){
    die();
}
$query_Collect1 = mysqli_query($con, 'select * from session where name="collect" and id='.$_GET['id'].'');
$collect1 = mysqli_fetch_assoc($query_Collect1);
if(! $collect1){
    die();
}
$query_Collect = mysqli_query($con, 'select * from posts where published=1 and status=1 and collect='.$collect1['id'].' order by date Desc limit 0,200');
$query_Collect_res = mysqli_query($con, 'select * from posts where published=1 and status=1 and collect='.$collect1['id'].' order by date Desc limit 0,200');
$collect = mysqli_fetch_assoc($query_Collect);
if(! $collect){
    die();
}
$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$collect1['userId'].'"'));
if(! $us){
    die();
}

?>
<title>کالکشن <?php echo $collect1['data']?> از <?php echo $us['username']?> در پیپرلاین</title>


    <section class="pt-4 pb-3">
		<div class="container">
			<div class="row">
		<div class="col-12">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active">کالکشن <?php echo $collect1['data']?></li>
						</ol>
					</nav>
                    <div class="d-flex align-items-center position-relative">
											<div class="avatar avatar-xs">
												<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
											</div>
											<span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>   <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></span>
										</div>
					<h1><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
                    <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
                    </svg> کالکشن "<?php echo $collect1['data']?>"</h1>
                    <small><?php echo $collect1['wiki']?></small>
		</div>
		</div>
		</div>
	</section>


<section class="p-0">
	<div class="container">
    <div class="row g-4">

    <?php
    while($res=mysqli_fetch_assoc($query_Collect_res)){
        $some_time = strtotime($res['date']);

        ?>

              <!-- Card item START -->
                <div class="col-sm-6 col-lg-4">
                    <div class="card card-overlay-bottom card-img-scale overflow-hidden">
                    <!-- Card featured -->
                                <span class="card-featured" title="Featured post"><i class="fas fa-star"></i></span>
                    <!-- Card Image -->
                    <img src="<?php echo $res['art']?>" alt="">
                    <!-- Card Image overlay -->
                    <div class="card-img-overlay d-flex flex-column p-3 p-md-4"> 
                        <div>
                        <!-- Card category -->
                        <a href="#" class="badge text-bg-warning"><i class="fas fa-circle me-2 small fw-bold"></i>Technology</a>
                        </div>
                        <div class="w-100 mt-auto">
                        
                        <!-- Card title -->
                        <h4 class="text-white"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link"><?php echo $res['title']?></a></h4>
                        <!-- Card info -->
                        <ul class="nav nav-divider text-white-force align-items-center small">
                            <li class="nav-item position-relative">
                            <div class="nav-link">توسط <a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>
                            </div>
                            </li>
                            <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
                        </ul>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- Card item END -->
        <?Php
    }
    ?>



      <!-- Card item START -->
      
      <!-- Card item END -->
    </div> <!-- Row END -->
	</div>
</section>