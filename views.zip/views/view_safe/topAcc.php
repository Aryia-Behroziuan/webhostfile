<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/account-confirm-2871196-2384396.png?f=avif" style="width: 50px;" alt=""> پیشنهاد شده</h1>
			</div>
		</div>


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between">
							<!-- Search bar -->
							<div class="col-md-8">
								<form class="rounded position-relative">
									<input class="form-control bg-transparent" type="search" placeholder="Search" aria-label="Search">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>
							<!-- Tab buttons -->
							<div class="col-md-3">
								<!-- Tabs START -->
								<ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
									<!-- Grid tab -->
									<li class="nav-item" role="presentation">
										<a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
											<i class="fas fa-fw fa-list-ul"></i>
										</a>
									</li>
									<!-- List tab -->
									<li class="nav-item" role="presentation">
										<a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
											<i class="fas fa-fw fa-th-large"></i>
										</a>
									</li>
								</ul>
								<!-- Tabs end -->
							</div>
						</div>
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						<!-- Tabs content START -->
						<div class="tab-content py-0 my-0">
                            <?php
                            $query_1212 = mysqli_query($con, 'select * from user where isActive="1" order by follower Desc limit 0,100');
                            $file_hash = mysqli_query($con, 'select * from user where isActive="1" order by follower Desc limit 0,100');
                            $file = mysqli_fetch_assoc($query_1212);
                            if($file){
                                ?>
                                    <!-- Tabs content item START -->
                                    <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                        <!-- Table START -->
                                        <div class="table-responsive border-0">
                                            <table class="table align-middle p-4 mb-0 table-hover">
                                      

                                                <!-- Table body START -->
                                                <tbody class="border-top-0">


                                                <?php
		
                                                while($res=mysqli_fetch_assoc($file_hash)){
														?>
														<!-- Table row -->
														<tr>
															<!-- Table data -->
															<td>
																<div class="d-flex align-items-center position-relative">
																	<!-- Image -->
																	<div class="avatar avatar-md">
																		<img src="<?php echo $res['avatar']?>" class="rounded-circle" alt="">
																	</div>
																	<div class="mb-0 ms-2">
																		<!-- Title -->
																		<h6 class="mb-0"><a href="index.php?content=profile&id=<?php echo $res['iduser']?>" class="stretched-link"><?php echo $res['username']?></a> 
                                                                        <?php
                                                                        if($res['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </h6>
																	
																	</div>
																</div>
									

															
															</td>


															<!-- Table data -->
															<td>						<?php

															$follow_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$res['iduser'].'"');
															$follow = mysqli_fetch_assoc($follow_hash);
															if($follow){
																?>
																<a id="follow<?php echo $res['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
																<?php
															}else{
																?>
																<a id="follow<?php echo $res['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
																<?php 
															}
															?>   



															<script>
																$('#follow<?php echo $res['iduser']?>').click(function(event){
																event.preventDefault();
																$('#follow<?php echo $res['iduser']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

																$.ajax({
																	method: "POST",
																	url: "../../index.php?controller=create&method=follow&id=<?php echo $res['iduser']?>",
																	data: { code: "1"}
																})
																	.done(function(data){
																	$('#follow<?php echo $res['iduser']?>').html(data);
																	})

																})
															</script></td>
															<!-- Table data -->
													
												
															<td>
																<div class="d-flex gap-2">
																	<a href="dashboard.php?content=profile&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
																	<i class="bi bi-link-45deg"></i>
																	</a>
																	<a href="https://www.spacify.ir/index.php?controller=user&method=profile&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
																	<i class="bi bi-send"></i>
																	</a>
																	<a href="../../blogzine.webestica.com/rtl/dashboard.php?content=sendMessage&id=<?php echo $res['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
																	<i class="bi bi-box-arrow-up-right"></i>
																	</a>
																</div>
															</td>
														</tr>
														<?php
												
                                                }
                                                
                                                ?>
                

                                    


                                                </tbody>
                                                <!-- Table body END -->
                                            </table>
                                        </div>
                                        <!-- Table END -->
                                    </div>
                                    <!-- Tabs content item END -->
                                <?php
                            }else{

                            }
                            ?>


							<!-- Tabs content item START -->
							<div class="tab-pane fade" id="nav-grid-tab" role="tabpanel">
								<div class="row g-4">

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Frances Guerrero</a></h5>
														<div class="small">Editor at Blogzine</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">5,354</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">846</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Carolyn Ortiz</a></h5>
														<div class="small">Editor at eduport</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">2,545</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">586</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/02.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Louis Ferguson</a></h5>
														<div class="small">Editor at folio</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">3,546</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">786</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/03.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Billy Vasquez</a></h5>
														<div class="small">Editor at Wizixo</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">6,586</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">1,235</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/04.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Samuel Bishop</a></h5>
														<div class="small">Editor at Realty</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">996</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">156</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/06.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Amanda Reed</a></h5>
														<div class="small">Editor at Blogzine</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">2,586</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">665</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/07.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Lori Stevens</a></h5>
														<div class="small">Editor at Eduport</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">1,586</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">458</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

									<!-- Card item START -->
									<div class="col-md-6 col-xl-4">
										<div class="card border p-2">
											<div class="card-body">
												<div class="d-flex align-items-center justify-content-between">
													<!-- avatar -->
													<div class="avatar avatar-lg me-3 flex-shrink-0">
														<img class="avatar-img rounded-circle" src="assets/images/avatar/12.jpg" alt="">
													</div>
													<!-- Connections holder -->
													<div class="flex-grow-1 d-block">
														<h5 class="mb-1"><a href="#">Jacqueline Miller</a></h5>
														<div class="small">Editor at Blogzine</div>
													</div>
												</div>

												<!-- Followers and Post -->
												<div class="d-sm-flex justify-content-sm-between mt-3">
													<!-- Followers -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-people-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">9,586</h5>
															<h6 class="mb-0 fw-light">Followers</h6>
														</div>
													</div>

													<!-- Total post -->
													<div class="d-flex text-start align-items-center mt-3">
														<div class="icon-md bg-light text-body rounded-circle flex-shrink-0">
															<i class="bi bi-file-earmark-text-fill fa-fw"></i>
														</div>
														<div class="ms-2">
															<h5 class="mb-0">2,586</h5>
															<h6 class="mb-0 fw-light">Total Blogs</h6>
														</div>
													</div>
												</div>

												<!-- Buttons -->
												<div class="d-sm-flex gap-2 mt-4">
													<a href="#" class="btn btn-primary-soft w-100">
														<i class="fab fa-facebook-messenger pe-2"></i> Message
													</a>
													<a href="#" class="btn btn-danger-soft w-100">
														<i class="fas fa-ban pe-2"></i> Block
													</a>
												</div>
											</div>
										</div>
									</div>
									<!-- Card item END -->

								</div> <!-- Row END -->
							</div>
							<!-- Tabs content item END -->

						</div>
						<!-- Tabs content END -->
					</div>
					<!-- Card body END -->

					<!-- Card Footer START -->
					<div class="card-footer p-3">
						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start">Showing 1 to 8 of 20 entries</p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="navigation">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true">Prev</a>
									</li>
									<li class="page-item"><a class="page-link" href="#">1</a></li>
									<li class="page-item active"><a class="page-link" href="#">2</a></li>
									<li class="page-item disabled"><a class="page-link" href="#">..</a></li>
									<li class="page-item"><a class="page-link" href="#">15</a></li>
									<li class="page-item">
										<a class="page-link" href="#">Next</a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
					<!-- Card Footer END -->
				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    </div>
	</div>
</section>