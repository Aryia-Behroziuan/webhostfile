<?php
if(! isset($_GET['tag'])){
	?>
	<section class="pt-4">
			<div class="container">
				<div class="row">
			<div class="col-lg-9 mx-auto text-center py-5">
				<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">داغ ترین های پیپرلاین</font></font></span>
				<h2 class="display-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img class="navbar-brand-item light-mode-item" style="width: 180px; height: 70px;" src="assets/images/logo.png" alt="لوگو"></font></font></h2>
				<span class="lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاوش را شروع کنید</font></font></span>
				<!-- Search -->
				<div class="row">
					<div class="col-sm-8 col-md-6 col-lg-12 mx-auto">
						<hr>
						<a class="btn btn-primary-soft" href="index.php?content=tags&tag=سبگ زندگی"><i class="bi bi-life-preserver"></i> سبک زندگی</a>
						<a class="btn btn-dark-soft" href="index.php?content=tags&tag=فناوری"><i class="bi bi-bullseye"></i> فناوری</a>
						<a class="btn btn-success-soft" href="index.php?content=tags&tag=مسافرت"><i class="bi bi-airplane-engines"></i> مسافرت</a>
						<a class="btn btn-danger-soft" href="index.php?content=tags&tag=کسبوکار"><i class="bi bi-briefcase"></i> کسبو کار</a>
						<a class="btn btn-warning-soft" href="index.php?content=tags&tag=ورزش"><i class="bi bi-bicycle"></i> ورزش</a>
						<a class="btn btn-info-soft" href="index.php?content=tags&tag=بازاریابی"><i class="bi bi-badge-vo"></i> بازاریابی</a>
						<br>

						<?php
						$query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,200');
						$file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,200');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$test_array = explode(" ", $res['tag']);


								foreach( $test_array as $name ){
						
									?>
									<a class="btn btn-outline-dark btn-xs" href="index.php?content=tags&tag=<?php echo $name?>"><?php echo $name?></a>

									<?PHP
									
								} 

							}
						}
						?>

					</div>
				</div>
			</div>
			</div>
			</div>
	</section>
	<?php
}else{
	?>
	<title><?php echo $_GET['tag']?> | piperline</title>
	<section class="pt-4 pb-3">
		<div class="container">
			<div class="row">
		<div class="col-12">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active"><?php echo $_GET['tag']?></li>
						</ol>
					</nav>
					<h1><?php echo $_GET['tag']?></h1>
		</div>
		</div>
		</div>
	</section>

	<section class="position-relative pt-0">
		<div class="container" data-sticky-container="">
			<div class="row">
				<div class="row">
					<div class="col-12">
						<div class="grid-menu" data-target=".filter-container">
							<a class="btn btn-primary-soft" href="index.php?content=tags&tag=سبگ زندگی"><i class="bi bi-life-preserver"></i> سبک زندگی</a>
							<a class="btn btn-dark-soft" href="index.php?content=tags&tag=فناوری"><i class="bi bi-bullseye"></i> فناوری</a>
							<a class="btn btn-success-soft" href="index.php?content=tags&tag=مسافرت"><i class="bi bi-airplane-engines"></i> مسافرت</a>
							<a class="btn btn-danger-soft" href="index.php?content=tags&tag=کسبوکار"><i class="bi bi-briefcase"></i> کسبو کار</a>
							<a class="btn btn-warning-soft" href="index.php?content=tags&tag=ورزش"><i class="bi bi-bicycle"></i> ورزش</a>
							<a class="btn btn-info-soft" href="index.php?content=tags&tag=بازاریابی"><i class="bi bi-badge-vo"></i> بازاریابی</a>
							

							<?php
							$query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,25');
							$file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,25');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$test_array = explode(" ", $res['tag']);


									foreach( $test_array as $name ){
							
										?>
										<a class="btn btn-outline-dark btn-xs" href="index.php?content=tags&tag=<?php echo $name?>"><?php echo $name?></a>

										<?PHP
										
									} 

								}
							}
							?>
						</div>
					</div>
				</div>
				<hr>
				<!-- Main Post START -->
				<div class="col-lg-9">
					<div class="row gy-4">
						<?php
						$query_1212 = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1');
						$file_hash = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
								mysqli_query($con, "
								UPDATE posts
								SET
								  `saged` = `saged`+5,
								  `sagedAd` = `sagedAd`+7,
								  `sagedTag` = `sagedTag`+2,
								  `explorer` = `explorer`+2
								WHERE
								  idPost = ".$res['idPost'].";
								");
								?>
														<?phP
												if($res['type'] == '1'){
													$type = 'پست';
												}elseif($res['type'] == '2'){
													$type = 'دوره اموزشی';
												}elseif($res['type'] == '3'){
													$type = 'فایل و منبع';
												}elseif($res['type'] =='4'){
													$type = 'ویدیو';
												}elseif($res['type'] == '5'){
													$type = 'سرویس یا خدمات';
												}else{
													$type = 'مشخض نیست';
												}
												
												?>

								<!-- Card item START -->
								<div class="col-12">
									<div class="card overflow-hidden">
										<!-- Card img -->
										<div class="position-relative">
											<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
									<!-- Card featured -->
									<span class="card-featured" title="Featured post"><i class="fas fa-star"></i></span>
											<div class="card-img-overlay d-flex align-items-start flex-column p-3">
												<!-- Card overlay bottom -->
												<div class="w-100 mt-auto">
													<!-- Card category -->
													<a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
												</div>
											</div>
										</div>
										<div class="card-body px-0 pt-3">
											<h2 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h2>
											<p class="card-text"><?php echo $res['doc']?></p>
											<!-- Card info -->
											<ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
												<li class="nav-item">
													<div class="nav-link">
														<div class="d-flex align-items-center position-relative">
															<div class="avatar avatar-xs">
																<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
															</div>
															<span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
														</div>
													</div>
												</li>
												<li class="nav-item">بازدید <?php echo $res['views']?></li>
											</ul>
										</div>
									</div>
								</div>
								<!-- Card item END -->

								<?php

							}
						}
						?>


						<?php
						$query_1212 = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1000');
						$file_hash = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1000');
						$file = mysqli_fetch_assoc($query_1212);
						if($file){
							while($res=mysqli_fetch_assoc($file_hash)){
								$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
								mysqli_query($con, "
								UPDATE posts
								SET
								  `saged` = `saged`+5,
								  `sagedAd` = `sagedAd`+7,
								  `sagedTag` = `sagedTag`+2,
								  `explorer` = `explorer`+2
								WHERE
								  idPost = ".$res['idPost'].";
								");
								?>
																<?phP
												if($res['type'] == '1'){
													$type = 'پست';
												}elseif($res['type'] == '2'){
													$type = 'دوره اموزشی';
												}elseif($res['type'] == '3'){
													$type = 'فایل و منبع';
												}elseif($res['type'] =='4'){
													$type = 'ویدیو';
												}elseif($res['type'] == '5'){
													$type = 'سرویس یا خدمات';
												}else{
													$type = 'مشخض نیست';
												}
												
												?>

								<!-- Card item START -->
								<div class="col-sm-6">
									<div class="card">
										<!-- Card img -->
										<div class="position-relative">
											<img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
											<div class="card-img-overlay d-flex align-items-start flex-column p-3">
												<!-- Card overlay Top -->
												<div class="w-100 mb-auto d-flex justify-content-end">
													<div class="text-end ms-auto">
														<!-- Card format icon -->
														<div class="icon-md bg-white bg-opacity-25 bg-blur text-white rounded-circle" title="This post has video"><i class="fas fa-video"></i></div>
													</div>
												</div>
												<!-- Card overlay bottom -->
												<div class="w-100 mt-auto">
													<!-- Card category -->
													<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $type?></a>
												</div>
											</div>
										</div>
										<div class="card-body px-0 pt-3">
											<h4 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res['title']?></a></h4>
											<p class="card-text"><?php echo $res['doc']?></p>
											<!-- Card info -->
											<ul class="nav nav-divider align-items-center d-none d-sm-inline-block">
												<li class="nav-item">
													<div class="nav-link">
														<div class="d-flex align-items-center position-relative">
															<div class="avatar avatar-xs">
																<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
															</div>
															<span class="ms-3"> <a href="index.php?content=open&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
														</div>
													</div>
												</li>
												<li class="nav-item"><?php echo $res['views']?> بازدید</li>
											</ul>
										</div>
									</div>
								</div>
								<!-- Card item END -->
								<?php
							}
							?>
						<div id="addNowCode"></div>
						<button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
						
												<script>
												
												var loadBox = 0;
												$('#loadMore').click(function(event){
												event.preventDefault();
												$('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
												var z = Math.random()*10;
												var code = '<div id="'+String(z)+'"></div>';
												document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



												$.ajax({
													method: "POST",
													url: "../../index.php?controller=home&method=loadTag&tag=<?php echo $_GET['tag']?>",
													data: { code: "1"}
												})
													.done(function(data){
													document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
													document.getElementById(z).innerHTML = data;
												
													})

												})
												</script>
							<?php
						}
						?>



						<!-- pagination START -->
						<nav class="mt-5" aria-label="navigation">
								<ul class="pagination d-flex justify-content-between">
								<li class="page-item flex-fill text-center">
									<a href="#" class="page-link"> <i class="fas fa-long-arrow-alt-left me-2 rtl-flip"></i> Older</a>
								</li>
								<li class="page-item flex-fill text-center">
									<a href="#" class="page-link">Newer <i class="fas fa-long-arrow-alt-right ms-2 rtl-flip"></i></a>
								</li>
								</ul>
						</nav>
						<!-- pagination END -->
					</div>
				</div>
				<!-- Main Post END -->

				<!-- Sidebar START -->
				<div class="col-lg-3 mt-5 mt-lg-0">
					<div data-sticky="" data-margin-top="80" data-sticky-for="767">
						<!-- Trending topics widget START -->
						<div>
							<h4 class="mb-3">برترین ها</h4>
							<!-- Category item -->
							<div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(assets/images/blog/4by3/01.jpg); background-position: center left; background-size: cover;">
								<div class="bg-dark-overlay-4 p-3">
									<a href="#" class="stretched-link btn-link fw-bold text-white h5">Travel</a>
								</div>
							</div>
							<!-- Category item -->
							<div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(assets/images/blog/4by3/02.jpg); background-position: center left; background-size: cover;">
								<div class="bg-dark-overlay-4 p-3">
									<a href="#" class="stretched-link btn-link fw-bold text-white h5">Business</a>
								</div>
							</div>
							<!-- Category item -->
							<div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(assets/images/blog/4by3/03.jpg); background-position: center left; background-size: cover;">
								<div class="bg-dark-overlay-4 p-3">
									<a href="#" class="stretched-link btn-link fw-bold text-white h5">Marketing</a>
								</div>
							</div>
							<!-- Category item -->
							<div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(assets/images/blog/4by3/04.jpg); background-position: center left; background-size: cover;">
								<div class="bg-dark-overlay-4 p-3">
									<a href="#" class="stretched-link btn-link fw-bold text-white h5">Photography</a>
								</div>
							</div>
							<!-- Category item -->
							<div class="text-center mb-3 card-bg-scale position-relative overflow-hidden rounded" style="background-image:url(assets/images/blog/4by3/05.jpg); background-position: center left; background-size: cover;">
								<div class="bg-dark-overlay-4 p-3">
									<a href="#" class="stretched-link btn-link fw-bold text-white h5">Sports</a>
								</div>
							</div>
							<!-- View All Category button -->
							<div class="text-center mt-3">
								<a href="#" class="fw-bold text-muted text-primary-hover"><u>View all categories</u></a>
							</div>
						</div>
						<!-- Trending topics widget END -->

						<div class="row">
							<!-- Recent post widget START -->
							<div class="col-12 col-sm-6 col-lg-12">
								<h4 class="mt-4 mb-3">پست های اخیر</h4>
								<?php
								$query_1212 = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1000');
								$file_hash = mysqli_query($con, 'select * from posts where published="1" and status="1" and (`category` LIKE "%'.$_GET['tag'].'%" or `tag` LIKE "%'.$_GET['tag'].'%") order by  RAND(),date Desc limit 0,1000');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
										$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
										mysqli_query($con, "
										UPDATE posts
										SET
										  `saged` = `saged`+5,
										  `sagedAd` = `sagedAd`+7,
										  `sagedTag` = `sagedTag`+2,
										  `explorer` = `explorer`+2
										WHERE
										  idPost = ".$res['idPost'].";
										");
										?>
								
										<!-- Recent post item -->
										<div class="card mb-3">
											<div class="row g-3">
												<div class="col-4">
													<img class="rounded" src="<?php echo $res['art']?>" alt="">
												</div>
												<div class="col-8">
													<h6><a href="index.php?content= open&id=<?php echo $res['idPost']?>" class="btn-link stretched-link text-reset fw-bold"><?php echo $res['title']?></a></h6>
													<div class="small mt-1"><?php echo $res['views']?> بازدید </div>
												</div>
											</div>
										</div>
										
										<?php

									}
								}
								?>


							</div>
							<!-- Recent post widget END -->

							<!-- ADV widget START -->
							<div class="col-12 col-sm-6 col-lg-12 my-4">
								<a href="#" class="d-block card-img-flash">
									<img src="assets/images/adv.png" alt="">
								</a>
								<div class="smaller text-end mt-2">ads via <a href="#" class="text-muted"><u>Bootstrap</u></a></div>
							</div>
							<!-- ADV widget END -->
						</div>
					</div>
				</div>
				<!-- Sidebar END -->
			</div> <!-- Row end -->
		</div>
	</section>
	<?php
}

?>
