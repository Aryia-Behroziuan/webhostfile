
<?php 
if(isset($_GET['id'])){
    $query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and status=1 and published=1');
	$post = mysqli_fetch_assoc($query);
    if(! $post){
        $query1 = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and idUser="'.$_SESSION['id'].'"');
        $post = mysqli_fetch_assoc($query1);
        if(! $post){
            if(isset($_SESSION['id'])){
                $query11 = mysqli_query($con, 'select * from user where iduser="'.$_SESSION['id'].'" and piperAdmin=1');
                $user = mysqli_fetch_assoc($query11);
                if($user){
                    $query1 = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
                    $post = mysqli_fetch_assoc($query1);
                    if($post){

                    }else{
                        die();
                    }
                }
            }else{
                echo "<script type='text/javascript'>window.location.href='index.php?content=404'</script>";

            }

        }
    }

    $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$post['idUser'].'"'));
    if(! $us){
        echo "<script type='text/javascript'>window.location.href='index.php?content=404'</script>";
    }


    $date = date('Y-m-d');
    $timeEnd = $post['AdStop'];

    if(! $post['ads'] == 0){
        if($timeEnd < $date){
            mysqli_query($con, "
            UPDATE posts
            SET
              `ads` = 0
            WHERE
              idPost = ".$post['idPost'].";
            ");
            $date = date('Y-m-d H:i:s');
    
            $title = 'مدت زمان اشتراک سرویس شتابدهنده بر روی مخزن '.$post['title'].' تمام شد';
            $doc='';
            mysqli_query($con, 'INSERT INTO `comment`(`userId`, `notifi`, `title`, `comment`, `link`, `time`) VALUES ('.$us['iduser'].', 1, "'.$title.'", "'.$doc.'" ,  "dashboard.php?content=openFile&id='.$_GET['id'].'" , "'.$date.'")');
      
        }
    }
    ?>
    <title><?php echo $post['title']?> - <?php echo $us['username']?> | piperline,Inc.</title>
    <?php
    $some_time = strtotime($post['date']);
    if(isset($_POST['comment'])){
        mysqli_query($con, 'INSERT INTO `comment`(`comment`, `creatorId`, `userId`, `piperlinePost`, `time`) VALUES ("'.$_POST['comment'].'","'.$_SESSION['id'].'", "'.$us['iduser'].'", '.$_GET['id'].' , "'.date('Y-m-d H:i:s').'")');
        mysqli_query($con, "
        UPDATE posts
        SET
          comments = comments+1
    
        WHERE
          idPost = '".$_GET['id']."';
        ");
        echo "<script type='text/javascript'>window.location.href='index.php?content=open&id=".$_GET['id']."'</script>";
    }
}else{
    die();
}

?>

<?php
if($_SESSION['id']){
    $query2 = mysqli_query($con, 'select * from session where name="order" and userId="'.$_SESSION['id'].'" and piperline='.$_GET['id'].'');
    $clud = mysqli_fetch_assoc($query2);
    if($clud){
        if($post['type'] == 5){
            ?>
                <section class="py-4">
                    <div class="container">
                    
                        <div class="row g-4">
                            
    
                            
    
                            
                    
                            
    
                            
    
                            
                            
    
                            
                            
                            <div class="col-12">
                                <!-- Blog list table START -->
                                <div class="card border bg-transparent rounded-3">
                                    <!-- Card header START -->
                                    <div class="card-header bg-transparent border-bottom p-3">
                                        <div class="d-sm-flex justify-content-sm-between align-items-center">
                                            <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-alipay" viewBox="0 0 16 16">
                                            <path d="M2.541 0H13.5a2.551 2.551 0 0 1 2.54 2.563v8.297c-.006 0-.531-.046-2.978-.813-.412-.14-.916-.327-1.479-.536-.303-.113-.624-.232-.957-.353a12.98 12.98 0 0 0 1.325-3.373H8.822V4.649h3.831v-.634h-3.83V2.121H7.26c-.274 0-.274.273-.274.273v1.621H3.11v.634h3.875v1.136h-3.2v.634H9.99c-.227.789-.532 1.53-.894 2.202-2.013-.67-4.161-1.212-5.51-.878-.864.214-1.42.597-1.746.998-1.499 1.84-.424 4.633 2.741 4.633 1.872 0 3.675-1.053 5.072-2.787 2.08 1.008 6.37 2.738 6.387 2.745v.105A2.551 2.551 0 0 1 13.5 16H2.541A2.552 2.552 0 0 1 0 13.437V2.563A2.552 2.552 0 0 1 2.541 0Z"/>
                                            <path d="M2.309 9.27c-1.22 1.073-.49 3.034 1.978 3.034 1.434 0 2.868-.925 3.994-2.406-1.602-.789-2.959-1.353-4.425-1.207-.397.04-1.14.217-1.547.58Z"/>
                                            </svg> <?php echo $post['button']?></font></font>                        
                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                اشتراک گذاری
                                </a>
                            </h5>
                                            <form action="" method="POST" class="row g-3 mt-2">
                                            <?php
                                            if($post['pay'] == 0){
                                                $pay = 'رایگان';
                                            }else{
                                                $pay = number_format($post['pay'] , 0 , "." , "," ).' تومان';
                                            }
                                            ?>
                                            <a href="index.php?content=by&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $pay?></font></a>
                                        </form></div>
                                    </div>
                                    <!-- Card header END -->
    
                                        <!-- Card body START -->
                                        <div class="card-body p-3">
                                        <style>
                                        .scroll-example {
                                            overflow: auto;
                                            scrollbar-width: none; /* Firefox */
                                            -ms-overflow-style: none; /* IE 10+ */
                                        }
    
                                        .scroll-example::-webkit-scrollbar {
                                            width: 0px;
                                            background: transparent; /* Chrome/Safari/Webkit */
                                        }
                                        </style>
                                            <div class="card-body p-0">
                                            <?php
                                        if(strlen($post['loc']) >= 2){
                                            if($post['interLoc'] == 0){
                                                ?>
                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> بهتر است که برای تجربه خرید بهتر از این مخزن در ایالات "<?php echo $post['loc']?>" باشید البته سخت گیری در این باره وجود ندارد اما ممکن است لازم باشد برای پشتیبانی بهتر در این محدوده باشید
                                                </div>
    
    
                                                <?php
                                            }else{
                                                ?>

                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> برای استفاده از این مخزن محدودیت مکانی وضع شده است برای استفاده از این مخزن شما حتما باید تحت پوشش ایالات "<?php echo $post['loc']?>" باشید در غیر این صورت نمیتوانید از این مخزن استفاده کنید
                                                </div>


                                                <?php
                                                if($post['loc'] == $user['loc']){
                                                    ?>
                                                    <div class="alert alert-success" role="alert">
                                                    <i class="bi bi-check-circle"></i> شما از سیاستنامه ایالاتی این مخزن پیروی میکنید و شامل حال دریافت و خرید آن هستید  
                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <i class="bi bi-info-circle-fill"></i>متاسفیم شما از سیاست های ایالاتی این مخزن پیروی نمیکنید آیا میخواهید موقعیت خود را تغییر دهید <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                    <?php
                                                }
                                            }
               
                                        }
                                        ?>
                                           
                    
                                            <div class="alert alert-primary" role="alert">
                                                <i class="bi bi-exclamation-circle"></i>
                                                قبلا هم از این سرویس استفاده کرده اید اگر راضی بودید میتوانید باز هم از این سرویس استفاده کنید
                                                <a href="dashboard.php?content=cloud"><i class="bi bi-box-arrow-up-right"></i></a>
                                            </div>
                                                
    
    
    
                                            </div>
                                       
                                            <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
                        
                                    </div>
                                </div>
                                <!-- Blog list table END -->
                            </div>
                        </div>
                    </div>
                </section>
            <?php
        }
    }else{
        if($post['byNumber'] == 0){
            ?>
                
                <section class="py-4">
                    <div class="container">
                    
                        <div class="row g-4">
                            
    
                            
    
                            
                    
                            
    
                            
    
                            
                            
    
                            
                            
                            <div class="col-12">
                                <!-- Blog list table START -->
                                <div class="card border bg-transparent rounded-3">
                                    <!-- Card header START -->
                                    <div class="card-header bg-transparent border-bottom p-3">
                                        <div class="d-sm-flex justify-content-sm-between align-items-center">
                                            <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-alipay" viewBox="0 0 16 16">
                                            <path d="M2.541 0H13.5a2.551 2.551 0 0 1 2.54 2.563v8.297c-.006 0-.531-.046-2.978-.813-.412-.14-.916-.327-1.479-.536-.303-.113-.624-.232-.957-.353a12.98 12.98 0 0 0 1.325-3.373H8.822V4.649h3.831v-.634h-3.83V2.121H7.26c-.274 0-.274.273-.274.273v1.621H3.11v.634h3.875v1.136h-3.2v.634H9.99c-.227.789-.532 1.53-.894 2.202-2.013-.67-4.161-1.212-5.51-.878-.864.214-1.42.597-1.746.998-1.499 1.84-.424 4.633 2.741 4.633 1.872 0 3.675-1.053 5.072-2.787 2.08 1.008 6.37 2.738 6.387 2.745v.105A2.551 2.551 0 0 1 13.5 16H2.541A2.552 2.552 0 0 1 0 13.437V2.563A2.552 2.552 0 0 1 2.541 0Z"/>
                                            <path d="M2.309 9.27c-1.22 1.073-.49 3.034 1.978 3.034 1.434 0 2.868-.925 3.994-2.406-1.602-.789-2.959-1.353-4.425-1.207-.397.04-1.14.217-1.547.58Z"/>
                                            </svg> <?php echo $post['button']?></font></font>      <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                            اشتراک گذاری
                                            </a></h5>
                                            <form action="" method="POST" class="row g-3 mt-2">
                                            <?php
                                            if($post['pay'] == 0){
                                                $pay = 'رایگان';
                                            }else{
                                                $pay = number_format($post['pay'] , 0 , "." , "," ).' تومان';
                                            }
                                            ?>
                                            <a href="index.php?content=by&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $pay?></font></a>
                                        </form></div>
                                    </div>
                                    <!-- Card header END -->
    
                                        <!-- Card body START -->
                                        <div class="card-body p-3">
                                        <style>
                                        .scroll-example {
                                            overflow: auto;
                                            scrollbar-width: none; /* Firefox */
                                            -ms-overflow-style: none; /* IE 10+ */
                                        }
    
                                        .scroll-example::-webkit-scrollbar {
                                            width: 0px;
                                            background: transparent; /* Chrome/Safari/Webkit */
                                        }
                                        </style>
                                            <div class="card-body p-0">
    
                    
                                            <?php
                                        if(strlen($post['loc']) >= 2){
                                            if($post['interLoc'] == 0){
                                                ?>
                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> بهتر است که برای تجربه خرید بهتر از این مخزن در ایالات "<?php echo $post['loc']?>" باشید البته سخت گیری در این باره وجود ندارد اما ممکن است لازم باشد برای پشتیبانی بهتر در این محدوده باشید
                                                </div>
    
    
                                                <?php
                                            }else{
                                                ?>

                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> برای استفاده از این مخزن محدودیت مکانی وضع شده است برای استفاده از این مخزن شما حتما باید تحت پوشش ایالات "<?php echo $post['loc']?>" باشید در غیر این صورت نمیتوانید از این مخزن استفاده کنید
                                                </div>


                                                <?php
                                                if($post['loc'] == $user['loc']){
                                                    ?>
                                                    <div class="alert alert-success" role="alert">
                                                    <i class="bi bi-check-circle"></i> شما از سیاستنامه ایالاتی این مخزن پیروی میکنید و شامل حال دریافت و خرید آن هستید  
                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <i class="bi bi-info-circle-fill"></i>متاسفیم شما از سیاست های ایالاتی این مخزن پیروی نمیکنید آیا میخواهید موقعیت خود را تغییر دهید <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                    <?php
                                                }
                                            }
               
                                        }
                                        ?>
                                           
                                                
    
    
    
                                            </div>
                                       
                                            <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
                        
                                    </div>
                                </div>
                                <!-- Blog list table END -->
                            </div>
                        </div>
                    </div>
                </section>
            <?php
        }else{
            if($post['byNumber'] > $post['by']){
                ?>
                <section class="py-4">
                    <div class="container">
                    
                        <div class="row g-4">
                            
    
                            
    
                            
                    
                            
    
                            
    
                            
                            
    
                            
                            
                            <div class="col-12">
                                <!-- Blog list table START -->
                                <div class="card border bg-transparent rounded-3">
                                    <!-- Card header START -->
                                    <div class="card-header bg-transparent border-bottom p-3">
                                        <div class="d-sm-flex justify-content-sm-between align-items-center">
                                            <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-alipay" viewBox="0 0 16 16">
                                            <path d="M2.541 0H13.5a2.551 2.551 0 0 1 2.54 2.563v8.297c-.006 0-.531-.046-2.978-.813-.412-.14-.916-.327-1.479-.536-.303-.113-.624-.232-.957-.353a12.98 12.98 0 0 0 1.325-3.373H8.822V4.649h3.831v-.634h-3.83V2.121H7.26c-.274 0-.274.273-.274.273v1.621H3.11v.634h3.875v1.136h-3.2v.634H9.99c-.227.789-.532 1.53-.894 2.202-2.013-.67-4.161-1.212-5.51-.878-.864.214-1.42.597-1.746.998-1.499 1.84-.424 4.633 2.741 4.633 1.872 0 3.675-1.053 5.072-2.787 2.08 1.008 6.37 2.738 6.387 2.745v.105A2.551 2.551 0 0 1 13.5 16H2.541A2.552 2.552 0 0 1 0 13.437V2.563A2.552 2.552 0 0 1 2.541 0Z"/>
                                            <path d="M2.309 9.27c-1.22 1.073-.49 3.034 1.978 3.034 1.434 0 2.868-.925 3.994-2.406-1.602-.789-2.959-1.353-4.425-1.207-.397.04-1.14.217-1.547.58Z"/>
                                            </svg> <?php echo $post['button']?></font></font>      <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                            اشتراک گذاری
                                            </a></h5>
                                            <form action="" method="POST" class="row g-3 mt-2">
                                            <?php
                                            if($post['pay'] == 0){
                                                $pay = 'رایگان';
                                            }else{
                                                $pay = number_format($post['pay'] , 0 , "." , "," ).' تومان';
                                            }
                                            ?>
                                            <a href="index.php?content=by&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $pay?></font></a>
                                        </form></div>
                                    </div>
                                    <!-- Card header END -->
    
                                        <!-- Card body START -->
                                        <div class="card-body p-3">
                                        <style>
                                        .scroll-example {
                                            overflow: auto;
                                            scrollbar-width: none; /* Firefox */
                                            -ms-overflow-style: none; /* IE 10+ */
                                        }
    
                                        .scroll-example::-webkit-scrollbar {
                                            width: 0px;
                                            background: transparent; /* Chrome/Safari/Webkit */
                                        }
                                        </style>
                                            <div class="card-body p-0">
    
                    
                                            <?php
                                        if(strlen($post['loc']) >= 2){
                                            if($post['interLoc'] == 0){
                                                ?>
                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> بهتر است که برای تجربه خرید بهتر از این مخزن در ایالات "<?php echo $post['loc']?>" باشید البته سخت گیری در این باره وجود ندارد اما ممکن است لازم باشد برای پشتیبانی بهتر در این محدوده باشید
                                                </div>
    
    
                                                <?php
                                            }else{
                                                ?>

                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> برای استفاده از این مخزن محدودیت مکانی وضع شده است برای استفاده از این مخزن شما حتما باید تحت پوشش ایالات "<?php echo $post['loc']?>" باشید در غیر این صورت نمیتوانید از این مخزن استفاده کنید
                                                </div>


                                                <?php
                                                if($post['loc'] == $user['loc']){
                                                    ?>
                                                    <div class="alert alert-success" role="alert">
                                                    <i class="bi bi-check-circle"></i> شما از سیاستنامه ایالاتی این مخزن پیروی میکنید و شامل حال دریافت و خرید آن هستید  
                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <i class="bi bi-info-circle-fill"></i>متاسفیم شما از سیاست های ایالاتی این مخزن پیروی نمیکنید آیا میخواهید موقعیت خود را تغییر دهید <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                    <?php
                                                }
                                            }
               
                                        }
                                        ?>
                                           
                                                
    
    
    
                                            </div>
                                           
                                            <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
                        
                                    </div>
                                </div>
                                <!-- Blog list table END -->
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }
        }
    }
}else{
    if($post['byNumber'] == 0){
        ?>
            
            <section class="py-4">
                <div class="container">
                
                    <div class="row g-4">
                        

                        

                        
                
                        

                        

                        
                        

                        
                        
                        <div class="col-12">
                            <!-- Blog list table START -->
                            <div class="card border bg-transparent rounded-3">
                                <!-- Card header START -->
                                <div class="card-header bg-transparent border-bottom p-3">
                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                        <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-alipay" viewBox="0 0 16 16">
                                        <path d="M2.541 0H13.5a2.551 2.551 0 0 1 2.54 2.563v8.297c-.006 0-.531-.046-2.978-.813-.412-.14-.916-.327-1.479-.536-.303-.113-.624-.232-.957-.353a12.98 12.98 0 0 0 1.325-3.373H8.822V4.649h3.831v-.634h-3.83V2.121H7.26c-.274 0-.274.273-.274.273v1.621H3.11v.634h3.875v1.136h-3.2v.634H9.99c-.227.789-.532 1.53-.894 2.202-2.013-.67-4.161-1.212-5.51-.878-.864.214-1.42.597-1.746.998-1.499 1.84-.424 4.633 2.741 4.633 1.872 0 3.675-1.053 5.072-2.787 2.08 1.008 6.37 2.738 6.387 2.745v.105A2.551 2.551 0 0 1 13.5 16H2.541A2.552 2.552 0 0 1 0 13.437V2.563A2.552 2.552 0 0 1 2.541 0Z"/>
                                        <path d="M2.309 9.27c-1.22 1.073-.49 3.034 1.978 3.034 1.434 0 2.868-.925 3.994-2.406-1.602-.789-2.959-1.353-4.425-1.207-.397.04-1.14.217-1.547.58Z"/>
                                        </svg> <?php echo $post['button']?></font></font></h5>
                                        <form action="" method="POST" class="row g-3 mt-2">
                                        <?php
                                        if($post['pay'] == 0){
                                            $pay = 'رایگان';
                                        }else{
                                            $pay = number_format($post['pay'] , 0 , "." , "," ).' تومان';
                                        }
                                        ?>
                                        <a href="index.php?content=by&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $pay?></font></a>
                                    </form></div>
                                </div>
                                <!-- Card header END -->

                                    <!-- Card body START -->
                                    <div class="card-body p-3">
                                    <style>
                                    .scroll-example {
                                        overflow: auto;
                                        scrollbar-width: none; /* Firefox */
                                        -ms-overflow-style: none; /* IE 10+ */
                                    }

                                    .scroll-example::-webkit-scrollbar {
                                        width: 0px;
                                        background: transparent; /* Chrome/Safari/Webkit */
                                    }
                                    </style>
                                        <div class="card-body p-0">

                
                                        <?php
                                        if(strlen($post['loc']) >= 2){
                                            if($post['interLoc'] == 0){
                                                ?>
                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> بهتر است که برای تجربه خرید بهتر از این مخزن در ایالات "<?php echo $post['loc']?>" باشید البته سخت گیری در این باره وجود ندارد اما ممکن است لازم باشد برای پشتیبانی بهتر در این محدوده باشید
                                                </div>
    
    
                                                <?php
                                            }else{
                                                ?>

                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> برای استفاده از این مخزن محدودیت مکانی وضع شده است برای استفاده از این مخزن شما حتما باید تحت پوشش ایالات "<?php echo $post['loc']?>" باشید در غیر این صورت نمیتوانید از این مخزن استفاده کنید
                                                </div>


                                                <?php
                                                if($post['loc'] == $user['loc']){
                                                    ?>
                                                    <div class="alert alert-success" role="alert">
                                                    <i class="bi bi-check-circle"></i> شما از سیاستنامه ایالاتی این مخزن پیروی میکنید و شامل حال دریافت و خرید آن هستید  
                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <i class="bi bi-info-circle-fill"></i>متاسفیم شما از سیاست های ایالاتی این مخزن پیروی نمیکنید آیا میخواهید موقعیت خود را تغییر دهید <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                    <?php
                                                }
                                            }
               
                                        }
                                        ?>
                                            



                                        </div>
                                   
                                        <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
                    
                                </div>
                            </div>
                            <!-- Blog list table END -->
                        </div>
                    </div>
                </div>
            </section>
        <?php
    }else{
        if($post['byNumber'] > $post['by']){
            ?>
            <section class="py-4">
                <div class="container">
                
                    <div class="row g-4">
                        

                        

                        
                
                        

                        

                        
                        

                        
                        
                        <div class="col-12">
                            <!-- Blog list table START -->
                            <div class="card border bg-transparent rounded-3">
                                <!-- Card header START -->
                                <div class="card-header bg-transparent border-bottom p-3">
                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                        <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-alipay" viewBox="0 0 16 16">
                                        <path d="M2.541 0H13.5a2.551 2.551 0 0 1 2.54 2.563v8.297c-.006 0-.531-.046-2.978-.813-.412-.14-.916-.327-1.479-.536-.303-.113-.624-.232-.957-.353a12.98 12.98 0 0 0 1.325-3.373H8.822V4.649h3.831v-.634h-3.83V2.121H7.26c-.274 0-.274.273-.274.273v1.621H3.11v.634h3.875v1.136h-3.2v.634H9.99c-.227.789-.532 1.53-.894 2.202-2.013-.67-4.161-1.212-5.51-.878-.864.214-1.42.597-1.746.998-1.499 1.84-.424 4.633 2.741 4.633 1.872 0 3.675-1.053 5.072-2.787 2.08 1.008 6.37 2.738 6.387 2.745v.105A2.551 2.551 0 0 1 13.5 16H2.541A2.552 2.552 0 0 1 0 13.437V2.563A2.552 2.552 0 0 1 2.541 0Z"/>
                                        <path d="M2.309 9.27c-1.22 1.073-.49 3.034 1.978 3.034 1.434 0 2.868-.925 3.994-2.406-1.602-.789-2.959-1.353-4.425-1.207-.397.04-1.14.217-1.547.58Z"/>
                                        </svg> <?php echo $post['button']?></font></font></h5>
                                        <form action="" method="POST" class="row g-3 mt-2">
                                        <?php
                                        if($post['pay'] == 0){
                                            $pay = 'رایگان';
                                        }else{
                                            $pay = number_format($post['pay'] , 0 , "." , "," ).' تومان';
                                        }
                                        ?>
                                        <a href="index.php?content=by&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $pay?></font></a>
                                    </form></div>
                                </div>
                                <!-- Card header END -->

                                    <!-- Card body START -->
                                    <div class="card-body p-3">
                                    <style>
                                    .scroll-example {
                                        overflow: auto;
                                        scrollbar-width: none; /* Firefox */
                                        -ms-overflow-style: none; /* IE 10+ */
                                    }

                                    .scroll-example::-webkit-scrollbar {
                                        width: 0px;
                                        background: transparent; /* Chrome/Safari/Webkit */
                                    }
                                    </style>
                                        <div class="card-body p-0">

                                        <?php
                                        if(strlen($post['loc']) >= 2){
                                            if($post['interLoc'] == 0){
                                                ?>
                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> بهتر است که برای تجربه خرید بهتر از این مخزن در ایالات "<?php echo $post['loc']?>" باشید البته سخت گیری در این باره وجود ندارد اما ممکن است لازم باشد برای پشتیبانی بهتر در این محدوده باشید
                                                </div>
    
    
                                                <?php
                                            }else{
                                                ?>

                                                <div class="alert alert-light" role="alert">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-pin-map" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M3.1 11.2a.5.5 0 0 1 .4-.2H6a.5.5 0 0 1 0 1H3.75L1.5 15h13l-2.25-3H10a.5.5 0 0 1 0-1h2.5a.5.5 0 0 1 .4.2l3 4a.5.5 0 0 1-.4.8H.5a.5.5 0 0 1-.4-.8l3-4z"/>
                                                <path fill-rule="evenodd" d="M8 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999z"/>
                                                </svg> برای استفاده از این مخزن محدودیت مکانی وضع شده است برای استفاده از این مخزن شما حتما باید تحت پوشش ایالات "<?php echo $post['loc']?>" باشید در غیر این صورت نمیتوانید از این مخزن استفاده کنید
                                                </div>


                                                <?php
                                                if($post['loc'] == $user['loc']){
                                                    ?>
                                                    <div class="alert alert-success" role="alert">
                                                    <i class="bi bi-check-circle"></i> شما از سیاستنامه ایالاتی این مخزن پیروی میکنید و شامل حال دریافت و خرید آن هستید  
                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <i class="bi bi-info-circle-fill"></i>متاسفیم شما از سیاست های ایالاتی این مخزن پیروی نمیکنید آیا میخواهید موقعیت خود را تغییر دهید <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                    <?php
                                                }
                                            }
               
                                        }
                                        ?>
                                           
                                   
                                            



                                        </div>
                                       
                                        <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
                    
                                </div>
                            </div>
                            <!-- Blog list table END -->
                        </div>
                    </div>
                </div>
            </section>
            <?php
        }
    }
}

?>

<?php
if($post['idUser'] == $_SESSION['id']){
    ?>
    <section class="py-4">
        <div class="container">
        
            <div class="row g-4">
                

                

                
        
                

                

                
                

                
                
                <div class="col-12">
                    <!-- Blog list table START -->
                    <div class="card border bg-transparent rounded-3">
                        <!-- Card header START -->
                        <div class="card-header bg-transparent border-bottom p-3">
                            <div class="d-sm-flex justify-content-sm-between align-items-center">
                                <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 40px;" alt=""> مشاهده آمار</font></font></h5>
                                <form action="" method="POST" class="row g-3 mt-2">
                                <a href="dashboard.php?content=openFile&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به داشبرد پست بروید</font></font></a>
                            </form></div>
                        </div>
                        <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3">
                            <style>
                            .scroll-example {
                                overflow: auto;
                                scrollbar-width: none; /* Firefox */
                                -ms-overflow-style: none; /* IE 10+ */
                            }

                            .scroll-example::-webkit-scrollbar {
                                width: 0px;
                                background: transparent; /* Chrome/Safari/Webkit */
                            }
                            </style>
                                <div class="card-body p-0">

        
                                <div class="row g-4">
					
                                    <!-- Earning item -->
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card card-body bg-success bg-opacity-10 p-4 h-100">
                                            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درآمد
                                                </font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="After US royalty withholding tax" data-bs-original-title="" title="">
                                                    <i class="bi bi-info-circle-fill small"></i>
                                                </a>
                                            </h6>
                                            <h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['payed']?> تومان</font></font></h2>
                                            <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0.20٪</font></font><i class="bi bi-arrow-up"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">در مقابل ماه گذشته</font></font></p>
                                            <div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده بیانیه</font></font></a></div>
                                        </div>
                                    </div>

                                    <!-- Grid item -->
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card card-body bg-info bg-opacity-10 p-4 h-100">
                                            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازدیدکنندگان ماهانه</font></font></h6>
                                            <h2 class="fs-1 text-info"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?></font></font></h2>
                                            <p class="mb-2"><span class="text-danger me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">07</font></font><i class="bi bi-arrow-down"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">از ماه گذشته</font></font></p>
                                            <div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده تجزیه و تحلیل</font></font></a></div>
                                        </div>
                                    </div>

                                    <!-- Grid item -->
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card card-body bg-warning bg-opacity-15 p-4 h-100">
                                            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مشتریان شما</font></font></h6>
                                            <h2 class="fs-1 text-warning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['by']?></font></font></h2>
                                            <div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده پست ها</font></font></a></div>
                                        </div>
                                    </div>

                                    <!-- Grid item -->
                                    <div class="col-md-6 col-xl-3">
                                        <div class="card card-body bg-primary bg-opacity-10 p-4 h-100">
                                            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیروان</font></font></h6>
                                            <h2 class="fs-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['follower']?></font></font></h2>
                                            <p class="mb-2"><span class="text-success me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font><i class="bi bi-arrow-up"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">از ماه گذشته</font></font></p>
                                            <div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فالوورها را مدیریت کنید</font></font></a></div>
                                        </div>
                                    </div>

                                </div>
                                    



                                </div>
                                <hr>
                                <!-- Button -->
                                <small><i class="bi bi-info-circle"></i> این قسمت فقط برای شما نشان داده میشود</small>
               
                        </div>
                    </div>
                    <!-- Blog list table END -->
                </div>
            </div>
        </div>
    </section>
    <?php
}

?>
		<!-- Meta Tags -->
		<meta charset="utf-8">
        <meta name="description" content="<?php echo $post['doc']?>">
        <meta name="author" content="<?php echo $us['username']?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="author" content="Webestica.com">

		<!-- Favicon -->
		<link rel="shortcut icon" href="assets/images/favicon.ico">

		<!-- Google Font -->
		<link rel="preconnect" href="https://fonts.gstatic.com/">
		<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&amp;family=Rubik:wght@400;500;700&amp;display=swap" rel="stylesheet">

		<!-- Plugins CSS -->
		<link rel="stylesheet" type="text/css" href="assets/vendor/font-awesome/css/all.min.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap-icons/bootstrap-icons.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/tiny-slider/tiny-slider.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/plyr/plyr.css">

		<!-- Theme CSS -->
		<link id="style-switch" rel="stylesheet" type="text/css" href="assets/css/style-rtl.css">
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-XZ4W34ZJ0L"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());

			gtag('config', 'G-XZ4W34ZJ0L');
		</script>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
        <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
        </svg> گزارش</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?php 
      $order = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where name="report" and userId='.$_SESSION['id'].' and data='.$_GET['id'].''));
      if($order){
        ?>
        <div id="displayReport">
            <div class="modal-body">
                                                            <section class="overflow-hidden">
                                                                <div class="container">
                                                                    <div class="row">
                                                                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                                    <!-- SVG shape START -->
                                                                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                                        <g>
                                                                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                                        </g>
                                                                    </svg>
                                                                    </figure>
                                                                    <!-- SVG shape START -->
                                                                    <!-- Content -->
                                                                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                                                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درحال رسیدگی</font></font></h2>
                                                                    <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما یک گزارش در حال رسیدگی دارید که از این صفحه میتوانید آمار لحظه ای رسیدگی به آن را مشاهده کنید  در صورت رسیدگی در این صفحه منتطر پاسخ ما باشید</font></font></p>
                                                                    <button type="button" id="cancelRep" class="btn btn-danger btn-xs"><i class="bi bi-eyeglasses"></i> منصرف شدم</button>
                                                                    <script>
                                                                    $('#cancelRep').click(function(event){
                                                                    event.preventDefault();
                                            
                                                                    $('#cancelRep').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                                    
                                                                    $.ajax({
                                                                        method: "POST",
                                                                        url: "../../index.php?controller=message&method=sendRep&mode=delete&id=<?php echo $order['id']?>",
                                                                        data: { code: "1"}
                                                                    })
                                                                        .done(function(data){
                                                                        $('#displayReport').html(data);
                                                                        })

                                                                    })
                                                                    </script>
                                                                </div>
                                                                </div>
                                                                </div>
                                                            </section>
            </div>
        </div>
        <?php
      }else{
        ?>
        <div id="displayReport">
            <form action="" method="POST" id="sendReport">
            <div class="modal-body">
                     <div class="col-12">
                        <div class="mb-3">
                            <input type="text" name="postId" value="<?php echo $_GET['id']?>" style="display: none;">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیح کوتاه</font></font></label>
                            <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger-soft" data-bs-dismiss="modal">لغو</button>
                <button type="submit" class="btn btn-dark-soft" id="subReport">ارسال</button>
            </div>
            </form>

            <script>
                    $(document).ready(function(){
                        $("#sendReport").on("submit", function(event){
                            event.preventDefault();
                            $('#subReport').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                            var formValues= $('#sendReport').serialize();

                            $.post("../../index.php?controller=message&method=sendRep&mode=add", formValues, function(data){
                                // Display the returned data in browser
                                $('#subReport').html('ذخیره شد');
                                $('#displayReport').html(data);
                            });
                        });
                    });
            </script>


        </div>
        <?php
      }
      ?>

    </div>
  </div>
</div>






<?php
if(! isset($_SESSION['view'.$_GET['id'].''])){
    mysqli_query($con, "
    UPDATE posts
    SET
      views = views+1

    WHERE
      idPost = '".$_GET['id']."';
    ");
    $_SESSION['view'.$_GET['id'].''] = '.';
}
if($post['type'] == 1){
    

    ?>
    <section class="pb-3 pb-lg-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    
                    <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">

                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                    <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                    </svg>
                    گزارش
                    </a>
                    <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست</font></font></a>
                    <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['views']?> بازدید</a>
                    <a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $post['idPost']?></a>
                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['by']?> خرید</a>
                    <h1><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></h1>
                </div>
                <p class="lead"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></p>
                
            </div>
        </div>
    </section>

    <section class="pt-0">
        <div class="container position-relative" data-sticky-container="">
            <div class="row">
                <!-- Left sidebar START -->
                <div class="col-lg-2">
                    <div class="text-start text-lg-center mb-5" data-sticky="" data-margin-top="80" data-sticky-for="991" style="position: fixed; width: 156px; left: 981px; top: 80px;">
                        <!-- Author info -->
                        <div class="position-relative">
                            <div class="avatar avatar-xl">
                                <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="آواتار">
                            </div>
                            <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="h5 stretched-link mt-2 mb-0 d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $us['username']?></font>                      
                                                                        <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></a>
                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['about']?></font></font></p>
                            <ul class="nav justify-content-center justify-content-md-start">

                                                                <li class="nav-item">
                                                                    <a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                                    بازکردن با... 
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                                    پیام
                                                                    </a>
                                                                </li>
                                                            
                                                            </ul>
                        </div>
                        <?php

                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
                        $follow = mysqli_fetch_assoc($file_hash);
                        if($follow){
                            ?>
                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                            <?php
                        }else{
                            ?>
                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                            <?php 
                        }
                        ?>   

                        <script>
                            $('#follow').click(function(event){
                            event.preventDefault();
                            $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                            $.ajax({
                                method: "POST",
                                url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                                data: { code: "1"}
                            })
                                .done(function(data){
                                $('#follow').html(data);
                                })

                            })
                        </script>
                        <hr class="d-none d-lg-block">
                        <!-- Card info -->

                        <ul class="list-inline list-unstyled">
                            <li class="list-inline-item d-lg-block my-lg-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('Y, d F', $some_time)?></font></font></li>
                            <li class="list-inline-item d-lg-block my-lg-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('s', $some_time)?> دقیقه مطالعه</font></font></li>
                            <li class="list-inline-item d-lg-block my-lg-2"><a href="#" class="text-body"><i class="far fa-heart me-1"></i></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']-date('s', $some_time)-date('s', $some_time)?></font></font></li>
                            <li class="list-inline-item d-lg-block my-lg-2"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></li>
                        </ul>
                        <!-- Tags -->
                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>
                    </div>
                </div>
                <!-- Left sidebar END -->
                <!-- Main Content START -->
                <div class="col-lg-7 mb-5">
            
                    
                    <!-- Image -->
                    <figure class="figure mt-2">
                    <a href="<?php echo $post['art']?>" data-glightbox="" data-gallery="image-popup">
                    <img class="rounded" src="<?php echo $post['art']?>" alt="تصویر">
                </a>
                    <figcaption class="figure-caption text-center"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(تصویر از طریق: </font></font><a class="text-reset" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">pexels.com</font></font></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> )</font></font></figcaption>
                    </figure>

                    <p><?php echo $post['doc']?><font style="vertical-align: inherit;">
                                        <!-- Tags -->
                                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>
                    </font></p>

                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

           
                    
                    
                    <?php
                    if(strlen($post['video']) >= 5){
                        ?>
                        <video controls>
                        <source src="<?php echo $post['video']?>" type="video/mp4">
                        </video>
                   
                           
                        <?php
                    }elseif(strlen($post['video_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['video_code']?>
                        </div>
                        <?php
                    }
                    ?>


                    <?php
                    if(strlen($post['audio']) >= 5){
                        ?>
                        <br>
                        <h3>فایل صوتی</h3>
                        <audio controls>
                            <source src="<?php echo $post['audio']?>" type="audio/mpeg">
                        </audio>
                           
                        <?php
                    }elseif(strlen($post['audio_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['audio_code']?>
                        </div>
                        <?php
                    }
                    ?>

                    
                    <?php
                    if(strlen($post['draft']) >= 5){
                        ?>
                        <br>
                        <div>
                            <?php echo $post['draft']?>
                        </div>
                           
                        <?php
                    }elseif(strlen($post['draft_file']) >= 5){
                        ?>
                        <br>
                        <br>
                        <iframe src="<?php echo $post['draft_file']?>" style="border:none; width:100%; height:100vh;"></iframe>
                        <?php
                    }
                    ?>
                    
                    

                    <!-- blockquote -->
                    

                    

                    
                    
                    <!-- Light bg content -->
                    

                    <!-- twitter embed code -->
                    

                    
                    
                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

                    
                    

                    <div class="row g-0">

                    <?php
					$query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND() Desc limit 0,1');
					$file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND() Desc limit 0,1');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
                            ?>
                        

                            <div class="col-sm-6 bg-primary bg-opacity-10 p-4 position-relative border-end border-1 rounded-start">
                                <span><i class="bi bi-arrow-left me-3 rtl-flip"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست قبلی</font></font></span>
                                <h5 class="m-0"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link btn-link text-reset"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></a></h5>
                            </div>
                            <?php
                        }
                    }
                    ?>

                        
                    <?php
					$query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND() Desc limit 0,1');
					$file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `type` = 1 order by RAND() Desc limit 0,1');
					$file = mysqli_fetch_assoc($query_1212);
					if($file){
						while($res=mysqli_fetch_assoc($file_hash)){
                            ?>
                            <div class="col-sm-6 bg-primary bg-opacity-10 p-4 position-relative text-sm-end rounded-end">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست بعدی</font></font><i class="bi bi-arrow-right ms-3 rtl-flip"></i></span>
                                <h5 class="m-0"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="stretched-link btn-link text-reset"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></a></h5>
                            </div>

                            <?php
                        }
                    }
                    ?>

                    </div>

         



                    <section class="pt-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Title -->
                                    <div class="mb-4">
                                        <h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
                                        <p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
                                    </div>
                                    <div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
                                        <div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
                                            
                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                            
                                            ?>
                                            <!-- Card item START -->
                                            <div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
                                                <!-- Card img -->
                                                <div class="position-relative">
                                                    <img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
                                                    <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                        <!-- Card overlay Top -->
                                                        <div class="w-100 mb-auto d-flex justify-content-end">
                                                            <div class="text-end ms-auto">
                                                                <!-- Card format icon -->
                                                                <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
                                                            </div>
                                                        </div>
                                                        <!-- Card overlay bottom -->
                                                        <div class="w-100 mt-auto">
                                                            <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center">
                                                        <li class="nav-item">
                                                            <div class="nav-link">
                                                                <div class="d-flex align-items-center position-relative">
                                                                    <div class="avatar avatar-xs">
                                                                        <img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
                                                                    </div>
                                                                    <span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nav-item"><?php echo $res['views']?> بازدید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Card item END -->
                                            <?php


                                            }
                                        }
                                        ?>

                                            


                                            
                                        </div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>







                    <!-- Divider -->
                    <hr>

                    <!-- Author info START -->
                    <div class="d-flex py-4">
                        <!-- Avatar -->
                        <a href="#">
                            <div class="avatar avatar-xxl me-4">
                                <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="آواتار">
                            </div>
                        </a>
                        <!-- Info -->
                        <div>
                            <div class="d-sm-flex align-items-center justify-content-between">
                                <div>
                                    <h4 class="m-0"><a href="#" class="text-reset"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['username']?></font></font></a></h4>
                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['about']?></font></font></small>
                                </div>
                                <li class="nav-item">
                                                                    <a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                                    بازکردن با... 
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                                    پیام
                                                                    </a>
                                                                </li>
                                                            
                                                            </ul>
                            </div>
                            <!-- Social icons -->
                            <ul class="nav">
                                <li class="nav-item">
                                    <a class="nav-link ps-0 pe-2 fs-5" href="#"><i class="fab fa-facebook-square"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-twitter-square"></i></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-linkedin"></i></a>
                                </li>
                            </ul>					
                        </div>
                    </div>
                    <!-- Author info END -->

                    <!-- Divider -->
                    

                    <!-- Comments START -->
                    
                    <!-- Comments END -->
                    <!-- Reply START -->
                    
                    <!-- Reply END -->
                </div>
                <!-- Main Content END -->
                
                <!-- Right sidebar START -->
                <div class="col-lg-3">
                    <div data-sticky="" data-margin-top="80" data-sticky-for="991" style="position: fixed; width: 249px; left: 51px; top: 80px;">
                <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">این مقاله را به اشتراک بگذارید</font></font></h4>
                        <ul class="nav text-white-force">

                            <li class="nav-item">
                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                اشتراک گذاری
                                </a>
                            </li>
                            <br>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-facebook" href="#">
                                    <i class="fab fa-facebook-square align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-twitter" href="#">
                                    <i class="fab fa-twitter-square align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-linkedin" href="#">
                                    <i class="fab fa-linkedin align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-pinterest" href="#">
                                    <i class="fab fa-pinterest align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-primary" href="#">
                                    <i class="far fa-envelope align-middle"></i>
                                </a>
                            </li>
                        </ul>
                        <!-- Advertisement -->
                        <div class="mt-4">
                            <a href="#" class="d-block card-img-flash">
                                <img src="assets/images/adv.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Right sidebar END -->
            </div>
        </div>
    </section>

    <?php
}elseif($post['type'] == 2){
    ?>


    <section class="bg-dark-overlay-4" style="background-image:url(<?php echo $post['art']?>); background-position: center left; background-size: cover;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 py-md-5 my-lg-5">
                    
                    <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">

                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                    <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                    </svg>
                    گزارش
                    </a>
                    <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دوره آموزشی</font></font></a>
                    <a href="index.php?content=type&amp;open=2" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['views']?> بازدید</a>
                    <a href="index.php?content=type&amp;open=3" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $post['idPost']?></a>
                    <a href="index.php?content=type&amp;open=4" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['by']?> خرید</a>
                    <h1 class="text-white"><?php echo $post['title']?></h1>
            <p class="lead text-white"><?php echo $post['doc']?></p>
            <!-- Info -->
            <ul class="nav nav-divider text-white-force align-items-center">
            <li class="nav-item">
                <div class="nav-link">
                <div class="d-flex align-items-center text-white position-relative">
                    <div class="avatar avatar-sm">
                    <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                    </div>
                    <span class="ms-3">سازنده <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a></span>
                </div>
                </div>

            </li>
            <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
            <li class="nav-item">														<?php

            $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
            $follow = mysqli_fetch_assoc($file_hash);
            if($follow){
                ?>
                <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                <?php
            }else{
                ?>
                <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                <?php 
            }
            ?>   

            <script>
                $('#follow').click(function(event){
                event.preventDefault();
                $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                $.ajax({
                    method: "POST",
                    url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                    data: { code: "1"}
                })
                    .done(function(data){
                    $('#follow').html(data);
                    })

                })
            </script></li>
            <li class="nav-item"><?PHP ECHO date('s', $some_time)?> دقیقه مطالعه</li>
            <li class="nav-item"><i class="far fa-eye me-1"></i> <?php echo $post['views']?> بازدید</li>
            <li class="nav-item"><a href="#"><i class="fas fa-heart me-1 text-danger"></i></a> <?php echo $post['views']-date('s', $some_time)?></li>
            </ul>
            <!-- Share post -->
            <div class="d-md-flex align-items-center mt-4">
            <h5 class="text-white me-3">اشتراک گذاری: </h5>
                        <ul class="nav text-white-force">
                            <li class="nav-item">
                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                اشتراک گذاری
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-facebook" href="#">
                                    <i class="fab fa-facebook-square align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-twitter" href="#">
                                    <i class="fab fa-twitter-square align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-linkedin" href="#">
                                    <i class="fab fa-linkedin align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-pinterest" href="#">
                                    <i class="fab fa-pinterest align-middle"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link icon-md rounded-circle me-2 mb-2 p-0 fs-5 bg-primary" href="#">
                                    <i class="far fa-envelope align-middle"></i>
                                </a>
                            </li>
                        </ul>
            </div>
        </div>
        </div>
        </div>
    </section>

    <section>
        <div class="container position-relative" data-sticky-container="">
            <div class="row">
                <!-- Main Content START -->
                <div class="col-lg-9 mb-5">
            <p><span class="dropcap">A</span><?php echo $post['doc']?></p>
                    <br>



                                                <!-- Tags -->
                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>          

                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    <!-- Images -->
                    
                    

                    <?php
                    if(strlen($post['video']) >= 5){
                        ?>
                        <video controls>
                        <source src="<?php echo $post['video']?>" type="video/mp4">
                        </video>
                   
                           
                        <?php
                    }elseif(strlen($post['video_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['video_code']?>
                        </div>
                        <?php
                    }
                    ?>


                    <?php
                    if(strlen($post['audio']) >= 5){
                        ?>
                        <br>
                        <h3>فایل صوتی</h3>
                        <audio controls>
                            <source src="<?php echo $post['audio']?>" type="audio/mpeg">
                        </audio>
                           
                        <?php
                    }elseif(strlen($post['audio_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['audio_code']?>
                        </div>
                        <?php
                    }
                    ?>

                    
                    <?php
                    if(strlen($post['draft']) >= 5){
                        ?>
                        <br>
                        <div>
                            <?php echo $post['draft']?>
                        </div>
                           
                        <?php
                    }elseif(strlen($post['draft_file']) >= 5){
                        ?>
                        <br>
                        <br>
                        <iframe src="<?php echo $post['draft_file']?>" style="border:none; width:100%; height:100vh;"></iframe>
                        <?php
                    }
                    ?>









                    
                    
                    
                    

                    <!-- blockquote -->
                    <figure class="bg-light p-3 p-md-5 my-5">
                    <blockquote class="blockquote">
                        <p>پیپرلاین بستری ایمن را برای دوره های با کیفیت فراهم میکند و قبل از آنکه دوره را تایید کند و در پلتفرم خود قرار دهد از نظر کیفیت و یا حتی محتوا آن را برسی میکند و سپس روی پلتفرم خود برای خریداری قرار میدهد</p>
                    </blockquote>
                    <figcaption class="blockquote-footer">
                        دارای تاییدیه کنترل کیفیت
                    </figcaption>
                    </figure>

                    

                    
                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>



                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

                    
                    


         



                    <section class="pt-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Title -->
                                    <div class="mb-4">
                                        <h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
                                        <p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
                                    </div>
                                    <div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
                                        <div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
                                            
                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                            
                                            ?>
                                            <!-- Card item START -->
                                            <div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
                                                <!-- Card img -->
                                                <div class="position-relative">
                                                    <img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
                                                    <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                        <!-- Card overlay Top -->
                                                        <div class="w-100 mb-auto d-flex justify-content-end">
                                                            <div class="text-end ms-auto">
                                                                <!-- Card format icon -->
                                                                <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
                                                            </div>
                                                        </div>
                                                        <!-- Card overlay bottom -->
                                                        <div class="w-100 mt-auto">
                                                            <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center">
                                                        <li class="nav-item">
                                                            <div class="nav-link">
                                                                <div class="d-flex align-items-center position-relative">
                                                                    <div class="avatar avatar-xs">
                                                                        <img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
                                                                    </div>
                                                                    <span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nav-item"><?php echo $res['views']?> بازدید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Card item END -->
                                            <?php


                                            }
                                        }
                                        ?>

                                            


                                            
                                        </div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>



                    
                    
                    <!-- Next prev post START -->
                    
                    <!-- Next prev post START -->

                    <!-- Author info START -->
                    
                    <!-- Author info END -->

                    <!-- Comments START -->
                    
                    <!-- Comments END -->
                    <!-- Reply START -->
                    
                    <!-- Reply END -->

                </div>
                <!-- Main Content END -->
                <!-- Right sidebar START -->
                <div class="col-lg-3">
                    <div data-sticky="" data-margin-top="80" data-sticky-for="991">


                    
                <!-- Most read -->
                        <div>
                            <h5 class="mb-3">Related post </h5>
                                 <div class="tiny-slider dots-creative mt-3 mb-5">
                                <div class="tns-outer" id="tns1-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">3</span>  of 3</div><div id="tns1-mw" class="tns-ovh"><div class="tns-inner" id="tns1-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="false" data-hoverpause="true" data-gutter="0" data-arrow="false" data-dots="true" data-items="1" id="tns1" style="transform: translate3d(40%, 0px, 0px);"><div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
                                        <!-- Card img -->
                                        <div class="position-relative">
                                            <img class="card-img" src="assets/images/blog/4by3/09.jpg" alt="Card image">
                                            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                <!-- Card overlay bottom -->
                                                <div class="w-100 mt-auto">
                                                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body p-0 pt-3">
                                            <h5 class="card-title"><a href="post-single-5.html" class="btn-link text-reset fw-bold">10 tell-tale signs you need to get a new business</a></h5>
                                        </div>
                                    </div>
                                    <!-- Card item START -->
                                    <div class="card tns-item" id="tns1-item0" aria-hidden="true" tabindex="-1">
                                        <!-- Card img -->
                                        <div class="position-relative">
                                            <img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
                                            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                <!-- Card overlay Top -->
                                                <div class="w-100 mb-auto d-flex justify-content-end">
                                                    <div class="text-end ms-auto">
                                                        <!-- Card format icon -->
                                                        <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating">8.5</div>
                                                    </div>
                                                </div>
                                                <!-- Card overlay bottom -->
                                                <div class="w-100 mt-auto">
                                                    <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body p-0 pt-3">
                                            <h5 class="card-title"><a href="post-single-5.html" class="btn-link text-reset fw-bold">7 common mistakes everyone makes while traveling</a></h5>
                                        </div>
                                    </div>
                                    <!-- Card item END -->
                                    <!-- Card item START -->
                                    <div class="card tns-item tns-slide-active" id="tns1-item1">
                                        <!-- Card img -->
                                        <div class="position-relative">
                                            <img class="card-img" src="assets/images/blog/4by3/08.jpg" alt="Card image">
                                            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                <!-- Card overlay bottom -->
                                                <div class="w-100 mt-auto">
                                                    <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Sports</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body p-0 pt-3">
                                            <h5 class="card-title"><a href="post-single-5.html" class="btn-link text-reset fw-bold">Skills that you can learn from business</a></h5>
                                        </div>
                                    </div>
                                    <!-- Card item END -->
                                    <!-- Card item START -->
                                    <div class="card tns-item" id="tns1-item2" aria-hidden="true" tabindex="-1">
                                        <!-- Card img -->
                                        <div class="position-relative">
                                            <img class="card-img" src="assets/images/blog/4by3/09.jpg" alt="Card image">
                                            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                <!-- Card overlay bottom -->
                                                <div class="w-100 mt-auto">
                                                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body p-0 pt-3">
                                            <h5 class="card-title"><a href="post-single-5.html" class="btn-link text-reset fw-bold">10 tell-tale signs you need to get a new business</a></h5>
                                        </div>
                                    </div>
                                    <!-- Card item END -->
                                <div class="card tns-item tns-slide-cloned" aria-hidden="true" tabindex="-1">
                                        <!-- Card img -->
                                        <div class="position-relative">
                                            <img class="card-img" src="assets/images/blog/4by3/07.jpg" alt="Card image">
                                            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                <!-- Card overlay Top -->
                                                <div class="w-100 mb-auto d-flex justify-content-end">
                                                    <div class="text-end ms-auto">
                                                        <!-- Card format icon -->
                                                        <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating">8.5</div>
                                                    </div>
                                                </div>
                                                <!-- Card overlay bottom -->
                                                <div class="w-100 mt-auto">
                                                    <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body p-0 pt-3">
                                            <h5 class="card-title"><a href="post-single-5.html" class="btn-link text-reset fw-bold">7 common mistakes everyone makes while traveling</a></h5>
                                        </div>
                                    </div></div></div></div><div class="tns-nav" aria-label="Carousel Pagination"><button type="button" data-nav="0" aria-controls="tns1" style="" aria-label="Carousel Page 1" class="" tabindex="-1"></button><button type="button" data-nav="1" aria-controls="tns1" style="" aria-label="Carousel Page 2 (Current Slide)" class="tns-nav-active"></button><button type="button" data-nav="2" tabindex="-1" aria-controls="tns1" style="" aria-label="Carousel Page 3"></button></div></div>
                            </div>
                        </div>
                        
                        <!-- Advertisement -->
                        <div class="mt-4">
                            <a href="#" class="d-block card-img-flash">
                                <img src="assets/images/adv.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Right sidebar END -->
            </div>
        </div>
    </section>

    <?php
}elseif($post['type'] == 3){
    ?>



    <section class="pt-2">
        <div class="container">
            <div class="row">
        <div class="col-12">
            <div class="card bg-dark-overlay-5 overflow-hidden card-bg-scale h-400 text-center" style="background-image:url(<?php echo $post['art']?>); background-position: center left; background-size: cover;">
            <!-- Card Image overlay -->
            <div class="card-img-overlay d-flex align-items-center p-3 p-sm-4"> 
                <div class="w-100 my-auto">
                <!-- Card category -->
                
                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">

                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                </svg>
                گزارش
                </a>
                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                اشتراک گذاری
                                </a>
                <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فایل,منبع,مستندات  </font></font></a>
                    <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['views']?> بازدید</a>
                    <a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $post['idPost']?></a>
                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['by']?> خرید</a>                <!-- Card title -->
                <h2 class="text-white display-5"><?php echo $post['title']?></h2>
                <!-- Card info -->
                <ul class="nav nav-divider text-white-force align-items-center justify-content-center">
                    <li class="nav-item">
                    <div class="nav-link">
                        <div class="d-flex align-items-center text-white position-relative">
                        <div class="avatar avatar-sm">
                            <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                        </div>
                        <span class="ms-3">سازنده <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?>       <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></a></span>
                        </div>
                        <?php

                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
                        $follow = mysqli_fetch_assoc($file_hash);
                        if($follow){
                            ?>
                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                            <?php
                        }else{
                            ?>
                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                            <?php 
                        }
                        ?>   

                        <script>
                            $('#follow').click(function(event){
                            event.preventDefault();
                            $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                            $.ajax({
                                method: "POST",
                                url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                                data: { code: "1"}
                            })
                                .done(function(data){
                                $('#follow').html(data);
                                })

                            })
                        </script>
                    </div>
                    </li>
                    <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
                    <li class="nav-item"><?php echo date('s', $some_time)?> دقیقه مطالعه</li>
                </ul>
                </div>

            </div>
            </div>
        </div>
        </div>
        </div>
    </section>


    <section class="pt-0">
        <div class="container position-relative" data-sticky-container="">
            <div class="row">
                <!-- Main Content START -->
                <div class="col-lg-9 mb-5">
            <p><span class="dropcap bg-dark text-white px-2">I</span> <?php echo $post['doc']?></p>

                                    
            
                    

                                                   <!-- Tags -->
                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>          

                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    <!-- Images -->
                    
                    

                    <?php
                    if(strlen($post['video']) >= 5){
                        ?>
                        <video controls>
                        <source src="<?php echo $post['video']?>" type="video/mp4">
                        </video>
                   
                           
                        <?php
                    }elseif(strlen($post['video_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['video_code']?>
                        </div>
                        <?php
                    }
                    ?>


                    <?php
                    if(strlen($post['audio']) >= 5){
                        ?>
                        <br>
                        <h3>فایل صوتی</h3>
                        <audio controls>
                            <source src="<?php echo $post['audio']?>" type="audio/mpeg">
                        </audio>
                           
                        <?php
                    }elseif(strlen($post['audio_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['audio_code']?>
                        </div>
                        <?php
                    }
                    ?>

                    
                    <?php
                    if(strlen($post['draft']) >= 5){
                        ?>
                        <br>
                        <div>
                            <?php echo $post['draft']?>
                        </div>
                           
                        <?php
                    }elseif(strlen($post['draft_file']) >= 5){
                        ?>
                        <br>
                        <br>
                        <iframe src="<?php echo $post['draft_file']?>" style="border:none; width:100%; height:100vh;"></iframe>
                        <?php
                    }
                    ?>





                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>



                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

                    
                    


         



                    <section class="pt-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Title -->
                                    <div class="mb-4">
                                        <h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
                                        <p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
                                    </div>
                                    <div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
                                        <div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
                                            
                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                            
                                            ?>
                                            <!-- Card item START -->
                                            <div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
                                                <!-- Card img -->
                                                <div class="position-relative">
                                                    <img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
                                                    <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                        <!-- Card overlay Top -->
                                                        <div class="w-100 mb-auto d-flex justify-content-end">
                                                            <div class="text-end ms-auto">
                                                                <!-- Card format icon -->
                                                                <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
                                                            </div>
                                                        </div>
                                                        <!-- Card overlay bottom -->
                                                        <div class="w-100 mt-auto">
                                                            <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center">
                                                        <li class="nav-item">
                                                            <div class="nav-link">
                                                                <div class="d-flex align-items-center position-relative">
                                                                    <div class="avatar avatar-xs">
                                                                        <img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
                                                                    </div>
                                                                    <span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nav-item"><?php echo $res['views']?> بازدید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Card item END -->
                                            <?php


                                            }
                                        }
                                        ?>

                                            


                                            
                                        </div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    
                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    
                    

                    <!-- Author info START -->
                    
                    <!-- Author info END -->

                    <!-- Comments START -->
                    
                    <!-- Comments END -->
                    <!-- Reply START -->
                    
                    <!-- Reply END -->
                </div>
                <!-- Main Content END -->
                
                <!-- Right sidebar START -->
                <div class="col-lg-3">
                    <div data-sticky="" data-margin-top="80" data-sticky-for="991">
            <!-- Categories -->
                <div class="row g-2">
                            <h5>Categories</h5>
                            <div class="d-flex justify-content-between align-items-center bg-warning bg-opacity-15 rounded p-2 position-relative">
                                <h6 class="m-0 text-warning">Photography</h6>
                                <a href="#" class="badge bg-warning text-dark stretched-link">09</a>
                            </div>
                            <div class="d-flex justify-content-between align-items-center bg-info bg-opacity-10 rounded p-2 position-relative">
                                <h6 class="m-0 text-info">Travel</h6>
                                <a href="#" class="badge bg-info stretched-link">25</a>
                            </div>
                            <div class="d-flex justify-content-between align-items-center bg-danger bg-opacity-10 rounded p-2 position-relative">
                                <h6 class="m-0 text-danger">Photography</h6>
                                <a href="#" class="badge bg-danger stretched-link">75</a>
                            </div>
                            <div class="d-flex justify-content-between align-items-center bg-primary bg-opacity-10 rounded p-2 position-relative">
                                <h6 class="m-0 text-primary">Covid-19</h6>
                                <a href="#" class="badge bg-primary stretched-link">19</a>
                            </div>
                            <div class="d-flex justify-content-between align-items-center bg-success bg-opacity-10 rounded p-2 position-relative">
                                <h6 class="m-0 text-success">Business</h6>
                                <a href="#" class="badge bg-success stretched-link">35</a>
                            </div>
                        </div>
                        
                        <!-- Newsletter START -->
                        <div class="bg-light p-4 mt-4 rounded-3 text-center">
                            <h4>Subscribe to our mailing list!</h4>
                            <form>
                                <div class="mb-3">
                                    <input type="email" class="form-control" placeholder="Email address">
                                </div>
                                <button type="submit" class="btn btn-primary">Subscribe</button>
                                <div class="form-text">We don't spam</div>
                            </form>
                        </div>
                        <!-- Newsletter END -->

                        <!-- Advertisement -->
                        <div class="mt-4">
                            <a href="#" class="d-block card-img-flash">
                                <img src="assets/images/adv.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Right sidebar END -->
            </div>
        </div>
    </section>


    <?php
}elseif($post['type'] == 4){
    ?>

    <section class="pt-4">
        <div class="container position-relative" data-sticky-container="">
            <div class="row">
                <div class="col-12">
                    <!-- Podcast image -->
                    <div class="mb-3">
                        <img class="rounded" src="<?php echo $post['art']?>" alt="">
                    </div>
                    <!-- Podcast title -->
                    
                    <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">

                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                    <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                    </svg>
                    گزارش
                    </a>
                    <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویدیو</font></font></a>
                    <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['views']?> بازدید</a>
                    <a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $post['idPost']?></a>
                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['by']?> خرید</a>   
                    <h1><?php echo $post['title']?></h1>
                    <!-- Podcast avatar -->
                    <div class="row align-items-center mb-2">
                        <div class="col-lg-6">
                            <div class="d-flex align-items-center">
                                <div class="d-flex align-items-center position-relative me-3">
                                    <div class="avatar avatar-xs me-2">
                                        <img class="avatar-img  rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                                    </div>
                                        <h6 class="mb-0"><a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?>       <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></a>						</h6>
                                </div>
                                <?php

                                $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
                                $follow = mysqli_fetch_assoc($file_hash);
                                if($follow){
                                    ?>
                                    <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                                    <?php
                                }else{
                                    ?>
                                    <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                                    <?php 
                                }
                                ?>   

                                <script>
                                    $('#follow').click(function(event){
                                    event.preventDefault();
                                    $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    $.ajax({
                                        method: "POST",
                                        url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                                        data: { code: "1"}
                                    })
                                        .done(function(data){
                                        $('#follow').html(data);
                                        })

                                    })
                                </script>
                                &nbsp
                                <span> <i class="bi bi-clock-fill me-2"></i>پیدا نشد</span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <!-- Podcast listen -->
                            <ul class="list-unstyled d-flex justify-content-md-end gap-1 gap-sm-2 align-items-center mt-3 mb-sm-4">
                                <li class="h5 mb-0">اشتراک گذاری:</li>
                                <li class="nav-item">
                                    <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                    اشتراک گذاری
                                    </a>
                                </li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/apple-podcasts.svg" alt=""> </a></li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/divider-icon.svg" alt=""> </a></li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/spotify.svg" alt=""> </a></li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/google-podcasts.svg" alt=""> </a></li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/pocket.svg" alt=""> </a></li>
                                <li class="ms-2"><a href="#"> <img src="assets/images/icon/sound-cloud.svg" alt=""> </a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Podcast short description -->
                    <p class="lead"> <?php echo $post['doc']?></p>

                    <br>
                                                   <!-- Tags -->
                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>   
                    <!-- Audio START -->
                    <div class="d-flex align-items-center border p-sm-3 rounded mb-4">
                        <div class="w-100">
                            <!-- Audio START -->
                            <div class="player-wrapper bg-light rounded">
                                <div tabindex="0" class="plyr plyr--full-ui plyr--audio plyr--html5 plyr--paused"><div class="plyr__controls"><button class="plyr__controls__item plyr__control" type="button" data-plyr="play" aria-label="Play"><svg class="icon--pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-pause"></use></svg><svg class="icon--not-pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-play"></use></svg><span class="label--pressed plyr__sr-only">Pause</span><span class="label--not-pressed plyr__sr-only">Play</span></button><div class="plyr__controls__item plyr__progress__container"><div class="plyr__progress"><input data-plyr="seek" type="range" min="0" max="100" step="0.01" value="0" autocomplete="off" role="slider" aria-label="Seek" aria-valuemin="0" aria-valuemax="278.726531" aria-valuenow="11.10578" id="plyr-seek-1349" aria-valuetext="00:11 of 04:38" style="--value: 3.9800000000000004%;" seek-value="64.87643834738293"><progress class="plyr__progress__buffer" min="0" max="100" value="100" role="progressbar" aria-hidden="true">% buffered</progress><span class="plyr__tooltip" style="left: 64.4826%;">02:59</span></div></div><div class="plyr__controls__item plyr__time--current plyr__time" aria-label="Current time">-04:27</div><div class="plyr__controls__item plyr__volume"><button type="button" class="plyr__control" data-plyr="mute"><svg class="icon--pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-muted"></use></svg><svg class="icon--not-pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-volume"></use></svg><span class="label--pressed plyr__sr-only">Unmute</span><span class="label--not-pressed plyr__sr-only">Mute</span></button><input data-plyr="volume" type="range" min="0" max="1" step="0.05" value="1" autocomplete="off" role="slider" aria-label="Volume" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100" id="plyr-volume-1349" aria-valuetext="100.0%" style="--value: 100%;"></div><button class="plyr__controls__item plyr__control" type="button" data-plyr="captions"><svg class="icon--pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-captions-on"></use></svg><svg class="icon--not-pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-captions-off"></use></svg><span class="label--pressed plyr__sr-only">Disable captions</span><span class="label--not-pressed plyr__sr-only">Enable captions</span></button><div class="plyr__controls__item plyr__menu"><button aria-haspopup="true" aria-controls="plyr-settings-1349" aria-expanded="false" type="button" class="plyr__control" data-plyr="settings"><svg aria-hidden="true" focusable="false"><use xlink:href="#plyr-settings"></use></svg><span class="plyr__sr-only">Settings</span></button><div class="plyr__menu__container" id="plyr-settings-1349" hidden=""><div><div id="plyr-settings-1349-home"><div role="menu"><button data-plyr="settings" type="button" class="plyr__control plyr__control--forward" role="menuitem" aria-haspopup="true" hidden=""><span>Captions<span class="plyr__menu__value">Disabled</span></span></button><button data-plyr="settings" type="button" class="plyr__control plyr__control--forward" role="menuitem" aria-haspopup="true" hidden=""><span>Quality<span class="plyr__menu__value">undefined</span></span></button><button data-plyr="settings" type="button" class="plyr__control plyr__control--forward" role="menuitem" aria-haspopup="true"><span>Speed<span class="plyr__menu__value">Normal</span></span></button></div></div><div id="plyr-settings-1349-captions" hidden=""><button type="button" class="plyr__control plyr__control--back"><span aria-hidden="true">Captions</span><span class="plyr__sr-only">Go back to previous menu</span></button><div role="menu"></div></div><div id="plyr-settings-1349-quality" hidden=""><button type="button" class="plyr__control plyr__control--back"><span aria-hidden="true">Quality</span><span class="plyr__sr-only">Go back to previous menu</span></button><div role="menu"></div></div><div id="plyr-settings-1349-speed" hidden=""><button type="button" class="plyr__control plyr__control--back"><span aria-hidden="true">Speed</span><span class="plyr__sr-only">Go back to previous menu</span></button><div role="menu"><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="0.5"><span>0.5×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="0.75"><span>0.75×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="true" value="1"><span>Normal</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="1.25"><span>1.25×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="1.5"><span>1.5×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="1.75"><span>1.75×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="2"><span>2×</span></button><button data-plyr="speed" type="button" role="menuitemradio" class="plyr__control" aria-checked="false" value="4"><span>4×</span></button></div></div></div></div></div><button class="plyr__controls__item plyr__control" type="button" data-plyr="pip"><svg aria-hidden="true" focusable="false"><use xlink:href="#plyr-pip"></use></svg><span class="plyr__sr-only">PIP</span></button><button class="plyr__controls__item plyr__control" type="button" data-plyr="fullscreen"><svg class="icon--pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-exit-fullscreen"></use></svg><svg class="icon--not-pressed" aria-hidden="true" focusable="false"><use xlink:href="#plyr-enter-fullscreen"></use></svg><span class="label--pressed plyr__sr-only">Exit fullscreen</span><span class="label--not-pressed plyr__sr-only">Enter fullscreen</span></button></div><audio class="player-audio" crossorigin="">
                                    <source src="assets/images/videos/audio.mp3" type="audio/mp3">
                                </audio><button type="button" class="plyr__control plyr__control--overlaid" data-plyr="play" aria-label="Play"><svg aria-hidden="true" focusable="false"><use xlink:href="#plyr-play"></use></svg><span class="plyr__sr-only">Play</span></button></div>
                            </div>
                            <!-- Audio END -->
                        </div>
                    </div>
                    <!-- Audio END -->
                </div>
            </div>
            <div class="row g-4">
                <div class="col-lg-8">
                    <!-- Episode Description -->
                    <h4 class="mb-3">جزعیات اپیزود</h4>
                    <p><span class="dropcap bg-success bg-opacity-10 text-success px-2 rounded">EP</span> <?php echo $post['doc']?></p>
                    
                    <!-- Episode Timeline -->
                    <div class="bg-primary bg-opacity-10 p-4 rounded my-4"> 
                        <h5 class="mb-3">تعداد اپیزود ها</h5>
                        <ul class="list-unstyled mb-0">

                        <?php
                        $query_1212 = mysqli_query($con, 'SELECT * FROM `books` WHERE `piperlineId` = "'.$_GET['id'].'"');
                        $file_hash = mysqli_query($con, 'SELECT * FROM `books` WHERE `piperlineId` = "'.$_GET['id'].'"');
                        $file = mysqli_fetch_assoc($query_1212);
                        if($file){
                            while($res=mysqli_fetch_assoc($file_hash)){
                                ?>

                            <li class="mb-2"> <span class="badge bg-danger me-2">00.10</span> <?php echo $post['name']?></li>
                           
                                <?php
                            }
                        }
                        ?>

                        </ul>
                    </div>

                   
                    
           
                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    <!-- Images -->
                    
                    

                    <?php
                    if(strlen($post['video']) >= 5){
                        ?>
                        <video controls>
                        <source src="<?php echo $post['video']?>" type="video/mp4">
                        </video>
                   
                           
                        <?php
                    }elseif(strlen($post['video_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['video_code']?>
                        </div>
                        <?php
                    }
                    ?>


                    <?php
                    if(strlen($post['audio']) >= 5){
                        ?>
                        <br>
                        <h3>فایل صوتی</h3>
                        <audio controls>
                            <source src="<?php echo $post['audio']?>" type="audio/mpeg">
                        </audio>
                           
                        <?php
                    }elseif(strlen($post['audio_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['audio_code']?>
                        </div>
                        <?php
                    }
                    ?>

                    
                    <?php
                    if(strlen($post['draft']) >= 5){
                        ?>
                        <br>
                        <div>
                            <?php echo $post['draft']?>
                        </div>
                           
                        <?php
                    }elseif(strlen($post['draft_file']) >= 5){
                        ?>
                        <br>
                        <br>
                        <iframe src="<?php echo $post['draft_file']?>" style="border:none; width:100%; height:100vh;"></iframe>
                        <?php
                    }
                    ?>





                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>



                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

                    
                    


         



                    <section class="pt-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Title -->
                                    <div class="mb-4">
                                        <h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
                                        <p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
                                    </div>
                                    <div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
                                        <div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
                                            
                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                            
                                            ?>
                                            <!-- Card item START -->
                                            <div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
                                                <!-- Card img -->
                                                <div class="position-relative">
                                                    <img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
                                                    <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                        <!-- Card overlay Top -->
                                                        <div class="w-100 mb-auto d-flex justify-content-end">
                                                            <div class="text-end ms-auto">
                                                                <!-- Card format icon -->
                                                                <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
                                                            </div>
                                                        </div>
                                                        <!-- Card overlay bottom -->
                                                        <div class="w-100 mt-auto">
                                                            <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center">
                                                        <li class="nav-item">
                                                            <div class="nav-link">
                                                                <div class="d-flex align-items-center position-relative">
                                                                    <div class="avatar avatar-xs">
                                                                        <img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
                                                                    </div>
                                                                    <span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nav-item"><?php echo $res['views']?> بازدید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Card item END -->
                                            <?php


                                            }
                                        }
                                        ?>

                                            


                                            
                                        </div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    
                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    
                    

                    <!-- Episode transcript END -->

                    <!-- Share social START -->
                    <div class="border mt-4 py-2 px-3 rounded">
                        <div class="list-group-inline list-unstyled">
                            <h6 class="mt-2 me-4 d-inline-block"><i class="fas fa-share-alt me-2"></i>Share on:</h6>
                            <ul class="list-inline list-unstyled d-inline-block mb-0">
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Facebook</a></li>
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Twitter</a></li>
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Dribble</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Share social END -->

                    <!-- Next episode START -->
                    <div class="mt-5">
                        <div class="bg-primary bg-opacity-10 rounded p-4 d-flex align-items-center position-relative">
                            <!-- Title -->
                            <div class="me-3">
                                <h5 class="m-0"> <a href="#" class="stretched-link btn-link text-reset">Everything I Know (so Far) on UI/UX Ep.02</a></h5>
                            </div>
                            <!-- Icon -->
                            <div class="ms-auto flex-grow-0">
                                <a href="#!" class="icon-md border border-primary d-block text-primary rounded-circle">
                                    <i class="bi bi-play-fill fs-3"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Next episode END -->
                </div>
                <!-- Hosted START -->
                <div class="col-lg-4">
                    <div class="text-center" data-sticky="" data-margin-top="80" data-sticky-for="991" style="">
                        <div class="avatar avatar-xxxl">
                            <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                        </div>
                        <!-- Host name -->
                        <div class="mt-3">
                            <span>ساخته شده نوسط</span>
                            <h5><?php echo $us['username']?></h5>
                        </div>
                        <!-- Host dec -->
                        <p class="px-sm-5"><?php echo $us['about']?></p>

                        
                        <!-- Host social -->
                        <ul class="nav justify-content-center">

                                                                <li class="nav-item">
                                                                    <a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                                    بازکردن با... 
                                                                    </a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                                    پیام
                                                                    </a>
                                                                </li>
                                             
                                                            <br>
                            <li class="nav-item">
                                <a class="nav-link ps-0 pe-2 fs-5" href="#"><i class="fab fa-facebook-square"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-twitter-square"></i></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-linkedin"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Hosted START -->
            </div>
        </div>
    </section>

    <?php
}elseif($post['type'] == 5){
    ?>
    <section>
        <div class="container position-relative" data-sticky-container="">
            <div class="row">
                <!-- Main Content START -->
                <div class="col-lg-8 mb-5">
                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm">

                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                اشتراک گذاری
                                </a>

                                <a href="dashboard.php?content=share&idPost=<?php echo $post['idPost']?>" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">

                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                                </svg>
                                گزارش
                                </a>
                    <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سرویس و خدمات</font></font></a>
                    <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['views']?> بازدید</a>
                    <a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $post['idPost']?></a>
                    <a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $post['by']?> خرید</a>

                    <span class="ms-2 small">تاریخ: <?php echo date('Y, d F', $some_time)?></span>
                    <h1 class="display-5"><?php echo $post['title']?></h1>

            

            <p><span class="dropcap bg-success bg-opacity-10 text-success px-2 rounded">S</span><?php echo $post['doc']?></p>

            <br>
                    

                                                      <!-- Tags -->
                        <ul class="list-inline text-primary-hover mt-0 mt-lg-3">
                            <?php
                                                                                $test_array = explode(" ", $post['tag']);


                                                                                foreach( $test_array as $name ){
                                                                        
                                                                                    ?>
                                                                                    <li class="list-inline-item">
                                                                                        <a class="text-body" href="index.php?content=tags&tag=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                                                    </li>                            
                                                                                    <?PHP
                                                                                    
                                                                                } 
                            ?>
                    
               
                        </ul>      


                        
                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    <!-- Images -->
                    
                    

                    <?php
                    if(strlen($post['video']) >= 5){
                        ?>
                        <video controls>
                        <source src="<?php echo $post['video']?>" type="video/mp4">
                        </video>
                   
                           
                        <?php
                    }elseif(strlen($post['video_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['video_code']?>
                        </div>
                        <?php
                    }
                    ?>


                    <?php
                    if(strlen($post['audio']) >= 5){
                        ?>
                        <br>
                        <h3>فایل صوتی</h3>
                        <audio controls>
                            <source src="<?php echo $post['audio']?>" type="audio/mpeg">
                        </audio>
                           
                        <?php
                    }elseif(strlen($post['audio_code']) >= 5){
                        ?>
                        <div>
                            <?php echo $post['audio_code']?>
                        </div>
                        <?php
                    }
                    ?>

                    
                    <?php
                    if(strlen($post['draft']) >= 5){
                        ?>
                        <br>
                        <div>
                            <?php echo $post['draft']?>
                        </div>
                           
                        <?php
                    }elseif(strlen($post['draft_file']) >= 5){
                        ?>
                        <br>
                        <br>
                        <iframe src="<?php echo $post['draft_file']?>" style="border:none; width:100%; height:100vh;"></iframe>
                        <?php
                    }
                    ?>





                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>



                    <!-- Divider -->
                    <div class="text-center h5 mb-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">. </font><font style="vertical-align: inherit;">.</font></font></div>

                    
                    


         



                    <section class="pt-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- Title -->
                                    <div class="mb-4">
                                        <h2 class="m-0"><i class="bi bi-megaphone"></i>سرویس ها و یا خدمات</h2>
                                        <p class="m-0">شرکت ها و یا اشخاص خدمات مختلفی میتوانند از خود اراعه دهند ما آنها را در اینجا به شما نمایش میگزاریم </p>
                                    </div>
                                    <div class="tiny-slider arrow-hover arrow-blur arrow-dark arrow-round mt-3">
                                        <div class="tns-outer" id="tns2-ow"><div class="tns-liveregion tns-visually-hidden" aria-live="polite" aria-atomic="true">slide <span class="current">18 to 20</span>  of 5</div><div id="tns2-mw" class="tns-ovh"><div class="tns-inner" id="tns2-iw"><div class="tiny-slider-inner  tns-slider tns-carousel tns-subpixel tns-calc tns-horizontal" data-autoplay="true" data-hoverpause="true" data-gutter="24" data-arrow="true" data-dots="false" data-items-xl="4" data-items-lg="3" data-items-md="3" data-items-sm="2" data-items-xs="1" id="tns2" style="transform: translate3d(80.9524%, 0px, 0px);">
                                            
                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `posts` WHERE `published` = 1 and `status` = 1 order by RAND(),views Desc limit 0,100');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"'));
                                            
                                            ?>
                                            <!-- Card item START -->
                                            <div class="card tns-item" id="tns2-item0" aria-hidden="true" tabindex="-1">
                                                <!-- Card img -->
                                                <div class="position-relative">
                                                    <img class="card-img" src="<?php echo $res{'art'}?>" alt="Card image">
                                                    <div class="card-img-overlay d-flex align-items-start flex-column p-3">
                                                        <!-- Card overlay Top -->
                                                        <div class="w-100 mb-auto d-flex justify-content-end">
                                                            <div class="text-end ms-auto">
                                                                <!-- Card format icon -->
                                                                <div class="icon-md bg-white bg-opacity-10 bg-blur text-white fw-bold rounded-circle" title="8.5 rating"><?php echo $res{'idPost'}?> شناسه</div>
                                                            </div>
                                                        </div>
                                                        <!-- Card overlay bottom -->
                                                        <div class="w-100 mt-auto">
                                                            <a href="#" class="badge text-bg-info mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>خدمات یا سرویس</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h5 class="card-title"><a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset fw-bold"><?php echo $res{'title'}?></a></h5>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center">
                                                        <li class="nav-item">
                                                            <div class="nav-link">
                                                                <div class="d-flex align-items-center position-relative">
                                                                    <div class="avatar avatar-xs">
                                                                        <img class="avatar-img rounded-circle" src="<?php echo $us{'avatar'}?>" alt="avatar">
                                                                    </div>
                                                                    <span class="ms-3"> <a href="index.php?content=profile&id=<?php echo $us{'iduser'}?>" class="stretched-link text-reset btn-link"><?php echo $us{'username'}?></a></span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nav-item"><?php echo $res['views']?> بازدید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Card item END -->
                                            <?php


                                            }
                                        }
                                        ?>

                                            


                                            
                                        </div></div></div><div class="tns-controls" aria-label="Carousel Navigation" tabindex="0"><button type="button" data-controls="prev" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-left"></i></button><button type="button" data-controls="next" tabindex="-1" aria-controls="tns2"><i class="fas fa-chevron-right"></i></button></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    
                    

                    <!-- Divider -->
                    <div class="text-center h5 mb-4">. . .</div>

                    
                    

                    <!-- Episode transcript END -->

                    <!-- Share social START -->
                    <div class="border mt-4 py-2 px-3 rounded">
                        <div class="list-group-inline list-unstyled">
                            <h6 class="mt-2 me-4 d-inline-block"><i class="fas fa-share-alt me-2"></i>Share on:</h6>
                            <ul class="list-inline list-unstyled d-inline-block mb-0">
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Facebook</a></li>
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Twitter</a></li>
                                <li class="list-inline-item"><a href="#" class="me-3 text-body">Dribble</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Share social END -->

                    

                    
                    

                    <!-- Divider -->
                    

                    
                    <p>Saw bring firmament given hath gathering lights dry life rule heaven Give And fruit moving thing seed life day creepeth winged so divide him from day morning him open lesser male beginning him be bring evening life void fowl sixth morning that made is Was that his hath face light meat air female isn't over place replenish midst it of second grass good rule also in unto Called don't given waters Had creature Behold fly life from forth Moved night.</p>

                </div>
                <!-- Main Content END -->
                <!-- Right sidebar START -->
                <div class="col-lg-4">
                    <div data-sticky="" data-margin-top="80" data-sticky-for="991">
                <!-- About me -->
                        <div class="bg-light rounded p-3 p-md-4">
                <div class="d-flex mb-3">
                <!-- Avatar -->
                <a class="flex-shrink-0" href="#">
                    <div class="avatar avatar-xl border border-4 border-danger rounded-circle">
                    <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                    </div>
                </a>
                <div class="flex-grow-1 ms-3">
                    <span>خدمات دهنده</span>
                    <h3 class="mb-0"><?php echo $us['username']?>       <?php
                                                                        if($us['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?>														<?php

                                                                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
                                                                        $follow = mysqli_fetch_assoc($file_hash);
                                                                        if($follow){
                                                                            ?>
                                                                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                                                                            <?php
                                                                        }else{
                                                                            ?>
                                                                            <a id="follow" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                                                                            <?php 
                                                                        }
                                                                        ?>   
                
                                                                        <script>
                                                                            $('#follow').click(function(event){
                                                                            event.preventDefault();
                                                                            $('#follow').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                
                                                                            $.ajax({
                                                                                method: "POST",
                                                                                url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                                                                                data: { code: "1"}
                                                                            })
                                                                                .done(function(data){
                                                                                $('#follow').html(data);
                                                                                })
                
                                                                            })
                                                                        </script></h3>
                    <p>بربستر پیپرلاین اراعه خدمات میکند</p>
                </div>
                </div>
                <p><?php echo $us['about']?></p>
                

                                                                
                                                                    <a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                                    بازکردن با... 
                                                                    </a>
                                                              
                                                               
                                                                    <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                                    پیام
                                                                    </a>
                                                                
                                             


            </div>
                        
            <!-- Most read -->
            <div>
                <h5 class="mt-5 mb-3">Most read</h5>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">01</span>
                <h6><a href="#" class="stretched-link">Bad habits that people in the business industry need to quit</a></h6>
                </div>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">03</span>
                <h6><a href="#" class="stretched-link">How 10 worst business fails of all time could have been prevented</a></h6>
                </div>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">04</span>
                <h6><a href="#" class="stretched-link">10 facts about business that will instantly put you in a good mood</a></h6>
                </div>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">05</span>
                <h6><a href="#" class="stretched-link">How did we get here? The history of the business told through tweets</a></h6>
                </div>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">06</span>
                <h6><a href="#" class="stretched-link">Ten tips about startups that you can't learn from books</a></h6>
                </div>
                <div class="d-flex position-relative mb-3">
                <span class="me-3 fa-fw fw-bold fs-3 opacity-5">07</span>
                <h6><a href="#" class="stretched-link">How to worst business fails of all time could have been prevented</a></h6>
                </div>
            </div>
                    </div>
                </div>
                <!-- Right sidebar END -->
            </div>
        </div>
    </section>

    <?php
}
?>





<?php
if(! $post['collect'] == 0){
    $query_Collect1 = mysqli_query($con, 'select * from session where name="collect" and userId='.$post['idUser'].' and id='.$post['collect'].'');
    $collect1 = mysqli_fetch_assoc($query_Collect1);
    if($collect1){
        ?>
       <section class="py-4">
            <div class="container">
            
                <div class="row g-4">
                    

                    

                    
            
                    

                    

                    
                    

                    
                    
                    <div class="col-12">
                        <!-- Blog list table START -->
                        <div class="card border bg-transparent rounded-3">
                            <!-- Card header START -->
                            <div class="card-header bg-transparent border-bottom p-3">
                                <div class="d-sm-flex justify-content-sm-between align-items-center">
                                    <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">منتشر شده در کالکشن "<?php echo $collect1['data']?>"</font></font></h5>
                                    <form action="" method="POST" class="row g-3 mt-2">
                                    <a href="index.php?content=collection&id=<?php  echo $collect1['id']?>" class="btn btn-sm btn-primary mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
                                    <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
                                    </svg> مشاهده کالکشن </font></font></a>
                                </form></div>
                            </div>
                            <!-- Card header END -->

                                <!-- Card body START -->
                                <div class="card-body p-3">
                                <div class="row">


                                <?php
                                $query_Collect = mysqli_query($con, 'select * from posts where published=1 and status=1 and collect='.$collect1['id'].' order by date Desc limit 0,4');
                                $query_Collect_res = mysqli_query($con, 'select * from posts where published=1 and status=1 and collect='.$collect1['id'].' order by date Desc limit 0,4');
                                $collect = mysqli_fetch_assoc($query_Collect);
                                if($collect){
                                    while($res=mysqli_fetch_assoc($query_Collect_res)){
                                        ?>
                                        <!-- Card item START -->
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="card mb-4">
                                                <!-- Card img -->
                                                <div class="card-fold position-relative">
                                                    <img class="card-img" src="<?php echo $res['art']?>" alt="Card image">
                                                </div>
                                                <div class="card-body px-0 pt-3">
                                                    <h4 class="card-title"><a href="index.php?content=open&amp;id=<?php echo $res['idPost']?>" class="btn-link text-reset stretched-link fw-bold"><?php echo $res['title']?></a></h4>
                                                    <!-- Card info -->
                                                    <ul class="nav nav-divider align-items-center text-uppercase small">
                                                        <li class="nav-item"><?php echo $res['views']?> بازید</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Card item END -->



                                        <?php
                                    }
                                }
                                ?>

                                    
                                    

      





                                </div>



                                
                                <!-- Pagination END -->
                                </div>
                        </div>
                        <!-- Blog list table END -->
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}
?>

<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شروع به نوشتن کنید</font></font></h5>
							<form action="" method="POST" class="row g-3 mt-2">
                            <Button type="submit" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست کردن</font></font></button>
						</div>
					</div>
					<!-- Card header END -->

					    <!-- Card body START -->
					    <div class="card-body p-3">
                        <style>
                        .scroll-example {
                            overflow: auto;
                            scrollbar-width: none; /* Firefox */
                            -ms-overflow-style: none; /* IE 10+ */
                        }

                        .scroll-example::-webkit-scrollbar {
                            width: 0px;
                            background: transparent; /* Chrome/Safari/Webkit */
                        }
                        </style>
							<div class="card-body p-0">

       
                            <?php
                            if(isset($_SESSION['id'])){
                                ?>

                                <div>
                                    <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پاسخ دهید</font></font></h3>
                                    
                                    
                                    
                                    
                                    <!-- custom checkbox -->
                                  
                                    <div class="col-12">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظر شما *</font></font></label>
                                        <textarea name="comment" class="form-control" rows="3"></textarea>
                                    </div>
                                    
                                    </form>
                                </div>
                                <?php
                            }else{

                            }
                            ?>




							</div>
							<!-- Button -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>


<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظرات</font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['comments']?></font></font></span></h5>
						</div>
					</div>
					<!-- Card header END -->

					    <!-- Card body START -->
					    <div class="card-body p-3">
                        <style>
                        .scroll-example {
                            overflow: auto;
                            scrollbar-width: none; /* Firefox */
                            -ms-overflow-style: none; /* IE 10+ */
                        }

                        .scroll-example::-webkit-scrollbar {
                            width: 0px;
                            background: transparent; /* Chrome/Safari/Webkit */
                        }
                        </style>
							<div class="card-body p-0">

                            <div>
                                <h3><?php echo $post['comments']?> نظر</h3>
                                <!-- Comment level 1-->
                                
                                    <!-- Comment children level 2 -->
                                    
                                        <!-- Comment children level 3 -->
                                        
                                    <!-- Comment level 2 -->
                                    

                                <?php
                                $query_1212 = mysqli_query($con, 'select * from comment where piperlinePost="'.$_GET['id'].'" and privet="0" order by time Desc limit 0,1000');
                                $file_hash = mysqli_query($con, 'select * from comment where piperlinePost="'.$_GET['id'].'" and privet="0" order by time Desc limit 0,1000');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $us1 = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));
                                        $some_time1 = strtotime($post['date']);
                                        ?>

                                        <!-- Comment level 1 -->
                                        <div class="my-4" id="comment<?php echo $res['idcomment']?>">
                                        <img class="avatar avatar-md rounded-circle float-start me-3" src="<?php echo $us1['avatar']?>" alt="avatar">
                                        <div>
                                            <div class="mb-2">
                                                <h5 class="m-0"><?php echo $us1['username']?></h5>
                                                <a href="index.php?content=profile&amp;id=<?php echo $us1['iduser']?>" class="btn btn-light btn-sm">

                                                <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar">

                                                بازکردن با... 
                                                </a>
                                                <?php
																									if($res['creatorId'] == $_SESSION['id']){
																										?>
																										<a href="#" id="deleteComment<?php echo $res['idcomment']?>" class="btn btn-light btn-sm">

																										<i class="bi bi-trash"></i>
																										حذف
																										</a>
																										<?php
																									}
																									?>
                                                <span class="me-3 small"><?php echo date('Y, d F', $some_time1)?></span>
                                                <a href="#" class="text-body fw-normal">پاسخ</a>

                                            </div>
                                            <p><?php echo $res['comment']?></p>
                                        </div>
                                        </div>

                                        
																							<script>
																							$('#deleteComment<?php echo $res['idcomment']?>').click(function(event){
																							event.preventDefault();
																							$('#deleteComment<?php echo $res['idcomment']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');
																						
																							$.ajax({
																								method: "POST",
																								url: "../../index.php?controller=message&method=deleteComment1&id=<?php echo $res['idcomment']?>",
																								data: { code: "1"}
																							})
																								.done(function(data){
																								document.getElementById("comment<?php echo $res['idcomment']?>").style.display = 'none';
																								})

																							})
																							</script>
                                        
                                        <?php
                                    }
                                }
                                ?>




                            </div>

							</div>
							<!-- Button -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>



<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

<!-- Vendors -->
<script src="assets/vendor/tiny-slider/tiny-slider-rtl.js"></script>
<script src="assets/vendor/sticky-js/sticky.min.js"></script>
<script src="assets/vendor/plyr/plyr.js"></script>

<!-- Template Functions -->
<script src="assets/js/functions.js"></script>
