<?php 




if(isset($_GET['id'])){
    $query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and status=1 and published=1');
	$post = mysqli_fetch_assoc($query);
    if(! $post){
        echo "<script type='text/javascript'>window.location.href='index.php?content=404'</script>";

    }
    $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$post['idUser'].'"'));
    if(! $us){
        echo "<script type='text/javascript'>window.location.href='index.php?content=404'</script>";
    }
    $some_time = strtotime($post['date']);


    if($post['pay'] == 0){
        $pay = 'رایگان';
    }else{
        $pay = ''.number_format($post['pay'] , 0 , "." , "," ).'';
    }

}else{
    die();
}

if(strlen($post['loc']) >= 2){
    if($post['interLoc'] == 1){
        if($post['loc'] == $user['loc']){

        }else{
            echo "<script type='text/javascript'>window.location.href='index.php?content=404'</script>";
            die();
        }
    }else{

    }
}

if(isset($_SESSION['id'])){
    $query2 = mysqli_query($con, 'select * from session where name="order" and userId="'.$_SESSION['id'].'" and piperline='.$_GET['id'].'');
    $clud = mysqli_fetch_assoc($query2);
    if($clud){
        if($post['type'] == 5){

        }else{
            die();
        }
    }
}else{
    $_SESSION['url'] = 'core/rtl/index.php?content=by&id='.$_GET['id'].'';
    die();
}



if($post['byNumber'] == 0){

}else{
    if($post['byNumber'] > $post['by']){
       
    }else{
        die();
    }
}
?>


<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
                            <div class="ms-3">
                            
                                
                                                        <h5 href="#" class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                                        <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                                        </svg><?php echo $post['button']?></font></font></h5>
                                                        <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></p>
                            </div>
							<form action="../../index.php?controller=home&method=by" method="POST" class="row g-3 mt-2">
                            <button type="submit" class="btn btn-sm btn-primary mb-0"><i class="bi bi-paypal"></i><font style="vertical-align: inherit;">پرداخت <font style="vertical-align: inherit;" id="payNum"><?php echo $pay?></font> تومان</font><font id="priceNumber" style="display: none;"><?php echo $post['pay']?></font></button>
						</div>
					</div>
					<!-- Card header END -->

					    <!-- Card body START -->
					    <div class="card-body p-3">
                        <style>
                        .scroll-example {
                            overflow: auto;
                            scrollbar-width: none; /* Firefox */
                            -ms-overflow-style: none; /* IE 10+ */
                        }

                        .scroll-example::-webkit-scrollbar {
                            width: 0px;
                            background: transparent; /* Chrome/Safari/Webkit */
                        }
                        </style>
							<div class="card-body p-0">

       
                            
                                <div>
                                    <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-link-45deg"></i> پیوند ها</font></font></h3>
                                    
                                    <input type="text" name="idPost" value="<?php echo $_GET['id']?>" style="display: none;">
                                    
                                    <?php
                                    $query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "fild" and `piperline` = '.$_GET['id'].'');
                                    $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "fild" and `piperline` = '.$_GET['id'].'');
                                    $file = mysqli_fetch_assoc($query_1212);
                                    if($file){
                                        while($res=mysqli_fetch_assoc($file_hash)){
                                            if($res['type'] == 'textarea'){
                                                ?>
                                                <!-- custom checkbox -->
                                                                        
                                                <div class="col-12">
                                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?></font></font></label>
                                                    <textarea name="<?php echo $res['id']?>" class="form-control" rows="4"></textarea>
                                                </div>
                                                <?php
                                            }else{
                                                ?>


                                                <div class="col-12">
                                                <!-- Post name -->
                                                <div class="mb-3">
                                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?></font></font></label>
                                                    <input required="" id="con-name" name="<?php echo $res['id']?>" type="<?php echo $res['type']?>" class="form-control" placeholder="وارد کنید">
                                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عرضه کننده از شما خواسته تا این فیلد را پر کنید </font></font></small>
                                                </div>
                                                </div>
    
                                                <?php
                                            }

                                        }
                                    }
                                    ?>




                                    <!-- custom checkbox -->
                                  
                                    <div class="col-12">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یادداشت شما</font></font></label>
                                        <textarea name="wiki" class="form-control" rows="4"></textarea>
                                    </div>

                                    <input type="number" name="math" value="0" id="math" style="display: none;">

                                    </form>

                                    <br>
                                    <?php 
                                    if($post['price'] == 1){
                                        ?>

                                        <div class="container">
                                            <div class="row pb-4">
                                                
                                            <div class="bg-light rounded-3 p-4 mb-3">
                                        
                                                <!-- Content -->
                                                <h6 class="h3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-tags" viewBox="0 0 16 16">
                                                <path d="M3 2v4.586l7 7L14.586 9l-7-7H3zM2 2a1 1 0 0 1 1-1h4.586a1 1 0 0 1 .707.293l7 7a1 1 0 0 1 0 1.414l-4.586 4.586a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 2 6.586V2z"/>
                                                <path d="M5.5 5a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1zm0 1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM1 7.086a1 1 0 0 0 .293.707L8.75 15.25l-.043.043a1 1 0 0 1-1.414 0l-7-7A1 1 0 0 1 0 7.586V3a1 1 0 0 1 1-1v5.086z"/>
                                                </svg> تعداد سفارش</font>
                                                </font>
                                                </h6>

                                                <form action="" id="priceByF">
                                                    <div class="input-group">
                                                        <input id="priceN" type="number" class="form-control" name="price" min="1" max="<?php echo $post['max']?>" placeholder="حد اکثر <?php echo $post['max']?>" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" type="submit" id="priceBy"><img style="width:20px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-sign-5339244-4466132.png" alt=""> محاسبه قیمت</button>
                                                        </div>

                                                    </div>
                                                </form>


                                                <div  class="alert alert-success alert-dismissible fade show" role="alert" style="width: 50%;">
                                                    <h5 id="priceShow"></h5> تومان                                          
                                                
                                                </div>
                                                    
                                                
                                                

                                                <script>
                                                        $(document).ready(function(){
                                                            $("#priceByF").on("submit", function(event){
                                                                event.preventDefault();

                                                                var formValues= $('#data2').serialize();


                                                                var myInput = $("#priceN");
                                                                var myValue = myInput.val()*<?php echo $post['pay']?>;
                                                                $("#math").val($("#priceN").val());
                                                                $('#priceShow').html(myValue.toLocaleString("en"));
                                                                $('#priceNumber').html(myValue);
                                                                $('#payNum').html(myValue.toLocaleString("en"));
                                                                $('#giftAcc').html('<i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">استفاده کردن</font></font>');
                                                            });
                                                        });
                                                </script>
                                            </div>
                                            
                                            </div>
                                        </div>

                                        <?php
                                    }
                                    ?>
              

                                    <br>

                                        <div class="container">
                                            <div class="row pb-4">
                                                
                                            <div class="bg-light rounded-3 p-4 mb-3">
                                        
                                                <!-- Content -->
                                                <h6 class="h3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/gift-card-5580691-4668671.png" style="width: 80px;" alt=""> کارت هدیه</font>
                                                </font>


                                                <?PHP 
                                                $query1 = mysqli_query($con, 'select * from session where rol="OFFERCODE" and userId='.$_SESSION['id'].' and piperline='.$post['idPost'].' order by id Desc limit 0,1');
                                                $off = mysqli_fetch_assoc($query1);
                                                if($off){
                                                    ?>
                                                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                                        
                                                        
                                                        
                                                    <img style="width: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/successfully-approve-5331611-4659611.png" alt="">   کارت هدیه "<?php echo $off['name']?>" شناخته شد <br> <small><?php echo $off['payment']?> درصد تخفیف</small>
                                                    </div>

                                                    </h6>
                                                    <button type="button" id="giftAcc" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">استفاده کردن</font></font></button>
                                                    <?PHP
                                                }else{
                                                    ?>
                                                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                                        
                                                        
                                                        
                                                        کارت هدیه ای شناخته نشد <a href="dashboard.php?content=club"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>

                                                    </h6>
                                                    <?php
                                                }
                                                
                                                ?>




                                                
                                                    
                                                
                                                

                                                <script>
                                                $('#giftAcc').click(function(event){
                                                event.preventDefault();

                                                $('#giftAcc').html("اعمال شد");

                                                var myInput = $('#priceNumber').html();
                                                

                                                var myValue = (<?php echo $off['payment']?> * Number(myInput)) / 100; 
                                             

                                                var math = myInput-myValue;




                                                $('#priceShow').html(math.toLocaleString("en"));
                                                $('#payNum').html(math.toLocaleString("en"));
                                                $('#payNum').html(math.toLocaleString("en"));
                                                

                                                })
                                                </script>
                                            </div>
                                            
                                            </div>
                                        </div>

                                      
                                    
                                </div>
                                

                                

							</div>
							<!-- Button -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>
