<title>پیپرز - پیپرلاین</title>

<section class="pt-4">
			<div class="container">
				<div class="row">
			<div class="col-lg-9 mx-auto text-center py-5">
				<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیپرز</font></font></span>
				<h2 class="display-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img class="navbar-brand-item light-mode-item" style="width: 180px; height: 70px;" src="assets/images/logo.png" alt="لوگو"></font></font></h2>
				<span class="lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاوش را شروع کنید</font></font></span>
				<!-- Search -->
				<div class="row">
					<div class="col-sm-8 col-md-6 col-lg-12 mx-auto">
						<hr>
						<a class="btn btn-primary-soft" href="index.php?content=tags&amp;tag=سبگ زندگی"><i class="bi bi-life-preserver"></i> سبک زندگی</a>
						<a class="btn btn-dark-soft" href="index.php?content=tags&amp;tag=فناوری"><i class="bi bi-bullseye"></i> فناوری</a>
						<a class="btn btn-success-soft" href="index.php?content=tags&amp;tag=مسافرت"><i class="bi bi-airplane-engines"></i> مسافرت</a>
						<a class="btn btn-danger-soft" href="index.php?content=tags&amp;tag=کسبوکار"><i class="bi bi-briefcase"></i> کسبو کار</a>
						<a class="btn btn-warning-soft" href="index.php?content=tags&amp;tag=ورزش"><i class="bi bi-bicycle"></i> ورزش</a>
						<a class="btn btn-info-soft" href="index.php?content=tags&amp;tag=بازاریابی"><i class="bi bi-badge-vo"></i> بازاریابی</a>
						<br>



									
					</div>
				</div>
			</div>
			</div>
			</div>
</section>


<section class="pt-4">
			<div class="container">
				<div class="row">			



                <?php
                      $query_1212 = mysqli_query($con, 'select * from blogs where published="1" order by RAND(),createDate Desc limit 0,25');
                      $file_hash = mysqli_query($con, 'select * from blogs where published="1" order by RAND(),createDate Desc limit 0,25');
                
                    
                      $file = mysqli_fetch_assoc($query_1212);
                      if($file){
                        while($res=mysqli_fetch_assoc($file_hash)){
                          $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                          $some_time = strtotime($res['createDate']);
                          ?>
                      
                
                                <div class="row g-4">
                                    <div class="col-12">
                                      <!-- Card START -->
                                      <div class="card border">
                                        <!-- Card header START -->
                                        <div class="card-header border-bottom p-3">
                                          <!-- Search and select START -->
                                          
                            
                                            
                                          <div class="d-sm-flex justify-content-sm-between align-items-center">
                
                                            <h5 class="mb-2 mb-sm-0"><div class="nav-link">
                                              <div class="d-flex align-items-center position-relative">
                                                <div class="avatar avatar-xs">
                                                  <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                                                </div>
                                                <span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>      <?php
                                                    if($us['admin'] == 1){
                                                      ?>
                                                      <i class="bi bi-patch-check-fill text-info small"></i>
                                                      <?php
                                                    }
                                                    ?></a><br><small><?php echo $us['job']?></small></span>
                                              </div>
                                            </div>
                                            </h5>
                
                
                                            <a href="dashboard.php?content=share&idPost=<?php echo $res['idPost']?>" class="btn mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
                                            <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z"/>
                                            </svg></a>
                
                                          </div>	
                                          
                                          <!-- Search and select END -->
                                        </div>
                                        <!-- Card header END -->
                
                                        <!-- Card body START -->
                                        <div class="card-body p-3 pb-0">
                
                            
                                          
                                          
                                          <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیپر</font></font></a>
                                          <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['visit']?> بازدید</a>
                                          <a href="#" class="badge text-bg-secondary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>PL.<?php echo $res['idBlog']?></a>
                                          <!-- Tabs content START -->
                                          <br/>
                                          <small><i class="bi bi-calendar-plus"></i>&nbsp<?php echo date('Y, d F', $some_time)?></small>
                                          <a href="index.php?content=openBlog&idBlog=<?php echo $res['idBlog']?>"><h5><?php echo $res['title']?></h5></a>
                                          <?php
                                          if(strlen($res['descrip']) > 5){
                                            ?>
                                            <p class="card-text"><?php echo $res['descrip']?></p>
                                            <?php
                                          }else{
                
                                      
                
                                            $text = $res['blog'];
                                            ?>
                                            <p class="card-text"><?php echo mb_substr($text, 0, 1000, mb_detect_encoding($text));?></p>
                                            <?php
                                          }
                                          ?>	
                                          <hr>
                
                                          <?php
                                                        $test_array = explode(" ", $res['label']);
                
                
                                                        foreach( $test_array as $name ){
                                                    
                                                          ?>
                                                          <li class="list-inline-item">
                                                            <a class="text-body" href="index.php?content=search&search=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
                                                          </li>                            
                                                          <?PHP
                                                          
                                                        } 
                                          ?>
                                          &nbsp
                
                                          &nbsp
                                          <a href="index.php?content=openBlog&idBlog=<?php echo $res['idBlog']?>" class="btn btn-light btn-sm">
                
                                          <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
                
                                          بازکردن با ...
                                          </a>
                                        </div>
                                        <!-- Card body END -->
                
                                      </div>
                                      <!-- Card END -->
                                    </div>
                                    
                                
                                </div>
                                <br>
                
                          <?php
                        }
                        ?>
                        <br>
                        <br>
                        <div id="addNowCode"></div>
                                            <button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
                            
                                                    <script>
                                                    
                                                    var loadBox = 0;
                                                    $('#loadMore').click(function(event){
                                                    event.preventDefault();
                                                    $('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
                                                    var z = Math.random()*10;
                                                    var code = '<div id="'+String(z)+'"></div>';
                                                    document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



                                                    $.ajax({
                                                        method: "POST",
                                                        url: "../../index.php?controller=home&method=loadPiper1",
                                                        data: { code: "1"}
                                                    })
                                                        .done(function(data){
                                                        document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
                                                        document.getElementById(z).innerHTML = data;
                                                    
                                                        })

                                                    })
                                                    </script>
                        <?php
                      }
                
                
                
                
                
                
                
                
                
                ?>













                
                </div>
			</div>
</section>
