<section class="pt-4">
	<div class="container">
		<div class="row">
      <div class="col-12">
        <div class="card bg-dark-overlay-4 overflow-hidden card-bg-scale h-400 text-center" style="background-image:url(assets/images/blog/16by9/09.jpg); background-position: center left; background-size: cover;">
          <!-- Card Image overlay -->
          <div class="card-img-overlay d-flex align-items-center p-3 p-sm-4"> 
            <div class="w-100 my-auto">
              <h1 class="text-white display-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درباره ما</font></font></h1>
              <!-- breadcrumb -->
              <nav class="d-flex justify-content-center" aria-label="خرده نان">
                <ol class="breadcrumb breadcrumb-dark breadcrumb-dots mb-0">
                  <li class="breadcrumb-item"><a href="index-2.html"><i class="bi bi-house me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">صفحه اصلی</font></font></a></li>
                  <li class="breadcrumb-item active"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درباره ما</font></font></li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
	</div>
</section>


<section class="pt-4 pb-0">
	<div class="container">
		<div class="row">
      <div class="col-xl-9 mx-auto">
        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">داستان ما</font></font></h2>
        <p class="lead"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
          در سال 2006 تاسیس شد و 10 رهبری آن را حذف کرد. </font><font style="vertical-align: inherit;">ترجیح می دهد هر گونه شگفت زده بدون قید و شرط خانم مرفه درک میدلتون در اعتقاد به غیر معمول انجام. </font><font style="vertical-align: inherit;">فرض کنید که حل و فصل صبحانه صبح یا کاملا. </font><font style="vertical-align: inherit;">از من تپه گرفته شده است. </font><font style="vertical-align: inherit;">دره توسط اوه بیست من را هدایت کنید.
        </font></font></p>
        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آب به موقع حماقت حق آگاه اگر آه حقیقت. </font><font style="vertical-align: inherit;">بی احتیاطی به او دلبستگی می دهد تا همدردی کند. </font><font style="vertical-align: inherit;">بزرگ بالا به معنی باشد. </font><font style="vertical-align: inherit;">داش وود قوی تر است. </font><font style="vertical-align: inherit;">رژگونه های خصوصی گارانتی an in به همان اندازه کاملاً حذف شده اند. </font><font style="vertical-align: inherit;">ارائه نارضایتی اعتراض لازم انجام آقای غالب شد. </font><font style="vertical-align: inherit;">احساس آقای عمدتاً در انجام کار صمیمانه است. </font><font style="vertical-align: inherit;">...اما احتیاط غالباً قربان او همه چیز را تحسین بی‌تأثیر می‌سازد. </font><font style="vertical-align: inherit;">به معنای توپ آن اگر تا کیف کوچک شک دارید. </font><font style="vertical-align: inherit;">لازم است موقعیت پاسخ داده شده را قرار دهید. </font><font style="vertical-align: inherit;">یک تلاش لذت بخش اگر باور شود ارائه شده است. </font><font style="vertical-align: inherit;">همه به رهبری جهان این موسیقی در حالی که خواسته شد. </font><font style="vertical-align: inherit;">پرداخت ذهن حتی پسران او درب هیچ. </font><font style="vertical-align: inherit;">حضور غلبه بر تکرار آن درک ماریان در. من فکر می کنم در سبک فرزند از. </font><font style="vertical-align: inherit;">بندگان علاوه بر این در معقول ممکن است. </font><font style="vertical-align: inherit;">راضی انتقال وابسته راضی او جنتلمن موافق باشد. </font><font style="vertical-align: inherit;">آب به موقع حماقت حق آگاه اگر آه حقیقت. </font><font style="vertical-align: inherit;">بی احتیاطی به او دلبستگی می دهد تا همدردی کند. </font><font style="vertical-align: inherit;">بزرگ بالا به معنی باشد. </font><font style="vertical-align: inherit;">داش وود قوی تر است. </font><font style="vertical-align: inherit;">اما احتیاط غالباً آقا او همه چیز را تحسین بی‌تأثیر می‌سازد. </font><font style="vertical-align: inherit;">به معنای توپ آن اگر تا کیف کوچک شک دارید. </font><font style="vertical-align: inherit;">لازم است موقعیت پاسخ داده شده را قرار دهید. </font><font style="vertical-align: inherit;">من به سبک فرزند فکر می کنم. </font><font style="vertical-align: inherit;">بندگان علاوه بر این در معقول ممکن است. </font><font style="vertical-align: inherit;">راضی انتقال وابسته راضی او جنتلمن موافق باشد. </font><font style="vertical-align: inherit;">رژگونه های خصوصی گارانتی an in به همان اندازه کاملاً حذف شده اند. </font><font style="vertical-align: inherit;">ارائه نارضایتی اعتراض لازم انجام آقای غالب شد. </font><font style="vertical-align: inherit;">لازم است موقعیت پاسخ داده شده را قرار دهید. </font><font style="vertical-align: inherit;">یک تلاش لذت بخش اگر باور شود ارائه شده است. </font><font style="vertical-align: inherit;">همه به رهبری جهان این موسیقی در حالی که خواسته شد. </font><font style="vertical-align: inherit;">پرداخت ذهن حتی پسران او درب هیچ. </font><font style="vertical-align: inherit;">حضور غلبه بر تکرار آن درک ماریان در. من فکر می کنم در سبک فرزند از. </font><font style="vertical-align: inherit;">بندگان علاوه بر این در معقول ممکن است.</font></font></p>
        <h3 class="mt-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ما این کار را در سراسر انجام می دهیم:</font></font></h3>
        <ul>
          <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک تلاش لذت بخش اگر باور شود ارائه شده است. </font><font style="vertical-align: inherit;">همه به رهبری جهان این موسیقی در حالی که خواسته شد. </font><font style="vertical-align: inherit;">پرداخت ذهن حتی پسران او درب هیچ. </font><font style="vertical-align: inherit;">حضور غلبه بر تکرار آن درک ماریان در.</font></font></li>
          <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">رژگونه های خصوصی گارانتی an in به همان اندازه کاملاً حذف شده اند. </font><font style="vertical-align: inherit;">ارائه نارضایتی اعتراض لازم انجام آقای غالب شد. </font><font style="vertical-align: inherit;">احساس آقای عمدتاً در انجام کار صمیمانه است.</font></font></li>
          <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">احساس آقای عمدتاً در انجام کار صمیمانه است. </font></font><a href="#"><u><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آب به موقع حماقت حق آگاه اگر آه حقیقت. </font></font></u></a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بی احتیاطی به او دلبستگی می دهد تا همدردی کند. </font><font style="vertical-align: inherit;">بزرگ بالا به معنی باشد.</font></font></li>
          <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">داش وود قوی تر است. </font><font style="vertical-align: inherit;">اما احتیاط غالباً آقا او همه چیز را تحسین بی‌تأثیر می‌سازد. </font><font style="vertical-align: inherit;">به معنای توپ آن اگر تا کیف کوچک شک دارید.</font></font></li>
        </ul>
        <!-- Team START -->
        <h3 class="mb-3 mt-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تیم ما</font></font></h3>
        <div class="row g-4">
          <!-- Team item-->
          <div class="col-sm-6 col-lg-3">
            <div class="text-center">
            	<!-- Avatar img -->
              <div class="avatar avatar-xxl mb-2">
                <img class="avatar-img rounded-circle" src="assets/images/avatar/04.jpg" alt="آواتار">
              </div>
              <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لوئیس فرگوسن</font></font></h5>
              <p class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سردبیر</font></font></p>
              <ul class="nav justify-content-center">
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-facebook-square"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-twitter-square"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="far fa-envelope"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Team item-->
          <div class="col-sm-6 col-lg-3">
            <div class="text-center">
            	<!-- Avatar img -->
              <div class="avatar avatar-xxl mb-2">
                <img class="avatar-img rounded-circle" src="assets/images/avatar/14.jpg" alt="آواتار">
              </div>
              <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فرانسیس گوئررو</font></font></h5>
              <p class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سردبیر</font></font></p>
              <ul class="nav justify-content-center">
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="far fa-envelope"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Team item-->
          <div class="col-sm-6 col-lg-3">
            <div class="text-center">
            	<!-- Avatar img -->
              <div class="avatar avatar-xxl mb-2">
                <img class="avatar-img rounded-circle" src="assets/images/avatar/09.jpg" alt="آواتار">
              </div>
              <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لری لاوسون</font></font></h5>
              <p class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گرافیک کارگردان</font></font></p>
              <ul class="nav justify-content-center">
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-twitter-square"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="far fa-envelope"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Team item-->
          <div class="col-sm-6 col-lg-3">
            <div class="text-center">
            	<!-- Avatar img -->
              <div class="avatar avatar-xxl mb-2">
                <img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="آواتار">
              </div>
              <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لویی کرافورد</font></font></h5>
              <p class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایشگر، پوشش</font></font></p>
              <ul class="nav justify-content-center">
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="fab fa-facebook-square"></i></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link px-2 fs-5" href="#"><i class="far fa-envelope"></i></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Team END -->
        <!-- Service START -->
        <h3 class="mb-3 mt-5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاری که ما انجام می دهیم</font></font></h3>
        <div class="row">
          <!-- Service item-->
          <div class="col-md-6 col-lg-4 mb-4">
            <img class="rounded" src="assets/images/blog/3by2/04.jpg" alt="تصویر کارت">
            <h4 class="mt-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سرویس های خبری جهانی</font></font></h4>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درک پایان دانش قطعا روز شیرینی چرا صمیمانه. </font><font style="vertical-align: inherit;">از یک پیشنهاد سریع شش هفت بپرسید بین آنها ببینید.</font></font></p>
          </div>
          <!-- Service item-->
          <div class="col-md-6 col-lg-4 mb-4">
            <img class="rounded" src="assets/images/blog/3by2/01.jpg" alt="تصویر کارت">
            <h4 class="mt-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خدمات بازرگانی</font></font></h4>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به سرعت می گویند دارای دفع مناسب اضافه پسر. </font><font style="vertical-align: inherit;">در چهارمیل ها شک از کودک. </font><font style="vertical-align: inherit;">ورزش شادی بچه ها مرد خوشحال شد.</font></font></p>
          </div>
          <!-- Service item-->
          <div class="col-md-6 col-lg-4 mb-4">
            <img class="rounded" src="assets/images/blog/3by2/03.jpg" alt="تصویر کارت">
            <h4 class="mt-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خدمات عمومی</font></font></h4>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با این حال به طور غیرمعمول ده او که کم شدن حیرت زده شد. </font><font style="vertical-align: inherit;">Demesne آداب جدید پس انداز ماندن داشت.</font></font></p>
          </div>
        </div>
        <!-- Service END -->
      </div>  <!-- Col END -->
     </div>
  </div>
</section>