<?php
if(! isset($_GET['idBlog'])){
    die();
}

$query121212 = mysqli_query($con, 'select * from blogs where idBlog='.$_GET['idBlog'].' and published=1;');
$blog = mysqli_fetch_assoc($query121212);
if(! $blog){
  die();
}

$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$blog['userId'].'"'));
$some_time = strtotime($blog['createDate']);
?>
<title><?php echo $blog['title']?> - <?php echo $us['username']?> | piperline,LLC.</title>
<!-- =======================
Inner intro START -->
<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9 mx-auto pt-md-5">
        <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>پیپر</a>
				<h1 class="display-4"><?php echo $blog['title']?></h1>
        <p class="lead">												<?php
														if(strlen($blog['descrip']) > 5){
															?>
															<p class="card-text"><?php echo $blog['descrip']?></p>
															<br>
															<?php
														}?></p>
                                                        										<?php
																					$test_array = explode(" ", $blog['label']);
	
	
																					foreach( $test_array as $name ){
																			
																						?>
																						<li class="list-inline-item">
																							<a class="text-body" href="index.php?content=search&search=<?php echo $name?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">#<?php echo $name?></font></font></a>
																						</li>                            
																						<?PHP
																						
																					} 
														?>
        <!-- Info -->
        <ul class="nav nav-divider align-items-center">
          <li class="nav-item">
            <div class="nav-link">
            <a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="text-reset btn-link"><?php echo $us['username']?></a>
            </div>
          </li>
          <li class="nav-item"><?php echo date('Y, d F', $some_time)?></li>
          <li class="nav-item">5 min read</li>
        </ul>
        
      </div>
    </div>
	</div>
</section>
<!-- =======================
Inner intro END -->

<!-- =======================
Main START -->
<section class="pt-0">
	<div class="container position-relative">
		<div class="row">
			<!-- Main Content START -->
			<div class="col-lg-9 mx-auto">
      	<p><span class="dropcap bg-primary bg-opacity-10 text-primary px-2">R</span><?php			$text = $blog['blog'];
															?>
															<div><?php echo $text?></div>
															 </p>

				

				<!-- Divider -->
				<div class="text-center h5 mb-4">. . .</div>

				<!-- Images -->
				
				
				
				
				
				

				<!-- blockquote -->
				

				

				
				

				<!-- Author info START -->
				<div class="d-flex p-2 p-md-4 mt-5 border rounded">
					<!-- Avatar -->
					<a href="#">
						<div class="avatar avatar-xxl me-2 me-md-4">
							<img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
						</div>
					</a>
					<!-- Info -->
					<div>
						<div class="d-sm-flex align-items-center justify-content-between">
							<div>
								<h4 class="m-0"><a href="index.php?content=profile&id=<?php echo $us['iduser']?>"><?php echo $us['username']?></a><?php
																			if($us['admin'] == 1){
																				?>
																				<i class="bi bi-patch-check-fill text-info small"></i>
																				<?php
																			}
																			?></h4>
								<small><?php echo $us['job']?></small>
							</div>
							<a href="index.php?content=profile&id=<?php echo $us['iduser']?>" class="btn btn-xs btn-primary-soft">بازدید نمایه</a>
                            
															<?php
                            
                            $follow_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" and user_follow_id="'.$us['iduser'].'"');
                            $follow = mysqli_fetch_assoc($follow_hash);
                            if($follow){
                                ?>
                                <a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو دنبال کردن</font></font></a>
                                <?php
                            }else{
                                ?>
                                <a id="follow<?php echo $us['iduser']?>" href="#" class="btn btn-primary-soft mb-0 btn-xs"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                                <?php 
                            }
                            ?>   

                            <script>
                                $('#follow<?php echo $us['iduser']?>').click(function(event){
                                event.preventDefault();
                                $('#follow<?php echo $us['iduser']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                $.ajax({
                                    method: "POST",
                                    url: "../../index.php?controller=create&method=follow&id=<?php echo $us['iduser']?>",
                                    data: { code: "1"}
                                })
                                    .done(function(data){
                                    $('#follow<?php echo $us['iduser']?>').html(data);
                                    })

                                })
                            </script>
						</div>
						<p class="my-2"><?php echo $us['about']?></p>
						<!-- Social icons -->
						<ul class="nav">
							<li class="nav-item">
								<a class="nav-link ps-0 pe-2 fs-5" href="#"><i class="fab fa-facebook-square"></i></a>
							</li>
							<li class="nav-item">
								<a class="nav-link px-2 fs-5" href="#"><i class="fab fa-twitter-square"></i></a>
							</li>
							<li class="nav-item">
								<a class="nav-link px-2 fs-5" href="#"><i class="fab fa-linkedin"></i></a>
							</li>
						</ul>					
					</div>
				</div>
				<!-- Author info END -->

        <!-- Next prev post START -->
				<div class="row g-0 mt-5 mx-0 border-top border-bottom">
					<div class="col-sm-6 py-3 py-md-4">
						<div class="d-flex align-items-center position-relative">
							<!-- Icon -->
							<div class="bg-primary py-1">
								<i class="bi bi-chevron-compact-left fs-3 text-white px-1 rtl-flip"></i>
							</div>
							<!-- Title -->
							<div class="ms-3">
								<h5 class="m-0"> <a href="#" class="stretched-link btn-link text-reset">Around the web: 20 fabulous infographics about business</a></h5>
							</div>
						</div>
					</div>
					<div class="col-sm-6 py-3 py-md-4 text-sm-end">
						<div class="d-flex align-items-center position-relative">
							<!-- Title -->
							<div class="me-3">
								<h5 class="m-0"> <a href="#" class="stretched-link btn-link text-reset">12 worst types of business accounts you follow on Twitter</a></h5>
							</div>
							<!-- Icon -->
							<div class="bg-primary py-1">
								<i class="bi bi-chevron-compact-right fs-3 text-white px-1 rtl-flip"></i>
							</div>
						</div>
					</div>
				</div>
				<!-- Next prev post START -->



                <div id="addNowCode"></div>
									<button class="btn btn-dark-soft w-100" type="button" id="loadMore"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بخوانید ...</font></font></button>
					
											<script>
											
											var loadBox = 0;
                                            $('#loadMore').click(function(event){
                                            event.preventDefault();
                                            $('#loadMore').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال خواندن...');
											var z = Math.random()*10;
											var code = '<div id="'+String(z)+'"></div>';
											document.getElementById('addNowCode').innerHTML = document.getElementById('addNowCode').innerHTML + code;



                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=home&method=loadPiper1",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
												document.getElementById('loadMore').innerHTML = 'بیشتر بخوانید ...';
												document.getElementById(z).innerHTML = data;
                                               
                                                })

                                            })
                                            </script>

			</div>
			<!-- Main Content END -->
		</div>
	</div>
</section>
<!-- =======================
Main END -->

<!-- =======================
Tag and share END -->
<section class="pt-0">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 mx-auto">
				<div class="text-center">
					<!-- Share -->
					<div class="list-group-inline list-unstyled">
						<h6 class="mt-2 me-4 d-inline-block"><i class="fas fa-share-alt me-2"></i>Share on:</h6>
						<ul class="list-inline list-unstyled d-inline-block">
							<li class="list-inline-item"><a href="#" class="me-3 text-body">Facebook</a></li>
							<li class="list-inline-item"><a href="#" class="me-3 text-body">Twitter</a></li>
							<li class="list-inline-item"><a href="#" class="me-3 text-body">Dribble</a></li>
						</ul>
					</div>
					<!-- Tags -->
					<ul class="list-inline text-primary-hover mt-0 mt-lg-3">
					  <li class="list-inline-item">
					  	<a class="text-body" href="#">#agency</a>
					  </li>
					  <li class="list-inline-item">
					  	<a class="text-body" href="#">#business</a>
					  </li>
					  <li class="list-inline-item">
					  	<a class="text-body" href="#">#theme</a>
					  </li>
					  <li class="list-inline-item">
					  	<a class="text-body" href="#">#bootstrap</a>
					  </li>
					  <li class="list-inline-item">
					  	<a class="text-body" href="#">#marketing</a>
					  </li>
					</ul>
				</div>
			</div> <!-- row END -->
		</div>
	</div>
</section>
<!-- =======================
Tag and share END -->

