<section>
	<div class="container">
		<div class="row">
      <div class="col-md-9 mx-auto text-center">
        <h1 class="display-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با ما تماس بگیرید</font></font></h1>
        <!-- breadcrumb -->
        <nav class="d-flex justify-content-center" aria-label="خرده نان">
          <ol class="breadcrumb breadcrumb-dots mb-0">
            <li class="breadcrumb-item"><a href="index-2.html"><i class="bi bi-house me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">صفحه اصلی</font></font></a></li>
            <li class="breadcrumb-item active"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با ما تماس بگیرید</font></font></li>
          </ol>
        </nav>      
      </div>
    </div>
	</div>
</section>


<section class="pt-4">
	<div class="container">
		<div class="row">
      <div class="col-xl-9 mx-auto">
        <iframe class="w-100 h-300 grayscale" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343008!2d-74.00425878428698!3d40.74076684379132!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259bf5c1654f3%3A0xc80f9cfce5383d5d!2sGoogle!5e0!3m2!1sen!2sin!4v1586000412513!5m2!1sen!2sin" height="500" style="border:0;" aria-hidden="false" tabindex="0"></iframe>	
        
        
        <div class="row mt-5">
          <div class="col-sm-6 mb-5 mb-sm-0">
            <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تبلیغات / حمایت مالی</font></font></h3>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با ما تماس بگیرید تبلیغات مربوط به طور مستقیم</font></font></p>
            <address><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2492 Centennial NW، Acworth، GA، 30102</font></font></address>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تماس بگیرید: </font></font><a href="#" class="text-reset"><u><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(678) 324-1251 (رایگان)</font></font></u></a></p>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایمیل: </font></font><a href="#" class="text-reset"><u><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">advertise@example.com</font></font></u></a></p>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">زمان پشتیبانی: دوشنبه تا شنبه 
               </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
              9:30 صبح تا 6:00 بعد از ظهر
            </font></font></p>
          </div>
          <div class="col-sm-6">
            <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات تماس</font></font></h3>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با ما تماس بگیرید تا ببینید چگونه می توانیم در مورد درخواست شما به شما کمک کنیم</font></font></p>
            <address><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">750 Sing Sing Rd, Horseheads, NY, 14845</font></font></address>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تماس: </font></font><a href="#" class="text-reset"><u><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2410-537-469 (رایگان)</font></font></u></a></p>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایمیل: </font></font><a href="#" class="text-reset"><u><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">contact@example.com</font></font></u></a></p>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">زمان پشتیبانی: دوشنبه تا شنبه 
               </font></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
              9:00 صبح تا 5:30 بعد از ظهر
            </font></font></p>
          </div>
        </div>
        
        
        
        
      </div>  <!-- Col END -->
     </div>
  </div>
</section>