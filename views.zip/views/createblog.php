
<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaEasy.js">
<script>   
    xinha_options = 
    {
      xinha_plugins:  [ 
         'minimal', 
         { from: '/path/to/xinha-cdn/plugins', load: ['MootoolsFileManager', 'Linker'] }
      ],
      
      // This is where you set the other default configuration globally
      xinha_config:            function(xinha_config) 
      {
        
        // Configure the plugins as you normally would here (consult plugin documentation)
        
      }
    }

</script>
<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaCore.js">
<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaLoader.js">
    xinha_options =
    {
      xinha_editors:  'textarea.some-css-class'
    }
</script>

<?php
if(isset($_GET['id'])){
    $query121212 = mysqli_query($con, 'select * from blogs where idBlog='.$_GET['id'].' and userId='.$_SESSION['id'].';');
    $blog = mysqli_fetch_assoc($query121212);
    if(! $blog){
      die();
    }

    ?>
    <section class="py-4">
                <div class="container">
                <div class="row pb-4">
                        <div class="col-12">
                    <!-- Title -->
                                <h1 class="mb-0 h2"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16" style="color: black;">
                                <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                                </svg> نوشتن پیپیرز </h1>
                        </div>
                        <strong style="text-align: left;"><a href="dashboard.php?content=profile&id=<?php echo $_SESSION['id']?>&page=6"><i class="bi bi-plus-square-dotted"></i> پیپرز های من</a></strong>

                    </div>
                    

                    
                    <div class="row">
                        <div class="col-12">
                            <!-- Chart START -->
                            <div class="card border">
                                <!-- Card body -->
                                <div class="card-body" id="displayRoom">
                                <?php
                                if(isset($_GET['alert'])){
                                    ?>
                                    <div class="alert alert-primary" role="alert">
                                    متاسفیم ما نمیتوانیم این را پردازش کنیم با خط مشی های ما مداخلت دارد 
                                    </div>
                                    <?php
                                }
                                ?>
                        <!-- Form START -->
                        <form action="../../index.php?controller=create&method=editPiper&id=<?php echo $blog['idBlog']?>" method="POST" id="pipers">
                        <!-- Main form -->
                        <div class="row">
                            <div class="col-12">
                            <!-- Post name -->
                            <div class="mb-3">
                            <div class="col-12">
                                <!-- Post name -->
                                <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></label>
                                    <input required="" id="con-name" name="title" type="text" value="<?php echo $blog['title']?>" class="form-control" placeholder="نام پست">
                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عنوان کوتاهی برای پیپیرز خود بگذارید</font></font></small>
                                </div>
                                </div>


                                
                            </div>
                    
                        <hr>


                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><i class="bi bi-braces-asterisk"></i> پیپرز شما</label>
                          
 
                                <textarea class="some-css-class" name="txt" style="width: 100%; height: 1000px; border:none;"><?php echo $blog['blog']?></textarea>
                            
                            </div>


                        <!-- Post type END -->
                        
                        <!-- Short description -->
                        

                            <!-- Post name -->
                            

                        <!-- Main toolbar -->



                            <!-- Post name -->
                            

                            <!-- Post name -->
                            


                            
                            
                            
                            
                                            
                            

                            


                            <!-- Post name -->
                            




                            
                            <!-- Create post button -->
                            <div class="col-md-12 text-start">
                                <button class="btn btn-primary w-100" id="subBTN" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش پیپر</font></font></button>
                            </div>
                        </div>
                        </form>



                        <!-- Form END -->
                                </div>
                            </div>
                            <!-- Chart END -->
                    </div>
                </div>
                </div>
    </section>
    <?php
}else{
    ?>
    <section class="py-4">
                <div class="container">
                <div class="row pb-4">
                        <div class="col-12">
                    <!-- Title -->
                                <h1 class="mb-0 h2"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16" style="color: black;">
                                <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                                </svg> نوشتن پیپیرز </h1>
                        </div>
                        <strong style="text-align: left;"><a href="dashboard.php?content=profile&id=<?php echo $_SESSION['id']?>&page=6"><i class="bi bi-plus-square-dotted"></i> پیپرز های من</a></strong>

                    </div>
                    

                    
                    <div class="row">
                        <div class="col-12">
                            <!-- Chart START -->
                            <div class="card border">
                                <!-- Card body -->
                                <div class="card-body" id="displayRoom">
                                <?php
                                if(isset($_GET['alert'])){
                                    ?>
                                    <div class="alert alert-primary" role="alert">
                                    متاسفیم ما نمیتوانیم این را پردازش کنیم با خط مشی های ما مداخلت دارد 
                                    </div>
                                    <?php
                                }
                                ?>
                        <!-- Form START -->
                        <form action="../../index.php?controller=create&method=createPiper" method="POST" id="pipers">
                        <!-- Main form -->
                        <div class="row">
                            <div class="col-12">
                            <!-- Post name -->
                            <div class="mb-3">
                            <div class="col-12">
                                <!-- Post name -->
                                <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></label>
                                    <input required="" id="con-name" name="title" type="text" class="form-control" placeholder="نام پست">
                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عنوان کوتاهی برای پیپیرز خود بگذارید</font></font></small>
                                </div>
                                </div>


                                
                            </div>
                    
                        <hr>


                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><i class="bi bi-braces-asterisk"></i> پیپرز شما</label>
                                <br>
                                <?php
                                if(isset($_GET['msg'])){
                                    $message= $_GET['msg'];
                                }else{
                                    $message= '';
                                }?>
                                <textarea class="some-css-class" name="txt" style="width: 100%; height: 1000px; border:none;"><?php echo $message?></textarea>
                            
                            </div>


                        <!-- Post type END -->
                        
                        <!-- Short description -->
                        

                            <!-- Post name -->
                            

                        <!-- Main toolbar -->



                            <!-- Post name -->
                            

                            <!-- Post name -->
                            


                            
                            
                            
                            
                                            
                            

                            


                            <!-- Post name -->
                            




                            
                            <!-- Create post button -->
                            <div class="col-md-12 text-start">
                                <button class="btn btn-primary w-100" id="subBTN" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایجاد پست</font></font></button>
                            </div>
                        </div>
                        </form>



                        <!-- Form END -->
                                </div>
                            </div>
                            <!-- Chart END -->
                    </div>
                </div>
                </div>
    </section>
    <?php
}
?>
