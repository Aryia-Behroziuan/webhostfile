
<?php
if(isset($_SESSION['ACC-KEY'])){
  ?>
  <script type='text/javascript'>window.location.href='dashboard.php?content=ACCError'</script>
  <?php
  die();
}
?>
<audio controls autoplay style="display: none;">
  <source src="https://www.qitsource.ir/public/audio.mp3" type="audio/mpeg">
</audio>

<section class="py-4">
	<div class="container">
    <div class="row pb-4">

			<?PHP 
			if(isset($_GET['alert1'])){
				?>
				<div class="alert alert-success" role="alert">
				<i style="width: 35px;" class="bi bi-exclamation-triangle"></i> <?php echo $_GET['alert1']?>
				</div>
				<?php
			}
			?>
			<?PHP 
			if(isset($_GET['alert'])){
				?>
				<div class="alert alert-danger" role="alert">
				<i style="width: 35px;" class="bi bi-exclamation-triangle"></i> <?php echo $_GET['alert']?>
				</div>
				<?php
			}
			?>




			  				<div class="card border-6 mb-4">
								<div class="bg-primary p-5 rounded-4">
									<div class="d-flex justify-content-between align-items-start text-white">
										<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
										<path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
										<path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
										<path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
										<path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
										<path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
										</svg>
										<!-- Card action START -->
										<div class="dropdown">
											<a class="text-white" href="#" id="creditcardDropdown" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
												<!-- Dropdown Icon -->
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<circle fill="currentColor" cx="12.5" cy="3.5" r="2.5"></circle>
													<circle fill="currentColor" opacity="0.5" cx="12.5" cy="11.5" r="2.5"></circle>
													<circle fill="currentColor" opacity="0.3" cx="12.5" cy="19.5" r="2.5"></circle>
												</svg>
											</a>               
											<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="creditcardDropdown">
												<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card-2-front-fill me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش کارت</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کارت جدید اضافه کنید</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-arrow-bar-down me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پول برداشت</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-calculator me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبدل ارز</font></font></a></li>
											</ul>
										</div>
										<!-- Card action END -->
									</div>
									<div class="mt-4 text-white">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اعتبار شما</font></font></span>
										<h2 class="text-white mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo number_format($user['charge'] , 0 , "." , "," )?> تومان</font></font></h2>
									</div>
									<h4 class="text-white mt-4"><font style="vertical-align: inherit;">QP<font style="vertical-align: inherit;">  "PL<?php echo $user['iduser']?>" </font></font></h4>
									<div class="d-flex justify-content-between text-white">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالک حقیقی : <?php echo $user['title']?></font></font></span>
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قدرت یافته:</font> qitSource,LLC <br> Piperline</font></span>
									</div>
								</div>
							</div>

			

			<div class="col-12">
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center">
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/wallet-5568743-4644460.mp4" style="width: 70px; height: 70px;" type="video/mp4" autoplay="autoplay" loop="loop"></video> کیف پول</font></font></h1>			
					<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تومان <?php echo number_format($user['charge'] , 0 , "." , "," )?>   </font></font></a>
				</div>
			</div>
		</div>
		<div class="row g-4">


			<div class="col-md-6 col-xl-4">
				<!-- Category item START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<div class="d-flex align-items-center">
							<div class="icon-lg shadow bg-body rounded-circle"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">⛰️</font></font></div>
							<h3 class="mb-0 ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img style="width: 150px;" src="https://way2pay.ir/wp-content/uploads/IDPay-Logo-Png-Way2pay-96-03-06.png" alt=""> </font></font></h3>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ شارژ به ریال</font></font></label>
                            <input class="form-control" name="pay" type="text" placeholder="مبلغ را وارد کنید">
                        </div>
						<!-- Followers and Post -->
						<div class="d-flex justify-content-between">
							<!-- Total post -->
							<div>
								<h5 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">846</font></font></h5>
								<h6 class="mb-0 fw-light"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کل پست ها</font></font></h6>
							</div>

							<!-- Avatar group -->
							<ul class="avatar-group mb-0">
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/02.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/03.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
								</li>
							</ul>
						</div>
						
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
                    <button type="submit" class="btn btn-primary-soft w-100 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پرداخت</font></font></button>
					</div>
				</div>
				<!-- Category item END -->
			</div>

			<div class="col-md-6 col-xl-4">
				<!-- Category item START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<div class="d-flex align-items-center">
							<div class="icon-lg shadow bg-body rounded-circle"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">🤖</font></font></div>
							<h3 class="mb-0 ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img style="width: 150px;" src="https://way2pay.ir/wp-content/uploads/Zarin-Pal-Logo-JPG-Way2pay-97-02-26.jpg" alt=""></font></font></h3>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ شارژ به ریال</font></font></label>
                            <input class="form-control" name="pay" type="text" placeholder="مبلغ را وارد کنید">
                        </div>
						<!-- Followers and Post -->
						<div class="d-flex justify-content-between">
							<!-- Total post -->
					

							<!-- Avatar group -->
							<ul class="avatar-group mb-0">
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/11.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/12.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
								</li>
							</ul>
						</div>
						
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
                    <button type="submit" class="btn btn-primary-soft w-100 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> پرداخت</font></font></button>
					</div>
				</div>
				<!-- Category item END -->
			</div>
	
			

			<div class="col-md-6 col-xl-4">
				<!-- Category item START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<div class="d-flex align-items-center">
							<div class="icon-lg shadow bg-body rounded-circle"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">🤖</font></font></div>
							<h3 class="mb-0 ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/PayPal.svg/1200px-PayPal.svg.png" style="width: 150px;" alt=""> </font></font></h3>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به معنای توپ آن اگر تا کیف کوچک شک دارید. </font><font style="vertical-align: inherit;">لازم است موقعیت پاسخ داده شده را قرار دهید.</font></font></p>

						<!-- Followers and Post -->
						<div class="d-flex justify-content-between">
							<!-- Total post -->
							<div>
								<h5 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">846</font></font></h5>
								<h6 class="mb-0 fw-light"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کل پست ها</font></font></h6>
							</div>

							<!-- Avatar group -->
							<ul class="avatar-group mb-0">
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/11.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/12.jpg" alt="آواتار">
								</li>
								<li class="avatar avatar-xs">
									<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
								</li>
							</ul>
						</div>
						
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
             <a href="#" class="btn btn-primary-soft w-100 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده پست ها</font></font></a>
					</div>
				</div>
				<!-- Category item END -->
			</div>

			<div class="col-md-6 col-xl-4">
				<!-- Category item START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<div class="d-flex align-items-center">
							<div class="icon-lg shadow bg-body rounded-circle"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/setting-5192257-4340262.mp4" type="video/mp4" autoplay="autoplay" style="width: 70px;" loop="loop"></video></font></font></div>
							<h3 class="mb-0 ms-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">واریز به حسابی دیگر</font></font></h3>
						</div>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">
						<p><font style="vertical-align: inherit;">میتوانید موجودی کیف پول خود را به حساب اشخاص دیگر انتقال دهید با داشتن شناسه مشتری انها</font></p>
						
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
             			<a href="../../core/rtl/dashboard.php?content=cartToCart" class="btn btn-primary-soft"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">باز کنید</font></font></a>
             			<a href="../../core/rtl/dashboard.php?content=recive" class="btn btn-primary-soft"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیگیری</font></font></a>
					</div>
				</div>
				<!-- Category item END -->
			</div>


			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تراکنش ها</font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">105</font></font></span></h5>
							<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک پست ایجاد کنید</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">

						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							<div class="col-md-8">
								<form action="" method="POST" class="rounded position-relative">
									<input name="search" class="form-control pe-5 bg-transparent" type="search" placeholder="جستجو کردن" aria-label="جستجو کردن">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>

							<!-- Select option -->
							<div class="col-md-3">
								<!-- Short by filter -->
								<form>
									<select class="form-select z-index-9 bg-transparent" aria-label=".form-sect-sm">
										<option value="">مرتب سازی بر اساس</option>
										<option>رایگان</option>
										<option>جدیدترین</option>
										<option>قدیمی ترین</option>
									</select>
								</form>
							</div>
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						<div class="table-responsive border-0">
							<table class="table table-dark-gray align-middle p-4 mb-0 table-hover table-shrink">
								<!-- Table head -->
								<thead>
									<tr>
										<th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه تراکنش</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ</font></font></th>
									</tr>
								</thead>

								<!-- Table body START -->
								<tbody>


								<?php
								if(isset($_POST['search'])){
									$query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE (`id` LIKE "%'.$_POST['search'].'%" or `createDate` LIKE "%'.$_POST['search'].'%" or `data` LIKE "%'.$_POST['search'].'%" or `wiki` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%") and userId="'.$_SESSION['id'].'" and rol="payment" order by createDate Desc');
									$file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE (`id` LIKE "%'.$_POST['search'].'%" or `createDate` LIKE "%'.$_POST['search'].'%" or `data` LIKE "%'.$_POST['search'].'%" or `wiki` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%") and userId="'.$_SESSION['id'].'" and rol="payment" order by createDate Desc');
									$file = mysqli_fetch_assoc($query_1212);
								}else{
									$query_1212 = mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and rol="payment" order by createDate Desc');
									$file_hash = mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and rol="payment" order by createDate Desc');
									$file = mysqli_fetch_assoc($query_1212);
								}
								if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
										?>
										<!-- Table item -->
										<tr>
											<!-- Table data -->
											<td>
												<h6 class="course-title mt-2 mt-md-0 mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['data']?></font></font></a></h6>
											</td>
											<!-- Table data -->
											<td>
												<h6 class="mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?></font></font></a></h6>
											</td>
											<!-- Table data -->
											<td><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['name']?></font></font></span></td>
											<!-- Table data -->
											<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['createDate']?></font></font></td>
											<!-- Table data -->
											<td>
												<span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['payment']?></font></font></span>
											</td>
											<!-- Table data -->
											<td>
												<div class="d-flex gap-2">
													<a href="<?php echo $res['link']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="ویرایش کنید"><i class="bi bi-box-arrow-up-right"></i></a>
												</div>
											</td>
										</tr>
										<?php
									}
								}
								?>
		
		

								</tbody>
								<!-- Table body END -->
							</table>
						</div>
						<!-- Blog list table END -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>