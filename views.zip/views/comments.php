<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/chat-5590408-4652800.png?f=webp" style="width: 50px;" alt=""> تعاملات اخیر با شما</h1>
			</div>
		</div>


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						

                    





                    <?php 
							$posts = '1';
							$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$posts = $posts.','.$res['idPost'];
								}
							}
							?>

							<?php 
						
							$query_12121 = mysqli_query($con, 'select * from comment where piperlinePost IN ('.$posts.') order by time Desc limit 0,900');
							$file_hash1 = mysqli_query($con, 'select * from comment where piperlinePost IN ('.$posts.') order by time Desc limit 0,1000');
							$file1 = mysqli_fetch_assoc($query_12121);
							if($file1){
								while($res=mysqli_fetch_assoc($file_hash1)){
									$some_time = strtotime($res['time']);

									$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost='.$res['piperlinePost'].''));
									$us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));

									?>
									<!-- Comment item -->
									<div class="col-12">
										<div class="d-flex align-items-center position-relative">
											<!-- Avatar -->
											<div class="avatar avatar-lg flex-shrink-0">
												<img class="avatar-img rounded-2" src="<?php echo $us['avatar']?>" alt="avatar">
											</div>
											<!-- Info -->
											<div class="ms-3">
												<small><?php echo date('Y, d F', $some_time)?></small>
												<p class="mb-1"> <a class="h6 fw-normal stretched-link" href="dashboard.php?content=messages&id=<?php echo $post['idPost']?>"><?php echo $us['username']?> بر روی "<?php echo $post['title']?>" نوشت</a></p>
												<div class="d-flex justify-content-between">
													<p class="small mb-0"><?php echo $res['comment']?></p>
													s
												</div>
											</div>
										</div>
									</div>

									<!-- Divider -->
									<hr class="my-3">

									<?php
								}
							}else{
								?>
								<section class="overflow-hidden">
									<div class="container">
										<div class="row">
									<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
										<!-- SVG shape START -->
										<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
										<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
											<g>
											<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
											<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
											<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
											<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
											<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
											<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
											<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
											<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
											<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
											<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
											c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
											</g>
										</svg>
										</figure>
										<!-- SVG shape START -->
										<!-- Content -->
										<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
										<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تعاملی یافت نشد</font></font></h2>
										
									</div>
									</div>
									</div>
								</section>
								<?php
							}
							?>
                                        

					</div>
					<!-- Card body END -->


					</div>
					<!-- Card Footer END -->
				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    
	
</section>