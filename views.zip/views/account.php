<?php
if(isset($_SESSION['ACC-KEY'])){
  ?>
  <script type='text/javascript'>window.location.href='dashboard.php?content=ACCError'</script>
  <?php
  die();
}
?>
<section class="py-4">
    <div class="container">
            
        
        <div class="row">
            <div class="col-12">
                <!-- Chart START -->
                <div class="card border">
                    <!-- Card body -->
                    <div class="card-body">
               
                            
                     <!-- Profile dropdown START -->
						<!-- Profile info -->
						
							<div class="d-flex align-items-center">
								<!-- Avatar -->
								<div class="avatar me-3">
									<img class="avatar-img rounded-circle shadow" src="<?php echo $user['avatar']?>" alt="آواتار">
								</div>
								<div>
									<a class="h6 mt-2 mt-sm-0" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['username']?></font></font></a>
									<p class="small m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['email']?></font></font></p>
								</div>
							</div>
							<hr>

							<div class="card bg-transparent border rounded-3 mt-4">
							<!-- Card header -->
							<div class="card-header bg-transparent border-bottom p-3">
								<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرکز کنترل حساب</font></font></h5>
							</div>
							<!-- Card body START -->
							<div class="card-body">
								<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><i class="fab fa-google text-google-icon"></i></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گوگل</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما با موفقیت به حساب Google خود متصل شدید</font></font></p>
										<!-- Button -->
										<button type="button" class="btn btn-sm btn-danger mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فراخوانی کنید</font></font></button>
										<a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>


									<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
									<path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
									<path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
									<path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
									</svg></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">QPassID</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیوپس آیدی تکنولوژی مدیریت حساب های شرکت کوییت سورس است که برای استفاده از سرویس های شرکت کوییت سورس باید شناسه کیوپس آیدی داشته باشید شما با ورود به هر یک از سرویس های مجموعه کوییت سورس حساب کیوپس آیدی خود را راه اندازی میکنید و برای مدیریت حساب و مرکز کنترل اصلی به سایت رسمی کیوپس آیدی بروید</font></font></p>
										<!-- Button -->
										<a href="https://www.qitsource.ir" class="btn btn-sm btn-primary mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به مرکز کنترل بروید</font></font></button>
																				<a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>

									<!-- Blogger -->
									<!-- Blogger -->
									

							
								</div>
								<!-- Card body END -->
							</div>
						<br>

								<!-- Google -->
								

								<div class="list-group">

									<!-- Links -->
									<a style="font-size: 20px;" class="list-group-item list-group-item-action" href="dashboard.php?content=editProfile"><i class="bi bi-person fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مدیریت حساب</font></font></a></li>
									<a style="font-size: 20px;" class="list-group-item list-group-item-action" href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting"><i class="bi bi-gear fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات حساب</font></font></a></li>
									<a style="font-size: 20px;" class="list-group-item list-group-item-action" href="#"><i class="bi bi-info-circle fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کمک</font></font></a></li>
									<a style="font-size: 20px;" class="list-group-item list-group-item-action" href="https://www.piperline.ir/index.php?controller=account&method=swich"><i class="bi bi-person-plus"></i> <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب های شما</font></font></a></li>
									<a style="font-size: 20px;" class="list-group-item list-group-item-action" href="../../index.php?controller=account&method=logout"><i class="bi bi-power fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></a></li>
								
				
									<button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.qitsource.ir">qitSource,LLC</a></button>

								</div>



					
							
							
							<li style="font-size: 20px;" class="dropdown-divider mb-3"></li>
							
								<div style="font-size: 20px;" class="dropdown-item">
									<div class="modeswitch m-0" id="darkModeSwitch">
										<div class="switch"></div>
									</div>
								</div>
							
									
	

                    </div>
                </div>
                        <!-- Chart END -->
            </div>
        </div>    
    </div>    
</section>
    
		