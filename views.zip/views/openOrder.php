<?php
if(! isset($_GET['id'])){
	die();
}
$query = mysqli_query($con, 'select * from session where id="'.$_GET['id'].'"');
$ses = mysqli_fetch_assoc($query);
if($ses){
	$query12 = mysqli_query($con, 'select * from user where iduser="'.$ses['userId'].'"');
	$userSes = mysqli_fetch_assoc($query12);

	$query12 = mysqli_query($con, 'select * from posts where idPost="'.$ses['piperline'].'"');
	$post = mysqli_fetch_assoc($query12);

	mysqli_query($con, "
	UPDATE session
	SET
	  seen = '1'

	WHERE
	  id = '".$_GET['id']."';
	");


}else{
	die();
}
?>
<section class="pt-0 pt-lg-5">
	<div class="container">
		<div class="row g-4 justify-content-between">



				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سفارش مشتری</font></font></h5>
							&nbsp
							<?php
							if($post['status'] == '5'){
								if($ses['status'] == '0'){
									?>
									<a href="../../index.php?controller=create&method=cancelOrder&id=<?php echo $ses['id']?>" class="btn btn-danger btn-sm"> X کنسل کردن</a>
									<?php
								}
								?>
								&nbsp
								<?php
								
								if($ses['status'] == '0'){
									?>
									<a href="../../index.php?controller=create&method=enterOrder&id=<?php echo $ses['id']?>" class="btn btn-primary  btn-sm"><i class="bi bi-cart2 me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> تایید سفارش و دریافت پول</font></font></a>
									<?php
								}
								
							}
							?>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">

						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							
														<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>

							<!-- Select option -->
							
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						
						<!-- Blog list table END -->

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>





			<!-- Description -->
			<div class="col-lg-7">
				<h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات ارسالی </font></font></h5>
				<p><font style="vertical-align: inherit;"></font><?php echo $ses['wiki']?></p>

			</div>

			<!-- List START -->
			<div class="col-lg-4">
				<h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات خریدار</font></font></h5>
				<div class="d-flex align-items-center position-relative">
					<div class="avatar avatar-sm">
						<img class="avatar-img rounded-circle" src="<?php echo $userSes['avatar']?>" alt="آواتار">
					</div>
					<div class="ms-3">
						<h6 class="mb-0"><font style="vertical-align: inherit;"><?php echo $userSes['username']?></font></a></h6>

					</div>
				</div>
				<!-- List -->
				<div class="hstack gap-3 flex-wrap mt-2 mb-4">
					<a href="../../blogzine.webestica.com/rtl/dashboard.php?content=profile&id=<?php echo $userSes['iduser']?>" class="btn btn-secondary btn-sm">مشاهده پروفایل</a>

					<p class="mb-0"><i class="bi bi-star-fill text-warning"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">5.0 </font></font><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">میانگین امتیاز</font></font></span></p>
					<p class="mb-0"><i class="bi bi-patch-check-fill text-primary"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">99% </font></font><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازخورد مثبت</font></font></span></p>
					

				</div>


				<!-- Shipment information -->
				<h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات خرید </font></font></h5>
				<ul class="list-group list-group-borderless">
					<li class="list-group-item py-0">
						<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ پرداختی: </font></font></span>
						<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $ses['payment']?> تومان</font></font></span>
					</li>
					<li class="list-group-item py-0">
						<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> روش پرداخت: </font></font></span>
						<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیف پول پیپرلاین</font></font></span>
					</li>

				</ul>

			</div>
			<!-- List END -->
		</div>
	</div>
</section>

<section>
	<div class="container">
		<div class="row g-4 g-lg-0 justify-content-between">
			<!-- Image -->
			

			<!-- Detail -->
			<div class="col-lg-6">
				<!-- Title -->
				<h1><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات مخزن</font></font></h1>
				<p class="mb-4"><font style="vertical-align: inherit;">اطلاعات مربوط به مالکیت و پیگیری در سیستم را میتوانید در این قسمت مشاهده کنید توجه کنید که این اطلاعات را در اختیار کسی قرار ندهید</font></p>

				<!-- Rating -->
				<ul class="list-inline mb-0">
					<li class="list-inline-item me-0"><i class="fas fa-star text-warning"></i></li>
					<li class="list-inline-item me-0"><i class="fas fa-star text-warning"></i></li>
					<li class="list-inline-item me-0"><i class="fas fa-star text-warning"></i></li>
					<li class="list-inline-item me-0"><i class="fas fa-star text-warning"></i></li>
					<li class="list-inline-item me-0"><i class="fas fa-star-half-alt text-warning"></i></li>
					<li class="list-inline-item me-0 h6">4.5/5.0</li>
				</ul>
				<!-- List START -->
				<div class="bg-light p-3 rounded-2 mb-4">
					<div class="row g-2">
						<!-- List -->
						<div class="col-sm-6">
							<ul class="list-group list-group-borderless">
								<li class="list-group-item py-0">
									<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه سفارش: </font></font></span>
									<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $ses['id']?></font></font></span>
								</li>
								<li class="list-group-item pb-0">
									<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه محصول: </font></font></span>
									<span class="h6 mb-0"><a href="shop-grid.html"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['idPost']?></font></font></a></span>
								</li>
							</ul>
						</div>
						<!-- List -->
						<div class="col-sm-6">
							<ul class="list-group list-group-borderless">
								<li class="list-group-item py-0">
									<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه خریدار: </font></font></span>
									<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $userSes['iduser']?></font></font></span>
								</li>
								<li class="list-group-item pb-0">
									<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ ثبت سفارش: </font></font></span>
									<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $ses['createDate']?></font></font></span>
								</li>
							</ul>
						</div>
					</div>
				</div>	
				<!-- List END -->

		

				<!-- Price and button START -->
				<div class="row">
					<!-- Price -->
					<div class="col-md-4">
						<h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قیمت کل</font></font></h6>
						<h4 class="text-success"><?php echo $ses['payment']?> تومان</h4>
					</div>

					<div class="col-md-6">
						<a href="../../index.php?controller=create&method=enterOrder&id=<?php echo $ses['id']?>" class="btn btn-primary mb-0 w-100"><i class="bi bi-cart2 me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> تایید سفارش و دریافت پول</font></font></a>
						<p class="mb-0 mt-2 text-end small"><i class="bi bi-question-circle-fill text-primary me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کمک خواستن؟ </font></font><a href="#" class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اکنون چت کنید</font></font></a></p>
					</div>
				</div>
				<!-- Price and button END -->
			</div>
		</div>
	</div>
</section>





