<section class="py-4">
  <div class="container">
    <div class="row pb-4">
    

                    <nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active">کنترل حساب</li>
							<li class="breadcrumb-item active">دستور العمل های انجمن</li>
						</ol>
					</nav>


         <div class="accordion" id="accordionExample">

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    داده های این صفحه به کجا فرستاده میشود
                </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    شرکت کوییت سورس با ساختن تکنولوژی کیوپس آیدی با استفاده از این سرویس حساب های کاربری مربوط به شرکت خود را پشتیبانی میکند و شما با ثبت نام در سایت رسمی کوییت سورس و ثبت نام در هر یک از سرویس های شرکت ما مالک یک شناسه کیوپس آیدی میشوید و سپس تمامی داده های مربوط به حساب شما برای حساب مادر در دیتاسنتر کوییت سورس فرستاده میشود و اعمالی همچو تایید و خدماتی دیگر فقط توسط سایت کیوپس آیدی امکان پذیر است پس ما این دادگان را از شما دریافت کرده و به دیتاسنتر سرویس والد اکانت شما ارسال میکنیم تا مراحل را از آنجا طی کند اگر مایل باشید میتوانید خودتان هم این کار را بکنید و برای مدیریت حساب خود به اکانت سنتر مرکزی در کیوپس آیدی مراجعه کنید
                    <br>
                    <strong>مالکیت فناوری کیوپس آیدی مال خودمان است و اطلاعات شما به شرکت شخص ثالثی ارسال نمیگردد بلکه به دیتاسنتر مرکزی خودمان میرود</strong>
                    <br>
                    <strong><a href="https://www.qitsource.ir">مدیریت حساب</a></strong>  
                    ,
                    <strong><a href="dashboard.php?content=verifiACCdoc">شرایط و قوانین انجمن ما</a></strong>  
        
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    اعتبار سنجی حساب 
                </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ما همانند همه پلتفرم های دیجیتال خط مشی ها و قوانینی داریم که توسط انجمن هیعت مدیره ما تصویب شده است و کاربرنی که خواستار آن هستند باید از خط مشی ها و قوانین پلتفرم ما به شکل تام تبعیت کنند ما روی این نوع موضوع بسیار حساسیم تا بتوانیم افرادی را گرد هم جمع کنیم که دارای ارزش گذاری صحیح و کارامد باشند و این شروع تعهدیست که متقابلا به مشتریان و توسعه دهندگانمان داریم

                    <strong><a href="dashboard.php?content=verifiACCdoc">شرایط و قوانین انجمن ما</a></strong>  
                </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    داده ها سرتاسر رمزگذاری شده
                </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ما روی امنیت پلتفرم خودمان به شدت حساسیم و دادگان را سرتاسر سرویس های خود رمزگذاری میکنیم با روش های نوین رمزگذاری و به خوبی از داده هایتان محافظت خواهیم کرد میتوانید به ما اعتماد کنید تا بتوانیم شروع به یک دوستی و رشد جمعی کنیم دادگان شما تک تک مسیر هایی که طی میکند ما آن را در اختیار  شما میگذاریم و هر زمان بخواهید آن را در هر مرحله ای به شکل کامل غیر قابل بازیابی خواهیم کرد
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree1" aria-expanded="false" aria-controls="collapseThree">
                    هزینه این کار چقدر است برای چه شامل هزینه میشود
                </button>
                </h2>
                <div id="collapseThree1" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    مانند هر پلتفرمی در سرویس ماهم خدمات تایید حساب شامل مبلغی هزینه میشود این بدان معنا نیست که تایید حساب را میتوان با پول خرید در پلتفرم ما ابتدا در انجمن تایید میشوید و اعتبار سنجی انجام میشود و در صورت داشتن شرایط لازم دستورالعمل حسابتان تایید میشود و مبلغ از شما کسر میشود

                    <br>
                    <br>
                    مبلغ مصوب انجمن ما برای این کار 200,000 تومان میباشد که به صورت پس پرداخت از شما کسر خواهد شد
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree2" aria-expanded="false" aria-controls="collapseThree">
                   بعد از تایید حسابم چه امکاناتی را دارم
                </button>
                </h2>
                <div id="collapseThree2" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    شما بعد از تایید حسابتان موضف به پیروی از دستور العمل های انجمن ما میشوید و از آن پس میتوانید به عنوان توسعه دهنده ارشد و همکار ما فعالیت کنید شما امکان این را دارید که پست هایی بدون تایید مدیر را منتشر کنید و در هر جا در سرتاسر پلتفرم ما اسمی از شما برده میشود در کنار اسمتان یک تیک آبی رنگ دارید که نشانه تایید توسط ماست و در رنکینگ ها و الگوریتم ها مختلف به اکانت شما توجه ویژه ای میشود و این تاییدیه را در تمامی سرویس هایی که از تکنولوژی مربوط به حساب های کوییت سورس یعنی کیوپس آیدی پیروی میکنند دارید و این تاییدیه به برنامه های شخص ثالث ما هم منتقل میشود
                   
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree3" aria-expanded="false" aria-controls="collapseThree">
                   چه قوانینی را باید رعایت کنم
                </button>
                </h2>
                <div id="collapseThree3" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    به طور کل با این فعالیت شما متعهد میشود که از قوانین اینترنتی ایالاتی که در آن زندگی میکنید به شکل تام تبعیت کنید و علاوه بر آن دستور العمل های انجمن ما را هم جدی بگیرید                   
                <br>
                <br>
                <?php
                if($user['iran'] == 1){
                    $loc = 'ایران';
                }else{
                    $loc = $user['iran'];
                }
                ?>
                 موقعیت و ایالات شما<strong><?php echo $loc.','.$user['loc']?></strong> تعریف شده است
                </div>
                </div>
            </div>
        </div>







            <br>



        <div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مراحل تایید حساب</font></font></h5>
							<a href="dashboard.php?content=editProfile" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مدیریت حساب</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0">
								


                            <div class="row">
                            <div class="col-4 col-sm-3">
                                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">تکمیل اطلاعات حساب</a>
                                <a class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">اطلاعات هویتی</a>
                                <a class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">استعلام اطلاعات</a>
                                <a class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">نظر انجمن</a>
                                </div>
                            </div>
                            <div class="col-8 col-sm-9">
                                <div class="tab-content pt-0" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    قبل از هر چیزی اطلاعات حساب کاربری خود را از جمله نام حقیقی و درباره شما و اطلاعات مربوط به شرکت و ایالات  خود را وارد کنید تا ما بهتر بتوانیم شمارا بشناسیم و شرکت و جامعه تان را درک کنیم سعی کنید اطلاعات خود را به درستی وارد کنید چون اگر اطلاعات شما رد شود چند ماهی تعلیق میشوید
                                    <br>
                                    در قدم اول به قسمت تکمیل اطلاعات سرویس پیپرلاین بروید و اطلاعات خود را کامل کنید
                                    <br>
                                    
                                    <strong><a href="dashboard.php?content=editProfile">مدیریت محلی حساب</a></strong>
                                    <br>
                                    <br>
                                    درگام دوم به وبسایت کیوپس آیدی رفته و به حساب خود متصل شوید و در قسمت اکانت سنتر اطلاعات بیشتر مانند شرکت و محل کار و تحصیلات و دانشگاه و... را پر کنید 
                                    <br>
                                    
                                    <strong><a href="https://www.qitsource.ir">مدیریت حساب</a></strong>
                                    <br>
                                    <br>
                                    <strong>نواقص حساب شما</strong>
                                    <br>
                                    <?php
                                    $strok = 0;
                                    if(strlen($user['phoneNumber']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا شماره موبایل خود را به درستی وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['title']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا نام حقیقی و اصلی خود را وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['loc']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا ایالات خود را وارد کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['job']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                           لطفا عنوان شغلی خود را وارد کنید     
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['about']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                           لطفا در باره خود کمی توضیحات به ما بدهید  
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['url']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا وبسایت شخصی خود را وارد کنید و یا اگر وبسایت ندارید آدرس وبلاگ یا یکی از شبکه اجتماعی های معتبر را بدهید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    if(strlen($user['codefoxs']) < 2){
                                        $strok = $strok+1;
                                        ?>
                                        <div class="alert alert-primary" role="alert">
                                            <i class="bi bi-exclamation-circle"></i>
                                            لطفا لینک رزومه خود را وارد کنید تا بتوانیم حقیق کاری و علمی را درباره شما بدانیم اگر رزومه ندارید مانعی نیست آن فیلد را با یک لینک از شبکه های اجتماعی خود پر کنید
                                            <a href="dashboard.php?content=editProfile"><i class="bi bi-box-arrow-up-right"></i></a>
                                        </div>
                                        <?php
                                    }
                                    
                                    ?>

                                    <?php
                                    if($strok == 0){
                                        ?>
                                        <strong style="color: #4387FF;">تبریک میگوییم حساب شما هیچ نقصی جهت اقدام به شروع مراحل تایید حساب ندارد اکنون میتوانید مراحل بعد را طی کنید</strong>

                                        <?php
                                    }else{
                                        ?>
                                        <strong style="color: #E35959;">حساب کاربری شما <?php echo $strok?> نقص دارد که از شما خواهشمندیم آن را مطالعه و تصحیح کنید و از صحت آن اطمینان حاصل کنید زیرا اگر اطلاعات ورودی شما نادرست باشد از درخواست مجدد برای دریافت تاییده تا شش ماه منبع خواهید شد پس لطفا جدی بگیرید</strong>
                                        <?php
                                    }
                                    ?>
                                    </div>
                                    
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    در این قسمت شما باید مدارک هویتی خود را برای ما بارگذاری کنید تا ما بتوانیم بهتر شمارا بشناسیم و برای تایید ما باید نشانه هایی از شهرت و یا مشروهیت این بدان معنی نیست که فقط افراد مشهور میتوانند تایید شوند شما میتوانید یک انسان کاملا متفاوت باشید اما تایید شوید همه چیز به نظر انجمن در باره شما بستگی دارد
                                    <br>
                                    <br>
                                    <strong>اطلاعات هویتی به شرح زیر است</strong> 
                                    <br>
                                    <small>درگام نخست یک عکس از صفحه اصلی شناسنامه محلی خود در هر ایالات و یا کشوری که هستید برای ما ارسال میکنید</small>    
                                    <br>
                                    <br>
                                    <small>در گام دوم عکس کارت ملی و یا پاسپورت خود را ارسال کنید برای افرادی که در ایالات ممنوعه زندگی  میکنند و یا زیر سن قانونی هستند در این بخش همان عکس شناسنامه خود را ارسال کنند</small>
                                    <br>
                                    <br>
                                    <small> درگام سوم شما باید شناسنامه و یا کارت ملی و یا پاسپورت خود را در کنار صورت خود گرفته و به شکلی که محتوای کارت هویتی و صورت شما در عکس کاملا واضح بیفتد</small>&nbsp<small>ارسال کنید</small>
                                    <br>
                                    <br>
                                    <small>گام چهارم مخصوص صاحبان شرکت است که بر روی یک کاغذ نمونه ای از امضای خود را کشیده و عکس گرفته و ارسال کنید افرادی که اشخاص حقیق هستند لازم به ارسال این مدرک ندارد و فیلد آن را خالی بگذارید</small>
                                </div>
                                <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                                    ما در این مرحله پیشینه و استعداد ها و هر اطلاعاتی که در اختیار داریم را تحلیل کرده و سپس از تایید به انجمن میروید
                                    </div>
                                <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                                    در این قسمت ما در یک انجمن چند نفره راجب شما گفتگو میکنیم و در صورت تایید حساب شما تایید خواهد شد فراموش نکنید که فرایند تایید سرویس ما فقط یک فرآیند تایید نیست بلکه یک فرآنید دوست یابی و همکاری اسن و ما برای همکاری هم روی شما حساب میکنیم
                                </div>
                                </div>
                            </div>
                            </div>



							</div>
							<!-- Button -->

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>

    </div>
  </div>
</section>