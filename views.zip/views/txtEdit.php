<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaEasy.js">
<script>   
    xinha_options = 
    {
      xinha_plugins:  [ 
         'minimal', 
         { from: '/path/to/xinha-cdn/plugins', load: ['MootoolsFileManager', 'Linker'] }
      ],
      
      // This is where you set the other default configuration globally
      xinha_config:            function(xinha_config) 
      {
        
        // Configure the plugins as you normally would here (consult plugin documentation)
        
      }
    }

</script>

<textarea name="txt" style="width: 100%; height: 500px; border:none;"></textarea>



