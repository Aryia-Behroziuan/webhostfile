<?php
if(! isset($_SESSION['id'])){
    die();
}
if(! isset($_GET['id'])){
    die();
}

if(isset($_GET['id'])){
    $query_for_search_post = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and idUser='.$_SESSION['id'].'');
    $post = mysqli_fetch_assoc($query_for_search_post);
    if(! $post){
        die();
    }
}


?>
<title>سرویس توسعه کسبو کار پیپرلاین</title>

<section class="pb-4">
	<div class="container">
		<div class="row g-4">
                    <nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active">داشبورد پست</li>
							<li class="breadcrumb-item active">سرویس تبلیغات</li>
						</ol>
					</nav>
    




                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-google-ads-8311058-6605240.png?f=avif" style="width: 200px;" alt="">
                        <h2>سرویس توسعه کسبو کار </h2>
                        <small>سرویس توسعه کسبو کار پیپرلاین برای رشد کسبو کار شما و توسعه شما کمک میکند و این یک سرویس تبلیغاتی نیست بلکه یک سرویس مشاوره و شتابدهندگی کسبو کار است</small>
                        </div>
                        <!-- End Title -->

                        <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?controller=home&amp;method=con">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">رشد و بازده کارامد</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/apps.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=apps-store">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">رشد با هوش مصنوعی</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/calendar.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=music">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">تاثیر منصفانه</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/communication.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>
                        </div>
                    </div>

                    <br>
                    <br>

                    <div class="card-header bg-transparent border-bottom p-3">
                        <div class="d-sm-flex justify-content-sm-between align-items-center">
                        <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-alipay"></i></font></font></span>مخزن</font><br><small> <?php echo $post['title']?></small></font>&nbsp; PL<?php echo $post['idPost']?></h5>
                        
                        </div>
                    </div>
                    <br>


                    <?php
                    if($post['ads'] == 0){
                        ?>
                    <div class="container space-2 space-lg-3">
                        <div class="row">
                            <div class="col-lg-5 mb-3 mb-sm-5 mb-lg-0">
                            <!-- Card -->
                            <a class="card bg-primary text-white min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up" data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
                                <figure class="position-sm-absolute top-0 left-0 w-100">
                                <img class="img-fluid rounded-top" src="https://www.spacify.ir/public/img/logo/abstract-shapes-8.svg" alt="SVG">
                                </figure>
                                <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                <h3 class="text-white">شراکت با کسبو کار های سازمانی</h3>
                                <p class="text-white-70">از کسبو کار های خانگی کوچک تا کسبوکار های سازمانی را پوشش میدهیم در سرتاسر سرویس های کوییت سورس اعمال خوهد شد در زیر لیستی از ویژگی های آن را بخوانید</p>
                                <span href="#" class="">

                                300,000  تومان             
                                </span>
                                <br>
                                <small>
                                تبلیغات کسترده در طیف وسیع
                                <BR>
                                مدت زمان 6 ماه فعال بر روی مخزن شما
                                <br>
                                استفاده از الگوریتم های خزشگر وب و هوش مصنوعی برای بازخورد بهتر
                                <br>
                                حداقل بازده شما 71 درصد از بازخورد های طبیبعی
                                <br>
                                مشاوره کسبوکار
                                </small>
                            

                                <span class="text-white font-weight-bold"><i class="bi bi-paypal"></i> پرداخت و فعالسازی <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </article>
                            </a>
                            <!-- End Card -->
                            </div>

                            <div class="col-sm-6 col-lg mb-3 mb-sm-0">
                            <!-- Card -->
                            <a class="card min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up" data-aos-delay="150" data-bs-toggle="modal" data-bs-target="#staticBackdrop1">
                                <figure class="position-sm-absolute top-0 left-0 w-100">
                                <img class="img-fluid rounded-top" src="https://www.spacify.ir/public/img/logo/abstract-shapes-7.svg" alt="SVG">
                                </figure>

                                <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                <h3>شراکت تجاری</h3>
                                <span href="#" class="">

                                150,000  تومان             
                                </span>
                                <p class="text-body">
                                تبلیغات در سرتاسر پلتفرم
                                <br>
                                مدت زمان فعالیت روی مخزن شما 3 ماه
                                <br>
                                بازده 61 درصد از بازخورد های طبیعی شما
                                <br>
                                استفاده از الگوریتم دانا در هوش مصنوعی
                                <br>
                                مشاوره کسبوکار
                                </p> 
                                <span class="text-primary font-weight-bold"><i class="bi bi-paypal"></i> پرداخت و فعالسازی <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </article>
                            </a>
                            <!-- End Card -->
                            </div>

                            <div class="col-sm-6 col-lg">
                            <!-- Card -->
                            <a class="card min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up" data-aos-delay="200" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                <figure class="position-sm-absolute top-0 left-0 w-100">
                                <img class="img-fluid rounded-top" src="https://www.spacify.ir/public/img/logo/abstract-shapes-6.svg" alt="SVG">
                                </figure>

                                <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                <h3>غیر رایگان</h3>
                                <span href="#" class="">

                                50,000  تومان             
                                </span>
                                <p class="text-body">
                                تبلیغات در سرتاسر پلتفرم
                                <br>
                                مدت زمان فعالیت روی مخزن شما 1 ماه
                                <br>
                                بازده 61 درصد از بازخورد های طبیعی شما
                                <br>
                                استفاده از الگوریتم دانا در هوش مصنوعی
                                <br>
                                مشاوره کسبوکار
                                </p>                             
                                <span class="text-primary font-weight-bold"><i class="bi bi-paypal"></i> پرداخت و فعالسازی <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </article>
                            </a>
                            <!-- End Card -->
                            </div>
                        </div>
                    </div>





                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <div class="modal-body">
                            <div id="displayNowAds1"></div>
                         
                            <div class="row">
                                <div class="col-sm-6 col-lg">
                                <!-- Card -->
                                <a class="card min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up" data-aos-delay="200" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    <figure class="position-sm-absolute top-0 left-0 w-100">
                                    <img class="img-fluid rounded-top" src="https://www.spacify.ir/public/img/logo/abstract-shapes-6.svg" alt="SVG">
                                    </figure>

                                    <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                    <h3>غیر رایگان</h3>
                                    <span href="#" class="">

                                    50,000  تومان             
                                    </span>
                                    <p class="text-body">
                                    تبلیغات در سرتاسر پلتفرم
                                    <br>
                                    مدت زمان فعالیت روی مخزن شما 1 ماه
                                    <br>
                                    بازده 61 درصد از بازخورد های طبیعی شما
                                    <br>
                                    استفاده از الگوریتم دانا در هوش مصنوعی
                                    <br>
                                    مشاوره کسبوکار
                                    </p>                             
                                    </article>
                                </a>
                                <!-- End Card -->
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                            <button type="button" class="btn btn-primary-soft" id="ByPlan1">پرداخت 50,000 تومان و خرید</button>
                        </div>
                        </div>
                    </div>
                    </div>
                                            <script>
                                            $('#ByPlan1').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=AdsPlusPost&mode=1&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan1').html('خرید');
                                                $('#displayNowAds1').html(data);
                                                })

                                            })
                                            </script>


                                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <div class="modal-body">
                            <div id="displayNowAds2"></div>

                        
                            <div class="row">
                                <div class="col-sm-6 col-lg mb-3 mb-sm-0">
                                <!-- Card -->
                                <a class="card min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up" data-aos-delay="150">
                                    <figure class="position-sm-absolute top-0 left-0 w-100">
                                    <img class="img-fluid rounded-top" src="https://www.spacify.ir/public/img/logo/abstract-shapes-7.svg" alt="SVG">
                                    </figure>

                                    <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                    <h3>شراکت تجاری</h3>
                                    <span href="#" class="">

                                    150,000  تومان             
                                    </span>
                                    <p class="text-body">
                                    تبلیغات در سرتاسر پلتفرم
                                    <br>
                                    مدت زمان فعالیت روی مخزن شما 3 ماه
                                    <br>
                                    بازده 61 درصد از بازخورد های طبیعی شما
                                    <br>
                                    استفاده از الگوریتم دانا در هوش مصنوعی
                                    <br>
                                    مشاوره کسبوکار
                                    </p> 
                                    </article>
                                </a>
                                <!-- End Card -->
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                            <button type="button" class="btn btn-primary-soft" id="ByPlan2">پرداخت 150,000 تومان و خرید</button>
                        </div>
                        </div>
                    </div>
                    </div>

                                             <script>
                                            $('#ByPlan2').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan2').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=AdsPlusPost&mode=2&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan2').html('خرید');
                                                $('#displayNowAds2').html(data);
                                                })

                                            })
                                            </script>


                    <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <div class="modal-body">
                            <div id="displayNowAds3"></div>
                         
                        
                            <div class="row">
         
                                <div class="col-sm-6 col-lg mb-3 mb-sm-0">
                                <!-- Card -->
                                <a class="card bg-primary text-white min-h-380rem h-100 transition-3d-hover aos-init aos-animate" href="index.php?controller=podcast&amp;method=view" data-aos="fade-up">
                                 
                                    <article class="d-flex align-content-end flex-wrap h-100 p-4">
                                    <h3 class="text-white">شراکت با کسبو کار های سازمانی</h3>
                                    <p class="text-white-70">از کسبو کار های خانگی کوچک تا کسبوکار های سازمانی را پوشش میدهیم در سرتاسر سرویس های کوییت سورس اعمال خوهد شد در زیر لیستی از ویژگی های آن را بخوانید</p>
                                    <span href="#" class="">

                                    300,000  تومان             
                                    </span>
                                    <br>
                                    <small>
                                    تبلیغات کسترده در طیف وسیع
                                    <BR>
                                    مدت زمان 6 ماه فعال بر روی مخزن شما
                                    <br>
                                    استفاده از الگوریتم های خزشگر وب و هوش مصنوعی برای بازخورد بهتر
                                    <br>
                                    حداقل بازده شما 71 درصد از بازخورد های طبیبعی
                                    <br>
                                    مشاوره کسبوکار
                                    </small>
                                

                                    </article>
                                </a>
                                <!-- End Card -->
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                            <button type="button" class="btn btn-primary-soft" id="ByPlan3">پرداخت 300,000 تومان و خرید</button>
                        </div>
                        </div>
                    </div>
                    </div>


                    
                                            <script>
                                            $('#ByPlan3').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan3').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=AdsPlusPost&mode=3&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan3').html('خرید');
                                                $('#displayNowAds3').html(data);
                                                })

                                            })
                                            </script>
                        <?php
                    }else{
                        $some_time = strtotime($post['AdStop']);

                        if($post['ads'] == 1){
                            $ad = 'غیر رایگان';
                        }elseif($post['ads'] == 2){
                            $ad = 'شراکت تجاری';
                        }elseif($post['ads'] == 3){
                            $ad = 'شراکت با کسبو کار های سازمانی';
                            
                        }else{
                            $ad = 'نامعلوم';
                        }
                        ?>
                        <div class="bg-light rounded-2 p-1 mb-1" >
                            <div class="bg-light rounded-2 p-1 mb-1">
                            <div class="container-fluid">
                            <h6> <img src="https://static-00.iconduck.com/assets.00/google-ads-icon-2048x1837-4vbvpswm.png" style="width: 30px;" alt="">  
                            سرویس فعال شما <br> <small><?php echo $ad?></small></h6>
                            <br>
                            <small>تاریخ اتمام اشتراک: <?php echo date('Y, d F', $some_time)?></small>

                            </div>
                            </nav>
                
                            </div>                               
                        </div>

                        <div class="col-12">
                            <!-- Counter START -->
                            <div class="row g-4">
                                
                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
                                                <i class="bi bi-people-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo number_format($post['views'] , 0 , "." , "," )?> </font></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازدید از صفحه</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-primary bg-opacity-10 rounded-3 text-primary">
                                                <i class="bi bi-file-earmark-text-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><?php echo number_format($post['sagedAd'] , 0 , "." , "," )?></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیشنهاد شده</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
                                                <i class="bi bi-suit-heart-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><?php echo number_format($post['sagedSearch'] , 0 , "." , "," )?></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>علایق و پرسشگری</font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
                                                <i class="bi bi-bar-chart-line-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo number_format($post['saged'] , 0 , "." , "," )?></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">رشد طبیعی</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                    <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
                                                <i class="bi bi-binoculars"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>  <?php echo number_format($post['explorer'] , 0 , "." , "," )?></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش در اکسپلور</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
                                                <i class="bi bi-bookmark-check-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>  <?php echo number_format($post['sagedTag'] , 0 , "." , "," )?></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاوش در تگ</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Counter END -->
                        </div>
                        <?php
                    }
                    ?>


                    <div class="bg-light rounded-5 p-1 mb-1" style="text-align: left;">
                        <div class="bg-light rounded-5 p-1 mb-1" style="text-align: left;">
            

                        <nav class="navbar bg-body-tertiary">
                        <div class="container-fluid">
                        <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action"> QPassID <strong><i class="bi bi-link-45deg"></i> Connected</strong> <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
                        <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
                        <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
                        <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
                        <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
                        <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
                        </svg></a>
                        </div>
                        </nav>
            
                         </div>                               
                    </div>
        </div>
    </div>
</section>