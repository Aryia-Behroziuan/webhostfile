
<?php
if(isset($_SESSION['ACC-KEY'])){
  ?>
  <script type='text/javascript'>window.location.href='dashboard.php?content=ACCError'</script>
  <?php
  die();
}
?>
<section class="py-4">
	<div class="container">
	 
    <div class="row g-4">

    <?php
            $date = date('Y-m-d');
            if(strlen($user['ACC-KEY']) > 5){
              if($user['Date_End_Suite'] < $date){
                mysqli_query($con, "
                UPDATE user
                SET
                  `ACC-KEY` = '',
                  `Suite` = 0,
                  `Date_End_Suite` = ''
                WHERE
                  iduser = ".$user['iduser'].";
                ");
                $date = date('Y-m-d H:i:s');

                $title = 'اشتراک حساب سازمانی شما به پایان رسید';
                $doc ='';
                mysqli_query($con, 'INSERT INTO `comment`(`userId`, `notifi`, `title`, `comment`, `link`, `time`) VALUES ('.$user['iduser'].', 1, "'.$title.'", "'.$doc.'" ,  "dashboard.php?content=Suite" , "'.$date.'")');
                ?>

                <div class="alert alert-danger" role="alert">
                <i class="bi bi-info-circle"></i> اشتراک حساب سازمانی این حساب به پایان رسیده است
                </div>
                <?php
               
            }
            }
      ?>
      <!-- Profile cover and info START -->
      <div class="col-12">
        <div class="card mb-4 position-relative z-index-9">
          <!-- Cover image -->
          <div class="py-5 h-200 rounded" style="background-image:url(assets/images/blog/16by9/big/07.jpg); background-position: center bottom; background-size: cover; background-repeat: no-repeat;">
          </div>
          <div class="card-body pt-3 pb-0">
            <div class="row d-flex justify-content-between">
              <!-- Avatar -->
              <div class="col-sm-12 col-md-auto text-center text-md-start">
                <div class="avatar avatar-xxl mt-n5">
                  <img class="avatar-img rounded-circle border border-white border-3 shadow" src="<?php echo $user['avatar']?>" alt="">
                </div>
              </div>
              <!-- Profile info -->
              <div class="col-sm-12 col-md text-center text-md-start d-md-flex justify-content-between align-items-center">
                <div>
                  <h4 class="my-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['username']?></font></font><?php
                                                                        if($user['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></h4>
                  <ul class="list-inline">
                    <li class="list-inline-item"><i class="bi bi-person-fill me-1"></i> <?php echo $user['email']?></li>
                    <li class="list-inline-item"><i class="bi bi-geo-alt me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایران</font></font></li>
                    <li class="list-inline-item"><i class="bi bi-calendar2-plus me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  <?php echo $user['Joined']?></font></font></li>
                  </ul>
                  <p class="m-0"></p>
                </div>
                <!-- Links -->
                <div class="d-flex align-items-center justify-content-center justify-content-md-end">
                  <a href="#" class="btn btn-primary-soft me-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دنبال کردن</font></font></a>
                  <!-- Card action START -->
                  <div class="dropdown ms-3">
                    <a class="text-secondary" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                      <!-- Dropdown Icon -->
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle fill="currentColor" cx="3" cy="12" r="2.5"></circle>
                        <circle fill="currentColor" opacity="0.5" cx="12" cy="12" r="2.5"></circle>
                        <circle fill="currentColor" opacity="0.3" cx="21" cy="12" r="2.5"></circle>
                      </svg>
                    </a>               
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                      <li><a class="dropdown-item" href="#"><i class="bi bi-share me-2 fw-icon"></i>Share profile</a></li>
                      <li><a class="dropdown-item" href="#"><i class="bi bi-volume-mute me-2 fw-icon"></i>Mute notification</a></li>
                      <li><a class="dropdown-item text-danger" href="#"><i class="bi bi-slash-circle me-2 fw-icon"></i>Delete profile</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="#"><i class="bi bi-flag me-2 fw-icon"></i>Report a bug</a></li>
                    </ul>
                  </div>
                  <!-- Card action END -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Profile info END -->
    </div>

    <div class="row g-4">
      <!-- Left sidebar START -->
      <div class="col-lg-7 col-xxl-8">

        <form id="data1" action="" method="POST">
            <!-- Profile START -->
            <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
                <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
                  <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"/>
                </svg> مشخصات</font></font></h5>
            </div>
            <div class="card-body">
                <!-- Full name -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام نمایشی و نام حقیقی</font></font></label>
                <div class="input-group">
                    <input type="text" class="form-control" name="username" value="<?php echo $user['username']?>" placeholder="نام کوچک">
                    <input type="text" class="form-control" name="title" value="<?php echo $user['title']?>" placeholder="نام خانوادگی">
                </div>
                </div>
                <!-- Username -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام کاربری</font></font></label>
                <div class="input-group">
                    <span class="input-group-text">piperline.com</span>
                    <input type="text" class="form-control" value="<?php echo $user['username']?>">
                </div>
                </div>
                <!-- Profile picture -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عکس پروفایل</font></font></label>
                <!-- Avatar upload START -->
                <div class="d-flex align-items-center">
                    <div class="position-relative me-3">
                    <!-- Avatar edit -->
                    <div class="position-absolute top-0 end-0  z-index-9">
                        <a class="btn btn-sm btn-light btn-round mb-0 mt-n1 me-n1" href="#"> <i class="bi bi-pencil"></i> </a>
                    </div>
                    <!-- Avatar preview -->
                    <div class="avatar avatar-xl">
                        <img class="avatar-img rounded-circle border border-white border-3 shadow" src="<?php echo $user['avatar']?>" alt="">
                    </div>
                    </div>
                    <!-- Avatar remove button -->
                    <div class="avatar-remove">
                    <input type="text" name="avatar" class="form-control" value="<?php echo $user['avatar']?>" placeholder="لینک عکس">
                    <button type="submit" class="btn btn-light"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره</font></font></button>
                    </div>
                </div>
                <!-- Avatar upload END -->
                </div>
                <!-- Job title -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عنوان شغلی</font></font></label>
                <input class="form-control" name="job" type="text" value="<?php echo $user['job']?>">
                </div>
                <!-- Location -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">محل</font></font></label>
                <input class="form-control" name="address" type="text" value="<?php echo $user['address']?>">
                </div>
                <!-- Bio -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> درباره شما</font></font></label>
                <textarea class="form-control" name="about" rows="3"><?php echo $user['about']?></textarea>
                <div class="form-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات مختصری برای پروفایل شما</font></font></div> 
                </div>
                <!-- Birthday -->
                <div>
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> لینک رزومه شما</font></font></label>
                <input type="text" name="resume" class="form-control flatpickr-input" value="<?php echo $user['codefoxs']?>">
                </div>
                <div>
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وبسایت شما</font></font></label>
                <input type="text" name="url" class="form-control flatpickr-input" value="<?php echo $user['url']?>">
                </div>
                <!-- Save button -->
                <div class="d-flex justify-content-end mt-4">
                <a href="#" class="btn text-secondary border-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دور انداختن</font></font></a>
                <button id="data1SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                </div>
            </div>
            </div>
            <!-- Profile END -->
        </form>
        <script>
                  $(document).ready(function(){
                      $("#data1").on("submit", function(event){
                          event.preventDefault();
                          $('#data1SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                          var formValues= $('#data1').serialize();

                          $.post("../../index.php?controller=account&method=edit&mode=1", formValues, function(data){
                              // Display the returned data in browser
                              $('#data1SUB').html('ذخیره شد');
                          });
                      });
                  });
        </script>
        

        <form id="locSend" action="" method="POST">
            <!-- Personal information START -->
            <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
                <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-lock" viewBox="0 0 16 16">
                  <path d="M7.293 1.5a1 1 0 0 1 1.414 0L11 3.793V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v3.293l2.354 2.353a.5.5 0 0 1-.708.708L8 2.207l-5 5V13.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 2 13.5V8.207l-.646.647a.5.5 0 1 1-.708-.708L7.293 1.5Z"/>
                  <path d="M10 13a1 1 0 0 1 1-1v-1a2 2 0 0 1 4 0v1a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-2Zm3-3a1 1 0 0 0-1 1v1h2v-1a1 1 0 0 0-1-1Z"/>
                </svg> موقعیت مکانی</font></font></h5>
            </div>
            <div class="card-body">
                <!-- Skype -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایالات خود را انتخاب کنید</font></font></label>
                
                
                  <select class="form-select" name="loc" multiple aria-label="multiple select example">

                  <?php
                  if(strlen($user['loc']) >= 2){
                      ?>
                      <option value="<?php echo $user['loc']?>" selected>"<?php echo $user['loc']?>" انتخاب شده</option>

                      <?php
                  }else{
                      ?>
                      <option value="" selected>برای فعالسازی منطقه را انتخاب کنید</option>

                      <?php
                  }

                  ?>
                    <br>
                    <option value="تهران">تهران</option>
                    <br>
                    <option value="گیلان">گیلان</option>
                    <option value="آذربایجان شرقی">آذربایجان شرقی</option>
                    <option value="خوزستان">خوزستان</option>
                    <option value="فارس">فارس</option>
                    <option value="اصفهان">اصفهان</option>
                    <option value="خراسان رضوی">خراسان رضوی</option>
                    <option value="قزوین">قزوین</option>
                    <option value="سمنان">سمنان</option>
                    <option value="قم">قم</option>
                    <option value="مرکزی">مرکزی</option>
                    <option value="زنجان">زنجان</option>
                    <option value="مازندران">مازندران</option>
                    <option value="گلستان">گلستان</option>
                    <option value="اردبیل">اردبیل</option>
                    <option value="آذربایجان غربی">آذربایجان غربی</option>
                    <option value="همدان">همدان</option>
                    <option value="کردستان">کردستان</option>
                    <option value="کرمانشاه">کرمانشاه</option>
                    <option value="لرستان">لرستان</option>
                    <option value="بوشهر">بوشهر</option>
                    <option value="کرمان">کرمان</option>
                    <option value="هرمزگان">هرمزگان</option>
                    <option value="چهارمحال و بختیاری">چهارمحال و بختیاری</option>
                    <option value="یزد">یزد</option>
                    <option value="سیستان و بلوچستان">سیستان و بلوچستان</option>
                    <option value="ایلام">ایلام</option>
                    <option value="کهگلویه و بویراحمد">کهگلویه و بویراحمد</option>
                    <option value="خراسان شمالی">خراسان شمالی</option>
                    <option value="خراسان جنوبی">خراسان جنوبی</option>
                    <option value="البرز">البرز</option>


                  </select> 
                  <small><font style="vertical-align: inherit;">کاربر گرامی لطفا ایالات خود را انتخاب کنید تا بتوانیم  داده هایی که بر اساس منطقه چیده میشوند و سرویس هایی که محدودیت مکانی دارند را برای شما پردازش کنیم</font></small>


                </div>

             
                <!-- Save button -->
                <div class="d-flex justify-content-end mt-4">
                <button id="data2SUB1" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                </div>
            </div>
            </div>
            <!-- Personal information END -->
        </form>
        <script>
                  $(document).ready(function(){
                      $("#locSend").on("submit", function(event){
                          event.preventDefault();
                          $('#data2SUB1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                          var formValues= $('#locSend').serialize();

                          $.post("../../index.php?controller=account&method=edit&mode=5", formValues, function(data){
                              // Display the returned data in browser
                              $('#data2SUB1').html(data);
                          });
                      });
                  });
        </script>



        <form id="data2" action="" method="POST">
            <!-- Personal information START -->
            <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
                <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-link-45deg" viewBox="0 0 16 16">
                  <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z"/>
                  <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z"/>
                </svg> اطلاعات شخصی</font></font></h5>
            </div>
            <div class="card-body">
                <!-- Skype -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اسکایپ</font></font></label>
                <input class="form-control"  type="text" value="iamlouisferguson">
                </div>

                <!-- Address -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شماره تلفن</font></font></label>
                <input class="form-control" name="phone" type="text" value="<?php echo $user['phoneNumber']?>">
                </div>
                <!-- Save button -->
                <div class="d-flex justify-content-end mt-4">
                <button id="data2SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                </div>
            </div>
            </div>
            <!-- Personal information END -->
        </form>
        <script>
                  $(document).ready(function(){
                      $("#data2").on("submit", function(event){
                          event.preventDefault();
                          $('#data2SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                          var formValues= $('#data2').serialize();

                          $.post("../../index.php?controller=account&method=edit&mode=2", formValues, function(data){
                              // Display the returned data in browser
                              $('#data2SUB').html('ذخیره شد');
                          });
                      });
                  });
        </script>

        <form id="data3" action="" method="POST">
            <!-- Social links START -->
            <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
                <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-slack" viewBox="0 0 16 16">
                  <path d="M3.362 10.11c0 .926-.756 1.681-1.681 1.681S0 11.036 0 10.111C0 9.186.756 8.43 1.68 8.43h1.682v1.68zm.846 0c0-.924.756-1.68 1.681-1.68s1.681.756 1.681 1.68v4.21c0 .924-.756 1.68-1.68 1.68a1.685 1.685 0 0 1-1.682-1.68v-4.21zM5.89 3.362c-.926 0-1.682-.756-1.682-1.681S4.964 0 5.89 0s1.68.756 1.68 1.68v1.682H5.89zm0 .846c.924 0 1.68.756 1.68 1.681S6.814 7.57 5.89 7.57H1.68C.757 7.57 0 6.814 0 5.89c0-.926.756-1.682 1.68-1.682h4.21zm6.749 1.682c0-.926.755-1.682 1.68-1.682.925 0 1.681.756 1.681 1.681s-.756 1.681-1.68 1.681h-1.681V5.89zm-.848 0c0 .924-.755 1.68-1.68 1.68A1.685 1.685 0 0 1 8.43 5.89V1.68C8.43.757 9.186 0 10.11 0c.926 0 1.681.756 1.681 1.68v4.21zm-1.681 6.748c.926 0 1.682.756 1.682 1.681S11.036 16 10.11 16s-1.681-.756-1.681-1.68v-1.682h1.68zm0-.847c-.924 0-1.68-.755-1.68-1.68 0-.925.756-1.681 1.68-1.681h4.21c.924 0 1.68.756 1.68 1.68 0 .926-.756 1.681-1.68 1.681h-4.21z"/>
                </svg> پیوندهای اجتماعی</font></font></h5>
            </div>
            <div class="card-body" style="text-align: left;">
                <!-- Skype -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Meta Instagram & Threads <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                  <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-meta" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M8.217 5.243C9.145 3.988 10.171 3 11.483 3 13.96 3 16 6.153 16.001 9.907c0 2.29-.986 3.725-2.757 3.725-1.543 0-2.395-.866-3.924-3.424l-.667-1.123-.118-.197a54.944 54.944 0 0 0-.53-.877l-1.178 2.08c-1.673 2.925-2.615 3.541-3.923 3.541C1.086 13.632 0 12.217 0 9.973 0 6.388 1.995 3 4.598 3c.319 0 .625.039.924.122.31.086.611.22.913.407.577.359 1.154.915 1.782 1.714Zm1.516 2.224c-.252-.41-.494-.787-.727-1.133L9 6.326c.845-1.305 1.543-1.954 2.372-1.954 1.723 0 3.102 2.537 3.102 5.653 0 1.188-.39 1.877-1.195 1.877-.773 0-1.142-.51-2.61-2.87l-.937-1.565ZM4.846 4.756c.725.1 1.385.634 2.34 2.001A212.13 212.13 0 0 0 5.551 9.3c-1.357 2.126-1.826 2.603-2.581 2.603-.777 0-1.24-.682-1.24-1.9 0-2.602 1.298-5.264 2.846-5.264.091 0 .181.006.27.018Z"/>
                </svg></font></font></label>
                <input class="form-control" name="meta" type="text" value="<?php echo $user['instagram']?>" style="text-align: left;">
                </div>
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Facebook & messanger <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                  <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-messenger" viewBox="0 0 16 16">
                  <path d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.639.639 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.639.639 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76zm5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z"/>
                </svg></font></font></label>
                <input class="form-control" name="facebook" type="text" value="<?php echo $user['facebook']?>" style="text-align: left;">
                </div>
                <!-- Email -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Linkedin <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
                  <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/>
                </svg></font></font></label>
                <input class="form-control" name="linkdin"  type="text" value="<?php echo $user['linkdin']?>" style="text-align: left;">
                </div>
                <!-- Address -->
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Twitter <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                  <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                </svg></font></font></label>
                <input class="form-control" name="towiter"  type="text" value="<?php echo $user['towitter']?>" style="text-align: left;">
                </div>
                <!-- Save button -->
                <div class="d-flex justify-content-end mt-4">
                <button id="data3SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                </div>
            </div>
            </div>
            <!-- Social links END -->
        </form>
        <script>
                  $(document).ready(function(){
                      $("#data3").on("submit", function(event){
                          event.preventDefault();
                          $('#data3SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                          var formValues= $('#data3').serialize();

                          $.post("../../index.php?controller=account&method=edit&mode=3", formValues, function(data){
                              // Display the returned data in browser
                              $('#data3SUB').html('ذخیره شد');
                          });
                      });
                  });
        </script>


        <form id="data4" action="" method="POST">
            <!-- Social links START -->
            <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
                <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
                  <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
                  <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
                </svg> افزونه ها</font></font></h5>
            </div>
            <div class="card-body">

                <button type="button" class="btn btn-light btn-xs" id="artBack">art back <i class="bi bi-brush"></i></button>
                
                <div id="artBack_style" style="display: none;">
                <!-- Skype -->
                <a href="#" id="closed_artBack"><i class="bi bi-x-lg"></i></a>
                <div class="mb-3">
                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> تصویر هنری</font></font></label>
                <input class="form-control" name="artBack" type="text" value="<?php echo $user['isport']?>">
                <small>تصویر هنری خود را در <a href="https://up.20script.ir/index.php" target="_blank">اینجا</a> بارگذاری کنید</small>
                </div>
                </div>

                                                                    <script>
                                                                                $(document).ready(function(){
                                                                                        $("#artBack").on("click", function(event){
                                                                                            event.preventDefault();
                                        
                                                                                            document.getElementById('artBack_style').style.display = "flex";
                                            
                                                                                        });
                                                                                    });
                                                                    </script>
                                                                                                     <script>
                                                                                $(document).ready(function(){
                                                                                        $("#closed_artBack").on("click", function(event){
                                                                                            event.preventDefault();
                                        
                                                                                            document.getElementById('artBack_style').style.display = "none";
                                            
                                                                                        });
                                                                                    });
                                                                    </script>
                <!-- Save button -->
                <div class="d-flex justify-content-end mt-4">
                <button id="data4SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                </div>
            </div>
            </div>
            <!-- Social links END -->
        </form>
        <script>
                  $(document).ready(function(){
                      $("#data4").on("submit", function(event){
                          event.preventDefault();
                          $('#data4SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                          var formValues= $('#data4').serialize();

                          $.post("../../index.php?controller=account&method=edit&mode=8", formValues, function(data){
                              // Display the returned data in browser
                              $('#data4SUB').html(data);
                          });
                      });
                  });
        </script>

      </div>
      <!-- Left sidebar END -->

      <!-- Right sidebar START -->
      <div class="col-lg-5 col-xxl-4">
          <!-- Profile Setting START -->
          <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
              <h5 class="card-header-title mb-0" style="text-align: left;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> QPassID <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
              <path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
              <path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
              <path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
              <path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
              <path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
            </svg></font></font></h5>
            </div>
         


            <div class="list-group" style="text-align: left;">
              
              <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action"> Account Center <strong>QP<?php echo $user['iduser']?></strong><img style="with: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png?f=webp" alt=""></a>
              <a href="https://myaccount.google.com/?utm_source=account-marketing-page&utm_medium=go-to-account-button&pli=1" class="list-group-item list-group-item-action"> Google Account center <img style="with: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/google-4118014-3410052.png?f=avif" alt=""></a>
              <a href="dashboard.php?content=verifiACC" class="list-group-item list-group-item-action"> Account verification <i class="bi bi-patch-check-fill text-info" style="font-size: 22px;"></i></a>
              <a href="dashboard.php?content=verification" class="list-group-item list-group-item-action"> Account Authentication <img src="https://cdn-icons-png.flaticon.com/512/6784/6784655.png" style="width: 26px;" alt=""></a>
              <a href="dashboard.php?content=accountStatus" class="list-group-item list-group-item-action"> Account status <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-exclamation-triangle" viewBox="0 0 16 16">
                <path d="M7.938 2.016A.13.13 0 0 1 8.002 2a.13.13 0 0 1 .063.016.146.146 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.163.163 0 0 1-.054.06.116.116 0 0 1-.066.017H1.146a.115.115 0 0 1-.066-.017.163.163 0 0 1-.054-.06.176.176 0 0 1 .002-.183L7.884 2.073a.147.147 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566z"></path>
                <path d="M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995z"></path>
                </svg></a>
                <a href="dashboard.php?content=Suite" class="list-group-item list-group-item-action"> Business Suite <i class="bi bi-link-45deg" style="font-size: 22px;"></i><i class="bi bi-universal-access-circle" style="font-size: 22px;"></i></a>
                <a href="dashboard.php?content=security" class="list-group-item list-group-item-action"> Account security <i class="bi bi-indent" style="font-size: 22px;"></i><i class="bi bi-key-fill" style="font-size: 22px;"></i></a>

              <button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.qitsource.ir">qitSource,LLC</a></button>
            </div>


          </div>
          <!-- Profile Setting END -->

          <!-- Profile Setting START -->
          <div class="card border mb-4">
            <div class="card-header border-bottom p-3">
              <h5 class="card-header-title mb-0" style="text-align: left;"><font style="vertical-align: inherit;"><img style="width: 130px; height: 40px;" src="https://www.spacify.ir/public/img/logo/nameCompany.png" alt="Logo">&nbsp<img style="width: 60px; height: 60px;" src="https://www.spacify.ir/public/img/logo/wizify.png" alt="Logo"></font></h5>
            </div>
            
           
            <div class="list-group" style="text-align: left;">
             
              <a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting" class="list-group-item list-group-item-action"> Workspace <img style="with: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/setting-4029220-3337919.png" alt=""></a>
              <a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=wallet" class="list-group-item list-group-item-action"> Wallet <img style="with: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/color-palette-4029197-3337901.png" alt=""></a>
              <a href="https://www.spacify.ir/index.php?controller=apps/spacify&method=explorer" class="list-group-item list-group-item-action"> Apps <img style="width: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/internet-4029216-3337894.png" alt=""></a>
              <a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=remot" class="list-group-item list-group-item-action"> KEY-API Remote Account <img style="with: 40px; height: 40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/unlink-3711825-3105299.png" alt=""></a>
              <button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.spacify.ir">Spacify</a></button>
            </div>




          </div>
          <!-- Profile Setting END -->


        <!-- Profile Setting START -->
        <div class="card border mb-4">
          <div class="card-header border-bottom p-3">
            <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات پروفایل</font></font></h5>
          </div>
          <div class="card-body">
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="availabilityCheck" checked="">
              <label class="form-check-label" for="availabilityCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایه قابل مشاهده برای همه</font></font></label>
            </div>
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="proCheck" disabled="">
              <label class="form-check-label" for="proCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">غیرفعال کردن تبلیغات</font></font><span class="badge bg-primary align-middle"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حرفه ای</font></font></span></label>
            </div>
          </div>
        </div>
        <!-- Profile Setting END -->

        <!-- Notifications START -->
        <div class="card border mb-4">
          <div class="card-header border-bottom p-3">
            <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعیه</font></font></h5>
          </div>
          <!-- Card body START -->
          <div class="card-body">
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع اعلان‌هایی را که می‌خواهید دریافت کنید انتخاب کنید</font></font></p>
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="withdrawalCheck" checked="">
              <label class="form-check-label" for="withdrawalCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فعالیت برداشت</font></font></label>
            </div>
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="weeklyCheck">
              <label class="form-check-label" for="weeklyCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارش هفتگی</font></font></label>
            </div>
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="passwordCheck" checked="">
              <label class="form-check-label" for="passwordCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تغییر رمز عبور</font></font></label>
            </div>
            <div class="form-check form-switch form-check-md mb-3">
              <input class="form-check-input" type="checkbox" id="dataCheck">
              <label class="form-check-label" for="dataCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">هشدار مصرف داده</font></font></label>
            </div>
          </div>
        <!-- Card body END -->
        </div>
        <!-- Notifications START -->

        <!-- Deactivate account START -->
        <div class="card border mb-4">
          <div class="card-header border-bottom p-3">
            <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">غیرفعال کردن اکانت</font></font></h5>
          </div>
          <div class="card-body">
            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبل از اینکه شما بروید...</font></font></h6>
            <ul>
              <li><font style="vertical-align: inherit;"><a href="#"><font style="vertical-align: inherit;">در اینجا</font></a><font style="vertical-align: inherit;"> از اطلاعات خود نسخه پشتیبان تهیه کنید</font></font><a href="#"><font style="vertical-align: inherit;"></font></a> </li>
              <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حذف حساب نهایی است. </font><font style="vertical-align: inherit;">هیچ راهی برای بازیابی حساب شما وجود نخواهد داشت</font></font></li>
            </ul>
            <div class="form-check form-check-md my-3">
              <input class="form-check-input" type="checkbox" value="" id="deleteaccountCheck">
              <label class="form-check-label" for="deleteaccountCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بله، من واقعاً می خواهم حساب خود را حذف کنم</font></font></label>
            </div>
            <a href="#" class="btn btn-success-soft my-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب من را حفظ کن</font></font></a>
            <a href="#" class="btn btn-danger my-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اکانت من رو پاک کن</font></font></a>
          </div>
        </div>
        <!-- Deactivate account START -->
        <p><i class="bi bi-info-circle me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">این حساب در 15 ژانویه 2018 ایجاد شده است</font></font></p>

        <div class="card bg-transparent border rounded-3 mt-4">
          <!-- Card header -->
          <div class="card-header bg-transparent border-bottom p-3">
            <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب پیوند شده</font></font></h5>
          </div>
          <!-- Card body START -->
          <div class="card-body">
            <!-- Google -->
            <div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
              <!-- Title and content -->
              <h2 class="fs-1 mb-0 me-3"><i class="fab fa-google text-google-icon"></i></h2>
              <div>
                <div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
                  <i class="bi bi-check-circle-fill text-success fs-5"></i>
                </div>
                  <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گوگل</font></font></h6>
                  <p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما با موفقیت به حساب Google خود متصل شدید</font></font></p>
                  <!-- Button -->
                  <button type="button" class="btn btn-sm btn-danger mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فراخوانی کنید</font></font></button>
                  <a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
              </div>
            </div>

            <!-- Blogger -->
            <div class="mb-3 d-sm-flex border p-3 rounded">
              <!-- Title and content -->
              <h2 class="fs-1 mb-0 me-3"><i class="fab fa-blogger text-warning"></i></h2>
              <div>
                <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وبلاگ نویس</font></font></h6>
                <p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برای تجربه شخصی با حساب Blogger ارتباط برقرار کنید</font></font></p>
                <!-- Button -->
                <button type="button" class="btn btn-sm btn-primary mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بلاگر را وصل کنید</font></font></button>
                <a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
              </div>
            </div>

            <!-- Facebook -->
            <div class="d-sm-flex border p-3 rounded mb-2">
              <!-- Title and content -->
              <h2 class="fs-1 mb-0 me-3"><i class="fab fa-facebook text-facebook"></i></h2>
              <div>
                <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فیس بوک</font></font></h6>
                <p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برای تجربه شخصی با حساب فیس بوک ارتباط برقرار کنید</font></font></p>
                <!-- Button -->
                <button type="button" class="btn btn-sm btn-primary mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فیس بوک را وصل کنید</font></font></button>
                <a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
              </div>
            </div>
          </div>
          <!-- Card body END -->
        </div>
      </div>
    </div>
	</div>
</section>