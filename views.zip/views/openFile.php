<?php
if(isset($_GET['id'])){
    $query_for_search_post = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and idUser='.$_SESSION['id'].'');
    $post = mysqli_fetch_assoc($query_for_search_post);
    if(! $post){
        die();
    }
}
$date = date('Y-m-d');
$timeEnd = $post['AdStop'];

if(! $post['ads'] == 0){
	if($timeEnd < $date){
		mysqli_query($con, "
		UPDATE posts
		SET
		  `ads` = 0
		WHERE
		  idPost = ".$post['idPost'].";
		");
		$date = date('Y-m-d H:i:s');
	
		$title = 'مدت زمان اشتراک سرویس شتابدهنده بر روی مخزن '.$post['title'].' تمام شد';
		$doc='';
		mysqli_query($con, 'INSERT INTO `comment`(`userId`, `notifi`, `title`, `comment`, `link`, `time`) VALUES ('.$user['iduser'].', 1, "'.$title.'", "'.$doc.'" ,  "dashboard.php?content=openFile&id='.$_GET['id'].'" , "'.$date.'")');
	
	}
}

?>
<section class="pb-4">
	<div class="container">
		<div class="row g-4">
			<div class="col-12">

			<?phP
			if($post['published'] == '0'){
				?>
				<div class="alert alert-primary alert-dismissible fade show" role="alert">
					<img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-alert-5803870-4923157.png" style="width: 70px;" alt="">
					<br>
					<strong> مخزن شما در انتظار تایید است</strong> 
					<br>
					زمانی که مخزن در انتظار تایید است به کاربران نمایش داده نمیشود و قابل خریداری نیست و فقط به شکل فایل شخصی میتوان ان را باز کرد پست شما حتما باید از مرحله کنترل کیفی رد شود در این مرحله ما پست شما را پردازش میکنیم تا از کیفیت خوبی برخوردار باشد و سپس ان را تایید میکنیم وقتی تایید شود به شما اطلاع میدهیم لطفا صبور باشید با تشکر
				
					<br>
					<br>
					<h6><i class="bi bi-pencil-square"></i> یادداشت شما </h6>
					<hr>
					<?php echo $post['txtE']?>
				</div>
				<?php
			}elseif($post['published'] == '1'){
				?>
				<div class="alert alert-success alert-dismissible fade show" role="alert">
					
					<strong><img src="https://cdn3d.iconscout.com/3d/premium/thumb/successfully-approve-5331611-4659611.png" style="width: 40px;" alt=""> مخزن شما تایید شده است</strong> 
					<br>
					پست شما اکنون قابلیت خرید و سفارش دادن را دارد و در سرتاسر سرویس پیپرلاین منتشر شده
				
				</div>
				<?php
			}elseif($post['published'] == '2'){
				?>
				<div class="alert alert-danger alert-dismissible fade show" role="alert">
					<img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-alert-5803870-4923157.png" style="width: 70px;" alt="">
					<br>
					<strong>مخزن شما تایید نشد </strong> 
					<br>
					<?php echo $post['error']?>
				</div>
				<?php
			}
			?>











				<!-- Modal -->
				<div class="modal fade" id="addCollect" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
				<div class="modal-dialog modal-dialog-centered modal-xl">
					<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="staticBackdropLabel"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
						<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
						<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
						</svg> افزودن به کالکشن</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>	
					<div class="modal-body">
						
						<div id="displayAlert"></div>
						<div class="col-12">
							<!-- Blog list table START -->
							<div class="card border bg-transparent rounded-3">
								<!-- Card header START -->
								<div class="card-header bg-transparent border-bottom p-3">
									<div class="d-sm-flex justify-content-sm-between align-items-center">
										<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کالکشن ها</font></font>
																	</h5>


										<a class="small" href="#" id="addNewCollection"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
										<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
										<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
										</svg> ساخت کالکشنن جدید </font></font></a>						
									</div>
								</div>
								<!-- Card header END -->

								<!-- Card body START -->
								<div class="card-body p-3" id="displayNoti1">
									<style>
									.scroll-example {
										overflow: auto;
										scrollbar-width: none; /* Firefox */
										-ms-overflow-style: none; /* IE 10+ */
									}

									.scroll-example::-webkit-scrollbar {
										width: 0px;
										background: transparent; /* Chrome/Safari/Webkit */
									}
									</style>
										<div class="card-body p-0" id="displayNowCollection">
											<ul style="height: 400px;" class="list-group list-unstyled list-group-flush scroll-example">
											<?php
											if(! $post['collect'] == 0){
												$query_Collect1 = mysqli_query($con, 'select * from session where name="collect" and userId='.$_SESSION['id'].' and id='.$post['collect'].'');
												$collect1 = mysqli_fetch_assoc($query_Collect1);
												if($collect1){
													?>
													<a href="#" class="list-group-item list-group-item-action" id="deleteCollection"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
													<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
													<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
													</svg> حذف از کالکشن فعلی "<?php echo $collect1['data']?>"</a>
													<br>
													


													<script>
													$('#deleteCollection').click(function(event){
													event.preventDefault();
													$('#deleteCollection').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال بارگیری...');

													
													$.ajax({
														method: "POST",
														url: "../../index.php?controller=create&method=collect&mode=3&id=<?php echo $_GET['id']?>",
														data: { code: "1"}
													})
														.done(function(data){
														$('#deleteCollection').html('<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16"><path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/><path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/></svg> کالکشن فعلی این پست حذف شد');
														})

													})
													</script>
													<?php
												}
												?>
	

												<?php
											}	
											?>

											<?php
											$query_Collect = mysqli_query($con, 'select * from session where name="collect" and userId='.$_SESSION['id'].' order by createDate Desc');
											$query_Collect_res = mysqli_query($con, 'select * from session where name="collect" and userId='.$_SESSION['id'].' order by createDate Desc');
											$collect = mysqli_fetch_assoc($query_Collect);
											if($collect){
												?>

												<div class="list-group">
											
												<?php
												while($res=mysqli_fetch_assoc($query_Collect_res)){
												?>
													<a href="#" class="list-group-item list-group-item-action" id="collectedTo<?php echo $res['id']?>"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
													<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
													<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
													</svg>  افزودن به کالکشن "<?php echo $res['data']?>"</a>

													<script>
													$('#collectedTo<?php echo $res['id']?>').click(function(event){
													event.preventDefault();
													$('#collectedTo<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال بارگیری...');

													
													$.ajax({
														method: "POST",
														url: "../../index.php?controller=create&method=collect&mode=4&postId=<?php echo $_GET['id']?>&id=<?php echo $res['id']?>",
														data: { code: "1"}
													})
														.done(function(data){
														$('#collectedTo<?php echo $res['id']?>').html('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16"><path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/><path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/></svg>  افزودن به کالکشن "<?php echo $res['data']?>"');
														$('#displayAlert').html(data);
														})

													})
													</script>
												<?php
												}
												?>
												</div>

												

												<?php
											}else{
												?>
												<section class="overflow-hidden">
													<div class="container">
														<div class="row">
													<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
														<!-- SVG shape START -->
														<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
														<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
															<g>
															<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
															<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
															<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
															<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
															<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
															<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
															<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
															<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
															c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
															<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
															<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
															c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
															</g>
														</svg>
														</figure>
														<!-- SVG shape START -->
														<!-- Content -->
														<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
														<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کالکشنی یافت نشد</font></font></h2>
														
													</div>
													</div>
													</div>
												</section>
												<?php
											}
											?>

											



											</ul>
										</div>
										<!-- Button -->

				

									<!-- Pagination START -->
									
									<!-- Pagination END -->
								</div>
							</div>
							<!-- Blog list table END -->
						</div>




											<script>
                                            $('#addNewCollection').click(function(event){
                                            event.preventDefault();
                                            $('#addNewCollection').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال بارگیری...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=collect&mode=1&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#addNewCollection').html('<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16"><path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/><path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/></svg> ساخت کالکشن جدید');
                                                $('#displayNowCollection').html(data);
                                                })

                                            })
                                            </script>




					</div>
			
					</div>
				</div>
				</div>










                <div class="bg-light rounded-3 p-4 mb-3">
							<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
							<hr>
					<!-- Content -->
						<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 40px;" alt=""> داشبورد پست</font></font></h6>
						<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> از این قسمت میتوانید محصولات خود را به شکل مجزا مورد برسی قرار دهید و انها را تحلیل کنید</font></font></p>
					<!-- Button -->
					<div class="d-sm-flex gap-3 align-items-center mt-3">
						<a href="index.php?content=open&id=<?php echo $post['idPost']?>" class="btn btn-primary mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده پست</font></font></a>
						<a href="dashboard.php?content=apiDoc&id=<?php echo $post['idPost']?>" class="btn btn-primary mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فعالسازی وبسرویس</font></font></a>


						<a class="btn btn-dark-soft" href="#" data-bs-toggle="modal" data-bs-target="#addCollect"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-add" viewBox="0 0 16 16">
						<path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h4a.5.5 0 1 0 0-1h-4a.5.5 0 0 1-.5-.5V7.207l5-5 6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z"/>
						<path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Zm-3.5-2a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 1 0 1 0v-1h1a.5.5 0 1 0 0-1h-1v-1a.5.5 0 0 0-.5-.5Z"/>
						</svg> افزودن کالکشن </a>

						<p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین تغییر 10 آگوست 2020</font></font></p>
					</div>
					<hr>
					<?php
					if($post['status'] == 1){
						?>
																		<div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                            <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5" checked="">
                                                                            <span class="d-block">انتشار</span>
                                                                            <span class="d-block small">در زمانی که این بخش روشن باشد پست شما سر تاسر پیپرلاین و برنامه های شخص ثالث منتشر میشود</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
						<?php
					}else{
						?>
																		<div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                            <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5">
                                                                            <span class="d-block">انتشار</span>
                                                                            <span class="d-block small">در زمانی که این بخش روشن باشد پست شما سر تاسر پیپرلاین و برنامه های شخص ثالث منتشر میشود</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>

																
						<?php
					}
					?>
					<script>
                                            $('#statusON').click(function(event){
                                            
                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=addPlaging&plagin=5&id=<?php echo $_GET['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#show_pv').html(data);
                                                })

                                            })
                    </script>
					<hr>
					
					<h6><img src="https://static-00.iconduck.com/assets.00/google-ads-icon-2048x1837-4vbvpswm.png" style='width: 20px;' alt=""> موشک رشد</h6>
					<small>به رشد عرضه خود با خدمات مدیریت تبلیغات پیپرلاین کمک کنید تا بتوانید بازخورد های بهتری از آن داشته باشید همین حالا این سرویس را تجربه کنید</small>
					<div class="list-group" >
              
					<?php 
					if($post['ads'] == 0){

					}else{
						$some_time = strtotime($post['AdStop']);

                        if($post['ads'] == 1){
                            $ad = 'غیر رایگان';
                        }elseif($post['ads'] == 2){
                            $ad = 'شراکت تجاری';
                        }elseif($post['ads'] == 3){
                            $ad = 'شراکت با کسبو کار های سازمانی';
                            
                        }else{
                            $ad = 'نامعلوم';
                        }
						?>
                        <div class="bg-light rounded-2 p-1 mb-1" >
                            <div class="bg-light rounded-2 p-1 mb-1">
                            <div class="container-fluid">
                            <h6> <img src="https://static-00.iconduck.com/assets.00/google-ads-icon-2048x1837-4vbvpswm.png" style="width: 30px;" alt="">  
                            سرویس فعال شما <br> <small><?php echo $ad?></small></h6>
                            <br>
                            <small>تاریخ اتمام اشتراک: <?php echo date('Y, d F', $some_time)?></small>

                            </div>
                            </nav>
                
                            </div>                               
                        </div>

						<?php
					}
					?>
					<a href="dashboard.php?content=adPay&id=<?php echo $_GET['id']?>"><strong><i class="bi bi-link-45deg"></i> پیوند دادن به موشک </strong></a>
				
					</div>
				</div>
				<!-- Grid START -->
				<div class="row g-4">
					
					<!-- Earning item -->
					<div class="col-md-6 col-xl-3">
						<div class="card card-body bg-success bg-opacity-10 p-4 h-100">
							<h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درآمد
								</font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="After US royalty withholding tax" data-bs-original-title="" title="">
									<i class="bi bi-info-circle-fill small"></i>
								</a>
							</h6>
							<h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['wallet']?> تومان</font></font></h2>
							<p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0.20٪</font></font><i class="bi bi-arrow-up"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">در مقابل ماه گذشته</font></font></p>
							<div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده بیانیه</font></font></a></div>
						</div>
					</div>

					<!-- Grid item -->
					<div class="col-md-6 col-xl-3">
						<div class="card card-body bg-info bg-opacity-10 p-4 h-100">
							<h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازدیدکنندگان ماهانه</font></font></h6>
							<h2 class="fs-1 text-info"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?></font></font></h2>
							<p class="mb-2"><span class="text-danger me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">07</font></font><i class="bi bi-arrow-down"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">از ماه گذشته</font></font></p>
							<div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده تجزیه و تحلیل</font></font></a></div>
						</div>
					</div>

					<!-- Grid item -->
					<div class="col-md-6 col-xl-3">
						<div class="card card-body bg-warning bg-opacity-15 p-4 h-100">
							<h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مشتریان شما</font></font></h6>
							<h2 class="fs-1 text-warning"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['payed']?></font></font></h2>
							<div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده پست ها</font></font></a></div>
						</div>
					</div>

					<!-- Grid item -->
					<div class="col-md-6 col-xl-3">
						<div class="card card-body bg-primary bg-opacity-10 p-4 h-100">
							<h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیروان</font></font></h6>
							<h2 class="fs-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['follower']?></font></font></h2>
							<p class="mb-2"><span class="text-success me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font><i class="bi bi-arrow-up"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">از ماه گذشته</font></font></p>
							<div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فالوورها را مدیریت کنید</font></font></a></div>
						</div>
					</div>

				</div>
				<!-- Grid END -->
			</div>

   
			<div class="col-12">
                            <!-- Counter START -->
                            <div class="row g-4">
                                
                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
                                                <i class="bi bi-people-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo number_format($post['views'] , 0 , "." , "," )?> </font></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازدید از صفحه</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
                                                <i class="bi bi-suit-heart-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><?php echo number_format($post['sagedSearch'] , 0 , "." , "," )?></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>علایق و پرسشگری</font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
                                                <i class="bi bi-bar-chart-line-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo number_format($post['saged'] , 0 , "." , "," )?></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">رشد طبیعی</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!-- Counter item -->
                                <div class="col-sm-6 col-lg-3">
                                    <div class="card card-body border p-3">
                                        <div class="d-flex align-items-center">
                                            <!-- Icon -->
                                            <div class="icon-xl fs-1 bg-info bg-opacity-10 rounded-3 text-info">
                                                <i class="bi bi-bookmark-check-fill"></i>
                                            </div>
                                            <!-- Content -->
                                            <div class="ms-3">
                                                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>  <?php echo number_format($post['sagedTag'] , 0 , "." , "," )?></font></h3>
                                                <h6 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کاوش در تگ</font></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Counter END -->
                        </div>

			<div class="col-lg-8">
				<!-- Chart START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom d-flex align-items-center p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/question-5321091-4471031.png" style="width: 35px" alt=""> اطلاعات مخزن</font></font></h5>
						&nbsp
						&nbsp

						<a href="../../core/rtl/dashboard.php?content=createPost&Edit=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary"><font><font style="vertical-align: inherit;">ویرایش مخزن</font></font></a>
						&nbsp

						<a href="../../core/rtl/dashboard.php?content=createPost&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary"><font><font style="vertical-align: inherit;">ویرایش سرویس</font></font></a>
					</div>
					
					<!-- Card body -->
					<div class="card-body">
						<div class="d-sm-flex justify-content-sm-between align-items-center mb-4">
							<!-- Avatar detail -->
							<div class="d-flex align-items-center">
								<!-- Avatar -->
								<div class="avatar avatar-lg">
									<img class="avatar-img rounded-circle border border-white border-3 shadow" src="<?php echo $user['avatar']?>" alt="">
								</div>
								<!-- Info -->
								<div class="ms-3">
									<h5 class="mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['username']?></font></font></h5>
									<p class="mb-0 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $user['email']?> </font></font></p>
								</div>
							</div>
							<!-- Tags -->
							<div class="d-flex mt-2 mt-sm-0">
								<h6 class="bg-danger py-2 px-3 text-white rounded"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">14K دنبال کنید</font></font></h6>
								<h6 class="bg-info py-2 px-3 text-white rounded ms-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">856 پست</font></font></h6>
							</div>
						</div>

						<!-- Information START -->
						<div class="row">
							<!-- Information item -->
							<div class="col-md-6">
								<ul class="list-group list-group-borderless">
                  <!-- Title -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عنوان: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></span>
									</li>
                  <!-- Full Name -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> قیمت: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['pay']?> تومان </font></font></span>
									</li>
                  <!-- User Name -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مالک حقیقی: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['title']?></font></font></span>
									</li>
								</ul>
							</div>

							<!-- Information item -->
							<div class="col-md-6">
								<ul class="list-group list-group-borderless">
                  <!-- Email ID -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه مالک: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['iduser']?>_<?php echo $user['username']?>_<?php echo $user['email']?></font></font></span>
									</li>
                  <!-- Mobile Number -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> شناسه مخزن: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $post['idPost']?></font></span>
									</li>
                  <!-- Joining Date -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ ایجاد: </font></font></span>
										<span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['date']?></font></font></span>
									</li>
								</ul>
							</div>

							<!-- Information item -->
							<div class="col-12">
								<ul class="list-group list-group-borderless">
                  					<!-- Description -->
									<li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شرح:</font></font></span>
										<p class="h6 mb-0"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></p>
									</li>
                                    <li class="list-group-item">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تگ ها:</font></font></span>
										<p class="h6 mb-0"><font style="vertical-align: inherit;"><?php echo $post['tag']?></font></p>
									</li>
								</ul>
							</div>
						</div>
						<!-- Information END -->
					</div>
				</div>
				<!-- Chart END -->
			</div>

			<div class="col-md-6 col-lg-4">
				<!-- Popular blog START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-sign-5339244-4466132.png" style="width: 35px;" alt=""> محاسبه مالیات شما در پیپرلاین</font></font></h5>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">

						<div class="row">
							<h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درآمد
								</font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="After US royalty withholding tax" data-bs-original-title="" title="">
									<i class="bi bi-info-circle-fill small"></i>
								</a>
							</h6>
							<h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['wallet']?> تومان</font></font></h2>
							<p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0.15٪</font></font><i class="bi bi-arrow-up"></i></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مالیات پیپرلاین </font></font></p>
							<div class="mt-auto"><a href="#" class="btn btn-link text-reset p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده بیانیه</font></font></a></div>
						<br>
						<hr>
							<!-- Content -->
								<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پس از کسر مالیات پیپرلاین</font></font></h6>
								<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالیات مصوب پیپرلاین برای همکاری در فروش محصولات شما 15 درصد از درامد دریافتی است</font></font></p>
							<!-- Button -->
							<div class="d-sm-flex gap-3 align-items-center mt-3">
								<a href="../../core/rtl/dashboard.php?content=payment" class="btn btn-primary mb-1" data-bs-toggle="modal" data-bs-target="#changePassword"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درخواست واریز</font></font></a>
								<?php
								$x = 15;
								$y = $post['wallet'];
								$res = ($x*$y)/100;
								$math = $y-$res;
								?>
								<p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  تومان <?php echo $math?>  </font></font></p>
								<p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  تومان <?php echo $res?>  </font></font></p>
							</div>

						</div>
						
					</div>
					<!-- Card body END -->

					<!-- Card footer -->
					<div class="card-footer border-top text-center p-3">
						<a href="../../core/rtl/dashboard.php?content=payment"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مدیریت مالی</font></font></a>
					</div>

				</div>
				<!-- Popular blog END -->
			</div>

      <div class="col-md-6 col-lg-4">
				<!-- Recent comment START -->
				<div class="card border h-100">
					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظرات اخیر</font></font></h5>
					</div>

					<!-- Card body START -->
					<div class="card-body p-3">

						<div class="row">
							<!-- Comment item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
									<!-- Avatar -->
									<div class="avatar avatar-lg flex-shrink-0">
										<img class="avatar-img rounded-2" src="assets/images/avatar/06.jpg" alt="آواتار">
									</div>
									<!-- Info -->
									<div class="ms-3">
										<p class="mb-1 h6 fw-normal"> <a class="stretched-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فرض کنید صبحانه را صبح یا کاملاً حل کنید..</font></font></a></p>
										<div class="d-flex justify-content-between">
											<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط جوآن</font></font></p>
										</div>
									</div>
								</div>
							</div>

							<!-- Divider -->
							<hr class="my-3">

							<!-- Comment item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
									<!-- Avatar -->
									<div class="avatar avatar-lg flex-shrink-0">
										<img class="avatar-img rounded-2" src="assets/images/avatar/08.jpg" alt="آواتار">
									</div>
									<!-- Info -->
									<div class="ms-3">
										<p class="mb-1 h6 fw-normal"> <a class="stretched-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ما تمرکز زیادی روی درک رفتار...</font></font></a></p>
										<div class="d-flex justify-content-between">
											<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط آلن اسمیت</font></font></p>
										</div>
									</div>
								</div>
							</div>

							<!-- Divider -->
							<hr class="my-3">

							<!-- Comment item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
									<!-- Avatar -->
									<div class="avatar avatar-lg flex-shrink-0">
										<img class="avatar-img rounded-2" src="assets/images/avatar/04.jpg" alt="آواتار">
									</div>
									<!-- Info -->
									<div class="ms-3">
										<p class="mb-1 h6 fw-normal"> <a class="stretched-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فرض کنید صبحانه را صبح یا کاملاً حل کنید..</font></font></a></p>
										<div class="d-flex justify-content-between">
											<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط لوئیس فرگوسن</font></font></p>
										</div>
									</div>
								</div>
							</div>

							<!-- Divider -->
							<hr class="my-3">

							<!-- Comment item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
									<!-- Avatar -->
									<div class="avatar avatar-lg flex-shrink-0">
										<img class="avatar-img rounded-2" src="assets/images/avatar/05.jpg" alt="آواتار">
									</div>
									<!-- Info -->
									<div class="ms-3">
										<p class="mb-1 h6 fw-normal"> <a class="stretched-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فرض کنید صبحانه را صبح یا کاملاً حل کنید..</font></font></a></p>
										<div class="d-flex justify-content-between">
											<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توسط جوآن والاس</font></font></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Card body END -->
				</div>
				<!-- Recent comment END -->
			</div>
			<br>
			<hr>
			<br>
			<h2 class="h3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/application-5590970-4652973.png" style="width: 50px;" alt=""> افزونه های نصب شده</font></font></h2>
			<br>
			<br>
			
			<div class="container">
				<div class="row g-4">


					<div class="col-md-6 col-xl-4">
						<!-- Category item START -->
						<div class="card border h-100">
							<!-- Card header -->
							<div class="card-header border-bottom p-3">
								<div class="d-flex align-items-center">
									<div class="icon-lg shadow bg-body rounded-circle">⛰️</div>
									<h3 class="mb-0 ms-3">مشتریان</h3>
								</div>
							</div>

							<!-- Card body START -->
							<div class="card-body p-3">
								<p>لیست سفرشات و مشخصات و اطلاعات ارسالی مشتریان شما به هنگام خرید در نزد ما در این سرویس است</p>

								<!-- Followers and Post -->
								<div class="d-flex justify-content-between">
									<!-- Total post -->
									<div>
										<h5 class="mb-0">846</h5>
										<h6 class="mb-0 fw-light">Total posts</h6>
									</div>

									<!-- Avatar group -->
									<ul class="avatar-group mb-0">
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/02.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/03.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- Card body END -->

							<!-- Card footer -->
							<div class="card-footer border-top text-center p-3">
								<a href="../../core/rtl/dashboard.php?content=costomer&id=<?php echo $_GET['id']?>" class="btn btn-primary-soft w-100 mb-0">مشاهده فایل</a>
							</div>
						</div>
						<!-- Category item END -->
					</div>

					<?php
					if($post['top'] == 1){
						?>
						<div class="col-md-6 col-xl-4">
							<!-- Category item START -->
							<div class="card border h-100">
								<!-- Card header -->
								<div class="card-header border-bottom p-3">
									<div class="d-flex align-items-center">
										<div class="icon-lg shadow bg-body rounded-circle">🩸</div>
										<h3 class="mb-0 ms-3">پست ویژه</h3>
									</div>
								</div>

								<!-- Card body START -->
								<div class="card-body p-3">
									<p>ویژگی پست ویژه برای این پست فعال است این الگوریتم کمک میکند تا پست شما به علافه مندان بیشتر پیشنهاد شود</p>

									<!-- Followers and Post -->
									<div class="d-flex justify-content-between">
										<!-- Total post -->
										<div>
											<h5 class="mb-0">روزانه 88 تا 200</h5>
											<h6 class="mb-0 fw-light">تعداد پیشنهادات امروز</h6>
										</div>

										<!-- Avatar group -->
										<ul class="avatar-group mb-0">
											<li class="avatar avatar-xs">
												<img class="avatar-img rounded-circle" src="assets/images/avatar/04.jpg" alt="avatar">
											</li>
											<li class="avatar avatar-xs">
												<img class="avatar-img rounded-circle" src="assets/images/avatar/05.jpg" alt="avatar">
											</li>
											<li class="avatar avatar-xs">
												<img class="avatar-img rounded-circle" src="assets/images/avatar/06.jpg" alt="avatar">
											</li>
											<li class="avatar avatar-xs">
												<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
											</li>
										</ul>
									</div>
									
								</div>
								<!-- Card body END -->

					
							</div>
							<!-- Category item END -->
						</div>
						<?php
					}
					?>
					<?php
					if($post['SEO'] == 1){
						?>
						<div class="col-md-6 col-xl-4">
							<!-- Category item START -->
							<div class="card border h-100">
								<!-- Card header -->
								<div class="card-header border-bottom p-3">
									<div class="d-flex align-items-center">
										<div class="icon-lg shadow bg-body rounded-circle">🩸</div>
										<h3 class="mb-0 ms-3">سئو</h3>
									</div>
								</div>

								<!-- Card body START -->
								<div class="card-body p-3">
									<p>الگوریتم سئو برای این پست فعال است و ما در فروش محصول و رتبه یابی گوگل در کنار شما هستیم</p>

									<!-- Followers and Post -->
									<div class="d-flex justify-content-between">
										<!-- Total post -->
										<div>
											<h5 class="mb-0">1-تگ های هوشمند</h5>
											<h5 class="mb-0">2-کلمات کلیدی</h5>
											<h5 class="mb-0">3-بک لینک مرتبط</h5>
											<h5 class="mb-0">4-تولید محتوای خودکار</h5>
											<h6 class="mb-0 fw-light">الگوریتم های فعال برای شما</h6>
										</div>

							
									</div>
									
								</div>
								<!-- Card body END -->

							</div>
							<!-- Category item END -->
						</div>
						<?php
					}
					?>

					<div class="col-md-6 col-xl-4">
						<!-- Category item START -->
						<div class="card border h-100">
							<!-- Card header -->
							<div class="card-header border-bottom p-3">
								<div class="d-flex align-items-center">
									<div class="icon-lg shadow bg-body rounded-circle"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/download-folder-5568716-4644433.mp4" type="video/mp4" autoplay="autoplay" style="width: 70px;" loop="loop"></video></div>
									<h3 class="mb-0 ms-3"> مدیریت فایل ها</h3>
								</div>
							</div>

							<!-- Card body START -->
							<div class="card-body p-3">
								<p>فایل های ذخیره شده در فضای این مخزن را مشاهده کنید و انها را مدیریت کنید تا بهتر با مخاطبان خود ارتبات بگیرید</p>

								<!-- Followers and Post -->
								<div class="d-flex justify-content-between">
									<!-- Total post -->
									<div>
										<h5 class="mb-0">657</h5>
										<h6 class="mb-0 fw-light">Total posts</h6>
									</div>

									<!-- Avatar group -->
									<ul class="avatar-group mb-0">
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/07.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/08.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/09.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- Card body END -->

							<!-- Card footer -->
							<div class="card-footer border-top text-center p-3">
								<a href="../../core/rtl/dashboard.php?content=fils&id=<?php echo $post['idPost']?>" class="btn btn-primary-soft w-100 mb-0">باز کنید</a>
							</div>
						</div>
						<!-- Category item END -->
					</div>

					<div class="col-md-6 col-xl-4">
						<!-- Category item START -->
						<div class="card border h-100">
							<!-- Card header -->
							<div class="card-header border-bottom p-3">
								<div class="d-flex align-items-center">
									<div class="icon-lg shadow bg-body rounded-circle">🤝</div>
									<h3 class="mb-0 ms-3"> نظرات</h3>
								</div>
							</div>

							<!-- Card body START -->
							<div class="card-body p-3">
								<p> نظرات و پیام هایی مشتریان را در این باره بخوانید و پاسخ دهید و برای انها نظر سنجی بفرستید</p>

								<!-- Followers and Post -->
								<div class="d-flex justify-content-between">
									<!-- Total post -->
									<div>
										<h5 class="mb-0">657</h5>
										<h6 class="mb-0 fw-light">Total posts</h6>
									</div>

									<!-- Avatar group -->
									<ul class="avatar-group mb-0">
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/07.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/08.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/09.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- Card body END -->

							<!-- Card footer -->
							<div class="card-footer border-top text-center p-3">
								<a href="../../core/rtl/dashboard.php?content=messages&id=<?php echo $post['idPost']?>" class="btn btn-primary-soft w-100 mb-0">باز کنید</a>
							</div>
						</div>
						<!-- Category item END -->
					</div>

					<div class="col-md-6 col-xl-4">
						<!-- Category item START -->
						<div class="card border h-100">
							<!-- Card header -->
							<div class="card-header border-bottom p-3">
								<div class="d-flex align-items-center">
									<div class="icon-lg shadow bg-body rounded-circle">🤖</div>
									<h3 class="mb-0 ms-3">گزارشات</h3>
								</div>
							</div>

							<!-- Card body START -->
							<div class="card-body p-3">
								<p>گزارشات مشتریان خود را بخوانید و برسی کنید تا بتوانیم مشکل را در کنار یکدیگر حل کنیم تا هم شما راضی باشید و هم مشتریانتان را افزایش دهید</p>

								<!-- Followers and Post -->
								<div class="d-flex justify-content-between">
									<!-- Total post -->
									<div>
										<h5 class="mb-0"><?php echo $post['report']?></h5>
										<h6 class="mb-0 fw-light">تعداد گزارشات</h6>
									</div>

									<!-- Avatar group -->
									<ul class="avatar-group mb-0">
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/11.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/12.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- Card body END -->

							<!-- Card footer -->
							<div class="card-footer border-top text-center p-3">
								<a href="dashboard.php?content=openRep&id=<?php echo $post['idPost']?>" class="btn btn-primary-soft w-100 mb-0">بازکردن با ...</a>
							</div>
						</div>
						<!-- Category item END -->
					</div>

					<div class="col-md-6 col-xl-4">
						<!-- Category item START -->
						<div class="card border h-100">
							<!-- Card header -->
							<div class="card-header border-bottom p-3">
								<div class="d-flex align-items-center">
									<div class="icon-lg shadow bg-body rounded-circle">🤖</div>
									<h3 class="mb-0 ms-3">Technology</h3>
								</div>
							</div>

							<!-- Card body START -->
							<div class="card-body p-3">
								<p>Meant balls it if up doubt small purse. Required his you put the outlived answered position.</p>

								<!-- Followers and Post -->
								<div class="d-flex justify-content-between">
									<!-- Total post -->
									<div>
										<h5 class="mb-0">846</h5>
										<h6 class="mb-0 fw-light">Total posts</h6>
									</div>

									<!-- Avatar group -->
									<ul class="avatar-group mb-0">
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/10.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/11.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<img class="avatar-img rounded-circle" src="assets/images/avatar/12.jpg" alt="avatar">
										</li>
										<li class="avatar avatar-xs">
											<div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
										</li>
									</ul>
								</div>
								
							</div>
							<!-- Card body END -->

							<!-- Card footer -->
							<div class="card-footer border-top text-center p-3">
								<a href="#" class="btn btn-primary-soft w-100 mb-0">View posts</a>
							</div>
						</div>
						<!-- Category item END -->
					</div>

			

			
			
			
				</div>
			</div>



            

			

			

			

			

			
			
			
		</div>

			
		</div>
	</div>
</section>