<?php
$query = mysqli_query($con, 'select * from comment where idcomment="'.$_GET['id'].'"');
$comment = mysqli_fetch_assoc($query);
if($comment){
    $post_hash = mysqli_query($con, 'select * from posts where idPost="'.$comment['piperlinePost'].'"');
    $post = mysqli_fetch_assoc($post_hash);
    if(! $post){
        die();
    }
}
?>
<section class="py-4">
	<div class="container">
        <div class="row pb-4">
                <div class="col-12">
            <!-- Title -->
                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                        <h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/message-6248662-5110056.mp4" style="width: 80px;" type="video/mp4" autoplay="autoplay" loop="loop"></video> مشاهده نامه</font></font></h1>			
                    </div>
                </div>
            </div>
            <div class="row g-4">
                

                <div class="bg-light rounded-3 p-4 mb-3">
							<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
							<hr>
				</div>
				<!-- Grid START -->

                
        
                

            <?php
                        if(isset($_GET['id'])){
                            $query = mysqli_query($con, 'select * from comment where idcomment="'.$_GET['id'].'"');
                            $comment = mysqli_fetch_assoc($query);
                            if($comment){
                                $query_user = mysqli_query($con, 'select * from user where iduser="'.$comment['creatorId'].'"');
                                $user1 = mysqli_fetch_assoc($query_user);

                            }else{
                                die();
                            }
                        }
                        ?>


                
                

                
                
                <div class="col-12">
                    <!-- Blog list table START -->
                    <div class="card border bg-transparent rounded-3">
                        <!-- Card header START -->
                        <div class="card-header bg-transparent border-bottom p-3">
                            <div class="d-sm-flex justify-content-sm-between align-items-center">
                                <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظرات و پیام ها </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></span></h5>
                                <a href="https://www.spacify.ir/Wizify/index.php?controller=user&method=profile&id=<?php echo $user1['iduser']?>&clint=true" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">باز کردن در مسنجر اسپیسیفای</font></font></a>
                            </div>
                        </div>
                        <!-- Card header END -->

                        <!-- Card body START -->
                        <div class="card-body p-3">
                        

                        <div>
                            
                                <!-- Comment children level 2 -->
                                <div class="my-4 d-flex ps-2 ps-md-3">
                                <img class="avatar avatar-md rounded-circle float-start me-3" src="<?php echo $user1['avatar']?>" alt="avatar">
                                <div>
                                    <div class="mb-2">
                                        <h5 class="m-0"><?php echo $user1['username']?></h5>
                                        <span class="me-3 small"><?php echo $comment['time']?> </span>
                                        <a href="#" class="text-body fw-normal">Reply</a>
                                    </div>

                                    <?php echo $comment['comment']?>
                                </div>
                                </div>
                    
                                <!-- Comment level 2 -->
                                
                            <!-- Comment level 1 -->
                            

                        </div>









                        </div>
                    </div>
                    <!-- Blog list table END -->
                </div>
            </div>
            <br>
            <div class="row g-4">
                

                

                
        
                

                

                
                

                
                
                <div class="col-12">
                    <!-- Blog list table START -->
                    <div class="card border bg-transparent rounded-3">
                        <!-- Card header START -->
                        <div class="card-header bg-transparent border-bottom p-2">
                            <div class="d-sm-flex align-items-center">
                                <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> پاسخ </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></span></h5>
                                <a id="image_button" href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن عکس</font></font></a>
                                &nbsp
                                <a id="video_button" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن فیلم</font></font></a>
                                &nbsp
                                <a id="audio_button" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن صوت </font></font></a>
                                &nbsp
                                <a id="file_button" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن فایل</font></font></a>
                                &nbsp
                                <a id="close_button" style="display: none;" class="btn btn-sm btn-danger mb-0">X<font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> بستن افزودنی ها</font></font></a>
                            </div>
                        </div>
                        <!-- Card header END -->

                        <!-- Card body START -->
                        <div class="card-body p-3">
                        

                        <div>
                            <form action="../../index.php?controller=message&method=rep" method="POST">

                                <div id="image_fileSHOW" style="display: none;" class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن عکس </font></font></label>
                                        <input name="image" type="text" class="form-control" placeholder=" لینک عکس را وارد کنید  ">
                                </div>
                                <input name="idComment" type="text" style="display: none;" class="form-control" value="<?PHP echo $_GET['id']?>" placeholder=" لینک عکس را وارد کنید  ">

                                <div id="video_fileSHOW" style="display: none;" class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن ویدیو </font></font></label>
                                        <input name="video" type="text" class="form-control" placeholder=" لینک ویدیو را وارد کنید  ">
                                </div>

                                <div id="audio_fileSHOW" style="display: none;" class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن صوت </font></font></label>
                                        <input name="audio" type="text" class="form-control" placeholder=" لینک صوت را وارد کنید  ">
                                </div>

                                
                                <div id="file_fileSHOW" style="display: none;" class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن فایل </font></font></label>
                                        <input name="file" type="text" class="form-control" placeholder=" لینک فایل را وارد کنید  ">
                                </div>

                                <script>
                                            $(document).ready(function(){
                                                    $("#image_button").on("click", function(event){
                                                        event.preventDefault();
    
                                                        document.getElementById('image_fileSHOW').style.display = "flex";
                                                        document.getElementById('close_button').style.display = "flex";
                                                        document.getElementById('video_fileSHOW').style.display = "none";
                                                        document.getElementById('audio_fileSHOW').style.display = "none";
                                                        document.getElementById('file_fileSHOW').style.display = "none";
        
                                                    });
                                                });
                                </script>

                                <script>
                                            $(document).ready(function(){
                                                    $("#video_button").on("click", function(event){
                                                        event.preventDefault();

                                                        document.getElementById('close_button').style.display = "flex";
                                                        document.getElementById('video_fileSHOW').style.display = "flex";
                                                        document.getElementById('image_fileSHOW').style.display = "none";
                                                        document.getElementById('audio_fileSHOW').style.display = "none";
                                                        document.getElementById('file_fileSHOW').style.display = "none";
                                                    });
                                                });
                                </script>

                                <script>
                                            $(document).ready(function(){
                                                    $("#audio_button").on("click", function(event){
                                                        event.preventDefault();

                                                        document.getElementById('close_button').style.display = "flex";
                                                        document.getElementById('audio_fileSHOW').style.display = "flex";
                                                        document.getElementById('image_fileSHOW').style.display = "none";
                                                        document.getElementById('video_fileSHOW').style.display = "none";
                                                        document.getElementById('file_fileSHOW').style.display = "none";
                                                    });
                                                });
                                </script>

                                <script>
                                            $(document).ready(function(){
                                                    $("#file_button").on("click", function(event){
                                                        event.preventDefault();
    
                                                        document.getElementById('file_fileSHOW').style.display = "flex";
                                                        document.getElementById('image_fileSHOW').style.display = "none";
                                                        document.getElementById('close_button').style.display = "flex";
                                                        document.getElementById('video_fileSHOW').style.display = "none";
                                                        document.getElementById('audio_fileSHOW').style.display = "none";
                                                    });
                                                });
                                </script>
                                
                                <script>
                                            $(document).ready(function(){
                                                    $("#close_button").on("click", function(event){
                                                        event.preventDefault();

                                                        document.getElementById('close_button').style.display = "none";
                                                        document.getElementById('video_fileSHOW').style.display = "none";
                                                        document.getElementById('image_fileSHOW').style.display = "none";
                                                        document.getElementById('audio_fileSHOW').style.display = "none";
                                                        document.getElementById('file_fileSHOW').style.display = "none";
                                                    });
                                                });
                                </script>

                                <div class="col-12">
                                    <label class="form-label"> پاسخ شما *</label>
                                    <textarea class="form-control" rows="3" name="txt"></textarea>
                                </div>
                                <small>در این قسمت میتوانید همانند یک فایل هر چه میخواهید از کد های html گرفته تا پیام های شخصی سازی شده و اینهادر قالب پاسخ پست نمایش داده میشود</small>
                                <br>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">ارسال پیام </button>
                                </div>
                            </form>
                        </div>








                        </div>
                    </div>
                    <!-- Blog list table END -->
                </div>
            </div>
        </div>
    </div>
</section>