<?PHP 
if(! $user['piperAdmin'] == 1){
    die();
}
$query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query);
if(! $post){
    die();
}

$query = mysqli_query($con, 'select * from user where iduser="'.$post['idUser'].'"');
$us = mysqli_fetch_assoc($query);
if(! $us){
    die();
}
?>
<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 
                        
                                    <!-- Avatar -->
                                    <div class="avatar me-3">
                                        <img class="avatar-img rounded-circle shadow" src="<?php echo $us['avatar']?>" alt="آواتار">
                                    </div>
                                    <div>
                                        <a class="h6 mt-2 mt-sm-0" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['username']?></font>                                                                            
                                        <?php 
                                        if($us['admin'] == 1){
                                            ?>
                                            <i class="bi bi-patch-check-fill text-info small"></i>

                                            <?php
                                        }
                                        ?>
                                                                                </font></a>
                                        <p class="small m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['email']?></font></font></p>
                                        <a href="https://www.qitsource.ir"><span class="badge bg-primary rounded-pill"><font style="vertical-align: inherit;">QPassID<?php echo $us['iduser']?>@</font></span></a>
                                    </div>
                            </font></font>
														</h5>


							<a class="small" href="dashboard.php?content=profile&id=<?php echo $us['iduser']?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1">مشاهده پروفایل</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0">
                            نام واقعی: <?php echo $us['title']?> 
                            <br>
                            شماره تلفن: <?php echo $us['phoneNumber']?> 
                            <br>
                            گزارش ها: <?php echo $us['report']?> 
                            <br>
                            <?php
                            if($us['enabled'] == 2){
                                ?>
                                محدودیت ها :  محدود شده

                               <?php
                            }elseif($us['enabled'] == 0){
                                ?>
                                 محدودیت ها :  مسدود کامل

                                <?php
                            }else{
                                ?>
                                 محدودیت ها : هیچ محدودیتی ندارد

                                <?php
                            }
                            
                            ?> 
                            <br>
                            موجودی ولت: <?php echo number_format($us['charge'] , 0 , "." , "," )?>
                            <br>
                            درآمد: <?php echo number_format($us['Income'] , 0 , "." , "," )?>

                            <?php
                            if($us['status'] == 2){
                                ?>
                                <br>
                                <br>
                                <div class="alert alert-info" role="alert">
                                درخواست وارسی داده است
                                </div>
                                <?php
                            }
                            ?>

                            <div class="alert alert-primary" role="alert">
                            کاربر درخواست واریزی داده است
                            </div>

                                <?php 
								$num = 0;
                                $posts ='1';
								$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" order by date Desc');
								$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" order by date Desc');
								$file = mysqli_fetch_assoc($query_1212);
								if($file){
									while($res=mysqli_fetch_assoc($file_hash)){
									    $num = $num+$res['by'];
                                        $posts = $posts.','.$res['idPost'];
									}
								}
                                $num1 = 0;
                                $query_bys = mysqli_query($con, 'select * from session where piperline IN ('.$posts.') and name = "order"');
                                $bys_hash = mysqli_query($con, 'select * from session where piperline IN ('.$posts.') and name = "order"');
                                $bys = mysqli_fetch_assoc($query_bys);
								if($bys){
                                    while($res=mysqli_fetch_assoc($bys_hash)){
                                        $num1 = $num1+1;
                                    }
                                }

                                if($num == $num1){

                                }else{
                                    ?>
                                    <div class="alert alert-secondary" role="alert">
                                    مشکلی در فروش وجود دارد 
                                    <br>    
                                    تعداد فروش ثبت شده: <?php echo $num?>
                                    <br>
                                    تعداد فروش واقعی: <?php echo $num1?>
                                    </div>

                                    <?php
                                }
								?>

                                

                                

                            <h5>گزارش ها</h5>
                            <br>
                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                            

                                <?php 
                                    $posts = '1';
                                    $query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$us['iduser'].'" and published="1" order by date Desc');
                                    $file_hash = mysqli_query($con, 'select * from posts where idUser="'.$us['iduser'].'" and published="1" order by date Desc');
                                    $file = mysqli_fetch_assoc($query_1212);
                                    if($file){
                                        while($res=mysqli_fetch_assoc($file_hash)){
                                            $posts = $posts.','.$res['idPost'];
                                        }
                                    }
                                    ?>
        
        
                                        <?php
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                                $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                                $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['data'].'"'));
                                                $order = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where name="order" and userId='.$res['userId'].' and piperline='.$post['idPost'].''));
                                                if($order){
                                                    $cos = 'مشتری';
                                                }else{
                                                    $cos = '';
                                                }
                                                ?>
                                
                                                <!-- Notif item -->
                                                    <a href="index.php?content=open&id=<?php echo $post['idPost']?>" style="color: black;"><small><?php echo $post['title']?></small></a>
        
                                                    <div class="list-group-item-action border-0 border-bottom d-flex p-3">
                                                        
                                                    <div class="me-3">
                                                        <div class="avatar avatar-sm">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                                            <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                                                            </svg>                           
                                                        </div>
                                                    </div>
                                                    
                                                    <div>
                                                        <?php
                                                        if($res['rol'] == '1'){
                                                            $status = 'برسی شده';
                                                        }elseif($res['rol'] == '2'){
                                                            $status = 'مجددا کاربر اعلام مشکل کرد';
                                                        }else{
                                                            $status = '';
                                                        } 
                                                        ?>
                                                        <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">"<a href='index.php?content=profile&id=<?php echo $us['iduser']?>'><?php echo $us['username']?></a>"</font> گزارشی برای مخزن شما نوشت</font><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" ><?php echo $cos?></font></font></span> <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="status<?php echo $res['id']?>"><?php echo $status?></font></font></span></h6>
                                                        <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?> </font></font></span>
                                                        <?php
                                                        $message = 'سلام من '.$user['username'].' هستم بابت گزارشتون روی مخزن '.$post['title'].' مزاحمتون میشم:';
                                                        
                                                        ?>
                                                        <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">
        
                                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">
        
                                                                    نوشتن پیام
                                                        </a>
                                                        <a class="btn btn-danger-soft btn-sm" href="#" id="deleteReport<?php echo $res['id']?>">حذف گزارش</a>

                                                        <?php
                                                        if($res['payment'] == 1){

                                                        }else{
                                                            ?>
                                                            <a class="btn btn-danger-soft btn-sm" href="#" id="cancel<?php echo $res['id']?>">کنسل کردن سفارش</a>

                                                            <?php
                                                        }
                                                        ?>
                                                            <script>
                                                            $('#deleteReport<?php echo $res['id']?>').click(function(event){
                                                            event.preventDefault();
                                                            $('#deleteReport<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                            
                                                            $.ajax({
                                                                method: "POST",
                                                                url: "../../index.php?controller=account&method=adminReq&mode=7&id=<?php echo $us['iduser']?>&idRep=<?php echo $res['id']?>",
                                                                data: { code: "1"}
                                                            })
                                                                .done(function(data){
                                                                $('#deleteReport<?php echo $res['id']?>').html(data);
        
                                                                })
        
                                                            })
                                                            </script>
                                                            <script>
                                                            $('#cancel<?php echo $res['id']?>').click(function(event){
                                                            event.preventDefault();
                                                            $('#cancel<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                            
                                                            $.ajax({
                                                                method: "POST",
                                                                url: "../../index.php?controller=create&method=cancelOrder1&id=<?php echo $res['id']?>",
                                                                data: { code: "1"}
                                                            })
                                                                .done(function(data){
                                                                $('#cancel<?php echo $res['id']?>').html(data);
        
                                                                })
        
                                                            })
                                                            </script>
                                                        <?php
                                                        if($res['rol'] == '1'){
                                                        }else{
                                                            ?>
                                                            <a id="inter<?php echo $res['id']?>" href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">
        
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-eyeglasses" viewBox="0 0 16 16">
                                                                <path d="M4 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm2.625.547a3 3 0 0 0-5.584.953H.5a.5.5 0 0 0 0 1h.541A3 3 0 0 0 7 8a1 1 0 0 1 2 0 3 3 0 0 0 5.959.5h.541a.5.5 0 0 0 0-1h-.541a3 3 0 0 0-5.584-.953A1.993 1.993 0 0 0 8 6c-.532 0-1.016.208-1.375.547zM14 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                                                                </svg>
                                                            رسیدگی شد 
                                                            </a>
        
                                                            
                                                            <script>
                                                            $('#inter<?php echo $res['id']?>').click(function(event){
                                                            event.preventDefault();
                                                            $('#inter<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                            
                                                            $.ajax({
                                                                method: "POST",
                                                                url: "../../index.php?controller=message&method=seeRep&id=<?php echo $res['id']?>",
                                                                data: { code: "1"}
                                                            })
                                                                .done(function(data){
                                                                $('#status<?php echo $res['id']?>').html(data);
                                                                $('#inter<?php echo $res['id']?>').html('');
        
                                                                })
        
                                                            })
                                                            </script>


                                                            <?php
                                                        } 
                                                        ?>
                                            
                                                        </div>
                                                        
            
                                                    </div>
                                                <!-- Notif item -->
                                                <?php
        
                                            }
                                        }else{
                                            ?>
                                            <section class="overflow-hidden">
                                                <div class="container">
                                                    <div class="row">
                                                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                    <!-- SVG shape START -->
                                                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                        <g>
                                                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                        </g>
                                                    </svg>
                                                    </figure>
                                                    <!-- SVG shape START -->
                                                    <!-- Content -->
                                                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارشی یافت نشد</font></font></h2>
                                                    
                                                </div>
                                                </div>
                                                </div>
                                            </section>
                                            <?php
                                        }
                                        ?>
        
        
                            </div>
                            <!-- Card body END -->



    


                            <hr>
                            <div id="displayNowAdmin"></div>

                            <a class="btn btn-dark-soft" href="#" id="statusAup">محدود سازی</a>
                            <a class="btn btn-dark-soft" href="#" id="blockedUser">مسدود</a>
                            <a class="btn btn-dark-soft" href="#" id="seeUser">برسی شد</a>

                            <?php
                            if($us['status'] == 2){
                                ?>
                                <a class="btn btn-dark-soft" href="#" id="endBlocked">آزادسازی</a>
                                <?php
                            }
                            ?>


                                            <script>
                                            $('#statusAup').click(function(event){
                                            event.preventDefault();
                                            $('#statusAup').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=1&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#statusAup').html('محدود سازی');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>

                                            <script>
                                            $('#blockedUser').click(function(event){
                                            event.preventDefault();
                                            $('#blockedUser').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=2&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#blockedUser').html('مسدود');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>

                                            <script>
                                            $('#endBlocked').click(function(event){
                                            event.preventDefault();
                                            $('#endBlocked').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=3&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#endBlocked').html('آزاد سازی');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>


                                            <script>
                                            $('#seeUser').click(function(event){
                                            event.preventDefault();
                                            $('#seeUser').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=4&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#seeUser').html('برسی شد');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>



							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>