<?php
if(! isset($_GET['id'])){
    die();
}

?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><img src="https://static.vecteezy.com/system/resources/previews/009/374/090/original/3d-user-account-icon-png.png" style="width: 50px;" alt=""> اشخاصی که این حساب آنها را دنبال میکند</h1>
			</div>
		</div>


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between">
							<!-- Search bar -->
							<div class="col-md-8">
								<form class="rounded position-relative">
									<input class="form-control bg-transparent" type="search" placeholder="Search" aria-label="Search">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>
							<!-- Tab buttons -->
							<div class="col-md-3">
								<!-- Tabs START -->
								<ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
									<!-- Grid tab -->
									<li class="nav-item" role="presentation">
										<a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
											<i class="fas fa-fw fa-list-ul"></i>
										</a>
									</li>
									<!-- List tab -->
									<li class="nav-item" role="presentation">
										<a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
											<i class="fas fa-fw fa-th-large"></i>
										</a>
									</li>
								</ul>
								<!-- Tabs end -->
							</div>
						</div>
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						<!-- Tabs content START -->
						<div class="tab-content py-0 my-0">
                            <?php
                            $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_GET['id'].'" order by list Desc');
                            $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_GET['id'].'" order by list Desc');
                            $file = mysqli_fetch_assoc($query_1212);
                            if($file){
                                ?>
                                    <!-- Tabs content item START -->
                                    <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                        <!-- Table START -->
                                        <div class="table-responsive border-0">
                                            <table class="table align-middle p-4 mb-0 table-hover">
                             

                                                <!-- Table body START -->
                                                <tbody class="border-top-0">


                                                <?php
		
                                                while($res=mysqli_fetch_assoc($file_hash)){
													$userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
													if($userData){
														?>
														<!-- Table row -->
														<tr>
															<!-- Table data -->
															<td>
																<div class="d-flex align-items-center position-relative">
																	<!-- Image -->
																	<div class="avatar avatar-md">
																		<img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
																	</div>
																	<div class="mb-0 ms-2">
																		<!-- Title -->
																		<h6 class="mb-0"><a href="index.php?content=profile&id=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a><?php
                                                                        if($userData['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></h6>
                                                                        <small><?php echo $userData['job']?></small>
																	</div>
																</div>
															</td>
												
												
															<td>
																<div class="d-flex gap-2">
																	<a href="https://www.spacify.ir/index.php?controller=user&method=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
																	<img style="width: 40px; height: 40px;" src="https://www.spacify.ir/public/img/logo/wizify.png" alt="Logo">
																	</a>
																	<a href="dashboard.php?content=sendMessage&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
																	<i class="bi bi-send"></i>
																	</a>

																</div>
															</td>
														</tr>
														<?php
													}else{
	
													}
                                                }
                                                
                                                ?>
                

                                    


                                                </tbody>
                                                <!-- Table body END -->
                                            </table>
                                        </div>
                                        <!-- Table END -->
                                    </div>
                                    <!-- Tabs content item END -->
                                <?php
                            }else{
                                ?>
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حسابی یافت نشد</font></font></h2>
                                        
                                    </div>
                                    </div>
                                    </div>
                                </section>
                                <?php
                            }
                            ?>


							<!-- Tabs content item START -->
							<div class="tab-pane fade" id="nav-grid-tab" role="tabpanel">
								<div class="row g-4">

				
			

						

	

			
				
				

								</div> <!-- Row END -->
							</div>
							<!-- Tabs content item END -->

						</div>
						<!-- Tabs content END -->
					</div>
					<!-- Card body END -->


					</div>
					<!-- Card Footer END -->
				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    </div>
	</div>
</section>