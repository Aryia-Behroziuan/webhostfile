<?PHP
if(! isset($_GET['id'])){
    die();
}
if(! isset($_SESSION['id'])){
    die();
}
$query = mysqli_query($con, 'select * from user where iduser="'.$_SESSION['id'].'"');
$user = mysqli_fetch_assoc($query);
if(! $user){
    die();
}

$query_session = mysqli_query($con, 'select * from session where id="'.$_GET['id'].'"');
$pay = mysqli_fetch_assoc($query_session);
if(! $pay){
    die();
}
$query_acc = mysqli_query($con, 'select * from user where iduser="'.$pay['userId'].'"');
$acc = mysqli_fetch_assoc($query_acc);
if(! $acc){
    die();
}

$query_post = mysqli_query($con, 'select * from posts where idPost="'.$pay['piperline'].'"');
$post = mysqli_fetch_assoc($query_post);
if(! $post){
    die();
}
$query_us = mysqli_query($con, 'select * from user where iduser="'.$pay['data'].'"');
$us = mysqli_fetch_assoc($query_us);
if(! $us){
    die();
}
if($_SESSION['id'] == $pay['userId']){
    $creator = 1;
}elseif($_SESSION['id'] == $pay['data']){
    $creator = 0;
}else{
    die();
}
?>
<section class="py-2">
	<div class="container">
    <div class="row pb-2">
    <?php
    if($pay['cunt'] == 1){
        ?>
        <section class="overflow-hidden">
            <div class="container">
                <div class="row">
            <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                <!-- SVG shape START -->
                <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                    <g>
                    <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                    <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                    <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                    <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                    <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                    <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                    <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                    <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                    <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                    <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                    c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                    </g>
                </svg>
                </figure>
                <!-- SVG shape START -->
                <!-- Content -->
                <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-alipay"></i></font></font></h1>
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پرداخت شده رسید تراکنش</font></font></h2>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> صورت حساب با شناسه <a href="#"><?php echo $_GET['id']?></a> پرداخت شده است</font></font></p>

                <div class="row g-4">
                    <div class="card card-body bg-success bg-opacity-10 p-4 h-100">
                        <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">صورت حساب
                            </font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="After US royalty withholding tax" data-bs-original-title="" title="">
                                <i class="bi bi-info-circle-fill small"></i>
                            </a>
                        </h6>
                        <h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo number_format($pay['payment'] , 0 , "." , "," )?> تومان</font></font></h2>
                        <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بابت:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $pay['wiki']?></font></font></p>
                        <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پرداخت کننده:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><a href="dashboard.php?content=profile&id=<?php echo $us['iduser']?>"></a><?php echo $us['username']?>-<?php echo $us['iduser']?></font></font></p>
                        <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالیات کسر شده:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">7 درصد از مبلغ</font></font></p>
                        <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مخزن مرتبط:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><strong><?php echo $post['title']?></strong></font></font></p>
                    </div>
                </div>
                <a href="dashboard.php?content=chats" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت به صفحه اصلی</font></font></a>
            </div>
            </div>
            </div>
        </section>
        <?php
    }else{
        if($creator == 1){
            ?>
            <section class="overflow-hidden">
                <div class="container">
                    <div class="row">
                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                    <!-- SVG shape START -->
                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                        <g>
                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                        </g>
                    </svg>
                    </figure>
                    <!-- SVG shape START -->
                    <!-- Content -->
                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-clock-history"></i></font></font></h1>
                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">در انتظار پرداخت</font></font></h2>
                    <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">هنوز صورت حساب با شناسه <a href="#"><?php echo $_GET['id']?></a> پرداخت نشده است</font></font></p>

                    <div class="row g-4">
                        <div class="card card-body bg-success bg-opacity-10 p-4 h-100">
                            <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">صورت حساب
                                </font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="After US royalty withholding tax" data-bs-original-title="" title="">
                                    <i class="bi bi-info-circle-fill small"></i>
                                </a>
                            </h6>
                            <h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo number_format($pay['payment'] , 0 , "." , "," )?> تومان</font></font></h2>
                            <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بابت:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $pay['wiki']?></font></font></p>
                        </div>
                    </div>
                    <a href="dashboard.php?content=chats" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت به صفحه اصلی</font></font></a>
                </div>
                </div>
                </div>
            </section>
            <?php
        }else{
            ?>
            
            <section class="py-2">
                <div class="container">
                <div class="row pb-2">

                        <div class="col-12">
                            <!-- Blog list table START -->
                            <div class="card border bg-transparent rounded-3">
                                <!-- Card header START -->
                                <div class="card-header bg-transparent border-bottom p-3">
                                    <div id="displayErrorGetPay"></div>
                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                        <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-paypal"></i>  پرداخت صورت حساب  </font></font>
                                                                    </h5>

                                <form action="" method="POST" id="formGETDATASENDPAY">
                                        <button type="submit" class="btn btn-link" id="GETDATAFORM"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"><i class="bi bi-alipay"></i> پرداخت از ولت </font></font></button>						
                                    </div>
                                </div>
                                <!-- Card header END -->

                                <!-- Card body START -->
                                <div class="card-body p-3" id="displayNoti1">
                                    <style>
                                    .scroll-example {
                                        overflow: auto;
                                        scrollbar-width: none; /* Firefox */
                                        -ms-overflow-style: none; /* IE 10+ */
                                    }

                                    .scroll-example::-webkit-scrollbar {
                                        width: 0px;
                                        background: transparent; /* Chrome/Safari/Webkit */
                                    }
                                    </style>
                                        <div class="card-body p-0">
                        

                                        <input type="text" style="display: none;" name="payInv" value="<?php echo $pay['id']?>">
                                           
                                            <h6> پرداخت برای ... <i class="bi bi-arrow-90deg-down"></i></h6>
                                                            <div class="d-flex align-items-center position-relative">
                                                                <div class="avatar avatar-sm">
                                                                    <img class="avatar-img rounded-circle" src="<?php echo $acc['avatar']?>" alt="avatar">
                                                                </div>
                                                                <div class="ms-3">
                                                                    <h6 class="mb-0"><a href="../../blogzine.webestica.com/rtl/dashboard.php?content=profile&amp;id=<?php echo $acc['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $acc['username']?></a><?php 
                                                                                if($acc['piperAdmin'] == 1){
                                                                                    ?>
                                                                                    <img src="https://cdn-icons-png.flaticon.com/512/5253/5253968.png" style="width: 20px;" alt="">
                                                                                    <?php
                                                                                }?> <?php 
                                                                                if($acc['admin'] == 1){
                                                                                    ?>
                                                                                    <i class="bi bi-patch-check-fill text-info small"></i>
                                                                                    <?php
                                                                                }?> </h6>
                                                                    <small><?php echo $acc['job']?></small>
                                                                </div>
                                                            </div>
                                                            <br>
                                                            <div class="d-flex align-items-center position-relative">
                                                                <div class="avatar avatar-sm">
                                                                    <img class="avatar-img" src="<?php echo $post['art']?>" alt="avatar">
                                                                </div>
                                                                <div class="ms-3">
                                                                    <h6 class="mb-0"><a href="../../core/rtl/index.php?content=open&amp;id=<?php echo $post['idPost']?>" class="stretched-link text-reset btn-link"><?php echo $post['title']?></a> </h6>
                                                                    <small><?php echo $post['doc']?></small>
                                                                </div>
                                                            </div>
                                                            <hr>


                                                            <h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo number_format($pay['payment'] , 0 , "." , "," )?> تومان</font></font></h2>

                                                            <hr>
                                                            بابت: <strong><?php echo $pay['wiki']?></strong>

                                                       
                                </form>
                    

                                        <script>
                                                $(document).ready(function(){
                                                    $("#formGETDATASENDPAY").on("submit", function(event){
                                                        event.preventDefault();
                                                        $('#GETDATAFORM').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                        var formValues= $('#formGETDATASENDPAY').serialize();

                                                        $.post("../../index.php?controller=message&method=payInv", formValues, function(data){
                                                            // Display the returned data in browser
                                                            $('#GETDATAFORM').html('<i class="bi bi-alipay"></i> پرداخت از ولت ');
                                                            $('#displayErrorGetPay').html(data);
                                                        });
                                                    });
                                                });
                                        </script>

                                        
                                       




                                        </div>
                                        <!-- Button -->

                

                                    <!-- Pagination START -->
                                    
                                    <!-- Pagination END -->
                                </div>
                            </div>
                            <!-- Blog list table END -->
                        </div>
                </div>
                </div>
            </section>

            <?php
        }
    }
    ?>
    </div>
    </div>
</section>
