<?php
if(isset($_SESSION['id'])){
    $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"'));
    $checkup = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and name="order" and piperline="'.$post['idPost'].'"'));
    $creator = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$post['idUser'].'"'));


    if(! $checkup){
        if($user['piperAdmin'] == 1){
         
        }else{
         die();
        }
    }
    if(! $post){
        die();
    }elseif($post['published'] == '0'){
        ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
					
					<strong> مخزن درحال به روزرسانی است</strong> 
					<br>
					مخزنی که انتخاب کرده اید فعلا در حال به روز رسانی است پس از این مرحله به مرحله تایید محتوای به روزرسانی میرسد و سپس بعد از تایید محتوا این مخزن برای بهره برداری مشتریان آزاد میشود اگر از این مخزن برای خود بکاپ یا نسخه پشتیبان تحیه کنید دیگر نیاز نیست برای هر به روز رسانی منتظر بمانید بلکه میتوانید از نسخه قبلی آن استفاده نمایید در این حال ما در تلاشیم بهترین خدمات را به شما اراعه دهیم و سعی میکنیم محتوای خود را همیشه به روز به شما اراعه دهید از صبوری شما کمال تشکر را داریم
                </div>

                <section class="py-4">
                        <div class="container">
                            <div class="row pb-4">
                                 
                            <div class="bg-light rounded-3 p-4 mb-3">
                                        <!-- Blog item -->
                                        <div class="col-12">
                                            <div class="d-flex align-items-center position-relative">
                                                    <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                <div class="ms-3">
                                                    <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                    <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                <!-- Content -->
                                    <h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 40px;" alt=""> بک آپ موجود نیست</font></font></h6>
                                    <p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد از اتمام فرآیند به روز رسانی این مخزن به شما اعلان ارسال خواهیم کرد</font></font></p>
                                <!-- Button -->
                                <div class="d-sm-flex gap-3 align-items-center mt-3">
                                    <a href="dashboard.php?content=cloud" class="btn btn-primary mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت</font></font></a>
                                    <p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین به روزرسانی <?php echo $post['dateEdit']?></font></font></p>
                                </div>
                            </div>
                             
                            </div>
                        </div>
                                            
                        
                </section>

                
        <?php
    }
    elseif($post['published'] == '2'){
        ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
					<img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-alert-5803870-4923157.png" style="width: 70px;" alt="">
					<br>
					<strong> متاسفیم این مخزن تحت تعلیق است</strong> 
					<br>
					این مخزن برای مدتی در حالت تعلیق درآمده است و اراعه دهنده خدمات باید نسبت به حل مشکلات و یا شکایات اقدام کند تا این سرویس فعال شود ما مخازنی که مورد شکایت قرار میگیرد و یا با سیاست ها و خط مشی های ما مخالف است را مورد پرسش قرارمیدهیم اکنون اگر شما هم چنین موردی مشاهده کرده اید میتوانید به ما گزارش کنید البته گزارش های مردمی اعتبار سنجی خواهند شد در هر صورت ما مشتاقیم که بهترین خدمات را به شما اراعه دهیم و میکوشیم سرویس هارا در بالاترین کیفیت به مشتری عرضه کنیم از صبر و شکیبایی شما سپاسگذاریم
				</div>
                
                <section class="py-4">
                        <div class="container">
                            <div class="row pb-4">
                                 
                            <div class="bg-light rounded-3 p-4 mb-3">
                                        <!-- Blog item -->
                                        <div class="col-12">
                                            <div class="d-flex align-items-center position-relative">
                                                    <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                <div class="ms-3">
                                                    <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                    <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                <!-- Content -->
                                    <h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 40px;" alt=""> بک آپ موجود نیست</font></font></h6>
                                    <p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد از اتمام فرآیند تعلیق این مخزن به شما اعلان ارسال خواهیم کرد</font></font></p>
                                <!-- Button -->
                                <div class="d-sm-flex gap-3 align-items-center mt-3">
                                    <a href="dashboard.php?content=cloud" class="btn btn-primary mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت</font></font></a>
                                    <p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین به روزرسانی <?php echo $post['dateEdit']?></font></font></p>
                                </div>
                            </div>
                             
                            </div>
                        </div>
                                            
                        
                </section>

        <?php
    }else{
        ?>
                            <div class="bg-light rounded-3 p-1 mb-3">
                                        <!-- Blog item -->
                                        <div class="col-12">
                                            <div class="d-flex align-items-center position-relative">
                                                    <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                <div class="ms-3">
                                                    <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                    <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین به روزرسانی <?php echo $post['dateEdit']?></font></font></p>
                                                </div>
                                            </div>
                                        </div>
                            
                            </div>


            <section class="py-4">
                <div class="container">
                    <div class="row pb-4">
                        <div class="container">
                            <div class="row pb-4">
                                 
                            <div class="bg-light rounded-3 p-4 mb-3">
                         
                                <!-- Content -->
                                    <h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 40px;" alt=""> توضیحات</font></font></h6>
                                    <p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
                                <hr>
                                <ul class="nav">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=draft"><i class="bi bi-book"></i> صفحه اصلی</a>
                                    </li>
                                    <?php
                                    if($post['type'] == '1'){
                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=home"><i class="bi bi-cloud-haze2-fill"></i> پست برخط</a>
                                        </li>
                                        <?php
                                    }elseif($post['type'] == '2'){
                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=home"><i class="bi bi-cloud-haze2-fill"></i> مستندات دوره</a>
                                        </li>
                                        <?php
                                    }elseif($post['type'] == '3'){
                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=home"><i class="bi bi-cloud-haze2-fill"></i>  اراعه برخط</a>
                                        </li>
                                        <?php
                                    }
                                    elseif($post['type'] == '4'){
                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=home"><i class="bi bi-cloud-haze2-fill"></i>  اراعه برخط</a>
                                        </li>
                                        <?php
                                    }elseif($post['type'] == '5'){
                                        ?>
                                        <li class="nav-item">
                                            <a class="nav-link active" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=home"><i class="bi bi-cloud-haze2-fill"></i>  صفحه خدمات</a>
                                        </li>
                                        <?php
                                    }
                                    ?>
              
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=react"><i class="bi bi-file-earmark-richtext-fill"></i> تعاملات شما</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=files"><i class="bi bi-git"></i> فایل و منبع</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=doc"><i class="bi bi-file-earmark-richtext-fill"></i> راهنما و مستندات</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=support"><i class="bi bi-chat"></i>  پشتیبانی</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=about"><i class="bi bi-grid"></i>درباره</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="dashboard.php?content=open&id=<?php echo $_GET['id']?>&page=rep"><i class="bi bi-flag"></i> گزارش</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link disabled" href="#"><i class="bi bi-globe-americas"></i> کامیونیتی </a>
                                    </li>
                                
                                </ul>
                            </div>
                             
                            </div>
                        </div>

                        
                        </div>
                            <div class="row">
                                <div class="col-12">
                                    <!-- Chart START -->
                                    <div class="card border">
                                        <style>
                                            .containeron {
                                                -ms-overflow-style: none;  /* Internet Explorer 10+ */
                                                scrollbar-width: none;  /* Firefox */
                                                overflow-y: scroll;
                                            }
                                            .containeron::-webkit-scrollbar { 
                                                display: none;  /* Safari and Chrome */
                                                width: 0;  /* Remove scrollbar space */
                                                height: 0;
                                                background: transparent;  /* Optional: just make scrollbar invisible */
                                            }
                                            .containeron::-webkit-scrollbar-thumb {
                                                background: #FF0000;
                                            }
                                        </style>
                                        <!-- Card body -->
                                        <div class="card-body">
                                        <?php
                                        if(isset($_GET['page'])){
                                            if($_GET['page'] == 'about'){
                                                ?>
                                                <h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/global-seo-5152809-4315324.png" style="width: 40px;" alt=""> درباره</font></font></h6>
                                                <hr>
                                                <div class="col-lg-4">
                                                <div class="bg-light rounded-3 p-1 mb-3">
                                                                <!-- Blog item -->
                                                                <div class="col-12">
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <div class="ms-3">
                                                                            <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات خرید شما</font></font></a>
                                                                            <hr>    
                                                                            <div class="d-flex align-items-center position-relative">
                                                                            <div class="avatar avatar-sm">
                                                                                <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                                                                            </div>
                                                                            <div class="ms-3">
                                                                                <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&amp;id=<?php echo $user['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $user['username']?></a></h6>
                                                                                مشتری
                                                                            </div>
                                                                            </div>
                                                                            <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ خرید:  <?php echo $checkup['createDate']?></font></font></p>
                                                                            <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مبلغ پرداختی:  <?php echo $checkup['payment']?> تومان</font></font></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                    
                                                </div>
                                                <div class="bg-light rounded-3 p-1 mb-3">
                                                                <!-- Blog item -->
                                                                <div class="col-12">
                                                                    <div class="d-flex align-items-center position-relative">
                                                                            <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                                        <div class="ms-3">
                                                                            <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                                            <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین به روزرسانی <?php echo $post['dateEdit']?></font></font></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                    
                                                </div>
                                                <div class="bg-light rounded-3 p-1 mb-3">
                                                    <div class="d-flex align-items-center position-relative">
                                                    <div class="avatar avatar-sm">
                                                        <img class="avatar-img rounded-circle" src="<?php echo $creator['avatar']?>" alt="avatar">
                                                    </div>
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&amp;id=<?php echo $creator['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $creator['username']?></a></h6>
                                                        سازنده-فروشنده
                                                    </div>
                                                    </div>
                                                    
                                                </div>
                                                <ul class="list-group list-group-borderless">
                                                    
                                                    <li class="list-group-item py-0">
                                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام مخزن: </font></font></span>
                                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></span>
                                                    </li>
                                                    <li class="list-group-item py-0">
                                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ ایجاد: </font></font></span>
                                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['date']?></font></font></span>
                                                    </li>
                                                    <li class="list-group-item py-0">
                                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اخرین به روزرسانی: </font></font></span>
                                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['dateEdit']?></font></font></span>
                                                    </li>
    
                                                    <li class="list-group-item py-0">
                                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه کاربری مالک: </font></font></span>
                                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><a href="dashboard.php?content=profile&id=<?php echo $creator['iduser']?>">KEY-API{ <?php echo $creator['iduser']?> }</a></font></font></span>
                                                    </li>
                                                    <li class="list-group-item py-0">
                                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه مخزن:</font></font></span>
                                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><a href="dashboard.php?content=profile&id=<?php echo $creator['iduser']?>">KEY{ <?php echo $post['idPost']?> }</a></font></font></span>
                                                    </li>
                                             





                                 
                            
                                                </ul>
                            
                            
                                              </div>
                                                <?php
                                            }elseif($_GET['page'] == 'rep'){
                                                ?>
                                     
                                                <h4>  <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                                <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                                                </svg> گزارش</h4>
                                                <div id="display">
                                                <hr>
                                                <?php 
                                                $order = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where name="report" and userId='.$_SESSION['id'].' and data='.$_GET['id'].''));
                                                if($order){
                                                    ?>
                                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                            
                                                            <strong><img src="https://cdn3d.iconscout.com/3d/premium/thumb/successfully-approve-5331611-4659611.png" style="width: 20px;" alt=""> گزارش شما ارسال شد</strong> 
                                                            <br>
                                                            اکنون شما یک گزارش درحال برسی دارید و ما و سازنده این مخزن در حال حل آن هستیم در صورت رسیدگی به این گزارش در همین صفحه به شما پیام خواهیم داد
                                                        </div>
                                                        <?php 
                                                        if($order['rol'] == '1'){
                                                            ?>
                                                            <section class="overflow-hidden">
                                                                <div class="container">
                                                                    <div class="row">
                                                                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                                    <!-- SVG shape START -->
                                                                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                                        <g>
                                                                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                                        </g>
                                                                    </svg>
                                                                    </figure>
                                                                    <!-- SVG shape START -->
                                                                    <!-- Content -->
                                                                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-repeat-1"></i></font></font></h1>
                                                                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">رسیدگی شد</font></font></h2>
                                                                    <p><font style="vertical-align: inherit;">اراعه دهنده مخزن به ما اطلاع داده است که این شکایت را مطالعه کرده و آن را برطرف نموده است ایا شما احساس میکنید هنوز مشکل وجود دارد اگر چنین حسی دارید میتوانید به شما اطلاع دهید</font></p>
                                                                    <button type="button" id="cancelRep" class="btn btn-success btn-xs"><i class="bi bi-eyeglasses"></i> بله تشکر</button>
                                                                    <button type="button" id="notOk" class="btn btn-danger btn-xs"><i class="bi bi-eyeglasses"></i>  هنوز در گیز مشکل هستم</button>
                                                                    <script>
                                                                    $('#cancelRep').click(function(event){
                                                                    event.preventDefault();
                                            
                                                                    $('#cancelRep').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                                    
                                                                    $.ajax({
                                                                        method: "POST",
                                                                        url: "../../index.php?controller=message&method=repStat&id=<?php echo $order['id']?>&rol=delete&post=<?php echo $_GET['id']?>",
                                                                        data: { code: "1"}
                                                                    })
                                                                        .done(function(data){
                                                                        $('#display').html(data);
                                                                        })

                                                                    })
                                                                    </script>
                                                                    <script>
                                                                    $('#notOk').click(function(event){
                                                                    event.preventDefault();
                                            
                                                                    $('#notOk').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                                    
                                                                    $.ajax({
                                                                        method: "POST",
                                                                        url: "../../index.php?controller=message&method=repStat&id=<?php echo $order['id']?>&rol=active",
                                                                        data: { code: "1"}
                                                                    })
                                                                        .done(function(data){
                                                                        $('#display').html(data);
                                                                        })

                                                                    })
                                                                    </script>
                                                                </div>
                                                                </div>
                                                                </div>
                                                            </section>
                                                            <?php
                                                        }else{
                                                            ?>

                                                            <section class="overflow-hidden">
                                                                <div class="container">
                                                                    <div class="row">
                                                                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                                    <!-- SVG shape START -->
                                                                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                                        <g>
                                                                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                                        </g>
                                                                    </svg>
                                                                    </figure>
                                                                    <!-- SVG shape START -->
                                                                    <!-- Content -->
                                                                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                                                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درحال رسیدگی</font></font></h2>
                                                                    <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما یک گزارش در حال رسیدگی دارید که از این صفحه میتوانید آمار لحظه ای رسیدگی به آن را مشاهده کنید  در صورت رسیدگی در این صفحه منتطر پاسخ ما باشید</font></font></p>
                                                                    <button type="button" id="cancelRep" class="btn btn-danger btn-xs"><i class="bi bi-eyeglasses"></i> منصرف شدم</button>
                                                                    <script>
                                                                    $('#cancelRep').click(function(event){
                                                                    event.preventDefault();
                                            
                                                                    $('#cancelRep').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                                    
                                                                    $.ajax({
                                                                        method: "POST",
                                                                        url: "../../index.php?controller=message&method=repStat&id=<?php echo $order['id']?>&rol=delete&post=<?php echo $_GET['id']?>",
                                                                        data: { code: "1"}
                                                                    })
                                                                        .done(function(data){
                                                                        $('#display').html(data);
                                                                        })

                                                                    })
                                                                    </script>
                                                                </div>
                                                                </div>
                                                                </div>
                                                            </section>
                                                            <?php
                                                        }?>
                                                    <?php
                                                }else{
                                                    if(isset($_GET['alert'])){
                                                        ?>
                                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                            
                                                            <strong><img src="https://cdn3d.iconscout.com/3d/premium/thumb/successfully-approve-5331611-4659611.png" style="width: 20px;" alt=""> گزارش شما ارسال شد</strong> 
                                                            <br>
                                                            <?php echo $_GET['alert']?>
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-alert-5803870-4923157.png" style="width: 50px;" alt="">
                                                        <br>
                                                        <strong>گزارشنامه یا شکایت از یک مخزن</strong> 
                                                        <br>
                                                        اگر در شیوه سرویس دهی و یا خدمات این مخزن مشکلی پیش آمده میتوانید در قالب گزارش آن را برای سازنده مخزن ارسال کنید پس از مدتی اگر شخص سازنده آن مشکل را برطرف نکرد این گزارش شما تبدیل به شکایت شده و شخص سازنده از طرف ما مورد پرسش قرار میگیرد در صورتی که این شخص خط مشی های مارا زیر پا گذاشته باشد ما او را وادار به پرداخت قرامت و در نهایت تعلیق مخزن و اگر شخص در اراعه خدمات کوتاهی کرده باشد با کمک جامعه پیپرلاین در کنار یکدیگر کمک میکنیم تا مشکلات بهبود پیدا کند ممنون از اینکه با ما همکاری میکنید گزارشات شما پایه مدیریت ماست
                                                    </div>

                                                    <form action="../../index.php?controller=message&method=report" method="POST">
                                                        <input style="display: none;" type="text" value="<?php echo $post['idPost']?>" name="postId">
                                                        <div class="col-12">
                                                            <div class="mb-3">
                                                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارش شما</font></font></label>
                                                                <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                        <div class="form-check mb-3">
                                                            <input class="form-check-input" type="checkbox" value="" id="postCheck">
                                                            <label class="form-check-label" for="postCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                                        مستقیما تبدیل به شکایت شود 
                                                            </font></font></label>
                                                        </div>
                                                        </div>
                                                        <button class="btn btn-primary w-100" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ارسال</font></font></button>
                                                    </form>
                                                    <?php
                                                }
                                 
                                                ?>
                                                </div>
                                                <?php
                                            }elseif($_GET['page'] == 'doc'){
                                                ?>
                                                <h4><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-files" viewBox="0 0 16 16">
                                                    <path d="M13 0H6a2 2 0 0 0-2 2 2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2 2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 13V4a2 2 0 0 0-2-2H5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1zM3 4a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4z"/>
                                                    </svg>مستندات راهنما</h4>
                                                    <hr>
                                                    <div class="row pb-4">
                                 
                                                        <div class="bg-light rounded-3 p-4 mb-3">
                                                    
                                                        <?php echo $post['doc_master']?>
                                                        <hr>
                                                        <br>
                                                        <?php echo $post['doc_creator']?>

                                                        </div>
                                                        
                                                    </div>
                                                <?php
                                            }elseif($_GET['page'] == 'files'){
                                                ?>
                                                
                                                <h4><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/download-folder-5568716-4644433.mp4" type="video/mp4" autoplay="autoplay" style="width: 70px;" loop="loop"></video>فایل ها و منابع</h4>
                                                
                                                <br>
                                                                <div class="col-12">
                                                            <!-- Title -->
                                                                    <div class="d-sm-flex align-items-center">

                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-12">
                                                            
                                                            <!-- Post list table START -->
                                                            <div class="card border bg-transparent rounded-3">

                                                                <!-- Card body START -->
                                                                <div class="card-body p-3">

                                                                <!-- Search and select START -->
                                                                <div class="row g-3 align-items-center justify-content-between mb-3">
                                                                    <!-- Search -->
                                                                    <div class="col-md-8">
                                                                    <form class="rounded position-relative">
                                                                        <input class="form-control pe-5 bg-transparent" type="search" placeholder="سرچ کن" aria-label="Search">
                                                                        <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                                                    </form>
                                                                    </div>

                                                                    <!-- Select option -->
                                                                    <div class="col-md-3">
                                                                    <!-- Short by filter -->
                                                                    <form>
                                                                        <select class="form-select z-index-9 bg-transparent" aria-label=".form-select-sm">
                                                                        <option value="">مرتب کردن به ترتیب</option>
                                                                        <option>ازاد</option>
                                                                        <option>بدون پسورد</option>
                                                                        <option>دارای پسورد</option>
                                                                        <option>فایل فشرده</option>
                                                                        <option>فایل معمولی</option>
                                                                        </select>
                                                                    </form>
                                                                    </div>
                                                                </div>
                                                                <!-- Search and select END -->

                                                                <!-- Post list table START -->
                                                                <div class="table-responsive border-0">
                                                                    <table class="table align-middle p-4 mb-0 table-hover table-shrink">
                                                                    <!-- Table head -->
                                                                    <thead class="table-dark">
                                                                        <tr>
                                                                        <th scope="col" class="border-0 rounded-start">نام فایل</th>
                                                                        <th scope="col" class="border-0">توضیحات</th>
                                                                        <th scope="col" class="border-0">زمان انتشار</th>
                                                                        <th scope="col" class="border-0">دسته بندی</th>
                                                                        <th scope="col" class="border-0">وضعیت</th>
                                                                        <th scope="col" class="border-0 rounded-end">عملگرها</th>
                                                                        </tr>
                                                                    </thead>

                                                                    <!-- Table body START -->
                                                                    <tbody class="border-top-0">
                                                                        <?php
                                                                        $query_1212 = mysqli_query($con, 'select * from books where piperlineId="'.$post['idPost'].'" order by createDate Desc');
                                                                        $file_hash = mysqli_query($con, 'select * from books where piperlineId="'.$post['idPost'].'" order by createDate Desc');
                                                                        $file = mysqli_fetch_assoc($query_1212);
                                                                        if($file){
                                                                            while($res=mysqli_fetch_assoc($file_hash)){
                                                                                $some_time = strtotime($res['createDate']);

                                                                                ?>
                                                                                <!-- Table item -->
                                                                                <tr>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <h6 class="course-title mt-2 mt-md-0 mb-0"><img style="width: 35px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/documents-6356606-5231758.png" alt=""> <a href="#"><?php echo $res['name']?></a></h6>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <h6 class="mb-0"><a href="#"><?php echo $res['doc']?></a></h6>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td><i class="bi bi-clock"></i> <?php echo date('Y, d F', $some_time)?></td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?PHP echo $res['type']?></a>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <span class="badge bg-success bg-opacity-10 text-success mb-2">Live</span>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <div class="d-flex gap-2">
                                                                                            <a href="<?php echo $res['wikilink']?>" class="btn btn-outline-dark btn-xs">بازکردن با..</a>

                                                                                            <a href="<?php echo $res['file']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Edit"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-house-down" viewBox="0 0 16 16">
                                                                                                <path d="M7.293 1.5a1 1 0 0 1 1.414 0L11 3.793V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v3.293l2.354 2.353a.5.5 0 0 1-.708.708L8 2.207l-5 5V13.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 1 0 1h-4A1.5 1.5 0 0 1 2 13.5V8.207l-.646.647a.5.5 0 1 1-.708-.708L7.293 1.5Z"/>
                                                                                                <path d="M12.5 9a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Zm.354 5.854 1.5-1.5a.5.5 0 0 0-.708-.707l-.646.646V10.5a.5.5 0 0 0-1 0v2.793l-.646-.646a.5.5 0 0 0-.708.707l1.5 1.5a.5.5 0 0 0 .708 0Z"/>
                                                                                                </svg> </a>
                                                                                        </div>
                                                                                    </td>
                                                                                </tr>

                                                                                

                                                                                <?php
                                                                            }

                                                                        }else{
                                                                            ?>
                                                                            <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                                                <!-- SVG shape START -->
                                                                                <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                                                <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                                                    <g>
                                                                                    <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                                                    </g>
                                                                                </svg>
                                                                                </figure>
                                                                                <!-- SVG shape START -->
                                                                                <!-- Content -->
                                                                                <h1 class="display-1 text-primary"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-2872691-2409395.png" style="width: 50%;" alt=""> </h1>
                                                                                <h2>پست ایجاد نشد</h2>
                                                                                <p>متاسفیم ما نمیتوانیم این فایل را پردازش کنیم دوباره ان را وارسی کنید شاید در داده ها مشکلی است</p>
                                                                                <a href="../../core/rtl/dashboard.php?content=createPost" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>بازگشت به فایل</a>
                                                                            </div>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    
                                                                   
                                                                        
                                                                    </tbody>
                                                                    <!-- Table body END -->
                                                                    </table>
                                                                </div>
                                                                <!-- Post list table END -->

                                                                <!-- Pagination START -->
                                                                <div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
                                                                    <!-- Content -->
                                                                    <p class="mb-sm-0 text-center text-sm-start">Showing 1 to 8 of 20 entries</p>
                                                                    <!-- Pagination -->
                                                                    <nav class="mb-sm-0 d-flex justify-content-center" aria-label="navigation">
                                                                    <ul class="pagination pagination-sm pagination-bordered mb-0">
                                                                        <li class="page-item disabled">
                                                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Prev</a>
                                                                        </li>
                                                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                                        <li class="page-item disabled"><a class="page-link" href="#">..</a></li>
                                                                        <li class="page-item"><a class="page-link" href="#">15</a></li>
                                                                        <li class="page-item">
                                                                        <a class="page-link" href="#">Next</a>
                                                                        </li>
                                                                    </ul>
                                                                    </nav>
                                                                </div>
                                                                <!-- Pagination END -->
                                                                </div>
                                                            </div>
                                                            <!-- Post list table END -->
                                                        </div>
                                                    <br>
                                                
                                                <?php

                                                
                                            }elseif($_GET['page'] == 'home'){
                                                if($post['type'] == '1'){
                                                    ?>
                                                    <H4><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-stickies" viewBox="0 0 16 16">
                                                        <path d="M1.5 0A1.5 1.5 0 0 0 0 1.5V13a1 1 0 0 0 1 1V1.5a.5.5 0 0 1 .5-.5H14a1 1 0 0 0-1-1H1.5z"/>
                                                        <path d="M3.5 2A1.5 1.5 0 0 0 2 3.5v11A1.5 1.5 0 0 0 3.5 16h6.086a1.5 1.5 0 0 0 1.06-.44l4.915-4.914A1.5 1.5 0 0 0 16 9.586V3.5A1.5 1.5 0 0 0 14.5 2h-11zM3 3.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 .5.5V9h-4.5A1.5 1.5 0 0 0 9 10.5V15H3.5a.5.5 0 0 1-.5-.5v-11zm7 11.293V10.5a.5.5 0 0 1 .5-.5h4.293L10 14.793z"/>
                                                    </svg> پست برخط</H4>
                                                    
                                                    
                            
                                                    <div class="containeron">
                                                        <iframe style="width: 100%; height: 1200px;" class="containeron" src="<?php echo $post['iframe']?>" frameborder="0"></iframe>

                                                    </div>
                                                    
                                                    <hr>
                                                    <?php
                                                }elseif($post['type'] == '2'){
                                                    ?>
                                                    <H4><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-binoculars" viewBox="0 0 16 16">
                                                        <path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h1A1.5 1.5 0 0 1 7 2.5V5h2V2.5A1.5 1.5 0 0 1 10.5 1h1A1.5 1.5 0 0 1 13 2.5v2.382a.5.5 0 0 0 .276.447l.895.447A1.5 1.5 0 0 1 15 7.118V14.5a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 14.5v-3a.5.5 0 0 1 .146-.354l.854-.853V9.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.793l.854.853A.5.5 0 0 1 7 11.5v3A1.5 1.5 0 0 1 5.5 16h-3A1.5 1.5 0 0 1 1 14.5V7.118a1.5 1.5 0 0 1 .83-1.342l.894-.447A.5.5 0 0 0 3 4.882V2.5zM4.5 2a.5.5 0 0 0-.5.5V3h2v-.5a.5.5 0 0 0-.5-.5h-1zM6 4H4v.882a1.5 1.5 0 0 1-.83 1.342l-.894.447A.5.5 0 0 0 2 7.118V13h4v-1.293l-.854-.853A.5.5 0 0 1 5 10.5v-1A1.5 1.5 0 0 1 6.5 8h3A1.5 1.5 0 0 1 11 9.5v1a.5.5 0 0 1-.146.354l-.854.853V13h4V7.118a.5.5 0 0 0-.276-.447l-.895-.447A1.5 1.5 0 0 1 12 4.882V4h-2v1.5a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V4zm4-1h2v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V3zm4 11h-4v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14zm-8 0H2v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14z"/>
                                                        </svg> درباره دوره</H4>
                                                    
                                                    
                            
                                                    <div class="containeron">
                                                        <iframe style="width: 100%; height: 1200px;" class="containeron" src="<?php echo $post['iframe']?>" frameborder="0"></iframe>

                                                    </div>
                                                    
                                                    <hr>
                                                    <?php
                                                }elseif($post['type'] == '3'){
                                                    ?>
                                                    <H4><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-at" viewBox="0 0 16 16">
                                                        <path d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z"/>
                                                        </svg> اراعه برخط</H4>
                                                    
                                                    
                            
                                                    <div class="containeron">
                                                        <iframe style="width: 100%; height: 1200px;" class="containeron" src="<?php echo $post['iframe']?>" frameborder="0"></iframe>

                                                    </div>
                                                    
                                                    <hr>
                                                    <?php
                                                }elseif($post['type'] == '4'){
                                                    ?>
                                                        <H4><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-at" viewBox="0 0 16 16">
                                                        <path d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z"/>
                                                        </svg> اراعه برخط</H4>
                                                    
                                                    
                            
                                                    <div class="containeron">
                                                        <iframe style="width: 100%; height: 1200px;" class="containeron" src="<?php echo $post['iframe']?>" frameborder="0"></iframe>

                                                    </div>
                                                    
                                                    <hr>
                                                    <?php
                                                }elseif($post['type'] == '5'){
                                                    ?>
                                                    <H4><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-boxes" viewBox="0 0 16 16">
                                                    <path d="M7.752.066a.5.5 0 0 1 .496 0l3.75 2.143a.5.5 0 0 1 .252.434v3.995l3.498 2A.5.5 0 0 1 16 9.07v4.286a.5.5 0 0 1-.252.434l-3.75 2.143a.5.5 0 0 1-.496 0l-3.502-2-3.502 2.001a.5.5 0 0 1-.496 0l-3.75-2.143A.5.5 0 0 1 0 13.357V9.071a.5.5 0 0 1 .252-.434L3.75 6.638V2.643a.5.5 0 0 1 .252-.434L7.752.066ZM4.25 7.504 1.508 9.071l2.742 1.567 2.742-1.567L4.25 7.504ZM7.5 9.933l-2.75 1.571v3.134l2.75-1.571V9.933Zm1 3.134 2.75 1.571v-3.134L8.5 9.933v3.134Zm.508-3.996 2.742 1.567 2.742-1.567-2.742-1.567-2.742 1.567Zm2.242-2.433V3.504L8.5 5.076V8.21l2.75-1.572ZM7.5 8.21V5.076L4.75 3.504v3.134L7.5 8.21ZM5.258 2.643 8 4.21l2.742-1.567L8 1.076 5.258 2.643ZM15 9.933l-2.75 1.571v3.134L15 13.067V9.933ZM3.75 14.638v-3.134L1 9.933v3.134l2.75 1.571Z"/>
                                                    </svg> خدمات شما</H4>
                                                    <hr>

                                                    
                            
                                                    <?php echo $post['doc_master']?>
                                                    
                                                 
                                                    <?php
                                                }
                                            }elseif($_GET['page'] == 'react'){
                                                ?>
                                                <!-- Blog item -->
                                                <div class="col-12">

                                                <?php
                                                if($post['type'] == 5){
                                                    ?>
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <div class="ms-3">
                                                                            <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تعاملات شما با این مخزن</font></font></a>
                                                                            <hr>    
                                                                            <small>تعاملات خود را با این سرویس و تعداد دفعات استفاده خود و اطلاعات هر دور خرید را ببینید</small>

                                                                            <br>
                                                                            <br>

                                                                            <?php 
                                                                            $query_1212 = mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and name="order" and piperline='.$_GET['id'].' order by createDate Desc');
                                                                            $file_hash = mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and name="order" and piperline='.$_GET['id'].' order by createDate Desc');
                                                                            $file = mysqli_fetch_assoc($query_1212);
                                                                            if($file){
                                                                                while($res=mysqli_fetch_assoc($file_hash)){
                                                                                    ?>
                                                                                    <div class="bg-light rounded-3 p-1 mb-3">
                                                                                                    <!-- Blog item -->
                                                                                                    <div class="col-12">
                                                                                                        <div class="d-flex align-items-center position-relative">
                                                                                                            <div class="ms-3">
                                                                                                                <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات خرید شما</font></font></a>
                                                                                                                <hr>    
                                                                                                                <div class="d-flex align-items-center position-relative">
                                                                                                                <div class="avatar avatar-sm">
                                                                                                                    <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                                                                                                                </div>
                                                                                                                <div class="ms-3">
                                                                                                                    <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&amp;id=<?php echo $user['iduser']?>" class="stretched-link text-reset btn-link"> <?php echo $user['username']?></a></h6>
                                                                                                                    مشتری
                                                                                                                </div>
                                                                                                                </div>
                                                                                                                <p><?php echo $res['wiki']?></p>
                                                                                                                <hr>
                                                                                                                <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ خرید:  <?php echo $res['createDate']?></font></font></p>
                                                                                                                <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مبلغ پرداختی:  <?php echo number_format($res['payment'] , 0 , "." , "," )?> تومان</font></font></p>
                                                                                                                <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> شناسه سفارش :  <?php echo $res['id']?> </font></font></p>
                                                                                                                <?php
                                                                                                                if($post['price'] == 1){
                                                                                                                    ?>
                                                                                                                    <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> تعداد سفارش:   <?php echo $res['cunt']?></font></font></p>

                                                                                                                    <?php
                                                                                                                }

                                                                                                                if($post['inter'] == 1){
                                                                                                                    if($res['status'] == 1){
                                                                                                                        ?>
                                                                                                                        <div class="alert alert-success" role="alert">
                                                                                                                        سفارش شما توسط تامین کننده تایید شد
                                                                                                                        </div>
                                                                                                                        <?php
                                                                                                                    }elseif($res['status'] == 2){
                                                                                                                        ?>
                                                                                                                        <div class="alert alert-danger" role="alert">
                                                                                                                        سفارش شما توسط تامین کننده رد شد و هزینه آن به ولت شما بازگشت داده شد
                                                                                                                        </div>
                                                                                                                        <?php
                                                                                                                    }else{
                                                                                                                        ?>
                                                                                                                        <div class="alert alert-dark" role="alert">
                                                                                                                        سفارش شما در انتظار تایید توسط تامین کننده است
                                                                                                                        </div>
                                                                                                                        <?php
                                                                                                                    }
                                                                                                                }else{
                                                                                                                    ?>
                                                                                                                    <div class="alert alert-info" role="alert">
                                                                                                                    سفارش شما انجام شد
                                                                                                                    </div>
                                                                                                                    <?php
                                                                                                                }
                                                                                                                ?>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                        
                                                                                    </div>

                                                                                    <?php
                                                                                }
                                                                            }
                                                                            
                                                                            ?>

                                                                 



                                                                        </div>
                                                                    </div>
                                                    <?php
                                                }else{
                                                    ?>
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <div class="ms-3">
                                                                            <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تعاملات شما با این مخزن</font></font></a>
                                                                            <hr>    
                                                                            <div class="d-flex align-items-center position-relative">
                                                                            <div class="avatar avatar-sm">
                                                                                <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                                                                            </div>
                                                                            <div class="ms-3">
                                                                                <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&amp;id=<?php echo $user['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $user['username']?></a></h6>
                                                                                مشتری
                                                                            </div>
                                                                            </div>
                                                                            <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $checkup['wiki']?></font></font></p>
                                                                        </div>
                                                                    </div>
                                                    <?php
                                                }
                                                ?>

                                                </div>
                                                <?php
                                            }elseif($_GET['page'] == 'draft'){
                                                echo $post['after_txt'];
                                            }
                                            elseif($_GET['page'] == 'support'){
                                                ?>
                                                <div class="row">
                                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                        <!-- SVG shape START -->
                                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                            <g>
                                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                            </g>
                                                        </svg>
                                                        </figure>
                                                        <!-- SVG shape START -->
                                                        <!-- Content -->
                                                        <h1 id="sppiner_se" class="display-1 text-primary"><img style="with: 80px; height: 80px;" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" alt=""></h1>
                                                        <h2 id="sppiner_se1">پیام ویژه</h2>
                                                        <p id="sppiner_se2">مشتریان برای سازندگان میتوانند پیام ویژه ارسال کنند</p>
                                                    </div>
                                                </div>
                                                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                                    
                                                    
                                                    
                                                    درخواست های پشتیبانی را از قسمت پیام رسان کاوش کنید <a href="dashboard.php?content=chats"><i class="bi bi-box-arrow-up-right"></i></a>
                                                </div>
                                                <div class="bg-light rounded-3 p-1 mb-3">
                                                    <div class="d-flex align-items-center position-relative">
                                                    <div class="avatar avatar-sm">
                                                        <img class="avatar-img rounded-circle" src="<?php echo $creator['avatar']?>" alt="avatar">
                                                    </div>
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&amp;id=<?php echo $creator['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $creator['username']?></a></h6>
                                                        سازنده-فروشنده
                                                    </div>
 
                                                    </div>
                                                    <form action="dashboard.php?content=sendMessage&id=<?php echo $creator['iduser']?>" method="POST">
                                                        <input type="text" name="idService" style="display: none;" value="<?php echo $post['idPost']?>">
                                                        <button type="submit" class="btn btn-light btn-sm">

                                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                        درخواست پشتیبانی ...
                                                        </button>
                                                    </form>
                                                    
                                                </div>
                                                <?php
                                            }
                                        }else{
                                            echo $post['after_txt'];
                                        }
                                        
                                        ?>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
                                    
                
            </section>



        <?php
    }
}

?>


