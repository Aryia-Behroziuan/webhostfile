<?php
if(! isset($_SESSION['id'])){
    die();
}
if(isset($_POST['img'])){
    mysqli_query($con, "
    UPDATE user
    SET
        idb = '".$_POST['img']."',
        EZip_code = 2
    WHERE
        iduser = '".$_SESSION['id']."';
    ");

    $query_us = mysqli_query($con, 'select * from user where iduser="'.$_SESSION['id'].'"');
    $user = mysqli_fetch_assoc($query_us);
    if(! $user){
        die();
    }


}
?>
<div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn-icons-png.flaticon.com/512/6784/6784655.png" style="width: 200px;" alt="">
                        <h2>سرویس احراز هویت پیپرلاین</h2>
                        <small>پیپرلاین بستری را فراهم کرده تا با تایید هویت افراد بتواند اعتماد تجاری و غیر تجاری را در سرتاسر پلتفرم خود افزایش دهد از همین رو افرادی یا سازمان هایی که به فعالیت های صنفی و فعالیت های حساس نیازمند هستند مشمول  گزینش در این مرحله هستند این سرویس مدارک هویتی شمارا صحت سنجی کرده و شمارا مالک قانونی حساب کاربری قرار میدهد در ادامه راه هایی برای احراز هویت چند عامنلی شما فراهم شده است </small>
                        </div>
                        <!-- End Title -->
                        <br>
                        <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?controller=home&amp;method=con">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">امنیت جامعه محور</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/business-person-saving-password-of-account-3391058-2829984.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=apps-store">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">مدیریت تیم و سازمان</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/employees-working-on-content-creation-3391050-2829976.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=music">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">اتصالات و ابزار ها</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/business-person-chatting-on-mobile-3391061-2829987.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>
                        </div>
                    </div>


<section class="py-2">
	<div class="container">
    <div class="row pb-2">
    
    <?php
    if($user['EZip_code'] == 1){
        ?>
            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-wikipedia" viewBox="0 0 16 16">
                                <path d="M8.835 3.003c.828-.006 2.688 0 2.688 0l.033.03v.288c0 .08-.045.12-.133.12-.433.02-.522.063-.68.29-.087.126-.258.393-.435.694l-1.52 2.843-.043.089 1.858 3.801.113.031 2.926-6.946c.102-.28.086-.478-.044-.595-.132-.114-.224-.18-.563-.195l-.275-.014a.161.161 0 0 1-.096-.035.1.1 0 0 1-.046-.084v-.289l.042-.03h3.306l.034.03v.29c0 .078-.045.117-.133.117-.433.02-.754.113-.962.281a1.64 1.64 0 0 0-.488.704s-2.691 6.16-3.612 8.208c-.353.672-.7.61-1.004-.019A224.05 224.05 0 0 1 8.044 8.81c-.623 1.285-1.475 3.026-1.898 3.81-.411.715-.75.622-1.02.019-.45-1.065-1.131-2.519-1.817-3.982-.735-1.569-1.475-3.149-1.943-4.272-.167-.4-.293-.657-.412-.759-.12-.1-.368-.16-.746-.18C.069 3.429 0 3.395 0 3.341v-.303l.034-.03c.615-.003 3.594 0 3.594 0l.034.03v.288c0 .08-.05.118-.15.118l-.375.016c-.322.013-.483.11-.483.288 0 .083.034.217.109.4.72 1.753 3.207 6.998 3.207 6.998l.091.023 1.603-3.197-.32-.71L6.24 5.095s-.213-.433-.286-.577l-.098-.196c-.387-.77-.411-.82-.865-.88-.137-.017-.208-.035-.208-.102v-.304l.041-.03h2.853l.075.024v.303c0 .069-.05.104-.15.104l-.206.03c-.523.04-.438.254-.09.946l1.057 2.163 1.17-2.332c.195-.427.155-.534.074-.633-.046-.055-.202-.144-.54-.158l-.133-.015a.159.159 0 0 1-.096-.034.099.099 0 0 1-.045-.085v-.288l.041-.03Z"/>
                                </svg> برگ سبز هویتی شما  </font></font>
														</h5>


							<a class="small" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"> مالکیت شما </font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
                    .scroll-example {
                        overflow: auto;
                        scrollbar-width: none; /* Firefox */
                        -ms-overflow-style: none; /* IE 10+ */
                    }

                    .scroll-example::-webkit-scrollbar {
                        width: 0px;
                        background: transparent; /* Chrome/Safari/Webkit */
                    }
                    </style>
							<div class="card-body p-0">
              

                                <div class="card card-body bg-success bg-opacity-10 p-4 h-100">
                                    <h6><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برگ سبز هویتی
                                        </font></font><a tabindex="0" class="h6 mb-0" role="button" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-placement="top" data-bs-content="برگ سبز هویتی شما در سرویس احراز هویت پیپرلاین برای استعلام پلتفرم ها و افراد شخص ثالث" data-bs-original-title="" title="">
                                            <i class="bi bi-info-circle-fill small"></i>
                                        </a>
                                    </h6>
                                    <h2 class="fs-1 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['zip_code']?></font></font></h2>
                                    <p class="mb-2"><span class="text-primary me-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه:</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['title']?>-<?php echo $user['username']?>-<?php echo $user['iduser']?></font></font></p>
                                </div>

                            <hr>
                            <small><i class="bi bi-info-circle"></i> اکنون هویت شما برای ما احراز شده است و ما شمارا مورد اعتماد خود و مشتریانمان در سرتاسر پلتفرم میدانیم و میتوانید به آنها اراعه خدمات صنفی و غیر صنفی صنعتی و غیر صنعتی کنید  </small>


                            <hr>
                            <small><i class="bi bi-question-lg"></i>
                             آیا میخواهید ملک حساب خود را انتقال مالکیت دهید؟ <a href="#" id="orderNewVerifi">بله میخواهم انتقال دهم</a>
                            </small>
							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>

            
            <h1></h1>
            <h1></h1>
            <form action="" method="POST" style="display: none;" id="displayOrderVerifi">
            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">احراز هویت پیپرلاین</font></font>
														</h5>


							<button class="small btn btn-link" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"><i class="bi bi-plus"></i> تایید و ارسال</font></font></button>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
                    .scroll-example {
                        overflow: auto;
                        scrollbar-width: none; /* Firefox */
                        -ms-overflow-style: none; /* IE 10+ */
                    }

                    .scroll-example::-webkit-scrollbar {
                        width: 0px;
                        background: transparent; /* Chrome/Safari/Webkit */
                    }
                    </style>
							<div class="card-body p-0">
                            <h6><i class="bi bi-question-lg"></i> راهنما </h6>
                            <small><i class="bi bi-info-circle"></i> برای حراز هویت جهانی پیپرلاین کافیست یک مدرک هویتی که کد ملیتی شمارا از هر کشوری که زندگی میکنید نوسته باشد این میتوان عکس شناسنامه شما و یا مدارک هویتی مورد تایید دیگر باشد دقت داشته باشید که در مدرک هویتی شما حتما یک تصویر از شما باشد و تصویر روی مدرک هویتی با تصویر پروفایل شما برابری کند به طوری که تضخیص داده شود که عکس پروفایل خودتان هستید سپس از مدک هویتی خود تصویر برداری کرده و آن را در <a href="https://up.20script.ir/index.php">اینجا <i class="bi bi-link-45deg"></i></a> بارگذاری کنید و سپس لینک فایل تصویری را در فیلد پایین وارد کنید و سپس گزینه تایید را بزنید و منتظر تایید هویت خود بمانید نتیجه از طریق اعلان ها به شما نمایش داده خواهد شد</small>
                            <div class="col-12">
                            <br>

                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-plus-circle-dotted"></i> پیوند</font></font></label>
                                <input required="" id="con-name" name="img" type="text" class="form-control" placeholder="محل درج پیوند تصویری">
                                <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لطفا لینک تصویری که از سایت دریافت کرده اید را در این قسمت وارد کنید =</font></font></small>
                            </div>
                            </div>

                            <hr>
                            <small style="text-align: left;"> Powered by <a href="https://wwww.qitsource.ir"> qitSource,Inc</a></small>



							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
            </form>


                                            <script>
                                            $('#orderNewVerifi').click(function(event){
                                            event.preventDefault();
                             
                                  
                                
                                            document.getElementById('displayOrderVerifi').style.display = "flex";


                                    

                                            })
                                            </script>
        <?php
    }elseif($user['EZip_code'] == 2){
        ?>
            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <i class="bi bi-clock-history"></i> درحال پردازش...  </font></font>
														</h5>


							<a class="small" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"> استعلام صحت مدارک </font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
                    .scroll-example {
                        overflow: auto;
                        scrollbar-width: none; /* Firefox */
                        -ms-overflow-style: none; /* IE 10+ */
                    }

                    .scroll-example::-webkit-scrollbar {
                        width: 0px;
                        background: transparent; /* Chrome/Safari/Webkit */
                    }
                    </style>
							<div class="card-body p-0">
              



                            <small><i class="bi bi-info-circle"></i> در این مرحله مدارک هویتی شما از سازمان های مربوطه استعلام میگردد لطفا کمی صبر کنید شما در صف پردازش صحت دادگان هستید کمی بعد به شما از طریق اعلان های سراسری کوییت سورس در کیوپس آیدی شما اطلاع میدهیم </small>




							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
        <?php
    }else{
        ?>
            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  احراز هویت هوشمند  </font></font>
														</h5>


							<a class="small" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"> در دسترس نیست</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
                    .scroll-example {
                        overflow: auto;
                        scrollbar-width: none; /* Firefox */
                        -ms-overflow-style: none; /* IE 10+ */
                    }

                    .scroll-example::-webkit-scrollbar {
                        width: 0px;
                        background: transparent; /* Chrome/Safari/Webkit */
                    }
                    </style>
							<div class="card-body p-0">
              



                            <small><i class="bi bi-info-circle"></i> سرویس احراز هویت هوشمند به زودی فعال میشود با استفاده از این سرویس به راحتی با استعلام از سازمان ها و نهاد های هویت شما تایید میگردد </small>




							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
            

            <h1></h1>
            <h1></h1>
            <form action="" method="POST">
            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">احراز هویت پیپرلاین</font></font>
														</h5>


							<button class="small btn btn-link" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"><i class="bi bi-plus"></i> تایید و ارسال</font></font></button>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
                    .scroll-example {
                        overflow: auto;
                        scrollbar-width: none; /* Firefox */
                        -ms-overflow-style: none; /* IE 10+ */
                    }

                    .scroll-example::-webkit-scrollbar {
                        width: 0px;
                        background: transparent; /* Chrome/Safari/Webkit */
                    }
                    </style>
							<div class="card-body p-0">
                            <h6><i class="bi bi-question-lg"></i> راهنما </h6>
                            <small><i class="bi bi-info-circle"></i> برای حراز هویت جهانی پیپرلاین کافیست یک مدرک هویتی که کد ملیتی شمارا از هر کشوری که زندگی میکنید نوسته باشد این میتوان عکس شناسنامه شما و یا مدارک هویتی مورد تایید دیگر باشد دقت داشته باشید که در مدرک هویتی شما حتما یک تصویر از شما باشد و تصویر روی مدرک هویتی با تصویر پروفایل شما برابری کند به طوری که تضخیص داده شود که عکس پروفایل خودتان هستید سپس از مدک هویتی خود تصویر برداری کرده و آن را در <a href="https://up.20script.ir/index.php">اینجا <i class="bi bi-link-45deg"></i></a> بارگذاری کنید و سپس لینک فایل تصویری را در فیلد پایین وارد کنید و سپس گزینه تایید را بزنید و منتظر تایید هویت خود بمانید نتیجه از طریق اعلان ها به شما نمایش داده خواهد شد</small>
                            <div class="col-12">
                            <br>

                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-plus-circle-dotted"></i> پیوند</font></font></label>
                                <input required="" id="con-name" name="img" type="text" class="form-control" placeholder="محل درج پیوند تصویری">
                                <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لطفا لینک تصویری که از سایت دریافت کرده اید را در این قسمت وارد کنید =</font></font></small>
                            </div>
                            </div>

                            <hr>
                            <small style="text-align: left;"> Powered by <a href="https://wwww.qitsource.ir"> qitSource,Inc</a></small>



							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
            </form>
        <?php
    }
    ?>
    




    
    
    </div>
    </div>
</section>
