<div class="container space-2 space-lg-3">
    <br>
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/key-5000471-4164981.png?f=avif" style="width: 200px;" alt="">
                        <h2> سطح دسترسی شما محدود است </h2>
                        <small>شما به عنوان کارمند در سازمان <?php echo $user['username']?> فعالیت میکنید و دسترسی های شما به سیستم محدود است</small>
                        </div>
                        <!-- End Title -->

                        <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?controller=home&amp;method=con">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">رشد و بازده کارامد</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/apps.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=apps-store">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">رشد با هوش مصنوعی</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/calendar.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=music">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">تاثیر منصفانه</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://www.spacify.ir/public/img/logo/communication.svg" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>
                        </div>
                    </div>