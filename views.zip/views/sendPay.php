<?php
if(! isset($_SESSION['id'])){
    die();
}
if($_GET['id'] == $_SESSION['id']){
    die();
}
$query = mysqli_query($con, 'select * from user where iduser="'.$_SESSION['id'].'"');
$user = mysqli_fetch_assoc($query);
if(! $user){
    die();
}

$query_post = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published=1');
$post = mysqli_fetch_assoc($query_post);
if(! $post){
   $EP_Post=0;
}else{
    $EP_Post=1;
}

if($user['EZip_code'] == 1){
   $EPCode = 1;
}else{
    $EPCode = 0;
}
if(! isset($_GET['id'])){
    die();
}
$query_us = mysqli_query($con, 'select * from user where iduser="'.$_GET['id'].'"');
$us = mysqli_fetch_assoc($query_us);
if(! $us){
    die();
}

?>


<section class="py-2">
	<div class="container">
    <div class="row pb-2">

            <div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
                        <div id="displayErrorGetPay"></div>
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-paypal"></i>  ارسال صورت حساب  </font></font>
														</h5>

                    <form action="" method="POST" id="formGETDATASENDPAY">
							<button type="submit" class="btn btn-link" id="GETDATAFORM"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1"><i class="bi bi-file-earmark-diff"></i> صادر کردن </font></font></button>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                        <style>
                        .scroll-example {
                            overflow: auto;
                            scrollbar-width: none; /* Firefox */
                            -ms-overflow-style: none; /* IE 10+ */
                        }

                        .scroll-example::-webkit-scrollbar {
                            width: 0px;
                            background: transparent; /* Chrome/Safari/Webkit */
                        }
                        </style>
							<div class="card-body p-0">
              

                            <?php
                            if($EPCode == 0){
                                ?>
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-paypal"></i></font></font></h1>
                                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">احراز هویت</font></font></h2>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برای قرار فعالسازی خدمات پرداخت ازاد باید حساب خود را احراز کنید</font></font></p>
                                        <a href="dashboard.php?content=verification" class="btn btn-success-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> احراز هویت چند عاملی</font></font></a>
                                    </div>
                                    </div>
                                    </div>
                                </section>
                                <?php
                            }elseif($EP_Post == 0){
                                ?>
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-paypal"></i></font></font></h1>
                                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">جامعه توسعه دهندگان</font></font></h2>
                                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برای این کار حتما باید عضو جامعه توسعه دهندگان باشید و یک مخزن در حال انتشار داشته باشید</font></font></p>
                                        <a href="dashboard.php?content=listPost" class="btn btn-success-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> داشبورد مخازن </font></font></a>
                                    </div>
                                    </div>
                                    </div>
                                </section>
                                <?php
                            }else{
                                ?> 
                                <h6> صدارات برای ... <i class="bi bi-arrow-90deg-down"></i></h6>
                                                <div class="d-flex align-items-center position-relative">
                                                    <div class="avatar avatar-sm">
                                                        <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                                                    </div>
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><a href="../../blogzine.webestica.com/rtl/dashboard.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a><?php 
                                                                    if($us['piperAdmin'] == 1){
                                                                        ?>
                                                                        <img src="https://cdn-icons-png.flaticon.com/512/5253/5253968.png" style="width: 20px;" alt="">
                                                                        <?php
                                                                    }?> <?php 
                                                                    if($us['admin'] == 1){
                                                                        ?>
                                                                        <i class="bi bi-patch-check-fill text-info small"></i>
                                                                        <?php
                                                                    }?> </h6>
                                                        <small><?php echo $us['job']?></small>
                                                    </div>
                                                </div>
                                                <input type="text" style="display: none;" name="us" value="<?php echo $us['iduser']?>">
                                                <hr>


                                                <h6>مخزن مذکور</h6>
                                                <select name="postID" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                
                                                    <option select="0">انتخاب مخزن</option>
                                                    <?php
                                                    $query_1212 = mysqli_query($con, 'select * from posts where idUser='.$_SESSION['id'].' and published="1" order by date Desc');
                                                    $file_hash = mysqli_query($con, 'select * from posts where idUser='.$_SESSION['id'].' and published="1" order by date Desc');
                                                    $file = mysqli_fetch_assoc($query_1212);
                                                    if($file){
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                        ?>
                                                        <option value="<?php echo $res['idPost']?>"><?php echo $res['title']?></option>

                                                        <?php
                                                        }
                                                    }
                                                    ?>
                        
                                                </select>

                                                <div class="mb-3">
                                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ</font></font></label>
                                                    <input type="number" name="pay" class="form-control" min="1000" rows="1" placeholder="مبلغ را به تومان وارد کنید">
                                                    <small>مالیات پیپرلاین برای صورت حساب های پرداخت 7 درصد از مبلغ فاکتور شماست</small>
                                                </div>


                                                <div class="col-12">
                                                    <div class="mb-3">
                                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیح کوتاه</font></font></label>
                                                        <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                                                    </div>
                                                </div>
                    </form>
          

                            <script>
                                    $(document).ready(function(){
                                        $("#formGETDATASENDPAY").on("submit", function(event){
                                            event.preventDefault();
                                            $('#GETDATAFORM').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            var formValues= $('#formGETDATASENDPAY').serialize();

                                            $.post("../../index.php?controller=message&method=sendPay", formValues, function(data){
                                                // Display the returned data in browser
                                                $('#GETDATAFORM').html('<i class="bi bi-file-earmark-diff"></i> صادر کردن ');
                                                $('#displayErrorGetPay').html(data);
                                            });
                                        });
                                    });
                            </script>

                                <?PHP
                            }
                            ?>




							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
	</div>
	</div>
</section>
