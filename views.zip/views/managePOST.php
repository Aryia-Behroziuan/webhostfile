<?PHP 
if(! $user['piperAdmin'] == 1){
    die();
}
$query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query);
if(! $post){
    die();
}

$query = mysqli_query($con, 'select * from user where iduser="'.$post['idUser'].'"');
$us = mysqli_fetch_assoc($query);
if(! $us){
    die();
}
?>
<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 
                        
                                    <!-- Avatar -->
                                    <div class="avatar me-3">
                                        <img class="avatar-img rounded-circle shadow" src="<?php echo $us['avatar']?>" alt="آواتار">
                                    </div>
                                    <div>
                                        <a class="h6 mt-2 mt-sm-0" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['username']?></font>                                                                            
                                        <?php 
                                        if($us['admin'] == 1){
                                            ?>
                                            <i class="bi bi-patch-check-fill text-info small"></i>

                                            <?php
                                        }
                                        ?>
                                                                                </font></a>
                                        <p class="small m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $us['email']?></font></font></p>
                                        <a href="https://www.qitsource.ir"><span class="badge bg-primary rounded-pill"><font style="vertical-align: inherit;">QPassID<?php echo $us['iduser']?>@</font></span></a>
                                    </div>
                            </font></font>
														</h5>


							<a class="small" href="dashboard.php?content=profile&id=<?php echo $us['iduser']?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1">مشاهده پروفایل</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3" id="displayNoti1">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
							<div class="card-body p-0">
                            نام واقعی: <?php echo $us['title']?> 
                            <br>
                            شماره تلفن: <?php echo $us['phoneNumber']?> 
                            <br>
                            گزارش ها: <?php echo $us['report']?> 
                            <br>
                            <?php
                            if($us['enabled'] == 2){
                                ?>
                                محدودیت ها :  محدود شده

                               <?php
                            }elseif($us['enabled'] == 0){
                                ?>
                                 محدودیت ها :  مسدود کامل

                                <?php
                            }else{
                                ?>
                                 محدودیت ها : هیچ محدودیتی ندارد

                                <?php
                            }
                            
                            ?> 
                            <br>
                            موجودی ولت: <?php echo number_format($us['charge'] , 0 , "." , "," )?>
                            <br>
                            درآمد: <?php echo number_format($us['Income'] , 0 , "." , "," )?>

                            <?php
                            if($us['status'] == 2){
                                ?>
                                <br>
                                <br>
                                <div class="alert alert-info" role="alert">
                                درخواست وارسی داده است
                                </div>
                                <?php
                            }
                            ?>

                      



                                

                            <?php 
                            if($us['EZip_code'] == 1){
                                ?>
                                <br>
                                <br>
                                <small><img src="https://cdn-icons-png.flaticon.com/512/6784/6784655.png" style="width: 20px;" alt="">  احراز هویت او تکمیل است</small>
                                <strong><?php echo $us['zip_code']?></strong>
                                <br>
                                <br>
                                <?php
                            }elseif($us['EZip_code'] == 2){
                                ?>
                                <br>
                                <br>
                                <small><i class="bi bi-exclamation-triangle"></i>   در دست برسی است</small>
                                <strong><a href="dashboard.php?content=manageACCOPEN&id=<?php echo $us['iduser']?>">برسی کنید</a></strong>
                                <br>
                                <br>
                                <?php
                            }
                            ?>


                            <form action="" method="POST" id="formForGetDateinterPost">

                                <div class="alert alert-dark" role="alert">
                                <strong><?php echo $post['title']?></strong>- <a href="#"><?php echo $post['idPost']?></a>
                                <br>
                                <small><?php echo $post['doc']?></small>
                                <br>
                                <a href="index.php?content=open&id=<?php echo $post['idPost']?>">مشاهده پست</a>,
                                <a href="dashboard.php?content=open&id=<?php echo $post['idPost']?>">خرید پست</a>
                                </div>

                                <div class="alert alert-dark" role="alert">
                                <small><?php echo $post['txtE']?></small>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیح کوتاه</font></font></label>
                                        <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                                    </div>
                                </div>

                                <button class="btn btn-danger-soft" type="submit" id="cabcelReqPost">رد این پست</button>
                                <?php
                                if($post['published'] == 1){
           
                                }else{
                                    ?>
                                    <a href="#" class="btn btn-success" id="interPostReq">تایید</a>
                                    <?PHP
                                }
                                ?>

                                            <script>
                                            $('#interPostReq').click(function(event){
                                            event.preventDefault();
                                            $('#interPostReq').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=10&id=<?php echo $post['idPost']?>&idAcc=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#interPostReq').html('تایید');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>
                                
                            </form>


                            <script>
                                    $(document).ready(function(){
                                        $("#formForGetDateinterPost").on("submit", function(event){
                                            event.preventDefault();
                                            $('#cabcelReqPost').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            var formValues= $('#formForGetDateinterPost').serialize();

                                            $.post("../../index.php?controller=account&method=adminReq&mode=11&id=<?php echo $post['idPost']?>&idAcc=<?php echo $us['iduser']?>", formValues, function(data){
                                                // Display the returned data in browser
                                                $('#cabcelReqPost').html('رد پست');
                                                $('#displayNowAdmin').html(data);

                                            });
                                        });
                                    });
                            </script>

                            <hr>
                            <div id="displayNowAdmin"></div>

                            <a class="btn btn-dark-soft" href="#" id="statusAup">محدود سازی</a>
                            <a class="btn btn-dark-soft" href="#" id="blockedUser">مسدود</a>
                            <a class="btn btn-dark-soft" href="#" id="seeUser">برسی شد</a>

                            <?php
                            if($us['status'] == 2){
                                ?>
                                <a class="btn btn-dark-soft" href="#" id="endBlocked">آزادسازی</a>
                                <?php
                            }
                            ?>


                                            <script>
                                            $('#statusAup').click(function(event){
                                            event.preventDefault();
                                            $('#statusAup').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=1&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#statusAup').html('محدود سازی');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>

                                            <script>
                                            $('#blockedUser').click(function(event){
                                            event.preventDefault();
                                            $('#blockedUser').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=2&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#blockedUser').html('مسدود');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>

                                            <script>
                                            $('#endBlocked').click(function(event){
                                            event.preventDefault();
                                            $('#endBlocked').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=3&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#endBlocked').html('آزاد سازی');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>


                                            <script>
                                            $('#seeUser').click(function(event){
                                            event.preventDefault();
                                            $('#seeUser').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=adminReq&mode=4&id=<?php echo $us['iduser']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#seeUser').html('برسی شد');
                                                $('#displayNowAdmin').html(data);
                                                })

                                            })
                                            </script>



							</div>
							<!-- Button -->

	

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>

