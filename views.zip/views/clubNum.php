<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">جوایز شما</font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['numClub']?></font></font></span></h5>
							<a href="dashboard.php?content=club" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">جوایز جدید دریافت کنید</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">

						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							<div class="col-md-8">
								<form action="" method="POST" class="rounded position-relative">
									<input class="form-control pe-5 bg-transparent" type="search" placeholder="جستجو کردن" aria-label="جستجو کردن">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>

							<!-- Select option -->
							<div class="col-md-3">
								<!-- Short by filter -->
								<form>
									<select class="form-select z-index-9 bg-transparent" aria-label=".form-sect-sm">
										<option value="">مرتب سازی بر اساس</option>
										<option>رایگان</option>
										<option>جدیدترین</option>
										<option>قدیمی ترین</option>
									</select>
								</form>
							</div>
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						<div class="table-responsive border-0">
							<table class="table table-dark-gray align-middle p-4 mb-0 table-hover table-shrink">
								<!-- Table head -->
								<thead>
									<tr>
										<th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه </font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لینک محصول</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کد تخفیف</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درصد تخفیف</font></font></th>
									</tr>
								</thead>

								<!-- Table body START -->
								<tbody>

                                <?php
                                $query_1212 = mysqli_query($con, 'select * from session where userId='.$_SESSION['id'].' and rol="OFFERCODE" order by id Desc');
                                $file_hash = mysqli_query($con, 'select * from session where userId='.$_SESSION['id'].' and rol="OFFERCODE" order by id Desc');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
										$post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost='.$res['piperline'].''));
										if(! $post){
											$title='پست یافت نشد';
										}else{
											$title=$post['title'];
										}

                                ?>
                                        <!-- Table item -->
                                        <tr>
                                                <!-- Table data -->
                                                <td>
                                                    <h6 class="course-title mt-2 mt-md-0 mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $res['name']?></font></a></h6>
                                                </td>
                                                <!-- Table data -->
                                                <td>
                                                    <h6 class="mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $res['wiki']?></font></a></h6>
                                                </td>
                                                <!-- Table data -->
												<!-- Table data -->
												<td>
                                                    <h6 class="mb-0"><a href="index.php?content=open&id=<?php echo $res['piperline']?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $title?></font></a></h6>
                                                </td>
                                                <!-- Table data -->
                                                <td><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">OFFERCODE</font></font></span></td>
                                                <!-- Table data -->
                                                <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['data']?></font></font></td>
                                                <!-- Table data -->
                                                <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['payment']?></font></font></td>
                                                <td>
                                                    <div class="d-flex gap-2">
                                                        <a href="index.php?content=open&id=<?php echo $res['piperline']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="ویرایش کنید"><i class="bi bi-box-arrow-up-right"></i></a>
                                                    </div>
                                                </td>
                                        </tr>
                                <?php
                                    }
                                }
                                ?>				
		

								</tbody>
								<!-- Table body END -->
							</table>
						</div>
						<!-- Blog list table END -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>