<!-- =======================
Header START -->
<header class="navbar-light navbar-sticky header-static border-bottom navbar-dashboard">
	<!-- Logo Nav START -->
	<nav class="navbar navbar-expand-xl">
		<div class="container">
			<!-- Logo START -->
			<a class="navbar-brand me-3" href="index-2.html">
                <img class="navbar-brand-item light-mode-item" style="width: 160px; height: 55px;" src="assets/images/logo.png" alt="لوگو">			
				<img class="navbar-brand-item dark-mode-item" src="assets/images/logo-light.svg" alt="لوگو">			
			</a>
			<!-- Logo END -->

			<!-- Responsive navbar toggler -->
			<button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse1" aria-controls="navbarCollapse1" aria-expanded="false" aria-label="ناوبری را تغییر دهید">
				<span class="text-body h6 d-none d-sm-inline-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">منو</font></font></span>
				<span class="navbar-toggler-icon"></span>
			</button>

        <!-- Main navbar START -->
        <div class="collapse navbar-collapse" id="navbarCollapse1" style="backgraund: #ffffff; height: 100%;">
          <ul class="navbar-nav navbar-nav-scroll mx-auto">

            <!-- Nav item 1 Demos -->

          					<!-- Nav item 2 Post -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="postMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="bi bi-clipboard-data-fill"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">&nbsp داشبورد</font></font></a>
						<ul class="dropdown-menu" aria-labelledby="postMenu">
							<!-- dropdown submenu -->
							<li> <a class="dropdown-item" href="dashboard.php?content=listPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/dashboard-5591015-4653018.png?f=avif" alt="">

							داشبورد توسعه</font></font></a> </li>
							<li> <a class="dropdown-item" href="dashboard.php"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/list-3711847-3105321.png" alt="">

							خانه داشبورد</font></font></a> </li>
							<li> <a class="dropdown-item" href="index.php?content=homeACC"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" alt="">
							پیپرلاین خانه </font></font></a> </li>

              <li> <a class="dropdown-item" href="index.php"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/content-idea-7378923-6041262.png?f=avif" alt="">
							 کاوش  </font></font></a> </li>
							
						</ul>
					</li>


					<!-- Nav item 2 Post -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="postMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="bi bi-pencil me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست</font></font></a>
						<ul class="dropdown-menu" aria-labelledby="postMenu">
							<!-- dropdown submenu -->
							<li> <a class="dropdown-item" href="dashboard.php?content=listPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/search-paper-3711796-3105270.png" alt="">

							لیست پست ها</font></font></a> </li>
							<li> <a class="dropdown-item" href="dashboard.php?content=listPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/list-3711847-3105321.png" alt="">

							لیست مخزن ها</font></font></a> </li>
							<li> <a class="dropdown-item" href="dashboard.php?content=createPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/push-pin-3711808-3105282.png" alt="">
							یک پست ایجاد کنید</font></font></a> </li>
							<li> <a class="dropdown-item" href="dashboard.php?content=listPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/push-pin-3711803-3105277.png" alt="">

							ویرایش پست</font></font></a> </li>

							<li> <a class="dropdown-item" href="dashboard.php?content=createPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/cloud-upload-3711802-3105276.png" alt="">
							 ایجاد مخزن جدید</font></font></a> </li>

							 <li> <a class="dropdown-item" href="dashboard.php?content=listPost"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							 <img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/star-3711810-3105284.png" alt="">

							  ویرایش مخازن</font></font></a> </li>

						</ul>
					</li>

					<!-- Nav item 3 Pages -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="pagesMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="bi bi-folder me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">صفحات</font></font></a>
						<ul class="dropdown-menu" aria-labelledby="pagesMenu">
							<li> <a class="dropdown-item" href="dashboard.php?content=res"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/full-volume-3711820-3105294.png" alt="">

							 گزارشات</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=editProfile"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/toggle-button-3711813-3105287.png" alt="">

							ویرایش نمایه</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=payment"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/income-4996090-4159687.png" alt="">

							مدیریت مالی</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=wallet"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-piggy-bank-5341951-4466129.png" alt="">
							 
							کیف پول</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=apiDoc" target="_blank"> <i class="text-warning fa-fw bi bi-braces-asterisk me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مستندات توسعه دهندگان</font></font></a></li>
							<li> <a class="dropdown-item" href="#" target="_blank"> <i class="text-warning fa-fw bi bi-life-preserver me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پشتیبانی</font></font></a></li>
							<li> <a class="dropdown-item" href="../docs/index.html" target="_blank"> <i class="text-danger fa-fw bi bi-card-text me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مستندات</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li><a class="dropdown-item" href="index.html" target="_blank"> <i class="text-info fa-fw bi bi-toggle-off me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نسخه ی نمایشی RTL</font></font></a></li>
							<li><a class="dropdown-item" href="#" target="_blank"> <i class="text-success fa-fw bi bi-cloud-download-fill me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خرید وبلاگ!</font></font></a> </li>
						</ul>
					</li>

          
					<!-- Nav item 3 Pages -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="pagesMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="bi bi-cloud-haze2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فضای کاری</font></font></a>
						<ul class="dropdown-menu" aria-labelledby="pagesMenu">
							<li> <a class="dropdown-item" href="dashboard.php?content=cloud"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/bell-3711884-3105237.png" alt="">

							 فضای شما</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=contact"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" alt="">

							 مخاطبین</font></font></a></li>
							<li> <a class="dropdown-item" href="../../core/rtl/dashboard.php?content=notifi"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/toggle-off-3711811-3105285.png" alt="">

							اعلان</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=profile&id=<?phP echo $_SESSION['id']?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/account-confirm-2871196-2384396.png" alt="">
							 
							نمایه من</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li> <a class="dropdown-item" href="https://support.webestica.com/" target="_blank"> <i class="text-warning fa-fw bi bi-life-preserver me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پشتیبانی</font></font></a></li>
							<li> <a class="dropdown-item" href="../docs/index.html" target="_blank"> <i class="text-danger fa-fw bi bi-card-text me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مستندات</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li><a class="dropdown-item" href="index.html" target="_blank"> <i class="text-info fa-fw bi bi-toggle-off me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نسخه ی نمایشی RTL</font></font></a></li>
							<li><a class="dropdown-item" href="https://themes.getbootstrap.com/store/webestica/" target="_blank"> <i class="text-success fa-fw bi bi-cloud-download-fill me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خرید وبلاگ!</font></font></a> </li>
						</ul>
					</li>

          <!-- Nav item 3 Pages -->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="pagesMenu" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="bi bi-cloud-haze2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پلتفرم</font></font></a>
						<ul class="dropdown-menu" aria-labelledby="pagesMenu">
							<li> <a class="dropdown-item" href="dashboard.php?content=helpCenter"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/question-5321091-4471031.png" alt="">

							 پایگاه دانش</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=news"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/toggle-button-3711813-3105287.png" alt="">

							 اخبار زیست بوم</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=payment"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/income-4996090-4159687.png" alt="">

							مدیریت مالی</font></font></a></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=wallet"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
							<img style="width: 30px; height: 30px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-piggy-bank-5341951-4466129.png" alt="">
							 
							کیف پول</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li> <a class="dropdown-item" href="dashboard.php?content=update" target="_blank"> <i class="text-warning fa-fw bi bi-life-preserver me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به روزرسانی</font></font></a></li>
							<li> <a class="dropdown-item" href="https://support.webestica.com/" target="_blank"> <i class="text-warning fa-fw bi bi-life-preserver me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پشتیبانی</font></font></a></li>
							<li> <a class="dropdown-item" href="../docs/index.html" target="_blank"> <i class="text-danger fa-fw bi bi-card-text me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مستندات</font></font></a></li>
							<li class="dropdown-divider"></li>
							<li><a class="dropdown-item" href="index.html" target="_blank"> <i class="text-info fa-fw bi bi-toggle-off me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نسخه ی نمایشی RTL</font></font></a></li>
							<li><a class="dropdown-item" href="https://themes.getbootstrap.com/store/webestica/" target="_blank"> <i class="text-success fa-fw bi bi-cloud-download-fill me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خرید وبلاگ!</font></font></a> </li>
						</ul>
					</li>
				</ul>
				
				<!-- Search dropdown START -->
				<div class="nav my-3 my-xl-0 px-4 px-lg-1 flex-nowrap align-items-center">
					<div class="nav-item w-100">
            
                    <a href="../../core/rtl/dashboard.php?content=createblog" class="btn btn-sm" style="color: black;">

                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-plus-square-dotted" viewBox="0 0 16 16">
                        <path d="M2.5 0c-.166 0-.33.016-.487.048l.194.98A1.51 1.51 0 0 1 2.5 1h.458V0H2.5zm2.292 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zm1.833 0h-.916v1h.916V0zm1.834 0h-.917v1h.917V0zm1.833 0h-.917v1h.917V0zM13.5 0h-.458v1h.458c.1 0 .199.01.293.029l.194-.981A2.51 2.51 0 0 0 13.5 0zm2.079 1.11a2.511 2.511 0 0 0-.69-.689l-.556.831c.164.11.305.251.415.415l.83-.556zM1.11.421a2.511 2.511 0 0 0-.689.69l.831.556c.11-.164.251-.305.415-.415L1.11.422zM16 2.5c0-.166-.016-.33-.048-.487l-.98.194c.018.094.028.192.028.293v.458h1V2.5zM.048 2.013A2.51 2.51 0 0 0 0 2.5v.458h1V2.5c0-.1.01-.199.029-.293l-.981-.194zM0 3.875v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 5.708v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zM0 7.542v.916h1v-.916H0zm15 .916h1v-.916h-1v.916zM0 9.375v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .916v.917h1v-.917H0zm16 .917v-.917h-1v.917h1zm-16 .917v.458c0 .166.016.33.048.487l.98-.194A1.51 1.51 0 0 1 1 13.5v-.458H0zm16 .458v-.458h-1v.458c0 .1-.01.199-.029.293l.981.194c.032-.158.048-.32.048-.487zM.421 14.89c.183.272.417.506.69.689l.556-.831a1.51 1.51 0 0 1-.415-.415l-.83.556zm14.469.689c.272-.183.506-.417.689-.69l-.831-.556c-.11.164-.251.305-.415.415l.556.83zm-12.877.373c.158.032.32.048.487.048h.458v-1H2.5c-.1 0-.199-.01-.293-.029l-.194.981zM13.5 16c.166 0 .33-.016.487-.048l-.194-.98A1.51 1.51 0 0 1 13.5 15h-.458v1h.458zm-9.625 0h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zm1.834-1v1h.916v-1h-.916zm1.833 1h.917v-1h-.917v1zm1.833 0h.917v-1h-.917v1zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                    </svg>
                                    

                    </a>
                    <a href="../../core/rtl/dashboard.php?content=chats" class="btn btn-light btn-sm">

                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 30px;" alt="Avatar">

                    
                    <?php 
                    if(! $user['notification'] == '0'){
                        ?>
                        <span class="notif-badge animation-blink"></span>
                        <?php
                    }
                    ?>
                    </a>
                    <a href="../../core/rtl/dashboard.php?content=wallet" class="btn btn-outline-dark btn-sm" style="border-radius:20px;">

                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-sign-5339244-4466132.png" style="width: 30px;" alt="Avatar">

                        
                        <?php
                        if($user['charge'] == 0){
                        echo 'کیف پول';
                        }else{
                        echo '<strong>'.number_format($user['charge'] , 0 , "." , "," ).'</strong>'?> تومان <?php
                        }
                        ?>
                    </a>            
					</div>
				</div>
				<!-- Search dropdown END -->
			</div>
		  <!-- Main navbar END -->
            <?php
            if(isset($_SESSION['id'])){
                ?>
                <!-- Nav right START -->
                <div class="nav flex-nowrap align-items-center">

                    <!-- Notification dropdown START -->
                    <div class="nav-item ms-2 ms-md-3 dropdown">
                        <!-- Notification button -->
                        <a class="btn btn-primary-soft btn-round mb-0" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                            <i class="bi bi-bell fa-fw"></i>
                        </a>
                        <!-- Notification dote -->
                        <span class="notif-badge animation-blink"></span>

                        <!-- Notification dropdown menu START -->
                        <div class="dropdown-menu dropdown-animation dropdown-menu-end dropdown-menu-size-md p-0 shadow-lg border-0">
                            <div class="card bg-transparent">
                                <div class="card-header bg-transparent border-bottom p-3 d-flex justify-content-between align-items-center">
                                    <h6 class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعیه</font></font>
                                        <?php
                                        if($user['notification'] == 0){

                                        }else{
                                        ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger ms-2" id="showNoti"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['notification']?> اعلان جدید</font></font></span>

                                        <?php
                                        }
                                        ?>
                                    
                                        </h6>
                                                        <a class="small" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti">همه را پاک کن</font></font></a>
                                                    </div>
                                    <style>
                                    .scroll-example {
                                        overflow: auto;
                                        scrollbar-width: none; /* Firefox */
                                        -ms-overflow-style: none; /* IE 10+ */
                                    }

                                    .scroll-example::-webkit-scrollbar {
                                        width: 0px;
                                        background: transparent; /* Chrome/Safari/Webkit */
                                    }
                                    </style>
                                                    <div class="card-body p-0" id="displayNoti">
                                                        <ul style="height: 400px;" class="list-group list-unstyled list-group-flush scroll-example">
                                                            
                                        <?php
                                        $query_1212 = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
                                        $file_hash = mysqli_query($con, 'select * from comment where userId="'.$_SESSION['id'].'" and notifi="1" order by time Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                        if($file){
                                            while($res=mysqli_fetch_assoc($file_hash)){
                                            $some_time = strtotime($res['time']);

                                            ?>
                                            <!-- Notif item -->
                                            <li>
                                                <?PHP
                                                if($res['link'] == '0'){
                                                ?>
                                                <a href="../../core/rtl/dashboard.php?content=openNotifi&id=<?PHP echo $res['idcomment']?>" class="list-group-item-action border-0 border-bottom d-flex p-3">
                                                <?php
                                                }else{
                                                ?>
                                                <a href="<?PHP echo $res['link']?>" class="list-group-item-action border-0 border-bottom d-flex p-3">
                                                <?php
                                                }
                                                ?>
                                                <div class="me-3">
                                                    <div class="icon-lg bg-warning bg-opacity-15 text-warning rounded-2 flex-shrink-0">
                                                    <i class="bi bi-bell"></i>
                                                    </div>
                                                </div>
                                                <div>
                                                    <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['title']?></font></font></h6>
                                                    <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('Y, d F', $some_time)?></font></font></span>
                                                </div>
                                                </a>
                                            </li>
                                            <?php
                                            }
                                        }else{
                                            ?>
                                            <section class="overflow-hidden">
                                                <div class="container">
                                                    <div class="row">
                                                <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                    <!-- SVG shape START -->
                                                    <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                    <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                        <g>
                                                        <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                        <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                        <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                        <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                        <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                        <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                        <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                        <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                        c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                        </g>
                                                    </svg>
                                                    </figure>
                                                    <!-- SVG shape START -->
                                                    <!-- Content -->
                                                    <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
                                                    <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اعلانی یافت نشد</font></font></h2>
                                                    
                                                </div>
                                                </div>
                                                </div>
                                            </section>
                                            <?php
                                        }
                                        ?>
                                                <script>
                                                $('#deletenoti').click(function(event){
                                                event.preventDefault();
                                                $('#deletenoti').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp حذف...');

                                                
                                                $.ajax({
                                                    method: "POST",
                                                    url: "../../index.php?controller=account&method=deleteNotifi",
                                                    data: { code: "1"}
                                                })
                                                    .done(function(data){
                                                    $('#deletenoti').html('');
                                                    $('#showNoti').html('');
                                                    $('#displayNoti').html(data);
                                                    })

                                                })
                                                </script>



                                    </ul>
                                </div>
                                <!-- Button -->
                                <div class="card-footer bg-transparent border-0 py-3 text-center position-relative">
                                    <a href="../../core/rtl/dashboard.php?content=notifi" class="stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشاهده تمام فعالیت های اعلان</font></font></a>
                                </div>
                            </div>
                        </div>
                        <!-- Notification dropdown menu END -->
                    </div>
                    <!-- Notification dropdown END -->

                    <!-- Profile dropdown START -->
                    <div class="nav-item ms-2 ms-md-3 dropdown">
                        <!-- Avatar -->
                        <a class="avatar avatar-sm p-0" href="#" id="profileDropdown" role="button" data-bs-auto-close="outside" data-bs-display="static" data-bs-toggle="dropdown" aria-expanded="false">
                            <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="آواتار">
                        </a>

                        <!-- Profile dropdown START -->
                        <ul class="dropdown-menu dropdown-animation dropdown-menu-end shadow pt-3" aria-labelledby="profileDropdown">
                            <!-- Profile info -->
                            <li class="px-3">
                                <div class="d-flex align-items-center">
                                    <!-- Avatar -->
                                    <div class="avatar me-3">
                                        <img class="avatar-img rounded-circle shadow" src="<?php echo $user['avatar']?>" alt="آواتار">
                                    </div>
                                    <div>
                                        <a class="h6 mt-2 mt-sm-0" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['username']?></font><?php
                                                                            if($user['admin'] == 1){
                                                                                ?>
                                                                                <i class="bi bi-patch-check-fill text-info small"></i>
                                                                                <?php
                                                                            }
                                                                            ?></font></a>
                                        <p class="small m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['email']?></font></font></p>
                    <a href="https://www.qitsource.ir"><span class="badge bg-primary rounded-pill"><font style="vertical-align: inherit;">QPassID<?php echo $user['iduser']?>@</font></span></a>
                                    </div>
                                </div>
                                <hr>
                            </li>
                            <!-- Links -->
                        <li><a class="dropdown-item" href="dashboard.php?content=account"><i class="bi bi-fingerprint"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">&nbsp مرکز پایش حساب</font></font></a></li>

                            <li><a class="dropdown-item" href="dashboard.php?content=editProfile"><i class="bi bi-person fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش نمایه</font></font></a></li>
                            <li><a class="dropdown-item" href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting"><i class="bi bi-gear fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات حساب</font></font></a></li>
                            <li><a class="dropdown-item" href="#"><i class="bi bi-info-circle fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کمک</font></font></a></li>
                            <li><a class="dropdown-item" href="../../index.php?controller=account&method=logout"><i class="bi bi-power fa-fw me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></a></li>
                            <li class="dropdown-divider mb-3"></li>
                            <li>
                                <div class="dropdown-item">
                                    <div class="modeswitch m-0" id="darkModeSwitch">
                                        <div class="switch"></div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <!-- Profile dropdown END -->
                    </div>
                    <!-- Profile dropdown END -->

                <!-- Nav right END -->
                </div>
                <?php
            }else{
                ?>
					<!-- Nav right START -->
                    <div class="nav flex-nowrap align-items-center">
			
                                
                            
                        <a class="btn" href="index.php?content=search">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-binoculars" viewBox="0 0 16 16">
                            <path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h1A1.5 1.5 0 0 1 7 2.5V5h2V2.5A1.5 1.5 0 0 1 10.5 1h1A1.5 1.5 0 0 1 13 2.5v2.382a.5.5 0 0 0 .276.447l.895.447A1.5 1.5 0 0 1 15 7.118V14.5a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 14.5v-3a.5.5 0 0 1 .146-.354l.854-.853V9.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.793l.854.853A.5.5 0 0 1 7 11.5v3A1.5 1.5 0 0 1 5.5 16h-3A1.5 1.5 0 0 1 1 14.5V7.118a1.5 1.5 0 0 1 .83-1.342l.894-.447A.5.5 0 0 0 3 4.882V2.5zM4.5 2a.5.5 0 0 0-.5.5V3h2v-.5a.5.5 0 0 0-.5-.5h-1zM6 4H4v.882a1.5 1.5 0 0 1-.83 1.342l-.894.447A.5.5 0 0 0 2 7.118V13h4v-1.293l-.854-.853A.5.5 0 0 1 5 10.5v-1A1.5 1.5 0 0 1 6.5 8h3A1.5 1.5 0 0 1 11 9.5v1a.5.5 0 0 1-.146.354l-.854.853V13h4V7.118a.5.5 0 0 0-.276-.447l-.895-.447A1.5 1.5 0 0 1 12 4.882V4h-2v1.5a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V4zm4-1h2v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V3zm4 11h-4v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14zm-8 0H2v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14z"></path>
                            </svg>
                        </a>

                        <div class="header-cta">


                        <?php
                                    include '../../inc/vendor/autoload.php';

                                    // init configuration
                                    $clientID = '104536222073-4skbqtebb2m5arvq42fje2lc3s1rm8ds.apps.googleusercontent.com';
                                    $clientSecret = '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';
                                    $redirectUri = 'https://www.piperline.ir/index.php?controller=account&method=googleSignup';
                                    
                                    // create Client Request to access Google API
                                    $client = new Google_Client();
                                    $client->setClientId($clientID);
                                    $client->setClientSecret($clientSecret);
                                    $client->setRedirectUri($redirectUri);
                                    $client->addScope("email");
                                    $client->addScope("profile");


                        ?>
                        <a href="<?php echo $client->createAuthUrl()?>"><div class="d-inline-block elementor-button-link elementor-button elementor-size-md">
                            
                            <img style="width: 25px; height: 25px;" src="https://upload.wikimedia.org/wikipedia/commons/0/09/IOS_Google_icon.png" alt="">
                                    
                            حساب من
                            </div></a>
                            




                        </div>


                



                <!-- Nav right END -->
                    </div>
                <?php
            }
            ?>

		</div>
	</nav>
	<!-- Logo Nav END -->
</header><div id="sticky-space" class="" style="height: 0px;"></div>
<!-- =======================
Header END -->