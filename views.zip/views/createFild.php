<?php

if(! isset($_GET['id'])){
    die();
}
$query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query);
if($post){

}else{
    die();
}
?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/language-translate-5192260-4340265.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video>ایجاد فیلد ...</h1>
			</div>
		</div>

        <div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
                   													<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
                
                    </div>
				</div>
			</div>
		</div>

        <br>

		<div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
            <!-- Form START -->
            <form action="../../index.php?controller=create&method=createFild" method="POST">
              <!-- Main form -->
              <div class="row">
                <div class="col-12">
                  <!-- Post name -->
                  <div class="mb-3">
                    <label class="form-label">نام</label>
                    <input required="" id="con-name" name="name" type="text" class="form-control" placeholder="وارد کنید">
                  </div>
                </div>
                <!-- Post type START -->
                <input type="text" style="display: none;" name="postID" value="<?php echo $_GET['id']?>">

                <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع</font></font></label>
                                <select name="type" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                
                                    <option value="text">ورود متن کم</option>
                                    <option value="textarea">ورود متن زیاد</option>
                                    <option value="number">ورود عدد</option>
                                    <option value="password">ورود کلمه عبور</option>
           
                                </select>
                                <small>نوع فیلد را مشخص کنید قرار است چه اطلاعاتی کاربر بتواند درون ان وارد کند</small>
                </div>
              
          

 
                <!-- Create post button -->
                <div class="col-md-12 text-start">
                    <a class="btn btn-outline-danger" href="../../blogzine.webestica.com/rtl/dashboard.php?content=createPost&id=<?php echo $_GET['id']?>">بازگشت</a>
                    <button class="btn btn-primary" type="submit">ایجاد فیلد</button>
                </div>
              </div>
            </form>
            <!-- Form END -->
					</div>
				</div>
				<!-- Chart END -->
		</div>
    </div>
	</div>
</section>