                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/firewall-security-5000466-4164984.png?f=avif" style="width: 200px;" alt="">
                        <h2><i class="bi bi-lock"></i> امنیت حساب </h2>
                        <small>ما بر روی امنیت حساب کیوپس آیدی شما متمرکزیم و در ادامه توضیحاتی را راجب وضعیت امنیتی حسابتان در نزد خود برای شما شفاف سازی خواهیم کرد همه اطلاعات شما توسط سرویس پشتیبان حساب شما یعنی کیوپس آیدی مدیریت شده و ما فقط آن در دریافت و ارسال میکنیم</small>
                        </div>
                        <!-- End Title -->
                        <br>
                        <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?controller=home&amp;method=con">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">امنیت پایدار</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdn3d.iconscout.com/3d/premium/thumb/key-5000470-4164980.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=apps-store">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">سرتاسر رمزگذاری شده</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdn3d.iconscout.com/3d/premium/thumb/key-5000471-4164981.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=music">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">Connected QPassID Account</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdn3d.iconscout.com/3d/premium/thumb/user-security-5000473-4164979.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>
                        </div>
                    </div>


<section class="pb-4">
	<div class="container">
		<div class="row g-4">
                        <div class="card bg-transparent border rounded-3 mt-4">
							<!-- Card header -->
							<div class="card-header bg-transparent border-bottom p-3">
								<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرکز کنترل حساب</font></font></h5>
							</div>
							<!-- Card body START -->
							<div class="card-body">
								<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><i class="fab fa-google text-google-icon"></i></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گوگل</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما با موفقیت به حساب Google خود متصل شدید</font></font></p>
										<!-- Button -->
										<button type="button" class="btn btn-sm btn-danger mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فراخوانی کنید</font></font></button>
										<a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>


									<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
									<path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
									<path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
									<path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
									</svg></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">QPassID</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیوپس آیدی تکنولوژی مدیریت حساب های شرکت کوییت سورس است که برای استفاده از سرویس های شرکت کوییت سورس باید شناسه کیوپس آیدی داشته باشید شما با ورود به هر یک از سرویس های مجموعه کوییت سورس حساب کیوپس آیدی خود را راه اندازی میکنید و برای مدیریت حساب و مرکز کنترل اصلی به سایت رسمی کیوپس آیدی بروید</font></font></p>
										<!-- Button -->
										<a href="https://www.qitsource.ir" class="btn btn-sm btn-primary mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به مرکز کنترل بروید</font></font>
																				</a><a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>

									<!-- Blogger -->
									<!-- Blogger -->
									

							
								</div>
								<!-- Card body END -->
							</div>

                            <div class="card-body" style="height: auto !important; min-height: 0px !important;">
                           
                        
                                <div class="row mx-n2">
                                    <div class="col-md-6 px-2 mb-3 mb-lg-0">
                                    <!-- Icon Block -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-body">
                                        <div class="media">
                                            <figure class="w-100 max-w-6rem mr-3">
                                            <img class="img-fluid" src="https://www.gstatic.com/identity/boq/accountsettingsmobile/dataandpersonalization_icon_96x96_cdb6dff2e31ed6745ece4662231bfd48.png" alt="SVG">
                                            </figure>
                                            <div class="media-body">
                                            <h3>Privacy &amp; personalization</h3>
                                            <p class="text-body">See the data in your Google Account and choose what activity is saved to personalize your Google experience</p>
                                            </div>
                                        </div>
                                        </div>
                                    </a>
                                    <!-- End Icon Block -->
                                    </div>

                                    <div class="col-md-6 px-2 mb-3 mb-lg-0">
                                    <!-- Icon Block -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-body">
                                        <div class="media">
                                            <figure class="w-100 max-w-6rem mr-3">
                                            <img class="img-fluid" src="https://www.gstatic.com/identity/boq/accountsettingsmobile/securitycheckup_green_96x96_7bebea78abf8844f14e338de252c6198.png" alt="SVG">
                                            </figure>
                                            <div class="media-body">
                                            <h3>Your account is protected</h3>
                                            <p class="text-body">The Security Checkup checked your account and found no recommended actions</p>
                                            </div>
                                        </div>
                                        </div>
                                    </a>
                                    <!-- End Icon Block -->
                                    </div>
                                </div>
                                <br>
                                <div class="row mx-n2">
                                    <div class="col-md-6 px-2 mb-3 mb-lg-0">
                                    <!-- Icon Block -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-body">
                                        <div class="media">
                                            <figure class="w-100 max-w-6rem mr-3">
                                            <img class="img-fluid" src="https://www.gstatic.com/identity/boq/accountsettingsmobile/googleonestorage_spot_72x72_33aff7baa37268ce05827c5c1d6752f0.png" alt="SVG">
                                            </figure>
                                            <div class="media-body">
                                            <h3>Account storage</h3>
                                            <p class="text-body">Cloud storage for the information we receive from you</p>
                                            <div class="progress">
                                                <div class="progress-bar" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                                <div class="progress-bar bg-success" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                                <div class="progress-bar bg-info" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            </div>
                                        </div>
                                        </div>
                                    </a>
                                    <!-- End Icon Block -->
                                    </div>

                                    <div class="col-md-6 px-2 mb-3 mb-lg-0">
                                    <!-- Icon Block -->
                                    <a class="card card-frame h-100" href="index.php?controller=community&amp;method=view&amp;page=polisy">
                                        <div class="card-body">
                                        <div class="media">
                                            <figure class="w-100 max-w-6rem mr-3">
                                            <img class="img-fluid" src="https://www.gstatic.com/identity/boq/accountsettingsmobile/privacycheckup_initial_active_96x96_dd32f2d12cd34121e479baf7a103ee93.png" alt="SVG">
                                            </figure>
                                            <div class="media-body">
                                            <h3>Privacy suggestions available</h3>
                                            <p class="text-body">Take the Privacy Checkup and choose the settings that are right for you</p>
                                            </div>
                                        </div>
                                        </div>
                                    </a>
                                    <!-- End Icon Block -->
                                    </div>
                                </div>
 
                                <div class="row mx-n2">
                                    <div class="col-sm-6 col-md-4 px-2 mb-3 mb-md-0">
                                    <!-- Card -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-header bg-success text-center rounded-lg-top py-4">
                                        <div class="avatar avatar-lg d-block bg-white rounded p-2 mx-auto">
                                            <img class="avatar-img" src="https://www.spacify.ir/public/img/logo/wizify.png" alt="Image Description">
                                        </div>
                                        </div>
                                        <div class="card-body">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="d-block text-dark font-weight-bold">Spacify apps</span>
                                            <img class="ml-2" src="public/img/logo/top-vendor.svg" alt="Image Description" title="Top Vendor" width="16">
                                        </div>
                                        <span class="d-block text-body font-size-1">Connect your account to other apps and use it as a switch</span>
                                        </div>
                                    </a>
                                    <!-- End Card -->
                                    </div>

                                    <div class="col-sm-6 col-md-4 px-2 mb-3 mb-md-0">
                                    <!-- Card -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-header bg-danger text-center rounded-lg-top py-4">
                                        <div class="avatar avatar-lg d-block bg-white rounded p-2 mx-auto">
                                            <img class="avatar-img" src="https://www.spacify.ir/public/img/logo/google.svg" alt="Image Description">
                                        </div>
                                        </div>
                                        <div class="card-body">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="d-block text-dark font-weight-bold">Google</span>
                                            <img class="ml-2" src="https://www.spacify.ir/public/img/logo/top-vendor.svg" alt="Image Description" title="Top Vendor" width="16">
                                        </div>
                                        <span class="d-block text-body font-size-1">Multinational technology company that specializes in Internet-related services</span>
                                        </div>
                                    </a>
                                    <!-- End Card -->
                                    </div>

                                    <div class="col-sm-6 col-md-4 px-2">
                                    <!-- Card -->
                                    <a class="card card-frame h-100" href="#">
                                        <div class="card-header bg-warning text-center rounded-lg-top py-4">
                                        <div class="avatar avatar-lg d-block bg-white rounded p-2 mx-auto">
                                            <img class="avatar-img" src="https://www.spacify.ir/public/img/logo/slack.svg" alt="Image Description">
                                        </div>
                                        </div>
                                        <div class="card-body">
                                        <div class="d-flex align-items-center mb-1">
                                            <span class="d-block text-dark font-weight-bold">Slack</span>
                                            <img class="ml-2" src="public/img/logo/top-vendor.svg" alt="Image Description" title="Top Vendor" width="16">
                                        </div>
                                        <span class="d-block text-body font-size-1">Email collaboration and email service desk made easy</span>
                                        </div>
                                    </a>
                                    <!-- End Card -->
                                    </div>
                                </div>



                                <br>

                            <div class="card bg-transparent border rounded-3 mt-4">
							<!-- Card header -->
							<div class="card-header bg-transparent border-bottom p-3">
								<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/access-password-5000469-4164983.png?f=avif" style="width: 50px;" alt=""> کلید امنیتی </font></font></h5>
							</div>
							<!-- Card body START -->
							<div class="card-body">
                                <div class="form-group">
                                    <h4><a id="reflesh" class="btn btn-xs btn-outline-indigo" href="#">
                                    <img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">
                                </a> Scret-Key</h4>
                                    <textarea id="displayAPIKEY" style="height: 150px;" class="form-control" placeholder="Disabled textarea" disabled=""><?php echo $user['Sec-key']?></textarea>
                                </div>
                            <hr>
                            <i class="bi bi-incognito"></i> این قسمت را در معرض دید دیگران قرار ندهید 
							</div>
                            <script>
                                            $('#reflesh').click(function(event){
                                            event.preventDefault();
                                            $('#reflesh').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=suite&mode=6",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#reflesh').html('<img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">');
                                                $('#displayAPIKEY').html(data);
                                                })

                                            })
                                            </script>


		</div>
	</div>
</section>
