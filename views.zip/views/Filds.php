<?php

if(! isset($_GET['id'])){
    die();
}
$query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query);
if($post){

}else{
    die();
}
?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/language-translate-5192260-4340265.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video>فیلد ها</h1>
                    <a href="../../blogzine.webestica.com/rtl/dashboard.php?content=createFild&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ایجاد فیلد جدید</a>
			</div>
		</div>

        <div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
                   													<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
                
                    </div>
				</div>
			</div>
		</div>

        <br>

		<div class="row">
			<div class="col-12">

                <?php
                $query_1212 = mysqli_query($con, 'select * from session where name="fild" and userId="'.$_SESSION['id'].'" and piperline="'.$_GET['id'].'" order by createDate Desc');
                $file_hash = mysqli_query($con, 'select * from session where name="fild" and userId="'.$_SESSION['id'].'" and piperline="'.$_GET['id'].'" order by createDate Desc');
                $file = mysqli_fetch_assoc($query_1212);
                if($file){
                    while($res=mysqli_fetch_assoc($file_hash)){
                        ?>
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                            <?php
                            if($res['type'] == 'textarea'){
                                ?>
                                <div class="col-12">
                                <!-- Post name -->
                                <div class="mb-3">
                                    <label class="form-label"><?php echo $res['wiki']?></label>
                                    <textarea required="" id="con-name" name="name" class="form-control" placeholder="وارد کنید"></textarea>
                                </div>
                                <a href="../../index.php?controller=create&amp;method=deleteFild&amp;id=<?php echo $res['id']?>" class="btn btn-danger btn-sm"><i class="bi bi-x-lg"></i> حذف</a>
                                </div>
                                <br>
                                <?php
                            }elseif($res['type'] == 'select'){
                                ?>
                                <div class="col-12">
                             
                                <?php echo $res['data']?>
                                <a href="../../index.php?controller=create&amp;method=deleteFild&amp;id=<?php echo $res['id']?>" class="btn btn-danger btn-sm"><i class="bi bi-x-lg"></i> حذف</a>
                                </div>
                                <br>
                                <?php
                               
                            }else{
                                ?>
                                <div class="col-12">
                                <!-- Post name -->
                                <div class="mb-3">
                                    <label class="form-label"><?php echo $res['wiki']?></label>
                                    <input required="" id="con-name" name="name" type="<?php echo $res['type']?>" class="form-control" placeholder="وارد کنید">
                                </div>
                                <a href="../../index.php?controller=create&amp;method=deleteFild&amp;id=<?php echo $res['id']?>" class="btn btn-danger btn-sm"><i class="bi bi-x-lg"></i> حذف</a>
                                </div>
                                <br>
                                <?php
                            }
                            ?>
                            </div>
                        </div>
                        <!-- Chart END -->
                        <br>
                        <?php
                    }
                }
                ?>






		</div>
    </div>
	</div>
</section>