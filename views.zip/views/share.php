<?php
if(isset($_GET['idAccount'])){
    $account = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$_GET['idAccount'].'"'));
    if(! $account){
        die();
    }
    ?>
    <section class="py-4">
            <div class="container">
            <div class="row pb-4">
                    <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2">  </h1>
                    </div>
                </div>


                

                <div class="row g-4">
                    <div class="col-12">
                        <!-- Card START -->
                        <div class="card border">
                            <!-- Card header START -->
                            <div class="card-header border-bottom p-3">
                                <!-- Search and select START -->
                                

                                

                                <h5><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar"> انتخاب از پیامرسان</h5>
                                
                                
                                <!-- Search and select END -->
                            </div>
                            <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                                <!-- Tabs content START -->
                                <div class="tab-content py-0 my-0">
                                    <?php

                                    $query_1212 = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                    $file_hash = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                    $file = mysqli_fetch_assoc($query_1212);
                                    if($file){
                                        ?>
                                            <!-- Tabs content item START -->
                                            <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                                <!-- Table START -->
                                                <div class="table-responsive border-0">
                                                    <table class="table align-middle p-4 mb-0 table-hover">
                                            

                                                        <!-- Table body START -->
                                                        <tbody class="border-top-0">
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2kO-icK_EeRI4hsstqHW1iHAUmDR0Ii1H5a8uptfpFOjs3MlrQxo8CGjMi4jVOgZysnk&usqp=CAU" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idAccount=<?php echo $_GET['idAccount']?>&sendTo=<?php echo $_SESSION['id']?>" class="stretched-link">پیام های ذخیره شده</a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                       
                                                                    </td>
                                                                </tr>

                                                        <?php
                
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                            $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                                            if($userData){
                                                                ?>
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idAccount=<?php echo $_GET['idAccount']?>&sendTo=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                        <div class="d-flex gap-2">
                                                                            <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-box-arrow-up-right"></i>
                                                                            </a>
                                                                            <a href="../../index.php?controller=message&method=share&idAccount=<?php echo $_GET['idAccount']?>&sendTo=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-send"></i>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }else{
            
                                                            }
                                                        }
                                                        
                                                        ?>
                        

                                            


                                                        </tbody>
                                                        <!-- Table body END -->
                                                    </table>
                                                </div>
                                                <!-- Table END -->
                                            </div>
                                            <!-- Tabs content item END -->
                                        <?php
                                    }else{

                                    }
                                    ?>


                

                                </div>
                                <!-- Tabs content END -->
                            </div>
                            <!-- Card body END -->

                        </div>
                        <!-- Card END -->
                    </div>
                    
            
                </div>
            </div>
            </div>
    </section>

    <section class="py-4">
            <div class="container">
            <div class="row pb-4">
         


                

                <div class="row g-4">
                    <div class="col-12">
                        <!-- Card START -->
                        <div class="card border">
                            <!-- Card header START -->
                            <div class="card-header border-bottom p-3">
                                <!-- Search and select START -->
                                <div class="row g-3 align-items-center justify-content-between">
                                <h5><img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar"> انتخاب از مخاطبین</h5>
                                    <!-- Search bar -->
                                    <div class="col-md-8">
                                        <form action="" method="POST" class="rounded position-relative">
                                            <input class="form-control bg-transparent" type="search" name="search" placeholder="جستجو شناسه" aria-label="Search">
                                            <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                        </form>
                                    </div>
                                    <!-- Tab buttons -->
                                    <div class="col-md-3">
                                        <!-- Tabs START -->
                                        <ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
                                            <!-- Grid tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
                                                    <i class="fas fa-fw fa-list-ul"></i>
                                                </a>
                                            </li>
                                            <!-- List tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
                                                    <i class="fas fa-fw fa-th-large"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <!-- Tabs end -->
                                    </div>
                                </div>
                                <!-- Search and select END -->
                            </div>
                            <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                                <!-- Tabs content START -->
                                <div class="tab-content py-0 my-0">
                                    <?php
                                    if(isset($_POST['search'])){
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }else{
                                        $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }

                                    if($file){
                                        ?>
                                            <!-- Tabs content item START -->
                                            <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                                <!-- Table START -->
                                                <div class="table-responsive border-0">
                                                    <table class="table align-middle p-4 mb-0 table-hover">
                                                        <!-- Table head -->
                                                        <thead class="table-dark">
                                                            <tr>
                                                                <th scope="col" class="border-0 rounded-start">نام مخاطب</th>
                                                                <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                            </tr>
                                                        </thead>

                                                        <!-- Table body START -->
                                                        <tbody class="border-top-0">


                                                        <?php
                
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                            $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
                                                            if($userData){
                                                                ?>
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idAccount=<?php echo $_GET['idAccount']?>&sendTo=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                        <div class="d-flex gap-2">
                                                                            <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-box-arrow-up-right"></i>
                                                                            </a>
                                                                            <a href="../../index.php?controller=message&method=share&idAccount=<?php echo $_GET['idAccount']?>&sendTo=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-send"></i>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }else{
            
                                                            }
                                                        }
                                                        
                                                        ?>
                        

                                            


                                                        </tbody>
                                                        <!-- Table body END -->
                                                    </table>
                                                </div>
                                                <!-- Table END -->
                                            </div>
                                            <!-- Tabs content item END -->
                                        <?php
                                    }else{

                                    }
                                    ?>


                

                                </div>
                                <!-- Tabs content END -->
                            </div>
                            <!-- Card body END -->

                        </div>
                        <!-- Card END -->
                    </div>
                    
            
                </div>
            </div>
            </div>
    </section>
    <?php
}elseif(isset($_GET['idPost'])){
    $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$_GET['idPost'].'"'));
    if(! $post){
        die();
    }
    ?>
    <section class="py-4">
            <div class="container">
            <div class="row pb-4">
                    <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2">  </h1>
                    </div>
                </div>


                

                <div class="row g-4">
                    <div class="col-12">
                        <!-- Card START -->
                        <div class="card border">
                            <!-- Card header START -->
                            <div class="card-header border-bottom p-3">
                                <!-- Search and select START -->
                                

                                

                                <h5><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar"> انتخاب از پیامرسان</h5>
                                
                                
                                <!-- Search and select END -->
                            </div>
                            <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                                <!-- Tabs content START -->
                                <div class="tab-content py-0 my-0">
                                    <?php

                                    $query_1212 = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                    $file_hash = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                    $file = mysqli_fetch_assoc($query_1212);
                                    if($file){
                                        ?>
                                            <!-- Tabs content item START -->
                                            <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                                <!-- Table START -->
                                                <div class="table-responsive border-0">
                                                    <table class="table align-middle p-4 mb-0 table-hover">
                                            

                                                        <!-- Table body START -->
                                                        <tbody class="border-top-0">
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2kO-icK_EeRI4hsstqHW1iHAUmDR0Ii1H5a8uptfpFOjs3MlrQxo8CGjMi4jVOgZysnk&usqp=CAU" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idPost=<?php echo $_GET['idPost']?>&sendTo=<?php echo $_SESSION['id']?>" class="stretched-link">پیام های ذخیره شده</a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                       
                                                                    </td>
                                                                </tr>

                                                        <?php
                
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                            $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                                            if($userData){
                                                                ?>
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idPost=<?php echo $_GET['idPost']?>&sendTo=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                        <div class="d-flex gap-2">
                                                                            <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-box-arrow-up-right"></i>
                                                                            </a>
                                                                            <a href="../../index.php?controller=message&method=share&idPost=<?php echo $_GET['idPost']?>&sendTo=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-send"></i>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }else{
            
                                                            }
                                                        }
                                                        
                                                        ?>
                        

                                            


                                                        </tbody>
                                                        <!-- Table body END -->
                                                    </table>
                                                </div>
                                                <!-- Table END -->
                                            </div>
                                            <!-- Tabs content item END -->
                                        <?php
                                    }else{

                                    }
                                    ?>


                

                                </div>
                                <!-- Tabs content END -->
                            </div>
                            <!-- Card body END -->

                        </div>
                        <!-- Card END -->
                    </div>
                    
            
                </div>
            </div>
            </div>
    </section>

    <section class="py-4">
            <div class="container">
            <div class="row pb-4">
         


                

                <div class="row g-4">
                    <div class="col-12">
                        <!-- Card START -->
                        <div class="card border">
                            <!-- Card header START -->
                            <div class="card-header border-bottom p-3">
                                <!-- Search and select START -->
                                <div class="row g-3 align-items-center justify-content-between">
                                <h5><img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-profile-2871145-2384395.png" style="width: 20px;" alt="Avatar"> انتخاب از مخاطبین</h5>
                                    <!-- Search bar -->
                                    <div class="col-md-8">
                                        <form action="" method="POST" class="rounded position-relative">
                                            <input class="form-control bg-transparent" type="search" name="search" placeholder="جستجو شناسه" aria-label="Search">
                                            <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                        </form>
                                    </div>
                                    <!-- Tab buttons -->
                                    <div class="col-md-3">
                                        <!-- Tabs START -->
                                        <ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
                                            <!-- Grid tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
                                                    <i class="fas fa-fw fa-list-ul"></i>
                                                </a>
                                            </li>
                                            <!-- List tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
                                                    <i class="fas fa-fw fa-th-large"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <!-- Tabs end -->
                                    </div>
                                </div>
                                <!-- Search and select END -->
                            </div>
                            <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                                <!-- Tabs content START -->
                                <div class="tab-content py-0 my-0">
                                    <?php
                                    if(isset($_POST['search'])){
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }else{
                                        $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }

                                    if($file){
                                        ?>
                                            <!-- Tabs content item START -->
                                            <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                                <!-- Table START -->
                                                <div class="table-responsive border-0">
                                                    <table class="table align-middle p-4 mb-0 table-hover">
                                                        <!-- Table head -->
                                                        <thead class="table-dark">
                                                            <tr>
                                                                <th scope="col" class="border-0 rounded-start">نام مخاطب</th>
                                                                <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                            </tr>
                                                        </thead>

                                                        <!-- Table body START -->
                                                        <tbody class="border-top-0">


                                                        <?php
                
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                            $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
                                                            if($userData){
                                                                ?>
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="../../index.php?controller=message&method=share&idPost=<?php echo $_GET['idPost']?>&sendTo=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                        <div class="d-flex gap-2">
                                                                            <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-box-arrow-up-right"></i>
                                                                            </a>
                                                                            <a href="../../index.php?controller=message&method=share&idPost=<?php echo $_GET['idPost']?>&sendTo=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-send"></i>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }else{
            
                                                            }
                                                        }
                                                        
                                                        ?>
                        

                                            


                                                        </tbody>
                                                        <!-- Table body END -->
                                                    </table>
                                                </div>
                                                <!-- Table END -->
                                            </div>
                                            <!-- Tabs content item END -->
                                        <?php
                                    }else{

                                    }
                                    ?>


                

                                </div>
                                <!-- Tabs content END -->
                            </div>
                            <!-- Card body END -->

                        </div>
                        <!-- Card END -->
                    </div>
                    
            
                </div>
            </div>
            </div>
    </section>
    <?php
}
?>
