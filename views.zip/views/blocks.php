<?php
$con = mysqli_connect('localhost','root','','mydb') or die('Not Connect');



if(isset($_SESSION['id'])){

    if(isset($_SESSION['Sec-key'])){
        $query = mysqli_query($con, 'select * from user where `Sec-key`="'.$_SESSION['Sec-key'].'"');
        $user = mysqli_fetch_assoc($query);
        if(! $user){
            if(! isset($_SESSION['ACC-KEY'])){
                unset($_SESSION['id']);
                echo "<script type='text/javascript'>window.location.href='index.php'</script>";

            }

            
        }elseif(isset($_SESSION['ACC-KEY'])){
            $query = mysqli_query($con, 'select * from user where `ACC-KEY`="'.$_SESSION['ACC-KEY'].'"');
            $user = mysqli_fetch_assoc($query);
            if(! $user){
                unset($_SESSION['id']);
                unset($_SESSION['Sec-key']);
                unset($_SESSION['ACC-KEY']);
                echo "<script type='text/javascript'>window.location.href='index.php'</script>";
    
                
            }
        }

        if(isset($_SESSION['path'])){
            echo "<script type='text/javascript'>window.location.href='".$_SESSION['path']."'</script>";
            unset($_SESSION['path']);
        }
    
    }else{
        unset($_SESSION['id']);
    }

}elseif(isset($_COOKIE['Sec-key'])){
    $query = mysqli_query($con, 'select * from user where `Sec-key`="'.$_COOKIE['Sec-key'].'"');
    $user = mysqli_fetch_assoc($query);
    if($user){
        
        $_SESSION['id'] = $user['iduser'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['Sec-key'] = $user['Sec-key'];
        setcookie("Sec-key", $user['Sec-key'], time()+2592000, "https://www.piperline.ir");

        

        mysqli_query($con, "
        UPDATE `user` SET `lastSeen`='".date('Y-m-d H:i')."' WHERE iduser = ".$user['iduser']."
        ");
    }
}else{
    if(! isset($_SESSION['path'])){
        $fullurl = 'https://'.$_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI].'';
        $_SESSION['path'] = $fullurl;
    }

}
if(isset($_SESSION['id'])){

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $test_array = $_POST;


        foreach( $test_array as $name => $data ){
            $data_math_rec = explode(" ", $data);

            if(in_array("<?php", $data_math_rec) == "true"){
                include('views/script_XSS.php');
                mysqli_query($con, "
                UPDATE user
                SET
                  `enabled` = 2
                WHERE
                  iduser = ".$_SESSION['id'].";
                ");
                die();
            }
            elseif(in_array("<?", $data_math_rec) == "true"){
                mysqli_query($con, "
                UPDATE user
                SET
                  `enabled` = 2
                WHERE
                  iduser = ".$_SESSION['id'].";
                ");
                include('views/script_XSS.php');
                die();
            }
            elseif(in_array("<script>", $data_math_rec) == "true"){
                mysqli_query($con, "
                UPDATE user
                SET
                  `enabled` = 2
                WHERE
                  iduser = ".$_SESSION['id'].";
                ");
                include('views/script_XSS.php');
                die();
            }
            
        }
        
        //$math = count($test_array);
        //echo $math;

        
    }

    $query = mysqli_query($con, 'select * from user where iduser="'.$_SESSION['id'].'"');
    $user = mysqli_fetch_assoc($query);
    if($user){
        if($user['enabled'] == '2'){
            header('location: http://'.$_SERVER[HTTP_HOST].'/piperline/views/blockedUser.php');

            include('core/rtl/views/blockedUser.php');
            die();
        }



     
    }else{
        die();
    }
}else{

}
?>