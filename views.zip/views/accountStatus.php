            
<section class="py-4">
	<div class="container"> 
        <div class="row g-4">       
            
            
            <div class="list-group" style="text-align: left;">
              
              <a href="https://www.qitsource.ir" class="list-group-item list-group-item-action">

                <style>
                #redsquare {
                    
                   
                    position: absolute;
                    left: 50%;
                    top: 50%;
                    transform: translate(-50%, -50%);
                }
                </style>
                <ul class="avatar-group" id="redsquare">
                    <li class="avatar">
                        <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                    </li>
                    <li class="avatar">
                        <img class="avatar-img rounded-circle" src="https://up.20script.ir/file/bd66-Screenshot-26-.png" alt="avatar">
                    </li>
              
                    <li class="avatar">
                        <div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
                    </li>
                </ul>
                

              </a>
              <a href="dashboard.php?content=verifiACC" class="list-group-item list-group-item-action"> Privacy policy <i class="bi bi-incognito" style="font-size: 22px;"></i></a>
              <button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.qitsource.ir">qitSource,LLC</a></button>
            </div>









            <?php
            if($user['enabled'] == 2){
                ?>
                <h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-exclamation-triangle" viewBox="0 0 16 16">
                <path d="M7.938 2.016A.13.13 0 0 1 8.002 2a.13.13 0 0 1 .063.016.146.146 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.163.163 0 0 1-.054.06.116.116 0 0 1-.066.017H1.146a.115.115 0 0 1-.066-.017.163.163 0 0 1-.054-.06.176.176 0 0 1 .002-.183L7.884 2.073a.147.147 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566z"/>
                <path d="M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995z"/>
                </svg>  محدودیت های حساب شما</font></font></h1>

                <div class="list-group">
              
                
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> محدودیت انجمن به دلیل راعایت نکردن دستور العمل های انجمن</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> محدودیت در انتشار عرضه های بیشتر</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> اعلام محدودیت در پروفایل کاربری شما</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> محدودیت های ایالاتی</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> محدودیت ورود به حساب با برنامه های شخص ثالث</a>
                    <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-info-circle"></i> احتمال تبدیل محدودیت به محدودیت داعمی</a>
                    <button type="button" class="list-group-item list-group-item-action">Powerd by <a href="https://www.qitsource.ir">qitSource,LLC</a></button>
                </div>


                <h4 class="mb-2 mb-sm-0 h4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/>
                <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/>
                </svg> درخواست وارسی</font></font></h4>
                <small>درخواست وارسی حساب به تعداد محدودی از طرف صاحبان حساب ها میتواند ارسال شود لازم به ذکر است که اگر در شرایط وارسی انجمن ما تشخیص دهد که هنوز هم  مالک حساب از عمد به دستورالعمل های انجمن پایبند نیست حساب بنا به تشخیص به طور یکساله و یا داعمی مسدود خواهد شد و طبق دستور العمل موجودی ولت و یا درآمد مالک حساب در صورت مسدود شدن داعمی به عنوان قرامت به پیپرلاین تعلق میگیرد</small>

                <?php
                if($user['status'] == 2){
                    ?>
                    <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">درخواست وارسی ارسال شد</h4>
                    <p>در این مدت ما تمامی منابع شما را از داخل و یا حتی خارج از پلتفرم وارسی خواهیم کرد اگر از دستورالعمل ها پیروی میکردید حساب شما آزاد سازی میشود در غیر اینصورت بنا به تشخیص انجمن یک فرصت دیگر به شما داده خواهد شد و یا حساب به صورت یکساله و یا داعمی مسدود خواهد شد</p>
                    <hr>
                    <p class="mb-0">متشکریم از همراهی شما تیم روابط عمومی کوییت سورس</p>
                    </div>
                    <?php
                }else{
                    ?>
                    <div class="alert alert-primary" role="alert">
                    <h4 class="alert-heading">درخواست وارسی</h4>
                    <p>در این مدت ما تمامی منابع شما را از داخل و یا حتی خارج از پلتفرم وارسی خواهیم کرد اگر از دستورالعمل ها پیروی میکردید حساب شما آزاد سازی میشود در غیر اینصورت بنا به تشخیص انجمن یک فرصت دیگر به شما داده خواهد شد و یا حساب به صورت یکساله و یا داعمی مسدود خواهد شد</p>
                    <hr>
                    <p class="mb-0">متشکریم از همراهی شما تیم روابط عمومی کوییت سورس</p>
                    <br>
                    <div id="displaySendRefReq"></div>

                    <a href="../../core/rtl/dashboard.php?content=wallet" class="btn btn-outline-dark btn-sm" id="sendRefReq">


                    ارسال درخواست وارسی

                    </a>

                                            <script>
                                            $('#sendRefReq').click(function(event){
                                            event.preventDefault();
                                            $('#sendRefReq').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=refReq",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sendRefReq').html('ارسال درخواست وارسی');
                                                $('#displaySendRefReq').html(data);
                                                })

                                            })
                                            </script>
                    </div>
                    <?php
                }
                
                ?>
                <?php
            }else{
                ?>
                <section class="overflow-hidden">
                    <div class="container">
                        <div class="row">
                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                        <!-- SVG shape START -->
                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                            <g>
                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                            </g>
                        </svg>
                        </figure>
                        <!-- SVG shape START -->
                        <!-- Content -->
                        <h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <img src="https://up.20script.ir/file/bd66-Screenshot-26-.png" style="width: 30px;" alt="avatar"></font></font></h1>
                        <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">محدودتی ندارید</font></font></h2>
                        <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب شما هیچ گونه محدودتی از نظر انجمن ما ندارد و میتوانید از تمامی قابلیت ها و سرویس ها استفاده کنید و کماکان بیشتر از قبل از ما کمک بگیرید</font></font></p>
                    </div>
                    </div>
                    </div>
                </section>

                <?php
            }
            
            ?>

        </div>
    </div>
</section>
