
<?PHP 
if(isset($_GET['alert'])){
	?>
	<div class="alert alert-danger" role="alert">
		<i class="bi bi-exclamation-circle"></i>	<?php echo $_GET['alert']?>
	</div>
	<?php
}

?>
<div class="row g-4">
					
					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
                                    <i class="bi bi-award"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $user['clubPiper']?></h3>
									<h6 class="mb-0">امتیازات پیپرکلاب شما</h6>
								</div>
							</div>
						</div>
					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="dashboard.php?content=wallet">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-primary bg-opacity-10 rounded-3 text-primary">
                                    <i class="bi bi-currency-dollar"></i>								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo number_format($user['charge'] , 0 , "." , "," )?> تومان</h3>
									<h6 class="mb-0">موجودی</h6>
								</div>
							</div>
						</div>
						</a>
					</div>

					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<div class="card card-body border p-3">
                            <a href="dashboard.php?content=clubNum">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
									<i class="bi bi-suit-heart-fill"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $user['numClub']?></h3>
									<h6 class="mb-0">جوایز شما</h6>
								</div>
							</div>
                            </a>
						</div>
					</div>

                    					<!-- Counter item -->
					<div class="col-sm-6 col-lg-3">
						<a href="dashboard.php?content=account">
						<div class="card card-body border p-3">
							<div class="d-flex align-items-center">
								<!-- Icon -->
								<div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
									<i class="bi bi-people-fill"></i>
								</div>
								<!-- Content -->
								<div class="ms-3">
									<h3><?php echo $user['username']?>_<?php echo $user['iduser']?></h3>
									<h6 class="mb-0">شناسه مشترک</h6>
								</div>
							</div>
						</div>
						</a>
					</div>



                    	
		

</div>


<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> بسته های تخفیفی کلاب </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">105</font></font></span></h5>
							<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">با ماموریت امتیاز بگیر</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">
                    <style>
              .scroll-example {
                overflow: auto;
                scrollbar-width: none; /* Firefox */
                -ms-overflow-style: none; /* IE 10+ */
              }

              .scroll-example::-webkit-scrollbar {
                width: 0px;
                background: transparent; /* Chrome/Safari/Webkit */
              }
              </style>
                    <div class="card-body p-0">
                        <ul style="height: 400px;" class="list-group list-unstyled list-group-flush scroll-example">
                                                
                        <div class="col-12">
                            
                        <?php
                        $query_1212 = mysqli_query($con, 'select * from posts where statusOFF="1" and published=1 order by date Desc');
                        $file_hash = mysqli_query($con, 'select * from posts where statusOFF="1" and published=1 order by date Desc');
                        $file = mysqli_fetch_assoc($query_1212);
                        if($file){
                            while($res=mysqli_fetch_assoc($file_hash)){
                                $user_hash = mysqli_query($con, 'select * from user where iduser="'.$res['idUser'].'"');
                                $user_db = mysqli_fetch_assoc($user_hash);
                                if(! $user_db){
                                    die();
                                }
                        ?>
                            <!-- Card item START -->
                            <div class="card border rounded-3 up-hover p-4 mb-4">
                                <div class="row g-3">
                                    <div class="col-lg-5">
                                        <!-- Categories -->
                                        <a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>OFF-<?php echo $res['clubOFF']?>%</a>
                                        <a href="#" class="badge bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><?php echo $res['priceOFF']?>امتیاز مورد نیاز</a>
                                        <!-- Title -->
                                        <h2 class="card-title">
                                            <a href="index.php?content=open&id=<?php echo $res['idPost']?>" class="btn-link text-reset"><?php echo $res['title']?></a>
                                        </h2>
                                        <!-- Author info -->
                                        <div class="d-flex align-items-center position-relative mt-3">
                                            <div class="avatar me-2">
                                                <img class="avatar-img rounded-circle" src="<?php echo $user_db['avatar']?>" alt="avatar">
                                            </div>
                                            <div>
                                                <h5 class="mb-1"><a href="#" class="stretched-link text-reset btn-link"><?php echo $user_db['username']?></a>  <?php
                                                                        if($user_db['admin'] == 1){
                                                                            ?>
                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                            <?php
                                                                        }
                                                                        ?></h5>
                                                <ul class="nav align-items-center small">
                                                    <li class="nav-item me-3"><?php echo $res['category']?></li>
                                                    <li class="nav-item"><i class="far fa-clock me-1"></i><?php echo $res['tag']?></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Detail -->
                                    <div class="col-md-6 col-lg-4">
                                        <p><?php echo $res['doc']?></p>
                                    </div>

                                    <!-- Image -->
                                    <div class="col-md-6 col-lg-3">
                                        <img class="rounded-3" src="<?php echo $res['art']?>" alt="Card image">
                                    </div>

                                </div>
                                <a href="../../index.php?controller=create&method=clubOver&id=<?php echo $res['idPost']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> دریافت کد تحفیف</a>

                            </div>
                            <!-- Card item END -->

                        <?php
                            }
                        }
                        ?>


                            <!-- Load more -->
                            <button type="button" class="btn btn-primary-soft w-100">Load more post <i class="bi bi-arrow-down-circle ms-2 align-middle"></i></button>

                        </div>



                        </ul>
                    </div>
                    <!-- Button -->

		
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>