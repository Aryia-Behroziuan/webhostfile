<section class="py-4">
  <div class="container">
    <div class="row pb-4">
          <nav aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots">
							<li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> خانه</a></li>
							<li class="breadcrumb-item active"> دستورالعمل ها و مستندات جامعه توسعه دهندگان</li>
						</ol>
					</nav>

          <div class="accordion" id="accordionExample">

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                <i class="bi bi-question-lg"></i> مستندات جامعه توسعه دهندگان چیست و به چه کار می آید
                </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">

                    ما بر روی سکوی خود برای جامعه توسعه دهندگان اتحادی را درست کردیم که به ما کمک و توسعه دهندکان کمک میکند بهتر از سرویس ما استفاده کنند ما برای توسعه دهندگان بر روی سکوی خود وب سرویس هایی ایجاد میکنیم که با استفاده از آن مشتریان میتوانند وبسایت شخصی خود و یا برنامه های درحال توسعه خود را به هسته سرویس ما متصل کرده و داده هایی دریافت کنند که به آنها کمک میکند از جمله امکان خرید هوشمند و ارسال اطلاعات خرید به وبسایت کاربران و خرید هوشمندانه و سیستمیک برای سرویس ها و یا خدماتی که نیاز به هندل کردن سیستمی دارند میتوان داده ها را به هنگام خرید مشتریان از ما دریافت کنند و به برسی سیستمی خود بدهند
                    <br>
                    <strong>برای هر مشتری وب سرویس های مجزاعی تعریف شده که با استفاده از گزینه داشبورد پست میتوانید گزینه وب سرویس را برای آن سرویس خاصت فعال کنید</strong>
                    <br>
                    <strong><a href="dashboard.php?content=listPost">پست های شما</a></strong>  
                    ,
                    <strong><a href="#">شرایط و قوانین انجمن ما</a></strong>  

                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="bi bi-question-lg"></i>  ای سرویس برای چه اشخاصی است و مخاطب آن کیست
                </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    مخاطب هدف این سرویس افراد و توسعه دهندگانی هستند که خود وبسایت داشته و یا توانایی پردازش داده های دریافتی را بر بستر آنلاین دارا هستند و میخواهد اطلاعات هر خرید مخزن هایشان را در وبسایت شخصی خود تحویل بگیرند و پردازش کنند با این کار سرویس ما به سایت شخص ثالث با مجوز های لازم متصل شده و با یکدیگر داده تبادل میکنند و عرضه محصولات و یا خرید کاربران در سایت مقصد هم فعال شده

                    <strong><a href="#">شرایط و قوانین انجمن ما</a></strong>  
                </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i>    داده ها سرتاسر رمزگذاری شده
                </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    ما روی امنیت پلتفرم خودمان به شدت حساسیم و دادگان را سرتاسر سرویس های خود رمزگذاری میکنیم با روش های نوین رمزگذاری و به خوبی از داده هایتان محافظت خواهیم کرد میتوانید به ما اعتماد کنید تا بتوانیم شروع به یک دوستی و رشد جمعی کنیم دادگان شما تک تک مسیر هایی که طی میکند ما آن را در اختیار  شما میگذاریم و هر زمان بخواهید آن را در هر مرحله ای به شکل کامل غیر قابل بازیابی خواهیم کرد
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree1" aria-expanded="true" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i>    هزینه این کار چقدر است برای چه شامل هزینه میشود
                </button>
                </h2>
                <div id="collapseThree1" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                   این سرویس به مقصود صحت سنجی درخواست کاربر مبلغ کمی هزینه نیار دارد که ما برای فعال کردن این سرویس روی هر خدماتی از کاربر دریافت میکنیم

                    <br>
                    <br>
                    مبلغ مصوب انجمن ما برای این کار <a href="#">30,000</a> تومان میباشد که به صورت پس پرداخت از شما کسر خواهد شد
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree2" aria-expanded="false" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i>   مراحل این کار چگونه است و چطور بایدآن را فعال کرد
                </button>
                </h2>
                <div id="collapseThree2" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                شما ابتدا به بخش پست های خود میروید و پست مورد نظر که در نظر دارید این سرویس را برای آن فعال کنید را انتخاب کرده و به بخش داشبرد پست میروید و سپس در داشبورد گزینه وب سرویس را انتخاب میکنید و به همین صفحه برمیگردد و فرمی در اختیارتان قرار میگیرد که میتوانید اطلاعات خواسته شده را وارد کنید و سپس هزینه این سرویس را پرداخت میکنید و سرویس برای مخزن مورد نظرتان فعال میگردد                  
                </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree3" aria-expanded="false" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i>   چه قوانینی را باید رعایت کنم
                </button>
                </h2>
                <div id="collapseThree3" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    به طور کل با این فعالیت شما متعهد میشود که از قوانین اینترنتی ایالاتی که در آن زندگی میکنید به شکل تام تبعیت کنید و علاوه بر آن دستور العمل های انجمن ما را هم جدی بگیرید                   
                <br>
                <br>
                
                <?php
                if($user['iran'] == 1){
                    $loc = 'ایران';
                }else{
                    $loc = $user['iran'];
                }
                ?>
                <?php
                if(isset($_SESSION['id'])){
                  ?>
                  موقعیت و ایالات شما<strong><?php echo $loc.','.$user['loc']?></strong> تعریف شده است

                  <?php
                }
                ?>
                </div>
              </div>

              <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree4" aria-expanded="false" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i>  API-KEY چیست 
                </button>
                </h2>
                <div id="collapseThree4" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                یک شناسه امنیتی است که مخصوص حساب شماست و منحصر به فرد است شما هر بار که میخواهید درخواستی به سمت ما ارسال کنید برای اعتبار سنجی اینکه آیا این شخص خودتان هستید آن را باید بریا ما ارسال کنید
                <br>
                <br>
                <strong>ایا میتوانم آن را ویرایش گنم</strong><br>
                <small>بله اما در سرویس پیپرلاین این امکان ندارد شما با مراجعه به سایت خدمات دهنده سرویس شناسه امنیتی که سرویس اسپیسیفای است و توسط شرکت ما ساخته شده است مراجعه کنید و اقدام به تازه سازی شناسه خود کنید در صورتی که حس میکنید آن در دسترس کسی قرار گرفته</small>
                <strong><a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=remot">تازه سازی شناسه امنیتی</a></strong>
                </div>
                </div>
              </div>

              
              <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree5" aria-expanded="false" aria-controls="collapseThree">
                <i class="bi bi-question-lg"></i> URL-API چیست 
                </button>
                </h2>
                <div id="collapseThree5" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                یک شناسه امنیتی است که مخصوص حساب شماست و منحصر به فرد است شما هر بار که میخواهید درخواستی به سمت ما ارسال کنید برای اعتبار سنجی اینکه آیا این شخص خودتان هستید آن را باید بریا ما ارسال کنید
                <br>
                <br>
                <strong>ایا میتوانم آن را ویرایش گنم</strong><br>
                <small>بله اما در سرویس پیپرلاین این امکان ندارد شما با مراجعه به سایت خدمات دهنده سرویس شناسه امنیتی که سرویس اسپیسیفای است و توسط شرکت ما ساخته شده است مراجعه کنید و اقدام به تازه سازی شناسه خود کنید در صورتی که حس میکنید آن در دسترس کسی قرار گرفته</small>
                <strong><a href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=remot">تازه سازی شناسه امنیتی</a></strong>
                </div>
                </div>
              </div>
            </div>
          </div>


          <br>
          


          <div class="card border bg-transparent rounded-3">
            <!-- Card header START -->
            <div class="card-header bg-transparent border-bottom p-3">
              <div class="d-sm-flex justify-content-sm-between align-items-center">
                <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مستندات</font></font></h5>
                
              </div>
            </div>
            <!-- Card header END -->
            <!-- Card body START -->
            <div class="card-body p-3">
                      <style>
                .scroll-example {
                  overflow: auto;
                  scrollbar-width: none; /* Firefox */
                  -ms-overflow-style: none; /* IE 10+ */
                }

                .scroll-example::-webkit-scrollbar {
                  width: 0px;
                  background: transparent; /* Chrome/Safari/Webkit */
                }
                </style>
                <div class="card-body p-0">
                <h1 class="bd-title mb-0" id="content">وبسرویس خرید</h1>
                <small>این اطلاعاتی که در زیرا است دقیقا با همین نام ها به هنگام خرید از مخزن شما برای شما ارسال میگردد به ادرسی که شما برای ما ارسال میکنید میتوانید آنها را دریافت کنید</small>
                <br>
                <br>


                <div class="table-responsive"><table class="table table-utilities">
                <thead>
                <tr>
                <th>Option</th>
                <th>Type</th>
                <th>Default&nbsp;value</th>
                <th>Description</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td><a href="#property"><code>property</code></a></td>
                <td><strong>Required</strong></td>
                <td>–</td>
                <td>Name of the property, this can be a string or an array of strings (e.g., horizontal paddings or margins).</td>
                </tr>
                <tr>
                <td><a href="#values"><code>values</code></a></td>
                <td><strong>Required</strong></td>
                <td>–</td>
                <td>List of values, or a map if you don’t want the class name to be the same as the value. If <code>null</code> is used as map key, <code>class</code> is not prepended to the class name.</td>
                </tr>
                <tr>
                <td><a href="#class"><code>class</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Name of the generated class. If not provided and <code>property</code> is an array of strings, <code>class</code> will default to the first element of the <code>property</code> array. If not provided and <code>property</code> is a string, the <code>values</code> keys are used for the <code>class</code> names.</td>
                </tr>
                <tr>
                <td><a href="#css-variable-utilities"><code>css-var</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean to generate CSS variables instead of CSS rules.</td>
                </tr>
                <tr>
                <td><a href="#css-variable-utilities"><code>css-variable-name</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Custom un-prefixed name for the CSS variable inside the ruleset.</td>
                </tr>
                <tr>
                <td><a href="#local-css-variables"><code>local-vars</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Map of local CSS variables to generate in addition to the CSS rules.</td>
                </tr>
                <tr>
                <td><a href="#states"><code>state</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>List of pseudo-class variants (e.g., <code>:hover</code> or <code>:focus</code>) to generate.</td>
                </tr>
                <tr>
                <td><a href="#responsive"><code>responsive</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean indicating if responsive classes should be generated.</td>
                </tr>
                <tr>
                <td><code>rfs</code></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean to enable <a href="/docs/5.3/getting-started/rfs/">fluid rescaling with RFS</a>.</td>
                </tr>
                <tr>
                <td><a href="#print"><code>print</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean indicating if print classes need to be generated.</td>
                </tr>
                <tr>
                <td><code>rtl</code></td>
                <td>Optional</td>
                <td><code>true</code></td>
                <td>Boolean indicating if utility should be kept in RTL.</td>
                </tr>
                </tbody>
                </table></div>


                <hr>

                <h1 class="bd-title mb-0" id="content">وبسرویس کنسل سفارش</h1>
                <small>در این وب سرویس اگر بعد از خرید به هر دلیل داده اشتباه بود یا خواستید سفارش را کنسل کنید و مبلغ پرداختی کاربر را بازگردانید میتوانید با استفاده از لینک داده شده به آن درخواستی بزنید و داده های خواسته شده زیر را تحت همین نام ها ارسال کنید </small>
                <br>
                <br>


                <div class="table-responsive"><table class="table table-utilities">
                <thead>
                <tr>
                <th>Option</th>
                <th>Type</th>
                <th>Default&nbsp;value</th>
                <th>Description</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td><a href="#property"><code>property</code></a></td>
                <td><strong>Required</strong></td>
                <td>–</td>
                <td>Name of the property, this can be a string or an array of strings (e.g., horizontal paddings or margins).</td>
                </tr>
                <tr>
                <td><a href="#values"><code>values</code></a></td>
                <td><strong>Required</strong></td>
                <td>–</td>
                <td>List of values, or a map if you don’t want the class name to be the same as the value. If <code>null</code> is used as map key, <code>class</code> is not prepended to the class name.</td>
                </tr>
                <tr>
                <td><a href="#class"><code>class</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Name of the generated class. If not provided and <code>property</code> is an array of strings, <code>class</code> will default to the first element of the <code>property</code> array. If not provided and <code>property</code> is a string, the <code>values</code> keys are used for the <code>class</code> names.</td>
                </tr>
                <tr>
                <td><a href="#css-variable-utilities"><code>css-var</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean to generate CSS variables instead of CSS rules.</td>
                </tr>
                <tr>
                <td><a href="#css-variable-utilities"><code>css-variable-name</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Custom un-prefixed name for the CSS variable inside the ruleset.</td>
                </tr>
                <tr>
                <td><a href="#local-css-variables"><code>local-vars</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>Map of local CSS variables to generate in addition to the CSS rules.</td>
                </tr>
                <tr>
                <td><a href="#states"><code>state</code></a></td>
                <td>Optional</td>
                <td>null</td>
                <td>List of pseudo-class variants (e.g., <code>:hover</code> or <code>:focus</code>) to generate.</td>
                </tr>
                <tr>
                <td><a href="#responsive"><code>responsive</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean indicating if responsive classes should be generated.</td>
                </tr>
                <tr>
                <td><code>rfs</code></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean to enable <a href="/docs/5.3/getting-started/rfs/">fluid rescaling with RFS</a>.</td>
                </tr>
                <tr>
                <td><a href="#print"><code>print</code></a></td>
                <td>Optional</td>
                <td><code>false</code></td>
                <td>Boolean indicating if print classes need to be generated.</td>
                </tr>
                <tr>
                <td><code>rtl</code></td>
                <td>Optional</td>
                <td><code>true</code></td>
                <td>Boolean indicating if utility should be kept in RTL.</td>
                </tr>
                </tbody>
                </table></div>



                </div>
                <!-- Button -->

              <!-- Pagination START -->
              
              <!-- Pagination END -->
            </div>
          </div>


          <br>

          
          <?php
          if(isset($_GET['id'])){
            $query1 = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" and idUser="'.$_SESSION['id'].'"');
            $post = mysqli_fetch_assoc($query1);
            if($post){
              if(strlen($post['API-URL']) >=5){
                ?>
                <div class="card border bg-transparent rounded-3">
                  <!-- Card header START -->
                  <div class="card-header bg-transparent border-bottom p-3">
                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                      <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فعال</font></font></span> وب سرویس</font><br><small><?php echo $post['title']?></small></font>&nbsp PL<?php echo $post['idPost']?></h5>
                      
                    </div>
                  </div>
                  <!-- Card header END -->
                  <!-- Card body START -->
                  <div class="card-body p-3">



                  <div class="form-group">
                  <h4><a id="reflesh" class="btn btn-xs btn-outline-indigo" href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=remot" target="_blank">
                    <img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">
                  </a> API-KEY</h4>
                    <textarea id="displayAPIKEY" style="height: 150px;" class="form-control" placeholder="Disabled textarea" disabled=""><?php echo $user['API_KEY']?></textarea>
                    <small>اگر قصد ویرایش شناسه امنیتی خود را دارید ابتدا مطمعن شوید که با همین حساب روی سرویس <strong><a href="https://www.spacify.ir" target="_blank">spacify</a></strong> لاگین هستید</small>
                  </div>
                  <br>

                  <form action="" method="POST" id="URLAPIGET">
                    <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">URL-API</font></font></label>
                            <input required="" id="con-name" name="url" type="text" class="form-control" value="<?php echo $post['API-URL']?>" placeholder="لینک را وارد کنید">
                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لینک ارسال داده ها را بدهید تا داده های شما را به آن لینک منتقل کنیم</font></font></small>
                        </div>
                      </div>
                      <div id='display12'>

                   

                      </div>
                      <button class="btn btn-dark-soft" type="submit" id="subGET">به روزرسانی</button>

                  </form>
                  <script>
                            $(document).ready(function(){
                                $("#URLAPIGET").on("submit", function(event){
                                    event.preventDefault();
                                    $('#subGET').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    var formValues= $('#URLAPIGET').serialize();

                                    $.post("../../index.php?controller=create&method=addAPI&id=<?php echo $post['idPost']?>", formValues, function(data){
                                        // Display the returned data in browser
                                        $('#display12').html(data);
                                        $('#subGET').html('به روزرسانی');
                                    });
                                });
                            });
                  </script>

                  </div>



                </div>
                <?php
              }else{
                ?>
                <div class="card border bg-transparent rounded-3">
                  <!-- Card header START -->
                  <div class="card-header bg-transparent border-bottom p-3">
                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                      <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وب سرویس</font><br><small><?php echo $post['title']?></small></font>&nbsp PL<?php echo $post['idPost']?></h5>
                      
                    </div>
                  </div>
                  <!-- Card header END -->
                  <!-- Card body START -->
                  <div class="card-body p-3">



                  <div class="form-group">
                  <h4><a id="reflesh" class="btn btn-xs btn-outline-indigo" href="https://www.spacify.ir/index.php?controller=admin/desk&method=setting&page=remot" target="_blank">
                    <img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">
                  </a> API-KEY</h4>
                    <textarea id="displayAPIKEY" style="height: 150px;" class="form-control" placeholder="Disabled textarea" disabled=""><?php echo $user['API_KEY']?></textarea>
                    <small>اگر قصد ویرایش شناسه امنیتی خود را دارید ابتدا مطمعن شوید که با همین حساب روی سرویس <strong><a href="https://www.spacify.ir" target="_blank">spacify</a></strong> لاگین هستید</small>
                  </div>
                  <br>

                  <form action="" method="POST" id="URLAPIGET">
                    <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">URL-API</font></font></label>
                            <input required="" id="con-name" name="url" type="text" class="form-control" placeholder="لینک را وارد کنید">
                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لینک ارسال داده ها را بدهید تا داده های شما را به آن لینک منتقل کنیم</font></font></small>
                        </div>
                      </div>
                      <div id='display12'>

                      <div class="alert alert-dark" role="alert">
                       هزینه فعالسازی این سرویس موصب انجمن ما 30,000 تومان است اگر شرایط را میپذیرید ادامه دهید
                      </div>

                      </div>
                      <button class="btn btn-dark-soft" type="submit" id="subGET">ادامه و پرداخت</button>

                  </form>
                  <script>
                            $(document).ready(function(){
                                $("#URLAPIGET").on("submit", function(event){
                                    event.preventDefault();
                                    $('#subGET').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    var formValues= $('#URLAPIGET').serialize();

                                    $.post("../../index.php?controller=create&method=addAPI&id=<?php echo $post['idPost']?>", formValues, function(data){
                                        // Display the returned data in browser
                                        $('#display12').html(data);
                                        $('#subGET').html('ادامه و پرداخت');
                                    });
                                });
                            });
                  </script>

                  </div>



                </div>
                <?php
              }
            }
          }
          
          ?>




    </div>
  </div>
<session>