<?php

if(! isset($_GET['id'])){
    die();
}
$query = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query);
if($post){

}else{
    die();
}
?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/add-file-5568733-4644450.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video> ایجاد فایل</h1>
			</div>
		</div>

        <div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
                   													<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>
                
                    </div>
				</div>
			</div>
		</div>

        <br>

		<div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
            <!-- Form START -->
            <form action="../../index.php?controller=create&method=createFile" method="POST">
              <!-- Main form -->
              <div class="row">
                <div class="col-12">
                  <!-- Post name -->
                  <div class="mb-3">
                    <label class="form-label">نام فایل</label>
                    <input required="" id="con-name" name="title" type="text" class="form-control" placeholder="فایل را وارد کنید">
                    <small>نام فایل حتما باید با نام فایل اصلی که کاربر دانلود میکند برابر باشد حتی پسوند فایل</small>
                  </div>
                </div>
                <!-- Post type START -->
                <input type="text" style="display: none;" name="postID" value="<?php echo $_GET['id']?>">

              <!-- Post type END -->
              
              <!-- Short description -->
              <div class="col-12">
                <div class="mb-3">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" rows="3" name="doc" placeholder="کمی مختصر در باره فایل توضیح دهید"></textarea>
                </div>
              </div>

                <!-- Post name -->
                <div class="mb-3">
                    <label class="form-label">لینک دانلود فایل</label>
                    <input required="" id="con-name" name="link" type="text" class="form-control" placeholder="لینک را وارد کنید">
                    <small>فایل خود را در گوگل درایور یا جایی دیگر اپلود کرده و لینک ان را وارد کنید</small>
                    <br>
                    <br>
                    
                    
                    <button id="onlineShow" type="button" class="btn btn-outline-dark btn-sm"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/document-6356603-5231807.png" style="width: 30px;" alt=""> مشاهده انلاین </button>
                    <button id="passShow" type="button" class="btn btn-outline-dark btn-sm"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/lock-5590702-4652394.png" style="width: 30px;" alt="">کلید پسورد</button>
                    <button id="closePanel" style="display: none;" type="button" class="btn btn-danger">x بستن</button>
                
                </div>

              <!-- Main toolbar -->



                <!-- Post name -->
                <div id="onlineLink" style="display: none;" class="mb-3">
                    <label class="form-label">لینک مشاهده انلاین</label>
                    <input id="con-name" name="linkOnline" type="text" class="form-control" placeholder="لینک را وارد کنید">
                    <small>اگر فایل شما قابلیت مشاهده انلاین و بدون دانلود را دارد در این قسمت میتوانید ان را وارد کنید</small>
                </div>

                <!-- Post name -->
                <div id="passCode" style="display: none;" class="mb-3">
                    <label class="form-label">پسورد:</label>
                    <input id="con-name" name="pass" type="text" value="0" class="form-control" placeholder="لینک را وارد کنید">
                    <small>پسورد فایل را وارد کنید تا از این پس هنگام دانلود یا اجرای فایل پسورد مور نیاز باشد</small>
                </div>


                
                <script>
                $(document).ready(function(){
                    $("#passShow").on("click", function(event){
                        event.preventDefault();

                        document.getElementById('passCode').style.display = "flex";                    
                        document.getElementById('closePanel').style.display = "flex";                    
                    });
                });
                </script>
                
                
                                
                <script>
                $(document).ready(function(){
                    $("#onlineShow").on("click", function(event){
                        event.preventDefault();

                        document.getElementById('onlineLink').style.display = "flex"; 
                        document.getElementById('closePanel').style.display = "flex";      
              
                   
                    });
                });
                </script>

                <script>
                $(document).ready(function(){
                    $("#closePanel").on("click", function(event){
                        event.preventDefault();

                        document.getElementById('onlineLink').style.display = "none"; 
                        document.getElementById('passCode').style.display = "none";  
                        document.getElementById('closePanel').style.display = "none";                    
                  
                   
                    });
                });
                </script>


                <!-- Post name -->
                <div class="mb-3">
                    <label class="form-label">فرمت فایل</label>
                    <select name="type" class="form-select" aria-label="Default select example">
                        <option selected value="file">فرمت را انتخاب کنید</option>
                        <option value="folder">پوشه</option>
                        <option value="file">فایل</option>
                        <option value="zip">زیپ</option>
                        <option value="img">تصویر</option>
                        <option value="audio">صوتی</option>
                        <option value="video">ویدیو</option>
                        <option value="exe">اجرایی</option>
                        <option value="file">گیت هاب</option>
                        <option value="file">فایل متنی</option>
                    </select>             

                </div>




                <div class="col-12">
                  <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" value="" id="postCheck">
                    <label class="form-check-label" for="postCheck">
                      Make this post featured?
                    </label>
                  </div>
                </div>
                <!-- Create post button -->
                <div class="col-md-12 text-start">
                    <a class="btn btn-outline-danger" href="../../blogzine.webestica.com/rtl/dashboard.php?content=createPost&id=<?php echo $_GET['id']?>">بازگشت</a>
                    <button class="btn btn-primary" type="submit">ایجاد فایل</button>
                </div>
              </div>
            </form>
            <!-- Form END -->
					</div>
				</div>
				<!-- Chart END -->
		</div>
    </div>
	</div>
</section>