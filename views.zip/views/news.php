<section class="py-0 py-md-5 overflow-hidden position-relative" style="background-image: url(assets/images/bg.png); background-position: center center; background-repeat: no-repeat;">
	<div class="container">
		<div class="row">
      <!-- Hero title -->
			<div class="col-lg-6 mx-auto text-center pt-5 position-relative">
        <h1 class="fw-bolder display-2">اخبار زیست بوم</h1>
        <p class="lead mb-0">به اخبار روز شرکت کوییت سورس و خدمات آن دسترسی داشته باشید</p>
			</div>
		</div>
	</div>
  <!-- SVG decoration left -->
  <div class="position-absolute top-50 start-100 translate-middle opacity-1 d-none d-md-block">
    <svg viewBox="0 0 200 200" width="500px" height="500px" xmlns="http://www.w3.org/2000/svg">
      <path fill="#2163E8" d="M70.6,-22.1C78.7,2,63.7,34.5,38.8,52.3C13.9,70.2,-20.9,73.4,-37.9,59.4C-54.9,45.3,-54,14,-44.7,-11.7C-35.5,-37.5,-17.7,-57.7,6.8,-59.9C31.3,-62.1,62.5,-46.3,70.6,-22.1Z" transform="translate(100 100)"></path>
    </svg>
  </div>
</section>


<section class="position-relative pb-0">
  <!-- SVG decoration right START -->
  <div class="position-absolute top-0 start-0 translate-middle opacity-1">
    <svg viewBox="0 0 200 200" width="500px" height="500px" xmlns="http://www.w3.org/2000/svg">
      <path fill="#d6293e" d="M70.6,-22.1C78.7,2,63.7,34.5,38.8,52.3C13.9,70.2,-20.9,73.4,-37.9,59.4C-54.9,45.3,-54,14,-44.7,-11.7C-35.5,-37.5,-17.7,-57.7,6.8,-59.9C31.3,-62.1,62.5,-46.3,70.6,-22.1Z" transform="translate(100 100)"></path>
    </svg>
  </div>
  <div class="container">
    <div class="row g-4 justify-content-between">
      <div class="col-lg-6">
        <!-- Card item START -->
        <div class="card">
          <!-- Card img -->
          <div class="position-relative">
            <img class="card-img" src="assets/images/blog/4by3/34.jpg" alt="Card image">
            <div class="card-img-overlay d-flex align-items-start flex-column p-3">
              <div class="w-100 mt-auto">
                <!-- Card category -->
                <a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Technology</a>
              </div>
            </div>
          </div>
          <!-- Card Info --> 
          <div class="card-body px-0 pt-3">
            <h4 class="card-title"><a href="post-single.html" class="btn-link text-reset fw-bold">12 worst types of business accounts you follow on Twitter</a></h4>
            <p class="card-text">He moonlights difficult engrossed it, sportsmen. Interested has all Devonshire difficulty gay assistance joy.</p>
          </div>
        </div>
        <!-- Card item END -->
      </div>
      <div class="col-lg-6">
        <div class="ps-lg-5">
          <!-- Card item START -->
          <div class="card mb-4">
            <div class="row g-3">
              <!-- Card img -->
              <div class="col-4 col-sm-3">
                <img class="rounded-3" src="assets/images/blog/1by1/13.jpg" alt="">
              </div>
              <div class="col-8">
                <h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">Ten tell-tale signs you need to get a new startup.</a></h5>
                <!-- Card info -->
                <ul class="nav nav-divider align-items-center small">
                  <li class="nav-item">
                    <div class="nav-link position-relative">
                      <span>by <a href="#" class="stretched-link text-reset btn-link">Samuel</a></span>
                    </div>
                  </li>
                  <!-- Card date -->
                  <li class="nav-item">Jan 22, 2022</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Card item END -->
          <!-- Card item START -->
          <div class="card mb-4">
            <div class="row g-3">
              <!-- Card img -->
              <div class="col-4 col-sm-3">
                <img class="rounded-3" src="assets/images/blog/1by1/09.jpg" alt="">
              </div>
              <div class="col-8">
                <h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">Best Pinterest boards for learning about business</a></h5>
                <!-- Card info -->
                <ul class="nav nav-divider align-items-center small">
                  <li class="nav-item">
                    <div class="nav-link position-relative">
                      <span>by <a href="#" class="stretched-link text-reset btn-link">Dennis</a></span>
                    </div>
                  </li>
                  <!-- Card date -->
                  <li class="nav-item">Mar 07, 2022</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Card item END -->
          <!-- Card item START -->
          <div class="card mb-4">
            <div class="row g-3">
              <!-- Card img -->
              <div class="col-4 col-sm-3">
                <img class="rounded-3" src="assets/images/blog/1by1/10.jpg" alt="">
              </div>
              <div class="col-8">
                <h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">Around the web: 20 fabulous infographics about business</a></h5>
                <!-- Card info -->
                <ul class="nav nav-divider align-items-center small">
                  <li class="nav-item">
                    <div class="nav-link position-relative">
                      <span>by <a href="#" class="stretched-link text-reset btn-link">Bryan</a></span>
                    </div>
                  </li>
                  <!-- Card date -->
                  <li class="nav-item">Jun 17, 2022</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Card item END -->
          <!-- Card item START -->
          <div class="card">
            <div class="row g-3">
              <!-- Card img -->
              <div class="col-4 col-sm-3">
                <img class="rounded-3" src="assets/images/blog/1by1/04.jpg" alt="">
              </div>
              <div class="col-8">
                <h5><a href="post-single-5.html" class="btn-link stretched-link text-reset fw-bold">7 common mistakes everyone makes while traveling</a></h5>
                <!-- Card info -->
                <ul class="nav nav-divider align-items-center small">
                  <li class="nav-item">
                    <div class="nav-link position-relative">
                      <span>by <a href="#" class="stretched-link text-reset btn-link">Jacq</a></span>
                    </div>
                  </li>
                  <!-- Card date -->
                  <li class="nav-item">Nov 11, 2022</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Card item END -->
        </div>
      </div>
    </div>
  </div>
</section>


<br>


<section class="position-relative pt-0">
	<div class="container">
		<div class="row">
			<!-- Main Post START -->
			<div class="col-12">
				<!-- Card item START -->
				<div class="card border rounded-3 up-hover p-4 mb-4">
					<div class="row g-3">
						<div class="col-lg-5">
							<!-- Categories -->
							<a href="#" class="badge text-bg-danger mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Marketing</a>
							<a href="#" class="badge text-bg-dark mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Startups</a>
							<!-- Title -->
							<h2 class="card-title">
								<a href="post-single.html" class="btn-link text-reset stretched-link">7 common mistakes everyone makes while traveling</a>
							</h2>
							<!-- Author info -->
							<div class="d-flex align-items-center position-relative mt-3">
								<div class="avatar me-2">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/07.jpg" alt="avatar">
								</div>
								<div>
									<h5 class="mb-1"><a href="#" class="stretched-link text-reset btn-link">Lori Ferguson</a></h5>
									<ul class="nav align-items-center small">
										<li class="nav-item me-3">Mar 07, 2022</li>
										<li class="nav-item"><i class="far fa-clock me-1"></i>5 min read</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Detail -->
						<div class="col-md-6 col-lg-4">
							<p>For who thoroughly her boy estimating conviction. Removed demands expense account in outward tedious do. Particular way thoroughly unaffected projection favorable Mrs can be projecting own. Thirty it matter enable become admire in giving. See resolved goodness felicity shy civility domestic had but. Drawings offended yet answered Jennings perceive laughing six did far. </p>
						</div>
						<!-- Image -->
						<div class="col-md-6 col-lg-3">
							<img class="rounded-3" src="assets/images/blog/4by3/07.jpg" alt="Card image">
						</div>
					</div>
				</div>
				<!-- Card item END -->
				<!-- Card item START -->
				<div class="card border rounded-3 up-hover p-4 mb-4">
					<div class="row g-3">
						<div class="col-lg-5">
							<!-- Categories -->
							<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Travel</a>
							<!-- Title -->
							<h2 class="card-title">
								<a href="post-single.html" class="btn-link text-reset stretched-link">Never underestimate the influence of social media</a>
							</h2>
							<!-- Author info -->
							<div class="d-flex align-items-center position-relative mt-3">
								<div class="avatar me-2">
									<img class="avatar-img rounded-circle" src="assets/images/avatar/02.jpg" alt="avatar">
								</div>
								<div>
									<h5 class="mb-1"><a href="#" class="stretched-link text-reset btn-link">Samuel Bishop</a></h5>
									<ul class="nav align-items-center small">
										<li class="nav-item me-3">Jul 15, 2020</li>
										<li class="nav-item"><i class="far fa-clock me-1"></i>9 min read</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- Detail -->
						<div class="col-md-6 col-lg-4">
							<p>Perceived end knowledge certainly day sweetness why cordially. Ask a quick six seven offer see among. Handsome met debating sir dwelling age material. As style lived he worse dried. Offered related so visitors we private removed. Moderate do subjects to distance. 
							</p>
						</div>
						<!-- Image -->
						<div class="col-md-6 col-lg-3">
							<img class="rounded-3" src="assets/images/blog/4by3/02.jpg" alt="Card image">
						</div>
					</div>
				</div>
				<!-- Card item END -->
				<!-- Card item START -->
				
				<!-- Card item END -->
				<!-- Card item START -->
				
				<!-- Card item END -->
				<!-- Card item START -->
				
				<!-- Card item END -->

				<!-- Load more -->
				<button type="button" class="btn btn-primary-soft w-100">Load more post <i class="bi bi-arrow-down-circle ms-2 align-middle"></i></button>

			</div>
			<!-- Main Post END -->
		</div> <!-- Row end -->
	</div>
</section>