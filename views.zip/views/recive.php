
<?php
if(isset($_GET['id'])){
    $query111 = mysqli_query($con, 'select * from session where data="'.$_GET['id'].'" order by id Desc');
    $session = mysqli_fetch_assoc($query111);
    if(! $session){
        ?>
        <section class="py-4">
            <div class="container">
            <div class="row pb-4">
            
                                <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/search-email-5192238-4340243.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video> رسید تراکنش </h1>
                    </div>
                </div>

                

                <br>

                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                                <!-- Form START -->
                    <form action="../../index.php?controller=account&amp;method=cartToCart" method="POST">
            
                        
                        <div class="col-lg-4">
            
                    
                            <div class="col-12 text-center">
                                <!-- Image -->
                                <img src="assets/images/icon/empty-cart.svg" class="h-200 h-md-300 mb-3" alt="">
                                <!-- Subtitle -->
                                <h2>رسیدی یافت نشد</h2>
                                <!-- info -->
                                <p class="mb-0">در وارد کردن شناسه پیگیری دقت کنید یا که ان را کپی کرده و پیست کنید</p>
                                <!-- Button -->
                            </div>

                        </div>

                
                        
                        <br>
                        <!-- Create post button -->
                        <div class="col-md-12 text-start">
                            <a class="btn btn-outline-danger" href="../../core/rtl/dashboard.php?content=wallet"><i class="bi bi-arrow-right-short"></i>بازگشت</a>
                        </div>
                        </form></div>
                    
                    <!-- Form END -->
                                        </div>
                        </div>
                        <!-- Chart END -->
                </div>
            </div>
            
        </section>
        <?php
    }else{
        $query112 = mysqli_query($con, 'select * from user where iduser="'.$session['userTow'].'"');
        $account = mysqli_fetch_assoc($query112);
        if(! $account){
            die();
        }
        
        $query113 = mysqli_query($con, 'select * from user where iduser="'.$session['userId'].'"');
        $send = mysqli_fetch_assoc($query113);
        if(! $account){
            die();
        }
        
        
        ?>
        <section class="py-4">
            <div class="container">
            <div class="row pb-4">
            
                                <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/search-email-5192238-4340243.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video> رسید تراکنش </h1>
                    </div>
                </div>
        
                
        
                <br>
        
                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                                <!-- Form START -->
                    <form action="../../index.php?controller=account&amp;method=cartToCart" method="POST">
            
                        
                        <div class="col-lg-4">
            
                            <!-- Shipment information -->
                            <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات تراکنش </font></font></h5>
                            <ul class="list-group list-group-borderless">
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ پرداختی: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $session['payment']?> تومان</font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> روش پرداخت: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیف پول پیپرلاین</font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مالیات انتقال پول در پیپرلاین: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 1000 تومان </font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مبلغی که از ارسال کننده کسر میشود : </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $session['payment']+1000?> تومان </font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  پرداخت به : </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $account['username']?>-<?php echo $account['iduser']?></font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> پرداخت کننده : </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $send['username']?>-<?php echo $send['iduser']?></font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  تاریخ و ساعت : </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $session['createDate']?></font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> شناسه پیگیری : </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $session['data']?></font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> بابت: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $session['wiki']?> </font></font></span>
                                </li>
        
                            </ul>
        
        
                        </div>
        
                
                        
                        <br>
                        <!-- Create post button -->
                        <div class="col-md-12 text-start">
                            <a class="btn btn-outline-danger" href="../../core/rtl/dashboard.php?content=wallet"><i class="bi bi-arrow-right-short"></i>بازگشت</a>
                        </div>
                        </form></div>
                    
                    <!-- Form END -->
                                        </div>
                        </div>
                        <!-- Chart END -->
                </div>
            </div>
            
        </section>
        <?php
    }


}else{
    ?>
    <section class="py-4">
        <div class="container">
        <div class="row pb-4">
        
            <div class="col-12">
            <!-- Title -->
                        <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/search-email-5192238-4340243.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video> دریافت رسید تراکنش </h1>
                </div>
            </div>

            

            <br>

            <div class="row">
                <div class="col-12">
                    <!-- Chart START -->
                    <div class="card border">
                        <!-- Card body -->
                        <div class="card-body">
                            <!-- Form START -->
                    <form action="" method="GET">
        
                    
                        <div class="col-12">
                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شناسه انتقال  </font></font></label>
                                <input required="" style="display: none;" id="con-name" name="content" type="text" class="form-control" value="recive" placeholder="نام پست">

                                <input required="" id="con-name" name="id" type="text" class="form-control" placeholder="شناسه را وارد کنید">
                                <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">در این قسمت شناسه های انتقال را وارد کنید و گزینه برسی کلیک کنید</font></font></small>
                            </div>
                        </div>

            
                    
                    <br>
                    <!-- Create post button -->
                    <div class="col-md-12 text-start">
                        <a class="btn btn-outline-danger" href="../../core/rtl/dashboard.php?content=wallet"><i class="bi bi-arrow-right-short"></i>بازگشت</a>
                        <button class="btn btn-primary" type="submit">برسی</button>
                    </div>
                    </form></div>
                
                <!-- Form END -->
                                    </div>
                    </div>
                    <!-- Chart END -->
            </div>
        </div>
        
    </section>
    <?php
}