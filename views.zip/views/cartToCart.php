<section class="py-4">
	<div class="container">
    <div class="row pb-4">
      
			<?PHP 
			if(isset($_GET['alert'])){
				?>
				<div class="alert alert-danger" role="alert">
				<i style="width: 35px;" class="bi bi-exclamation-triangle"></i> <?php echo $_GET['alert']?>
				</div>
				<?php
			}
			?>
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/setting-5192257-4340262.mp4" type="video/mp4" style="width: 100px;" autoplay="autoplay" loop="loop"></video> واریز به حساب</h1>
			</div>
		</div>

        

        <br>

		<div class="row">
			<div class="col-12">
				<!-- Chart START -->
				<div class="card border">
					<!-- Card body -->
					<div class="card-body">
            <?php
            if(isset($_POST['ID'])){
              ?>
              <!-- Form START -->
              <form action="../../index.php?controller=account&method=cartToCart" method="POST">
      
                <?php
                $query1 = mysqli_query($con, 'select * from user where iduser="'.$_POST['ID'].'"');
                $account = mysqli_fetch_assoc($query1);
                if($account){
                  if($account['iduser'] == $_SESSION['id']){
                    ?>
                    <script> location.replace("../../core/rtl/dashboard.php?content=wallet&alert=شما نمیتوانید برای خود پول منتقل کنید"); </script>
                    <?php
                    die();
                  }elseif($_POST['pay'] <= 0){
                    ?>
                    <script> location.replace("../../core/rtl/dashboard.php?content=wallet&alert=مشکل در داده های ورودی وجود دارد و ما نمیتوانیم ان را پردازش کنیم"); </script>
                    <?php
                    die();
                  }
                  
                  
                  if($user['charge'] < $_POST['pay']){
                    ?>
                    <script> location.replace("../../core/rtl/dashboard.php?content=cartToCart&alert=موجودی شما برای پرداخت این مبلغ کافی نیست"); </script>
                    <?php
                    die();
                  }

                  ?>

                  <div class="col-lg-4">
                    <h5>تایید تراکنش</h5>
                    <div class="d-flex align-items-center position-relative">
                      <div class="avatar avatar-sm">
                        <img class="avatar-img rounded-circle" src="<?php echo $account['avatar']?>" alt="avatar">
                      </div>
                      <div class="ms-3">
                        <h6 class="mb-0"><a href="../../core/rtl/dashboard.php?content=profile&id=<?phP echo $account['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $account['username']?></a></h6>
                      </div>
                    </div>
                    <!-- List -->
                    <div class="hstack gap-3 flex-wrap mt-2 mb-4">
                      <p class="mb-0"><i class="bi bi-star-fill text-warning"></i> <?php echo $account['iduser']?> <span>شناسه مشتری</span></p>
                      <p class="mb-0"><i class="bi bi-patch-check-fill text-primary"></i> 99% <span>Positive Feedback</span></p>
                    </div>



                      <!-- Shipment information -->
                      <h5><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اطلاعات تراکنش </font></font></h5>
                      <ul class="list-group list-group-borderless">
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبلغ پرداختی: </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $_POST['pay']?> تومان</font></font></span>
                        </li>
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> روش پرداخت: </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیف پول پیپرلاین</font></font></span>
                        </li>
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مالیات انتقال پول در پیپرلاین: </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 1000 تومان </font></font></span>
                        </li>
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> مبلغی که از شما کسر میشود : </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $_POST['pay']+1000?> تومان </font></font></span>
                        </li>
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  پرداخت به : </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $account['username']?></font></font></span>
                        </li>
                        <li class="list-group-item py-0">
                          <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> بابت: </font></font></span>
                          <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $_POST['doc']?> </font></font></span>
                        </li>

                      </ul>


                  </div>

                  <input style="display: none;" id="con-name" name="ID" value="<?PHP echo $_POST['ID']?>" type="text" class="form-control" placeholder="فایل را وارد کنید">
                  <input style="display: none;" id="con-name1" name="pay" value="<?PHP echo $_POST['pay']?>" type="number" class="form-control" placeholder="فایل را وارد کنید">
                  <textarea style="display: none;" class="form-control" rows="3" name="doc" placeholder="کمی مختصر در باره فایل توضیح دهید"><?PHP echo $_POST['doc']?></textarea>

                  <?php
                }
                ?>

                  <br>
                  <!-- Create post button -->
                  <div class="col-md-12 text-start">
                      <a class="btn btn-outline-danger" href="../../core/rtl/dashboard.php?content=wallet">لغو</a>
                      <button class="btn btn-primary" type="submit">تایید پرداخت</button>
                  </div>
                </div>
              </form>
              <!-- Form END -->
              <?php
            }else{
              ?>
              <!-- Form START -->
              <form action="../../core/rtl/dashboard.php?content=cartToCart" method="POST">
                <!-- Main form -->
                <div class="row">
                  <div class="col-12">
                    <!-- Post name -->
                    <div class="mb-3">
                      <label class="form-label">شناسه مشتری</label>
                      <input required="" id="con-name" name="ID" type="text" class="form-control" placeholder="فایل را وارد کنید">
                      <small>با مراجعه به پروفایل شخصی که میخواید به حساب ان واریز کنید شناسه مشتری یا ایدی عددی ان را برداشته و وارد کنید</small>
                    </div>
                  </div>
                  <!-- Post type START -->

                <!-- Post type END -->
                
                <!-- Short description -->
                <div class="col-12">
                  <div class="mb-3">
                      <label class="form-label">توضیحات</label>
                      <textarea class="form-control" rows="3" name="doc" placeholder="کمی مختصر در باره فایل توضیح دهید"></textarea>
                  </div>
                </div>

                  <!-- Post name -->
                  <div class="mb-3">
                      <label class="form-label">مبلغ</label>
                      <input required="" id="con-name" name="pay" type="number" class="form-control" placeholder="مبلغ را وارد کنید">
                      <small>مبلغ خود را به تومان وارد کنید دقت کنید که اشتباه نشود</small>
                      <br>
                      <br>
                      
                      
                      
                      
                  
                  </div>

                <!-- Main toolbar -->





                  



                  <!-- Post name -->
                  




                  <div class="col-12">
                    <div class="form-check mb-3">
                      <input class="form-check-input" type="checkbox" value="" id="postCheck">
                      <label class="form-check-label" for="postCheck">
                        Make this post featured?
                      </label>
                    </div>
                  </div>
                  <!-- Create post button -->
                  <div class="col-md-12 text-start">
                      <a class="btn btn-outline-danger" href="../../core/rtl/dashboard.php?content=wallet">بازگشت</a>
                      <button class="btn btn-primary" type="submit">مرحله بعد</button>
                  </div>
                </div>
              </form>
              <!-- Form END -->
              <?php
            }
            ?>
					</div>
				</div>
				<!-- Chart END -->
		</div>
    </div>
	</div>
</section>