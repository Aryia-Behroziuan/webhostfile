<section class="py-4">
	<div class="container">
        <div class="row pb-4">
                <div class="col-12">
            <!-- Title -->
                        <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/plus-5730395-4787681.mp4" style="width: 70px;" type="video/mp4" autoplay="autoplay" loop="loop"></video><font style="vertical-align: inherit;">یک پست ایجاد کنید</font></font></h1>
                </div>
            </div>
            <?PHP
            if(isset($_GET['id'])){
                
                ?>
                            <?php
                            $query_search = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'" ');
                            $post = mysqli_fetch_assoc($query_search);
                            if($post){
                                if(! $user['iduser'] == $post['idUser']){
                                    die();
                                }
                            }else{
                                die();
                            }
                            ?>
                               
                            <!-- Modal -->
                            <div style="background: #ffffff;" class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel"><ol class="breadcrumb breadcrumb-dots">
                                        <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> <?php echo $post['title']?></a></li>
                                        <li class="breadcrumb-item active">شخصی سازی</li>
                                    </ol></h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                <div id="alert"></div>
                                <br>
                                    <div class="bg-dark alert alert-warning py-2 m-0 bg-primary border-0 rounded-0 alert-dismissible fade show text-center overflow-hidden" role="alert">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle">
                                            <svg width="1848" height="481" viewBox="0 0 1848.9 481.8" xmlns="http://www.w3.org/2000/svg">
                                                <path class="fill-success" d="m779.4 251c-10.3-11.5-19.9-23.8-29.4-36.1-9-11.6-18.4-22.8-27.1-34.7-15.3-21.2-30.2-45.8-54.8-53.3-10.5-3.2-21.6-3.2-30.6 2.5-7.6 4.8-13 12.6-17.3 20.9-10.8 20.6-16.1 44.7-24.6 66.7-7.9 20.2-19.4 38.6-33.8 54.3-14.7 16.2-31.7 30-50.4 41-15.9 9.4-33.4 17.2-52 19.3-18.4 2-38-2.5-56.5-6.2-22.4-4.4-45.1-9.7-67.6-10.9-9.8-0.5-19.8-0.3-29.1 2.3-9.8 2.8-18.7 8.6-26.6 15.2-17.3 14.5-30.2 34.4-43.7 52.9-12.9 17.6-26.8 34.9-45.4 45.4-19.5 11-42.6 12.1-65 6.6-52.3-13.1-93.8-56.5-127.9-101.5-8.8-11.6-17.3-23.4-25.6-35.4-0.6-0.9-1.1-1.8-1.6-2.7-1.1-2.4-0.9-2.6 0.6-1.2 1 0.9 1.9 1.9 2.7 3 35.3 47.4 71.5 98.5 123.2 123.9 22.8 11.2 48.2 17.2 71.7 12.2 23-5 40.6-21.2 55.3-39.7 24.5-30.7 46.5-75.6 87.1-83 19.5-3.5 40.7 0.1 60.6 3.7 21.2 3.9 42.3 9.1 63.6 11.7 17.8 2.3 35.8-0.1 52.2-7 20-8.1 38.4-20.2 54.8-34.6 16.2-14.1 31-30.7 41.8-50.4 11.1-20.2 17-43.7 24.9-65.7 6.1-16.9 13.8-36.2 29.3-44.5 16.1-8.6 37.3-1.9 52.3 10.6 18.7 15.6 31.2 39.2 46.7 58.2"></path>
                                                <path class="fill-warning" d="m1157.9 344.9c9.8 7.6 18.9 15.8 28.1 24 8.6 7.7 17.6 15.2 26 23.2 14.8 14.2 29.5 30.9 51.2 34.7 9.3 1.6 18.8 0.9 26.1-3.8 6.1-3.9 10.2-9.9 13.2-16.2 7.6-15.6 10.3-33.2 15.8-49.6 5.2-15.1 13.6-29 24.7-41.3 11.4-12.6 24.8-23.6 40-32.8 12.9-7.8 27.3-14.6 43.1-17.3 15.6-2.6 32.8-0.7 49 0.7 19.6 1.7 39.4 4 58.8 3.4 8.4-0.3 17-1.1 24.8-3.6 8.2-2.7 15.4-7.4 21.6-12.7 13.7-11.6 23.1-26.7 33.3-40.9 9.6-13.5 20.2-26.9 35.3-35.6 15.8-9.2 35.6-11.6 55.2-9.1 45.7 5.8 84.8 34.3 117.6 64.4 8.7 8 17.2 16.2 25.6 24.6 2.5 3.2 1.9 3-1.2 1-34.3-32-69.7-66.9-116.5-81.9-20.5-6.5-42.7-9.2-62.4-4-19.3 5.1-33.1 17.9-44.3 32.2-18.5 23.7-33.9 57.5-68.1 65.5-16.5 3.8-34.9 2.6-52.3 1.3-18.5-1.4-37-3.7-55.4-4.2-15.5-0.5-30.7 2.5-44.2 8.5-16.5 7.2-31.3 17.1-44.3 28.5-12.8 11.2-24.1 24.1-31.9 39-7.9 15.3-11.1 32.5-16.2 48.9-3.9 12.6-9 26.9-21.6 33.9-13.1 7.3-31.9 3.8-45.7-4.1-17.2-10-29.9-26.1-44.6-38.8"></path>
                                                <path class="fill-warning" d="m1840.8 379c-8.8 40.3-167.8 79.9-300.2 45.3-42.5-11.1-91.4-32-138.7-11.6-38.7 16.7-55 66-90.8 67.4-25.1 1-48.6-20.3-58.1-39.8-31-63.3 50.7-179.9 155.7-208.1 50.4-13.5 97.3-3.2 116.1 1.6 36.3 9.3 328.6 87.4 316 145.2z"></path>
                                                <path class="fill-success" d="M368.3,247.3C265.6,257.2,134,226,110.9,141.5C85,47.2,272.5-9.4,355.5-30.7s182.6-31.1,240.8-18.6    C677.6-31.8,671.5,53.9,627,102C582.6,150.2,470.9,237.5,368.3,247.3z"></path>
                                            </svg>
                                        </figure>

                                                                        <!-- SVG shape END -->
                                                        <div class="position-relative">
                                                                                                
                                                            <p class="text-white m-0"><?php echo $post['txtB']?><a href="index.php?content=by&amp;id=7" class="btn btn-xs btn-primary ms-3 mb-0"><?php echo $post['button']?><br><?php echo number_format($post['pay'] , 0 , "." , "," )?> تومان</a></p>
                                                        </div>
                                                        <!-- Close button -->
                                                                        <button type="button" class="btn-close btn-close-white opacity-9 p-3" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                    <form action="../../index.php?controller=create&method=addPlaging&plagin=1" method="POST" id="getDataF">
                                            <div class="card border bg-transparent rounded-3">
                                                <!-- Card header START -->
                                                <div class="card-header bg-transparent border-bottom p-3">
                                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                                        <h5 class="mb-2 mb-sm-0"><img src="https://3dicons.sgp1.cdn.digitaloceanspaces.com/v1/dynamic/color/figma-dynamic-color.png" style="width: 30px;" alt=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شخصی سازی</font></font></h5>
                                                        
                                                    </div>
                                                </div>
                                                <!-- Card header END -->

                                                <!-- Card body START -->
                                                <div class="card-body p-3">
                                                
                                                        <input type="text" value="<?php echo $post['idPost']?>" style="display: none;" name="idpost">
                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کلید خرید مخزن</font></font></label>
                                                            <input required="" id="con-name" name="buttonTxt" type="text" value="<?php echo $post['button']?>" class="form-control" placeholder="لینک صفحه را وارد کنید">
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وقتی کاربر به صفحه مخصوص مخزن شما میرود دیکمه ای برای امکان خرید در بالا برای او نشان داده میشود تنظیم کنید روی آن دکمه چه چیزی بنویسیم</font></font></small>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">متن دعوت</font></font></label>
                                                            <input required="" id="con-name" name="txtB" type="text" value="<?php echo $post['txtB']?>" class="form-control" placeholder="لینک صفحه را وارد کنید">
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">متنی بنوسید که افراد را ترقیب به خرید کنید و در یک متن بسیار کوتاه از مخاطب دعوت کنید تا مخزن شما را انتخاب کند</font></font></small>
                                                        </div>

                                                </div>
                                            </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger-soft" data-bs-dismiss="modal"><i class="bi bi-arrow-right-short"></i> بازگشت</button>
                                    <button type="submit" id="btnS" class="btn btn-dark-soft"><i class="bi bi-send-plus"></i> ویرایش </button>
                                    </form>
                                    
                                    <script>
                                            $(document).ready(function(){
                                                $("#getDataF").on("submit", function(event){
                                                    event.preventDefault();
                                                    $('#btnS').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                    var formValues= $('#getDataF').serialize();

                                                    $.post("../../index.php?controller=create&method=addPlaging&plagin=1", formValues, function(data){
                                                        // Display the returned data in browser
                                                        $('#btnS').html('ذخیره شد');
                                                        $('#alert').html(data);
                                                    });
                                                });
                                            });
                                    </script>
                                </div>
                                </div>
                            </div>
                            </div>


                                        <!-- Modal -->
                            <div style="background: #ffffff;" class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel"><ol class="breadcrumb breadcrumb-dots">
                                        <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> <?php echo $post['title']?></a></li>
                                        <li class="breadcrumb-item active">محدودیت سازی</li>
                                    </ol></h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                    <form action="" method="POST" id="getDataF1">
                                <div class="modal-body">
                                <div id="alert1"></div>
                                            <input type="text" value="<?php echo $post['idPost']?>" style="display: none;" name="idpost">

                                            <div class="card border bg-transparent rounded-3">
                                                <!-- Card header START -->
                                                <div class="card-header bg-transparent border-bottom p-3">
                                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                                        <h5 class="mb-2 mb-sm-0"><img src="https://3dicons.sgp1.cdn.digitaloceanspaces.com/v1/dynamic/color/figma-dynamic-color.png" style="width: 30px;" alt=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شخصی سازی</font></font></h5>
                                                        
                                                    </div>
                                                </div>
                                                <!-- Card header END -->

                                                <!-- Card body START -->
                                                <div class="card-body p-3">
                                                
                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تعداد فروش</font></font></label>
                                                            <input required="" id="con-name" name="number" type="number" min="0" value="<?php echo $post['byNumber']?>" class="form-control" placeholder="لینک صفحه را وارد کنید">
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">محدودیت اتوماتیک را اگر روی صفر تنظیم کنید بی نهایت میتوانید از این مخزن به فروش برسانید و اگر عددی را وارد کنید وقتی تعداد فروشتان به آن تعداد رسید از مخزن از دسترس خارج خواهد شد</font></font></small>
                                                        </div>

                                                  
                                                </div>
                                            </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger-soft" data-bs-dismiss="modal"><i class="bi bi-arrow-right-short"></i> بازگشت</button>
                                    <button type="submit" id='btnS1' class="btn btn-dark-soft"><i class="bi bi-send-plus"></i> ویرایش </button>
                                    </form>
                                    <script>
                                            $(document).ready(function(){
                                                $("#getDataF1").on("submit", function(event){
                                                    event.preventDefault();
                                                    $('#btnS1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                    var formValues= $('#getDataF1').serialize();

                                                    $.post("../../index.php?controller=create&method=addPlaging&plagin=2", formValues, function(data){
                                                        // Display the returned data in browser
                                                        $('#btnS1').html('ذخیره شد');
                                                        $('#alert1').html(data);
                                                    });
                                                });
                                            });
                                    </script>
                                </div>
                                </div>
                            </div>
                            </div>
                            
                            <div style="background: #ffffff;" class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel"><ol class="breadcrumb breadcrumb-dots">
                                        <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> <?php echo $post['title']?></a></li>
                                        <li class="breadcrumb-item active">تنظیمات سرویسدهی </li>
                                    </ol></h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                <div id="alert2"></div>
                                            <div class="card border bg-transparent rounded-3">
                                                <!-- Card header START -->
                                                <div class="card-header bg-transparent border-bottom p-3">
                                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                                        <h5 class="mb-2 mb-sm-0"><img src="https://3dicons.sgp1.cdn.digitaloceanspaces.com/v1/dynamic/color/figma-dynamic-color.png" style="width: 30px;" alt=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شخصی سازی</font></font></h5>
                                                        
                                                    </div>
                                                </div>
                                                <!-- Card header END -->

                                                <!-- Card body START -->
                                                <div class="card-body p-3">
                                    <form action="" method="POST" id="getDataF2">

                                                        <input type="text" value="<?php echo $post['idPost']?>" style="display: none;" name="idpost">

                                                        
                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> تعداد سفارش در هر عرضه</font></font></label>
                                                            <input required="" id="con-name" name="max" type="number" min="0" value="<?php echo $post['max']?>" class="form-control" placeholder="لینک صفحه را وارد کنید">
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشخص کنید در هرعرضه کاربر میتواند چه تعداد از محتوای درون این سرویس را سفارش دهد</font></font></small>
                                                        </div>

                                                        <?php if($post['inter'] == 1){
                                                            ?>

                                                            <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                                <input name="inter" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5" checked="">
                                                                                <span class="d-block">امکان تایید هر سفارش</span>
                                                                                <span class="d-block small">به شما این امکان  را میدهد که از این پس هر کس سرویس شما را سفارش دهد در قسمت مدیریت همین سرویس یک بخش تحت عنوان تایید یا رد سفارش را دارید و فقط سفارش هایی که تایید میکنید هزینه آن را دریافت میکنید</span>
                                                            </label>
                                                            <?php
                                                        }else{
                                                            ?>

                                                            <label class="form-check form-switch" for="accountNotificationSwitch8">
                                                                                <input name="inter" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch8">
                                                                                <span class="d-block">امکان تایید هر سفارش</span>
                                                                                <span class="d-block small text-muted">به شما این امکان  را میدهد که از این پس هر کس سرویس شما را سفارش دهد در قسمت مدیریت همین سرویس یک بخش تحت عنوان تایید یا رد سفارش را دارید و فقط سفارش هایی که تایید میکنید هزینه آن را دریافت میکنید</span>
                                                            </label>
                                                            <?php
                                                        }?>

                        
                                                  
                                                </div>
                                            </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger-soft" data-bs-dismiss="modal"><i class="bi bi-arrow-right-short"></i> بازگشت</button>
                                    <button type="submit" id="btnS2" class="btn btn-dark-soft"><i class="bi bi-send-plus"></i> ویرایش </button>
                                    </form>
                                    <script>
                                            $(document).ready(function(){
                                                $("#getDataF2").on("submit", function(event){
                                                    event.preventDefault();
                                                    $('#btnS2').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                    var formValues= $('#getDataF2').serialize();

                                                    $.post("../../index.php?controller=create&method=addPlaging&plagin=3", formValues, function(data){
                                                        // Display the returned data in browser
                                                        $('#btnS2').html('ذخیره شد');
                                                        $('#alert2').html(data);
                                                    });
                                                });
                                            });
                                    </script>
                                </div>
                                </div>
                            </div>
                            </div>

                            <div style="background: #ffffff;" class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable modal-xl">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel"><ol class="breadcrumb breadcrumb-dots">
                                        <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house me-1"></i> <?php echo $post['title']?></a></li>
                                        <li class="breadcrumb-item active">تنظیمات موقعیت مکانی </li>
                                    </ol></h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                <div id="alert3"></div>
                                    <form action="" method="POST" id="getDataF3">
                                            <div class="card border bg-transparent rounded-3">
                                                <!-- Card header START -->
                                                <div class="card-header bg-transparent border-bottom p-3">
                                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                                        <h5 class="mb-2 mb-sm-0"><i class="bi bi-geo-alt-fill"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موقعیت مکامنی</font></font></h5>
                                                        
                                                    </div>
                                                </div>
                                                <!-- Card header END -->

                                                <!-- Card body START -->
                                                <div class="card-body p-3">
                                                <h4>انتخاب موقعیت مکانی</h4>
                                                <select class="form-select" name="loc" multiple aria-label="multiple select example">

                                                    <?php
                                                    if(strlen($post['loc']) >= 2){
                                                        ?>
                                                        <option value="<?php echo $post['loc']?>" selected>"<?php echo $post['loc']?>" انتخاب شده</option>

                                                        <?php
                                                    }else{
                                                        ?>
                                                        <option value="" selected>برای فعالسازی منطقه را انتخاب کنید</option>

                                                        <?php
                                                    }
                                                    
                                                    ?>
                                                    <br>
                                                    <option value="تهران">تهران</option>
                                                    <br>
                                                    <option value="گیلان">گیلان</option>
                                                    <option value="آذربایجان شرقی">آذربایجان شرقی</option>
                                                    <option value="خوزستان">خوزستان</option>
                                                    <option value="فارس">فارس</option>
                                                    <option value="اصفهان">اصفهان</option>
                                                    <option value="خراسان رضوی">خراسان رضوی</option>
                                                    <option value="قزوین">قزوین</option>
                                                    <option value="سمنان">سمنان</option>
                                                    <option value="قم">قم</option>
                                                    <option value="مرکزی">مرکزی</option>
                                                    <option value="زنجان">زنجان</option>
                                                    <option value="مازندران">مازندران</option>
                                                    <option value="گلستان">گلستان</option>
                                                    <option value="اردبیل">اردبیل</option>
                                                    <option value="آذربایجان غربی">آذربایجان غربی</option>
                                                    <option value="همدان">همدان</option>
                                                    <option value="کردستان">کردستان</option>
                                                    <option value="کرمانشاه">کرمانشاه</option>
                                                    <option value="لرستان">لرستان</option>
                                                    <option value="بوشهر">بوشهر</option>
                                                    <option value="کرمان">کرمان</option>
                                                    <option value="هرمزگان">هرمزگان</option>
                                                    <option value="چهارمحال و بختیاری">چهارمحال و بختیاری</option>
                                                    <option value="یزد">یزد</option>
                                                    <option value="سیستان و بلوچستان">سیستان و بلوچستان</option>
                                                    <option value="ایلام">ایلام</option>
                                                    <option value="کهگلویه و بویراحمد">کهگلویه و بویراحمد</option>
                                                    <option value="خراسان شمالی">خراسان شمالی</option>
                                                    <option value="خراسان جنوبی">خراسان جنوبی</option>
                                                    <option value="البرز">البرز</option>


                                                </select> 

                                                <br>
                                               

                                                        <input type="text" value="<?php echo $post['idPost']?>" style="display: none;" name="idpost">

                                               
                                                
                                                        <?php if($post['interLoc'] == 1){
                                                            ?>

                                                            <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                                <input name="interLoc" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5" checked="">
                                                                                <span class="d-block">محدودیت مکانی</span>
                                                                                <span class="d-block small">در هنگام خاموش بودن این گزنه موقعیت مکانی فقط به کاربر نمایش داده میشود ولی در صورت روشن بودن اگر کاربر در محدوده تحت پوشش شما نباشد امکان خرید محصول را هم ندارد</span>
                                                            </label>
                                                            <?php
                                                        }else{
                                                            ?>

                                                            <label class="form-check form-switch" for="accountNotificationSwitch8">
                                                                                <input name="interLoc" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch8">
                                                                                <span class="d-block">محدودیت مکانی</span>
                                                                                <span class="d-block small">در هنگام خاموش بودن این گزنه موقعیت مکانی فقط به کاربر نمایش داده میشود ولی در صورت روشن بودن اگر کاربر در محدوده تحت پوشش شما نباشد امکان خرید محصول را هم ندارد</span>
                                                            </label>
                                                            <?php
                                                        }?>


                                                  
                                                </div>
                                            </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger-soft" data-bs-dismiss="modal"><i class="bi bi-arrow-right-short"></i> بازگشت</button>
                                    <button type="submit" id="btnS3" class="btn btn-dark-soft"><i class="bi bi-send-plus"></i> ویرایش </button>
                                    </form>
                                    <script>
                                            $(document).ready(function(){
                                                $("#getDataF3").on("submit", function(event){
                                                    event.preventDefault();
                                                    $('#btnS3').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                    var formValues= $('#getDataF3').serialize();

                                                    $.post("../../index.php?controller=create&method=addPlaging&plagin=4", formValues, function(data){
                                                        // Display the returned data in browser
                                                        $('#btnS3').html('ذخیره شد');
                                                        $('#alert3').html(data);
                                                    });
                                                });
                                            });
                                    </script>
                                </div>
                                </div>
                            </div>
                            </div>
                            <form action="../../index.php?controller=create&method=create" method="POST">


                                                                    <!-- Modal -->
                                                    <div class="modal fade" id="noteEdit" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm">
                                                        <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="staticBackdropLabel"><i class="bi bi-pencil-square"></i> یادداشت شما...</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <textarea name="txtE" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                                                            <font style="vertical-align: inherit;">به همراه هر تغییراتی که انجام میدهید یادداشتی برای ما بگذارید و در باره تغییرات توضیح دهید تا سریع تر به تایید برسد</font>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"> <i class="bi bi-arrow-right-short"></i> بستن </button>
                                                            <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">ذخیره</button>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    </div>


                                
                                    <div class="row g-4">
                                        

                                        

                                        
                                
                                        

                                        

                                        
                                        

                                        
                                        
                                        <div class="col-12">
                                            <!-- Blog list table START -->
                                            <div class="card border bg-transparent rounded-3">
                                                <!-- Card header START -->
                                                <div class="card-header bg-transparent border-bottom p-3">
                                                    <div class="d-sm-flex justify-content-sm-between align-items-center">
                                                        <h5 class="mb-2 mb-sm-0"><img src="https://3dicons.sgp1.cdn.digitaloceanspaces.com/v1/dynamic/color/figma-dynamic-color.png" style="width: 30px;" alt=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">افزودنی ها</font></font></h5>
                                                        <a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نصب افزونه </font></font></a>
                                                    </div>
                                                </div>
                                                <!-- Card header END -->

                                                <!-- Card body START -->
                                                <div class="card-body p-3">
                                                <style>
                                        .scroll-example {
                                            overflow: auto;
                                            scrollbar-width: none; /* Firefox */
                                            -ms-overflow-style: none; /* IE 10+ */
                                        }

                                        .scroll-example::-webkit-scrollbar {
                                            width: 0px;
                                            background: transparent; /* Chrome/Safari/Webkit */
                                        }
                                        </style>
                                                        <div class="card-body p-0">
                                           

                                                   

                                                        <div class="row g-4">
					
                                                        <div class="col-sm-6 col-lg-3">
                                                            <div class="card card-body border p-3">
                                                                <div class="d-flex align-items-center">
                                                                    <!-- Icon -->
                                                                    <div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-box" viewBox="0 0 16 16">
                                                                        <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5 8 5.961 14.154 3.5 8.186 1.113zM15 4.239l-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z"/>
                                                                        </svg>
                                                                    </div>
                                                                    <!-- Content -->
                                                                    <div class="ms-3">
                                                                        <h3>شخصی سازی</h3>
                                                                        <a type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="btn btn-light btn-sm">

                                                                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/link-8634497-6856464.png?f=avif" style="width: 20px;" alt="Avatar">

                                                                        بازکردن با... 
                                                                        </a>
                                                                        
                                                                    </div>
                                                                </div>
                                                                
                                                            </div>
                                                            
                                                        </div>

                                                        <div class="col-sm-6 col-lg-3">
                                                            <div class="card card-body border p-3">
                                                                <div class="d-flex align-items-center">
                                                                    <!-- Icon -->
                                                                    <div class="icon-xl fs-1 bg-primary bg-opacity-10 rounded-3 text-primary">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-behance" viewBox="0 0 16 16">
                                                                        <path d="M4.654 3c.461 0 .887.035 1.278.14.39.07.711.216.996.391.286.176.497.426.641.747.14.32.216.711.216 1.137 0 .496-.106.922-.356 1.242-.215.32-.566.606-.997.817.606.176 1.067.496 1.348.922.281.426.461.957.461 1.563 0 .496-.105.922-.285 1.278a2.317 2.317 0 0 1-.782.887c-.32.215-.711.39-1.137.496a5.329 5.329 0 0 1-1.278.176L0 12.803V3h4.654zm-.285 3.978c.39 0 .71-.105.957-.285.246-.18.355-.497.355-.887 0-.216-.035-.426-.105-.567a.981.981 0 0 0-.32-.355 1.84 1.84 0 0 0-.461-.176c-.176-.035-.356-.035-.567-.035H2.17v2.31c0-.005 2.2-.005 2.2-.005zm.105 4.193c.215 0 .426-.035.606-.07.176-.035.356-.106.496-.216s.25-.215.356-.39c.07-.176.14-.391.14-.641 0-.496-.14-.852-.426-1.102-.285-.215-.676-.32-1.137-.32H2.17v2.734h2.305v.005zm6.858-.035c.286.285.711.426 1.278.426.39 0 .746-.106 1.032-.286.285-.215.46-.426.53-.64h1.74c-.286.851-.712 1.457-1.278 1.848-.566.355-1.243.566-2.06.566a4.135 4.135 0 0 1-1.527-.285 2.827 2.827 0 0 1-1.137-.782 2.851 2.851 0 0 1-.712-1.172c-.175-.461-.25-.957-.25-1.528 0-.531.07-1.032.25-1.493.18-.46.426-.852.747-1.207.32-.32.711-.606 1.137-.782a4.018 4.018 0 0 1 1.493-.285c.606 0 1.137.105 1.598.355.46.25.817.532 1.102.958.285.39.496.851.641 1.348.07.496.105.996.07 1.563h-5.15c0 .58.21 1.11.496 1.396zm2.24-3.732c-.25-.25-.642-.391-1.103-.391-.32 0-.566.07-.781.176-.215.105-.356.25-.496.39a.957.957 0 0 0-.25.497c-.036.175-.07.32-.07.46h3.196c-.07-.526-.25-.882-.497-1.132zm-3.127-3.728h3.978v.957h-3.978v-.957z"/>
                                                                        </svg>
                                                                    </div>
                                                                    <!-- Content -->
                                                                    <div class="ms-3">
                                                                        <h3>محدودیت عرضه</h3>
                                                                        <a type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop1" class="btn btn-light btn-sm">

                                                                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/link-8634497-6856464.png?f=avif" style="width: 20px;" alt="Avatar">

                                                                        بازکردن با... 
                                                                        </a>
                                                                        
                                                                    </div>
                                                                </div>
                                                                
                                                            </div>
                                                            
                                                        </div>

                                                        <?php
                                                        if($post['type'] == 5){
                                                            ?>
                                                            <div class="col-sm-6 col-lg-3">
                                                                <div class="card card-body border p-3">
                                                                    <div class="d-flex align-items-center">
                                                                        <!-- Icon -->
                                                                        <div class="icon-xl fs-1 bg-danger bg-opacity-10 rounded-3 text-danger">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-book" viewBox="0 0 16 16">
                                                                            <path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/>
                                                                            </svg>
                                                                        </div>
                                                                        <!-- Content -->
                                                                        <div class="ms-3">
                                                                            <h3>تنظیمات سرویسی</h3>
                                                                            <a type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop2" class="btn btn-light btn-sm">

                                                                            <img src="https://cdn3d.iconscout.com/3d/premium/thumb/link-8634497-6856464.png?f=avif" style="width: 20px;" alt="Avatar">

                                                                            بازکردن با... 
                                                                            </a>
                                                                            
                                                                        </div>
                                                                    </div>
                                                                    
                                                                </div>
                                                                
                                                            </div>

                                                            <?PHP
                                                        }
                                                        ?>
                                         

                                                        <!-- Counter item -->
                                                        <div class="col-sm-6 col-lg-3">
                                                            <div class="card card-body border p-3">
                                                                <div class="d-flex align-items-center">
                                                                    <!-- Icon -->
                                                                    <div class="icon-xl fs-1 bg-success bg-opacity-10 rounded-3 text-success">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                                                                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
                                                                        </svg>                                                                    </div>
                                                                    <!-- Content -->
                                                                    <div class="ms-3">
                                                                        <h3>موقعیت مکانی</h3>
                                                                            <a type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop3" class="btn btn-light btn-sm">

                                                                            <img src="https://cdn3d.iconscout.com/3d/premium/thumb/link-8634497-6856464.png?f=avif" style="width: 20px;" alt="Avatar">

                                                                            بازکردن با... 
                                                                            </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Counter item -->
                                                        

                                                        <!-- Counter item -->
                                                        
                                                        <!-- Counter item -->
                                                        
                                                                            <!-- Counter item -->
                                                        
                                                        

                                                    </div>
                                                        


                                                         
                                                        </div>
                                                        <!-- Button -->

                                                </div>
                                            </div>
                                            <!-- Blog list table END -->
                                        </div>
                                    </div>
                                    <br>


                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
       



                            
                            <div class="bg-primary bg-opacity-10 p-4 mb-4 text-center w-100 rounded">
                                <span style="text-align: right;">  جزعیات فایل را به آن لینک کنید  </span>
                                <h3 style="text-align: right;"><?php echo $post['title']?></h3>
                                <p style="text-align: right;"> <?php echo $post['doc']?></p>
                            </div>
                            <!-- Form START -->

                                                        
                                <!-- Main form -->
                                <div class="row">
    
                                    <!-- Post type START -->
                                    <div class="col-12">
                                        <div class="mb-3">
                                        <div class="mb-3">
                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن صوت</font></font></label>
                                            <!-- Editor toolbar -->
                                            <button id="audio" type="button" class="btn-sm btn btn-outline-dark"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/bell-2871540-2389346.png" style="width: 30px;" alt=""> اپلود فایل صوتی</button>
                                            یا
                                            <button id="audio_code" type="button" class="btn-sm btn btn-outline-dark"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/code-5590552-4652667.png" style="width: 30px;" alt=""> فراخوانی صوت</button>

                                            <!-- Short description -->
                                                <div id="audio_codeH" style="display: none; width: 100%;" class="col-12">
                                                    <div class="mb-3">
                                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل خود را ینویسید</font></font></label>
                                                        <textarea style="width: 450%;" name="audio" class="form-control" rows="15" placeholder=" کد امبد یا ای فریم یا هر نوع کد قابل نمایشی را وارد کنید     "><?php echo $post['audio_code']?></textarea>
                                                    </div>
                                                </div>
                                                <!-- Main toolbar -->

                                                <div id="audioH" style="display: none;" class="mb-3">
                                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ادرس فایل خود را وارد کنید  </font></font></label>
                                                    <input name="audio_code" value="<?php echo $post['audio']?>" type="text" class="form-control" placeholder=" لینک فایل  ">
                                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">    فایل خود را در جایی اپلود کنید و سپس لینک ان را وارد کنید فرمت های فایل باید فرمت هایی باشند که برای مرورگر قابل تفسیر است مانند HTML, XML      </font></font></small>
                                                </div>

                                                    <script>
                                                        $(document).ready(function(){
                                                                $("#audio").on("click", function(event){
                                                                    event.preventDefault();

                                                                    document.getElementById('audioH').style.display = "flex";
                                                                    document.getElementById('audio_codeH').style.display = "none";
                    
                                                                });
                                                            });
                                                    </script>

                                                    <script>
                                                        $(document).ready(function(){
                                                                $("#audio_code").on("click", function(event){
                                                                    event.preventDefault();

                                                                    document.getElementById('audioH').style.display = "none";
                                                                    document.getElementById('audio_codeH').style.display = "flex";
                    
                                                                });
                                                            });
                                                    </script>

                                            
                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> اضافه کردن ویدیو</font></font></label>
                                            <!-- Editor toolbar -->
                                            <button id="video" type="button" class="btn-sm btn btn-outline-dark"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/warning-2872393-2389825.png" style="width: 30px;" alt=""> اپلود فایل ویدیویی</button>
                                            یا
                                            <button id="video_code" type="button" class="btn-sm btn btn-outline-dark"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/cat-3095843-2598657.png" style="width: 30px;" alt=""> فراخوانی ویدیو</button>

                                            <!-- Short description -->
                                                <div id="video_codeH" style="display: none; width: 100%;" class="col-12">
                                                    <div class="mb-3">
                                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل خود را ینویسید</font></font></label>
                                                        <textarea style="width: 450%;" name="video" class="form-control" rows="15" placeholder=" کد امبد یا ای فریم یا هر نوع کد قابل نمایشی را وارد کنید     "><?php echo $post['audio_code']?></textarea>
                                                    </div>
                                                </div>
                                                <!-- Main toolbar -->

                                                <div id="videoH" style="display: none;" class="mb-3">
                                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ادرس فایل خود را وارد کنید  </font></font></label>
                                                    <input name="video_code" value="<?php echo $post['audio']?>" type="text" class="form-control" placeholder=" لینک فایل  ">
                                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">    فایل خود را در جایی اپلود کنید و سپس لینک ان را وارد کنید فرمت های فایل باید فرمت هایی باشند که برای مرورگر قابل تفسیر است مانند HTML, XML      </font></font></small>
                                                </div>

                                                    <script>
                                                        $(document).ready(function(){
                                                                $("#video").on("click", function(event){
                                                                    event.preventDefault();

                                                                    document.getElementById('videoH').style.display = "flex";
                                                                    document.getElementById('video_codeH').style.display = "none";
                    
                                                                });
                                                            });
                                                    </script>

                                                    <script>
                                                        $(document).ready(function(){
                                                                $("#video_code").on("click", function(event){
                                                                    event.preventDefault();

                                                                    document.getElementById('videoH').style.display = "none";
                                                                    document.getElementById('video_codeH').style.display = "flex";
                    
                                                                });
                                                            });
                                                    </script>

                                                    <hr>
                                                    
                                                    <div class="col-12">
                                                        <!-- Post name -->
                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کلید صفحه شما</font></font></label>
                                                            <input id="con-name" name="iframe" type="text" value="<?php echo $post['iframe']?>" class="form-control" placeholder="لینک صفحه را وارد کنید">
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> شما میتوانید با استفاده از این ویژگی صفحه وبی اختصاصی را بعد از خریده شدن مخزن توسط کاربر به ان نمایش دهید این صفحه میتواند شامل ویدیو متن یا فرم برای ثبت سفارش کردن باشد شما میتوانید با ابزار های اماده مانند گوگل فرم فرم های زیادی بسازید و لینک ان را در این قسمت وارد کنید تا کاربر بعد از خرید این مخزن بتواند انهارا برای شما پر کند در واقع این ویژگی پلی ارتباطی برای وبسایت ما و شما است تا بتوانید سفارشات خود را خودتان تحویل بگیرید و در سایت خود نمایش دهید </font></font></small>
                                                        </div>
                                                    </div>

                                                    <div class="col-12">
                                                        <!-- Post name -->
                                                        <div class="mb-3">
                                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">محتوای صفحه اصلی بعد از خرید</font></font></label>
                                                            <textarea required="" id="con-name" name="after_txt" type="text" class="form-control" placeholder="محتوا را وارد کنید"><?php echo $post['after_txt']?></textarea>
                                                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وقتی مشتریان محصول شما را خریداری میکنند به قسمتی میرومد که میتوانند محتوای بعد از خرید را مشاهده کنند این متن صفحه ای است که خریداران آن را به عنوان اولین متن بعد از خرید میبینند</font></font></small>
                                                            <a href="dashboard.php?content=txtEdit" class="btn btn-light btn-sm">

                                                            <img src="https://seeklogo.com/images/M/microsoft-365-logo-6D6E233C94-seeklogo.com.png" style="width: 20px;" alt="Avatar">

                                                            ویرایشگر متن ...
                                                            </a>
                                                        </div>
                                                    </div>

                                                    <br>
                                                    <div class="container">
                                                        <div class="row pb-4">
                                                                <div class="col-12">
                                                            <!-- Title -->
                                                                    <div class="d-sm-flex align-items-center">
                                                                        <h1 class="mb-2 mb-sm-0 h2">فایل ها <span class="">  <img style="width:40px;" src="https://emojipedia-us.s3.amazonaws.com/source/microsoft-teams/337/backhand-index-pointing-down_1f447.png" alt="">  </span></h1>			
                                                                        &nbsp
                                                                        <a href="../../core/rtl/dashboard.php?content=createFile&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ایجاد فایل جدید</a>
                                                                        &nbsp
                                                                        <a href="../../core/rtl/dashboard.php?content=fils&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-light mb-0"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/folder-5734346-4811691.png" style="width: 20px;" alt=""> مدیرت فایل</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-12">
                                                            
                                                            <!-- Post list table START -->
                                                            <div class="card border bg-transparent rounded-3">

                                                                <!-- Card body START -->
                                                                <div class="card-body p-3">

                                                                <!-- Search and select START -->
                                                                <div class="row g-3 align-items-center justify-content-between mb-3">
                                                                    <!-- Search -->
                                                                    <div class="col-md-8">
                                                                    <form class="rounded position-relative">
                                                                        <input class="form-control pe-5 bg-transparent" type="search" placeholder="سرچ کن" aria-label="Search">
                                                                        <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                                                    </form>
                                                                    </div>

                                                                    <!-- Select option -->
                                                                    <div class="col-md-3">
                                                                    <!-- Short by filter -->
                                                                    <form>
                                                                        <select class="form-select z-index-9 bg-transparent" aria-label=".form-select-sm">
                                                                        <option value="">مرتب کردن به ترتیب</option>
                                                                        <option>ازاد</option>
                                                                        <option>بدون پسورد</option>
                                                                        <option>دارای پسورد</option>
                                                                        <option>فایل فشرده</option>
                                                                        <option>فایل معمولی</option>
                                                                        </select>
                                                                    </form>
                                                                    </div>
                                                                </div>
                                                                <!-- Search and select END -->

                                                                <!-- Post list table START -->
                                                                <div class="table-responsive border-0">
                                                                    <table class="table align-middle p-4 mb-0 table-hover table-shrink">
                                                                    <!-- Table head -->
                                                                    <thead class="table-dark">
                                                                        <tr>
                                                                        <th scope="col" class="border-0 rounded-start">نام فایل</th>
                                                                        <th scope="col" class="border-0">توضیحات</th>
                                                                        <th scope="col" class="border-0">زمان انتشار</th>
                                                                        <th scope="col" class="border-0">دسته بندی</th>
                                                                        <th scope="col" class="border-0">وضعیت</th>
                                                                        <th scope="col" class="border-0 rounded-end">عملگرها</th>
                                                                        </tr>
                                                                    </thead>

                                                                    <!-- Table body START -->
                                                                    <tbody class="border-top-0">
                                                                        <?php
                                                                        $query_1212 = mysqli_query($con, 'select * from books where userId="'.$user['iduser'].'" and piperlineId="'.$post['idPost'].'" order by createDate Desc');
                                                                        $file_hash = mysqli_query($con, 'select * from books where userId="'.$_SESSION['id'].'" and piperlineId="'.$post['idPost'].'" order by createDate Desc');
                                                                        $file = mysqli_fetch_assoc($query_1212);
                                                                        if($file){
                                                                            while($res=mysqli_fetch_assoc($file_hash)){
                                                                                ?>
                                                                                <!-- Table item -->
                                                                                <tr>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <h6 class="course-title mt-2 mt-md-0 mb-0"><img style="width: 35px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/documents-6356606-5231758.png" alt=""> <a href="#"><?php echo $res['name']?></a></h6>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <h6 class="mb-0"><a href="#"><?php echo $res['doc']?></a></h6>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td><?php echo $res['createDate']?></td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <a href="#" class="badge text-bg-warning mb-2"><i class="fas fa-circle me-2 small fw-bold"></i>Technology</a>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <span class="badge bg-success bg-opacity-10 text-success mb-2">Live</span>
                                                                                    </td>
                                                                                    <!-- Table data -->
                                                                                    <td>
                                                                                        <div class="d-flex gap-2">
                                                                                            <a href="../../index.php?controller=create&method=deleteFile&id=<?php echo $res['idBook']?>" class="btn btn-danger btn-sm">حذف</a>
                                                                                            <a href="../../core/rtl/dashboard.php?content=editFile&id=<?php echo $res['idBook']?>" class="btn btn-outline-dark btn-sm">ویرایش</a>

                                                                                            <a href="<?php echo $res['file']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Edit"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/linking-3711816-3105290.png" style="width: 35px;" alt=""> </a>
                                                                                        </div>
                                                                                    </td>
                                                                                </tr>

                                                                                

                                                                                <?php
                                                                            }

                                                                        }else{
                                                                            ?>
                                                                            <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                                                                <!-- SVG shape START -->
                                                                                <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                                                                <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                                                                    <g>
                                                                                    <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                                                                    <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                                                                    c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                                                                    </g>
                                                                                </svg>
                                                                                </figure>
                                                                                <!-- SVG shape START -->
                                                                                <!-- Content -->
                                                                                <h1 class="display-1 text-primary"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-2872691-2409395.png" style="width: 50%;" alt=""> </h1>
                                                                                <h2>پست ایجاد نشد</h2>
                                                                                <p>متاسفیم ما نمیتوانیم این فایل را پردازش کنیم دوباره ان را وارسی کنید شاید در داده ها مشکلی است</p>
                                                                                <a href="../../core/rtl/dashboard.php?content=createPost" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>بازگشت به فایل</a>
                                                                            </div>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    
                                                                   
                                                                        
                                                                    </tbody>
                                                                    <!-- Table body END -->
                                                                    </table>
                                                                </div>
                                                                <!-- Post list table END -->

                                                                <!-- Pagination START -->
                                                                <div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
                                                                    <!-- Content -->
                                                                    <p class="mb-sm-0 text-center text-sm-start">Showing 1 to 8 of 20 entries</p>
                                                                    <!-- Pagination -->
                                                                    <nav class="mb-sm-0 d-flex justify-content-center" aria-label="navigation">
                                                                    <ul class="pagination pagination-sm pagination-bordered mb-0">
                                                                        <li class="page-item disabled">
                                                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Prev</a>
                                                                        </li>
                                                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                                        <li class="page-item disabled"><a class="page-link" href="#">..</a></li>
                                                                        <li class="page-item"><a class="page-link" href="#">15</a></li>
                                                                        <li class="page-item">
                                                                        <a class="page-link" href="#">Next</a>
                                                                        </li>
                                                                    </ul>
                                                                    </nav>
                                                                </div>
                                                                <!-- Pagination END -->
                                                                </div>
                                                            </div>
                                                            <!-- Post list table END -->
                                                        </div>
                                                        </div>
                                                    </div>
                                                    <br>

                                                    <div class="mb-3">
                                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات تکمیلی بعد از خرید محصول</font></font></label>
                                                        <textarea name="doc_master" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"><?php echo $post['doc_master']?></textarea>
                                                    </div>
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">    منابع به همراه لینک </font></font></label>
                                                        <textarea name="doc_creator" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"><?php echo $post['doc_creator']?></textarea>
                                                    </div>
                                                    <style>
                                                        .switch {
                                                        position: relative;
                                                        display: inline-block;
                                                        width: 60px;
                                                        height: 34px;
                                                        }

                                                        /* Hide default HTML checkbox */
                                                        .switch input {
                                                        opacity: 0;
                                                        width: 0;
                                                        height: 0;
                                                        }

                                                        /* The slider */
                                                        .slider {
                                                        position: absolute;
                                                        cursor: pointer;
                                                        top: 0;
                                                        left: 0;
                                                        right: 0;
                                                        bottom: 0;
                                                        background-color: #ccc;
                                                        -webkit-transition: .4s;
                                                        transition: .4s;
                                                        }

                                                        .slider:before {
                                                        position: absolute;
                                                        content: "";
                                                        height: 26px;
                                                        width: 26px;
                                                        left: 4px;
                                                        bottom: 4px;
                                                        background-color: white;
                                                        -webkit-transition: .4s;
                                                        transition: .4s;
                                                        }

                                                        input:checked + .slider {
                                                        background-color: #2196F3;
                                                        }

                                                        input:focus + .slider {
                                                        box-shadow: 0 0 1px #2196F3;
                                                        }

                                                        input:checked + .slider:before {
                                                        -webkit-transform: translateX(26px);
                                                        -ms-transform: translateX(26px);
                                                        transform: translateX(26px);
                                                        }

                                                        /* Rounded sliders */
                                                        .slider.round {
                                                        border-radius: 34px;
                                                        }

                                                        .slider.round:before {
                                                        border-radius: 50%;
                                                        }
                                                    </style>
                                                    <br/>
                                                                                          <div class="row">                                   
                                                        <div class="col-12">
                                                            
                                                            <!-- Post list table START -->
                                                            <div class="card border bg-transparent rounded-3">

                                                                <!-- Card body START -->
                                                                <div class="card-body p-3">
                                                                <h3><img src="https://cdn3d.iconscout.com/3d/premium/thumb/broken-chain-4029199-3337891.png" style="width: 35px;" alt="">امکانات هنگام خرید</h3>
                                                                <div class="card-body">
                                                                <div class="col-12">
                                                                <!-- Title -->
                                                                    <div class="d-sm-flex align-items-center">
                                                                        <h5 class="mb-2 mb-sm-0 h5"><span class="">  <img style="width:40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/documents-6356674-5231783.png" alt="">  </span>تعریف فیلد اطلاعات</h5>			
                                                                        &nbsp;
                                                                        <a href="../../core/rtl/dashboard.php?content=createFild&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ایجاد فیلد جدید</a>
                                                                        &nbsp;
                                                                        <a href="../../core/rtl/dashboard.php?content=Filds&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-light mb-0"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/lifebuoy-4029215-3337916.png" style="width: 20px;" alt=""> فیلد ها</a>
                                                                    </div>
                                                                    <div class="d-sm-flex align-items-center">
                                                                        <h5 class="mb-2 mb-sm-0 h5"><span class="">  <img style="width:40px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/offer-chat-6861001-5628258.png?f=avif" alt="">  </span>فعالسازی تخفیف ویژه برای کاربران کلاب</h5>			
                                                                        &nbsp;
                                                                        <a href="dashboard.php?content=createOFFER&id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ایجاد کد تحفیف</a>
                                                                        <?php
                                                                        if($post['statusOFF'] == 1){
                                                                            ?>
                                                                            <span class="badge bg-success ms-1">تخفیف فعال</span>
                                                                            <?php
                                                                        }else{
                                                                            ?>
                                                                            <span class="badge bg-success ms-1">تخفیف غیرفعال</span>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                              




                                                                    <!-- End List Group -->
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <!-- Post list table END -->
                                                        </div>
                                                    </div>
                                                    <br> 

                                                    <div class="row">                                   
                                                        <div class="col-12">
                                                            
                                                            <!-- Post list table START -->
                                                            <div class="card border bg-transparent rounded-3">

                                                                <!-- Card body START -->
                                                                <div class="card-body p-3">
                                                                <h3><img src="https://cdn3d.iconscout.com/3d/premium/thumb/application-5590970-4652973.png" style="width: 35px;" alt=""> امکانات بعد از خرید</h3>
                                                                <div class="card-body">
                                                                    <small class="card-subtitle">گزینه ها را روشن و یا خاموش کنید</small>

                                                                    <!-- List Group -->
                                                                    <div class="list-group list-group-flush list-group-no-gutters">
                                                                        <!-- Item -->
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                            <input name="info" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5" checked="">
                                                                            <span class="d-block">نمایش مشخصات</span>
                                                                            <span class="d-block small text-muted">بعد از خرید این امکان را به کاربر بدهید تا مشخصات ایمیل  شما را ببیند</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
                                                                        <!-- End Item -->

                                                                        <!-- Item -->
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch6">
                                                                            <input name="number" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch6" checked="">
                                                                            <span class="d-block">نمایش شماره موبایل <span class="badge bg-success ms-1">بهتر است روشن باشد  </span></span>
                                                                            <span class="d-block small text-muted">شماره موبایل خود را به خریدار بدهید</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
                                                                        <!-- End Item -->

                                                                        <!-- Item -->
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch7">
                                                                            <input name="facebook" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch7">
                                                                            <span class="d-block">چت در فیسبوک <span class="badge bg-success ms-1">متصل کنید</span></span>
                                                                            <span class="d-block small text-muted">به کاربر این امکان را بدهید تا در فیسبوک با شما چت کند و در ارطبات باشد</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
                                                                        <!-- End Item -->

                                                                        <!-- Item -->
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch8">
                                                                            <input name="spacify" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch8">
                                                                            <span class="d-block">چت در اسپیسیفای</span>
                                                                            <span class="d-block small text-muted">کاربر میتواند به پروفایل کاربری شما در کارگذاری که همان برنامه اسپیسیفای است پیام ارسال کند</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        <br>
                                                                        <h5>وضعیت انتشار</h5>
                                                                        </div>
                                                                        <!-- End Item -->
                                                                        <!-- Item -->
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch8">
                                                                            <input name="published" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch8" checked="">
                                                                            <span class="d-block">در پیپرلاین منتشر کن</span>
                                                                            <span class="d-block small text-muted"> میتوانید در هر بازه زمانی که دوست دارید پست را از دسترس خارچ کنید    </span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
                                                                        <!-- End Item -->
                                                                    </div>
                                                                    <!-- End List Group -->
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <!-- Post list table END -->
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="container">
                                                            <div class="row g-0">
                                                                <div class="col-12 bg-light p-2 p-sm-4 rounded-3">
                                                                    <?php
                                                                    if($post['top'] == 1){
                                                                        ?>
                                                                        <div class="alert alert-primary" role="alert">
                                                                            <span>این ویژگی در حال حاضر برای شما فعال است با فعال کردن مجدد تعداد تکرار و دور الگوریتم را بیشتر و قوی تر میکنید</span>
                                                                        </div>
                                                                        <?php
                                                                    } 
                                                                    ?>
                                                                    <h1><img src="https://cdn3d.iconscout.com/3d/premium/thumb/add-apps-4059075-3363998.png" style="width: 35px;" alt=""> پست ویژه</h1> 
                                                                    <font style="vertical-align: inherit;">   پست شما را با استفاده از الگوریتم هوش مصنوعی به مخاطب واقعی و کارا وصل میکنیم</font>
                                                                    <hr>
                                                                    <?php
                                                                    if(! $post['top'] == 1){
                                                                        ?>
                                                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                                                            <span>قیمت ویژگی</span>
                                            
                                                                            <span class="h5 mb-0">20 هزار تومان</span>
                                                                        </div>
                                                                        <!-- Rounded switch -->
                                                                        <label class="switch">
                                                                        <input name="AI" type="checkbox">
                                                                        <span class="slider round"></span>
                                                                        </label> 
                                                                        <?php
                                                                    }
                                                                    ?>
                                                        

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <input type="text" style="display: none;" name="idPOST" value="<?php echo $_GET['id']?>">
                                                    <br>
                                                    <div class="container">
                                                            <div class="row g-0">
                                                                <div class="col-12 bg-light p-2 p-sm-4 rounded-3">
                                                                    <?php
                                                                    if($post['SEO'] == 1){
                                                                        ?>
                                                                        <div class="alert alert-primary" role="alert">
                                                                            <span>این ویژگی در حال حاضر برای شما فعال است با فعال کردن مجدد تعداد تکرار و دور الگوریتم را بیشتر و قوی تر میکنید</span>
                                                                        </div>
                                                                        <?php
                                                                    } 
                                                                    ?>
                                                                    <h1><img src="https://cdn3d.iconscout.com/3d/premium/thumb/global-seo-5152809-4315324.png" style="width: 40px;" alt="">  سئو و بازاریابی</h1> 
                                                                    <font style="vertical-align: inherit;">   برای محصول شما به شکل جداگانه و مجزا الگوریتم های سئو و بازاریابی را فعلا میکنیم تا مشتری بیشتری جذب کنید  </font>
                                                                    <hr>
                                                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                                                        
                                                                    <?php
                                                                    if(! $post['SEO'] == 1){
                                                                        ?>
                                                                         <span> قیمت خدمات</span>
                                                                            <span class="h5 mb-0">20 هزار تومان</span>
                                                                        </div>
                                                                        <!-- Rounded switch -->
                                                                        <label class="switch">
                                                                        <input name="SEO" type="checkbox">
                                                                        <span class="slider round"></span>
                                                                        </label> 
                                                                        <?php
                                                                    }
                                                                    ?>
                                        

                                                                </div>
                                                            </div>
                                                    </div>
                                                    <br>

        

                                                    <button class="btn btn-dark-soft" type="button" data-bs-toggle="modal" data-bs-target="#noteEdit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-pencil-square"></i> افزودن یادداشت بر روی تغییر ..  </font></font></button>
                                                    <button class="btn btn-primary w-100" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ذخیره تغییرات</font></font></button>

                                            </div>	
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Post type END -->




                            </form>
                            <!-- Form END -->
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }elseif(isset($_GET['Edit'])){
                $query_search = mysqli_query($con, 'select * from posts where idPost="'.$_GET['Edit'].'" ');
                $post = mysqli_fetch_assoc($query_search);
                if($post){

                    ?>
                    <div class="row">
                        <div class="col-12">
                            <!-- Chart START -->
                            <div class="card border">
                                <!-- Card body -->
                                <div class="card-body">
                        <!-- Form START -->
                        <form action="../../index.php?controller=create&method=editDraft" method="POST">
                        <!-- Main form -->
                        <div class="row">
                            <div class="col-12">
                            <!-- Post name -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></label>
                                <input required="" id="con-name" name="title" type="text" class="form-control" value="<?php echo $post['title']?>" placeholder="نام پست">
                                <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بهشت در حال حرکت تقسیم دو دریا زن بزرگ روح وسط</font></font></small>
                            </div>
                            </div>
                     
                        <!-- Post type END -->
                        <input type="text" style="display: none;" name="idPOST" value="<?php echo $_GET['Edit']?>">
                        <!-- Short description -->
                        <div class="col-12">
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیح کوتاه</font></font></label>
                                <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"><?php echo $post['doc']?></textarea>
                            </div>
                        </div>
    
                        <!-- Main toolbar -->
                            <div class="col-md-12">
                            <!-- Subject -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بدن پست</font></font></label>
                                <!-- Editor toolbar -->
                                <button id="Draft_file" type="button" class="btn-sm btn btn-outline-dark">اپلود فایل بدنه</button>
                                یا
                                <button id="Draft" type="button" class="btn-sm btn btn-outline-dark">نوشتن بدنه</button>
    
                                <!-- Short description -->
                                    <div id="Draft_SHOW" style="display: none; width: 100%;" class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل خود را ینویسید</font></font></label>
                                            <textarea class="some-css-class" name="draft" style="width: 100%; height: 500px; border:none;"></textarea>                                        </div>
                                        </div>
                                    <!-- Main toolbar -->
    
                                    <div id="Draft_fileSHOW" style="display: none;" class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ادرس فایل خود را وارد کنید  </font></font></label>
                                        <input name="draft_file" type="text" class="form-control" value="<?php echo $post['draft_file']?>" placeholder=" لینک فایل  ">
                                        <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">    فایل خود را در جایی اپلود کنید و سپس لینک ان را وارد کنید فرمت های فایل باید فرمت هایی باشند که برای مرورگر قابل تفسیر است مانند HTML, XML      </font></font></small>
                                    </div>
    
                                        <script>
                                            $(document).ready(function(){
                                                    $("#Draft").on("click", function(event){
                                                        event.preventDefault();
    
                                                        document.getElementById('Draft_SHOW').style.display = "flex";
                                                        document.getElementById('Draft_fileSHOW').style.display = "none";
        
                                                    });
                                                });
                                        </script>
    
                                        <script>
                                            $(document).ready(function(){
                                                    $("#Draft_file").on("click", function(event){
                                                        event.preventDefault();
    
                                                        document.getElementById('Draft_SHOW').style.display = "none";
                                                        document.getElementById('Draft_fileSHOW').style.display = "flex";
        
                                                    });
                                                });
                                        </script>
    
                                
                                </div>	
                            </div>
                            <div class="col-12">
                            <div class="mb-3">
                            <!-- Image -->
                            <div class="position-relative">
                                <h6 class="my-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تصویر پست را در اینجا آپلود کنید یا </font></font><a href="#!" class="text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرور کنید</font></font></a></h6>
                                <label class="w-100" style="cursor:pointer;">
                                <span> 
                                    <input name="art" class="form-control stretched-link" type="text" name="my-image" id="image" value="<?php echo $post['art']?>" accept="image/gif, image/jpeg, image/png">
                                </span>
                                </label>
                            </div>
                            <p class="small mb-0 mt-2"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توجه:</font></font></b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل تصویری خود را در <a href="https://up.20script.ir/index.php">اینجا</a> اپلود کرده و سپس لینک ان را در فیلد وارد کنید      </font><font style="vertical-align: inherit;"> </font><font style="vertical-align: inherit;"></font></font></p>
                            </div>
                            </div>
                            <div class="col-lg-7">
                            <!-- Tags -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع قیمتگذاری</font></font></label>
                                <select name="price" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                                    <?php 
                                    if($post['price'] == 0){
                                        $price = 'برای کل سرویس';
                                    }else{
                                        $price = 'برای هر یک عدد از محصولی که درون این سرویس است';
                                    }
                                    ?>
                                    <option selected="<?php echo $post['price']?>"><?php echo $price?>(فعلی)</option>
                                    <option select="0">برای کل سرویس</option>
                                    <option value="1">برای هر یک عدد از محصولی که درون این سرویس است</option>
           
                                </select>
                                <small><font style="vertical-align: inherit;">تایین کنید نوع محصولاتان چیست ایا کاربر میتواند تعداد دلخواه از این سرویس سفارش دهد و قیمت برای هر یک دانه از این محصول است و یا این قیمت برای کل این سرویس است</font></small>
                            </div>
                            <!-- Tags -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برچسب ها</font></font></label>
                                <textarea name="tag" class="form-control" rows="1" placeholder="تجارت، ورزش ..."><?php echo $post['tag']?></textarea>
                                <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حداکثر 14 کلمه کلیدی </font><font style="vertical-align: inherit;">کلمات کلیدی همگی باید با حروف کوچک و با کاما از هم جدا شوند. </font><font style="vertical-align: inherit;">به عنوان مثال جاوا اسکریپت، واکنش، بازاریابی.</font></font></small>
                            </div>
                            </div>
                            <div class="col-lg-5">
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قیمت گذاری (تومان)</font></font></label>
                                <input type="number" name="pay" class="form-control" value="<?php echo $post['pay']?>" rows="1" placeholder="قیمت اسفاده از محصول خود را به تومان بزنید">
                            </div>
                            <!-- Message -->
                            <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دسته بندی</font></font></label>
                                <select name="category" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                                <option selected="<?php echo $post['category']?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سبک زندگی</font></font></option>
                                <option value="1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فن آوری</font></font></option>
                                <option value="2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مسافرت رفتن</font></font></option>
                                <option value="3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کسب و کار</font></font></option>
                                <option value="4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ورزش ها</font></font></option>
                                <option value="5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازار یابی</font></font></option>
                                </select>
                            </div>
                            </div>
                            <div class="col-12">
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" value="" id="postCheck">
                                <label class="form-check-label" for="postCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                                این پست برجسته شود؟
                                </font></font></label>
                            </div>
                            </div>
                            <!-- Create post button -->
                            <div class="col-md-12 text-start">
                            <button class="btn btn-primary w-100" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش مخزن</font></font></button>
                            </div>
                        </div>
                        </form>
                        <!-- Form END -->
                                </div>
                            </div>
                            <!-- Chart END -->
                    </div>
                    <?php
                }
            }elseif(isset($_GET['alert'])){
                ?>
                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                                <!-- Form START -->
                                <form>
                    
                                <section class="overflow-hidden">
                                    <div class="container">
                                        <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 class="display-1 text-primary"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/notification-2872691-2409395.png" style="width: 50%;" alt=""> </h1>
                                        <h2>پست ایجاد نشد</h2>
                                        <p>متاسفیم ما نمیتوانیم این فایل را پردازش کنیم دوباره ان را وارسی کنید شاید در داده ها مشکلی است</p>
                                        <a href="../../core/rtl/dashboard.php?content=createPost" class="btn btn-danger-soft mt-3"><i class="fas fa-long-arrow-alt-left me-3"></i>بازگشت به فایل</a>
                                    </div>
                                    </div>
                                    </div>
                                </section>
                
                            
                            
                                </form>
                                <!-- Form END -->
                            </div>
                        </div>
                        <!-- Chart END -->
                    </div>
                </div>
                <?php
            }else{
                ?>
                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                    <!-- Form START -->
                    <form action="../../index.php?controller=create&method=draft" method="POST">
                    <!-- Main form -->
                    <div class="row">
                        <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></label>
                            <input required="" id="con-name" name="title" type="text" class="form-control" placeholder="نام پست">
                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بهشت در حال حرکت تقسیم دو دریا زن بزرگ روح وسط</font></font></small>
                        </div>
                        </div>
                        <!-- Post type START -->
                        <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع پست</font></font></label>
                            <div class="d-flex flex-wrap gap-3">
                            <!-- Post type item -->
                            <div class="flex-fill">
                                <input type="radio" class="btn-check" name="post" id="option">
                                <label class="btn btn-outline-light w-100" for="option">
                                <i class="bi bi-chat-left-text fs-1"></i>
                                <span class="d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پست</font></font></span>
                                </label>
                            </div>
                            <!-- Post type item -->
                            <div class="flex-fill">
                                <input type="radio" class="btn-check" name="corse" id="option2">
                                <label class="btn btn-outline-light w-100" for="option2">
                                <i class="bi bi-camera-reels fs-1"></i>
                                <span class="d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دوره اموزشی</font></font></span>
                                </label>
                            </div>
                            <!-- Post type item -->
                            <div class="flex-fill">
                                <input type="radio" class="btn-check" name="file" id="option3">
                                <label class="btn btn-outline-light w-100" for="option3">
                                <i class="bi bi-ui-checks-grid fs-1"></i>
                                <span class="d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فایل و منبع</font></font></span>
                                </label>
                            </div>
                            <!-- Post type item -->
                            <div class="flex-fill">
                                <input type="radio" class="btn-check" name="video" id="option5">
                                <label class="btn btn-outline-light w-100" for="option5">
                                <i class="bi bi-camera-reels fs-1"></i>
                                <span class="d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویدئو</font></font></span>
                                </label>
                            </div>
                            <!-- Post type item -->
                            <div class="flex-fill">
                                <input type="radio" class="btn-check" name="blog" id="option6">
                                <label class="btn btn-outline-light w-100" for="option6">
                                <i class="bi bi-chat-square fs-1"></i>
                                <span class="d-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خدمات </font></font></span>
                                </label>
                            </div>
                            <!-- Post type item -->
                        </div>
                        </div>
                    </div>
                    <!-- Post type END -->
                    
                    <!-- Short description -->
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیح کوتاه</font></font></label>
                            <textarea name="doc" class="form-control" rows="3" placeholder="توضیحات اضافه کنید"></textarea>
                        </div>
                    </div>

                    <!-- Main toolbar -->
                        <div class="col-md-12">
                        <!-- Subject -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بدن پست</font></font></label>
                            <!-- Editor toolbar -->
                            <button id="Draft_file" type="button" class="btn-sm btn btn-outline-dark">اپلود فایل بدنه</button>
                            یا
                            <button id="Draft" type="button" class="btn-sm btn btn-outline-dark">نوشتن بدنه</button>

                            <!-- Short description -->
                                <div id="Draft_SHOW" style="display: none; width: 100%;" class="col-12">
                                    <div class="mb-3">
                                        <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل خود را ینویسید</font></font></label>
                                        <textarea style="width: 450%;" name="draft" class="form-control" rows="15" placeholder="  فایل خود را بنویسید      "></textarea>
                                    </div>
                                </div>
                                <!-- Main toolbar -->

                                <div id="Draft_fileSHOW" style="display: none;" class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> ادرس فایل خود را وارد کنید  </font></font></label>
                                    <input name="draft_file" type="text" class="form-control" placeholder=" لینک فایل  ">
                                    <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">    فایل خود را در جایی اپلود کنید و سپس لینک ان را وارد کنید فرمت های فایل باید فرمت هایی باشند که برای مرورگر قابل تفسیر است مانند HTML, XML      </font></font></small>
                                </div>

                                    <script>
                                        $(document).ready(function(){
                                                $("#Draft").on("click", function(event){
                                                    event.preventDefault();

                                                    document.getElementById('Draft_SHOW').style.display = "flex";
                                                    document.getElementById('Draft_fileSHOW').style.display = "none";
    
                                                });
                                            });
                                    </script>

                                    <script>
                                        $(document).ready(function(){
                                                $("#Draft_file").on("click", function(event){
                                                    event.preventDefault();

                                                    document.getElementById('Draft_SHOW').style.display = "none";
                                                    document.getElementById('Draft_fileSHOW').style.display = "flex";
    
                                                });
                                            });
                                    </script>

                            
                            </div>	
                        </div>
                        <div class="col-12">
                        <div class="mb-3">
                        <!-- Image -->
                        <div class="position-relative">
                            <h6 class="my-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تصویر پست را در اینجا آپلود کنید یا </font></font><a href="#!" class="text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرور کنید</font></font></a></h6>
                            <label class="w-100" style="cursor:pointer;">
                            <span> 
                                <input name="art" class="form-control stretched-link" type="text" name="my-image" id="image" accept="image/gif, image/jpeg, image/png">
                            </span>
                            </label>
                        </div>
                        <p class="small mb-0 mt-2"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توجه:</font></font></b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> فایل تصویری خود را در <a href="https://up.20script.ir/index.php">اینجا</a> اپلود کرده و سپس لینک ان را در فیلد وارد کنید      </font><font style="vertical-align: inherit;"> </font><font style="vertical-align: inherit;"></font></font></p>
                        </div>
                        </div>
                        <div class="col-lg-7">
                        <!-- Tags -->
                        <div class="mb-3">
                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع قیمتگذاری</font></font></label>
                                <select name="price" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                
                                    <option select="0">برای کل سرویس</option>
                                    <option value="1">برای هر یک عدد از محصولی که درون این سرویس است</option>
           
                                </select>
                                <small><font style="vertical-align: inherit;">تایین کنید نوع محصولاتان چیست ایا کاربر میتواند تعداد دلخواه از این سرویس سفارش دهد و قیمت برای هر یک دانه از این محصول است و یا این قیمت برای کل این سرویس است</font></small>
                        </div>
                        <!-- Tags -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">برچسب ها</font></font></label>
                            <textarea name="tag" class="form-control" rows="1" placeholder="تجارت، ورزش ..." id="textera_tags"></textarea>
                            <button type="button" class="btn btn-dark btn-xs" id="tagsAcc">استفاده از برچسب های قبلی</button>
                            <small><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حداکثر 14 کلمه کلیدی </font><font style="vertical-align: inherit;">کلمات کلیدی همگی باید با حروف کوچک و با کاما از هم جدا شوند. </font><font style="vertical-align: inherit;">به عنوان مثال جاوا اسکریپت، واکنش، بازاریابی.</font></font></small>
                        </div>
                        </div>



                                            <script>
                                            $('#tagsAcc').click(function(event){
                                            event.preventDefault();
                                            $('#tagsAcc').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp درحال بارگیری...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=create&method=tag",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#tagsAcc').html('استفاده از برچست های قبلی');
                                                $('#textera_tags').html(data);
                                                })

                                            })
                                            </script>
                        <div class="col-lg-5">
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> قیمت گذاری</font></font></label>
                            <input type="number" name="pay" class="form-control" rows="1" placeholder="قیمت اسفاده از محصول خود را به تومان بزنید">
                        </div>
                        <!-- Message -->
                        <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دسته بندی</font></font></label>
                            <select name="category" class="form-select" aria-label="نمونه انتخاب پیش فرض">
                            <option selected=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سبک زندگی</font></font></option>
                            <option value="1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فن آوری</font></font></option>
                            <option value="2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مسافرت رفتن</font></font></option>
                            <option value="3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کسب و کار</font></font></option>
                            <option value="4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ورزش ها</font></font></option>
                            <option value="5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازار یابی</font></font></option>
                            </select>
                        </div>
                        </div>
                        <div class="col-12">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" id="postCheck">
                            <label class="form-check-label" for="postCheck"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                            این پست برجسته شود؟
                            </font></font></label>
                        </div>
                        </div>
                        <!-- Create post button -->
                        <div class="col-md-12 text-start">
                        <button class="btn btn-primary w-100" type="submit"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایجاد پست</font></font></button>
                        </div>
                    </div>
                    </form>
                    <!-- Form END -->
                            </div>
                        </div>
                        <!-- Chart END -->
                </div>
                <?php
            }
            ?>
        </div>
	</div>
</section>