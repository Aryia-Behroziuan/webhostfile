<section class="pt-3 pt-lg-5">
	<div class="container">
		<div class="row">
      <!-- Title -->
      <div class="mb-4">
        <h2 class="m-0"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/preview-watermark/download-folder-5568716-4644433.mp4" type="video/mp4" style="width: 120px;" autoplay="autoplay" loop="loop"></video> <font style="vertical-align: inherit;">به روزرسانی</font></font></h2>
      </div>
			
			<!-- Filter START -->
			<aside class="col-xl-4 col-xxl-3">
				<!-- Responsive offcanvas body START -->
				<div class="offcanvas-xl offcanvas-end" tabindex="-1" id="offcanvasSidebar" aria-labelledby="offcanvasSidebarLabel">
					<div class="offcanvas-header bg-light">
						<h5 class="offcanvas-title" id="offcanvasSidebarLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فیلتر پیشرفته</font></font></h5>
						<button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar" aria-label="نزدیک"></button>
					</div>
					<div class="offcanvas-body flex-column p-3 p-xl-0">
						<form class="border rounded-2">





                        <style>
                            .scroll-example {
                                overflow: auto;
                                scrollbar-width: none; /* Firefox */
                                -ms-overflow-style: none; /* IE 10+ */
                            }

                            .scroll-example::-webkit-scrollbar {
                                    width: 0px;
                                    background: transparent; /* Chrome/Safari/Webkit */
                            }
                        </style>


							<!-- Availability START -->
							<div class="card-body">	
								<!-- Title -->
								<h6 class="mb-3 mt-3">&nbsp;&nbsp;&nbsp;<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشخصات حساب</font></font></h6>
                                
								
							</div>
							<!-- Availability END -->

							<hr class="my-0"> <!-- Divider -->

		
					

						</form><!-- Form End -->
                        <div class="col-lg-4">
            
                            <!-- Shipment information -->
                            <ul class="list-group list-group-borderless">
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مدل جساب: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['iduser']?>M_LNPI</font></font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> نسخه فعلی پایدار: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font>PL1.0.0.0</font></span>
                                </li>
                                <li class="list-group-item py-0">
                                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالکیت حقوقی: </font></font></span>
                                <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo $user['title']?></font></span>
                                </li>
          
          
                            </ul>
        
        
                        </div>
					</div>
					<!-- Buttons -->
					<div class="d-flex justify-content-between p-2 p-xl-0 mt-xl-3">
						<button class="btn btn-link p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">همه را پاک کن</font></font></button>
						<button class="btn btn-primary mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نتیجه فیلتر</font></font></button>
					</div>
				</div>
				<!-- Responsive offcanvas body END -->
			</aside>
			<!-- Filter END -->

			<!-- Main part START -->
			<div class="col-xl-9">



                <div class="card border">
                    <!-- Card body -->
                    <div class="card-body scroll-example" style="height: 700px; overflow-y:scroll; overflow-x:scroll;">
                        <!-- Product START -->
                        <div class="row g-4 scroll-example" id="show_pv">



                                                            <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 id="sppiner_se" class="display-1 text-primary"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/preview-watermark/clock-5568708-4644425.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video></h1>
                                        <h2 id="sppiner_se1">هیچ پکیج بروزرسانی یافت نشد</h2>
                                        <p id="sppiner_se2">هر وقت حساب شما واجد شرایط به روز رسانی بود خودمان به شما اطلاع میدهیم</p>
                                    </div>
                                </div>
                                











                        </div>
                        <!-- Product END -->
                    </div>
                </div>
			</div>
			<!-- Main part END -->
		</div>
	</div>
</section>