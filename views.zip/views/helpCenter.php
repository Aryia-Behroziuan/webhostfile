<section class="pt-4">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="card card-overlay-bottom h-300 overflow-hidden text-center" style="background-image:url(assets/images/blog/16by9/08.jpg); background-position: center left; background-size: cover;">
					<!-- Card Image overlay -->
					<div class="card-img-overlay d-flex align-items-center p-3 pb-4 px-sm-5"> 
						<div class="col-12 mt-auto d-md-flex justify-content-between align-items-center">
							<h1 class="text-white display-5">پایگاه دانش</h1>
							<nav class="d-flex justify-content-center" aria-label="breadcrumb">
						<ol class="breadcrumb breadcrumb-dots mb-0">
							<li class="breadcrumb-item"><a href="index.html"><i class="bi bi-house me-1"></i> Home</a></li>
							<li class="breadcrumb-item active">All post</li>
						</ol>
					</nav>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>









<section class="position-relative p-0">
	<div class="container">
		<div class="row g-4">










			<!-- Card item START -->
			<div class="col-md-6">
				<div class="card card-overlay-bottom card-img-scale">
					<!-- Card Image -->
					<img class="card-img" src="assets/images/blog/4by3/16.jpg" alt="">
					<!-- Card Image overlay -->
					<div class="card-img-overlay d-flex align-items-center p-3 p-sm-5"> 
						<div class="w-100 mt-auto">
							<div class="col">
								<!-- Card category -->
								<a href="#" class="badge text-bg-success mb-2"><i class="fas fa-circle me-2"></i>Photography</a>
								<a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2"></i>Travel</a>
								<!-- Card title -->
								<h2 class="text-white display-6"><a href="post-single-4.html" class="btn-link text-reset stretched-link fw-normal">This is why this year will be the year of startups</a></h2>
								<!-- Card info -->
								<ul class="nav nav-divider text-white-force align-items-center d-none d-sm-inline-block">
									<li class="nav-item">
										<div class="nav-link">
											<div class="d-flex align-items-center text-white position-relative">
												<div class="avatar avatar-sm">
													<img class="avatar-img rounded-circle" src="assets/images/avatar/01.jpg" alt="avatar">
												</div>
												<span class="ms-3">by <a href="#" class="stretched-link text-reset btn-link">Carolyn</a></span>
											</div>
										</div>
									</li>
									<li class="nav-item">Feb 28, 2022</li>
									<li class="nav-item">
										<a href="#" class="btn-link"><i class="fas fa-comment-alt me-1"></i> 5 Comments</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Card item END -->



			

		</div><!-- Row end -->

		<!-- Pagination START -->
		<nav class="my-5 d-lg-flex justify-content-between" aria-label="navigation">
			<!-- Pagination 1 2 3  -->
			<ul class="pagination pagination-bordered justify-content-center d-inline-block d-lg-flex">
				<li class="page-item">
					<a class="page-link" href="#">First</a>
				</li>
				<li class="page-item"><a class="page-link" href="#">1</a></li>
				<li class="page-item active"><a class="page-link" href="#">2</a></li>
				<li class="page-item disabled"><a class="page-link" href="#">..</a></li>
				<li class="page-item"><a class="page-link" href="#">22</a></li>
				<li class="page-item"><a class="page-link" href="#">23</a></li>
				<li class="page-item">
					<a class="page-link" href="#">Last</a>
				</li>
			</ul>
			<!-- Pagination jump -->
			<ul class="pagination pagination-bordered justify-content-center d-none d-lg-flex">
				<li class="page-item disabled">
					<span class="page-link">Total 25 pages</span>
				</li>
				<li class="page-item disabled">
					<span class="page-link">|</span>
				</li>
				<li class="page-item disabled">
					<span class="page-link">Go to page:</span>
				</li>
				<li class="page-item">
					<input class="form-control h-100 icon-lg fs-6" type="text" placeholder="12">
				</li>
				<li class="page-item active">
					<a class="page-link" href="#">Jump <i class="bi bi-arrow-90deg-right ms-2"></i></a>
				</li>
			</ul>
		</nav>
		<!-- Pagination END -->
	</div>
</section>