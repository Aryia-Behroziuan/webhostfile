<?php
if(! isset($_GET['id'])){
    die();
}
$query_1212 = mysqli_query($con, 'select * from comment where idcomment="'.$_GET['id'].'"');
$noti = mysqli_fetch_assoc($query_1212);
if(! $noti){
    die();
}
$some_time = strtotime($noti['time']);

?>
<section class="py-4">
	<div class="container">
    <div class="row pb-4">
	
		</div>
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  <?php echo $noti['title']?> </font></font></h5>
							<a href="dashboard.php?content=notifi" class="btn btn-sm btn-primary mb-0"><i class="bi bi-arrow-right-short"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بازگشت </font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">
   



                    <?php echo $noti['comment']?>


                    <br>
                    <br>
                    <br>
                    <hr>






						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
                            <li class="list-group-item py-0">
                                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-clock" viewBox="0 0 16 16">
									<path d="M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71V3.5z"/>
									<path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm7-8A7 7 0 1 1 1 8a7 7 0 0 1 14 0z"/>
									</svg> ارسال شده در </font></font></span>
                                    <span class="h6 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><?php echo date('Y, d F', $some_time)?></font></span>
                            </li>
					
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>