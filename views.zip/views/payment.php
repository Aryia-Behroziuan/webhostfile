<?php
if(isset($_SESSION['ACC-KEY'])){
  ?>
  <script type='text/javascript'>window.location.href='dashboard.php?content=ACCError'</script>
  <?php
  die();
}
?>
<section class="py-4">
	<div class="container">
		<div class="row pb-4">
			<div class="col-12">
				<!-- Title -->
				<h1 class="mb-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات</font></font></h1>			
			</div>
		</div>
		<div class="row g-4">
			<!-- Profile settings START -->
			<div class="col-lg-6">
				<div class="card border">
                    
				<!-- Change password -->
				<div class="bg-light rounded-3 p-4 mb-3">
					<!-- Content -->
						<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شارژ کیف پول</font></font></h6>
						<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیف پول خود را در نزد ما شارژ کنید تا بتوانید از سرویس ها و خدمات پولی استفاده کنید</font></font></p>
					<!-- Button -->
					<div class="d-sm-flex gap-3 align-items-center mt-3">
						<a href="../../blogzine.webestica.com/rtl/dashboard.php?content=wallet" class="btn btn-primary mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شارژ کردن</font></font></a>
						<p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین تغییر 10 آگوست 2020</font></font></p>
					</div>
				</div>


					<!-- Card body START -->
					<div class="card-body">

						<!-- Profile START -->
						<h5 class="mb-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات پروفایل</font></font></h5>
						<div class="form-check form-switch form-check-md">
							<input class="form-check-input" type="checkbox" role="switch" id="profilePublic" checked="">
							<label class="form-check-label" for="profilePublic"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایه عمومی شما</font></font></label>
						</div>
						<!-- Profile START -->

						<hr><!-- Divider -->

						<!-- Notification START -->
						<h5 class="card-header-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات اعلان ها</font></font></h5>
						<p class="mb-2 mt-3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نوع اعلان‌هایی را که می‌خواهید دریافت کنید انتخاب کنید</font></font></p>
						<div class="form-check form-switch form-check-md mb-3">
							<input class="form-check-input" type="checkbox" id="checkPrivacy1" checked="">
							<label class="form-check-label" for="checkPrivacy1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">هنگام ورود به سیستم از طریق ایمیل به من اطلاع دهید</font></font></label>
						</div>
						<div class="form-check form-switch form-check-md mb-3">
							<input class="form-check-input" type="checkbox" id="checkPrivacy2">
							<label class="form-check-label" for="checkPrivacy2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ارسال پیامک تایید برای تمام پرداخت های آنلاین</font></font></label>
						</div>
						<div class="form-check form-switch form-check-md mb-3">
							<input class="form-check-input" type="checkbox" id="checkPrivacy3" checked="">
							<label class="form-check-label" for="checkPrivacy3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بررسی کنید کدام دستگاه(ها) به حساب شما دسترسی دارند</font></font></label>
						</div>
						<div class="form-check form-switch form-check-md mb-3">
							<input class="form-check-input" type="checkbox" id="checkPrivacy4">
							<label class="form-check-label" for="checkPrivacy4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایه خود را به صورت عمومی نشان دهید</font></font></label>
						</div>
						<!-- Notification START -->

						<!-- Buttons -->
						<div class="d-sm-flex justify-content-end">
							<button type="button" class="btn btn-sm btn-primary me-2 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
							<a href="#" class="btn btn-sm btn-outline-secondary mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">لغو کنید</font></font></a>
						</div>

					</div>
					<!-- Card body END -->
				</div>
			</div>
			<!-- Profile settings END -->
			
			<!-- Credit card START -->
			<div class="col-lg-6">
				<div class="card border-0 mb-4">
					<div class="bg-primary p-4 rounded-3">
						<div class="d-flex justify-content-between align-items-start text-white">
							<img class="w-60" src="assets/images/visa.svg" alt="">
							<!-- Card action START -->
							<div class="dropdown">
								<a class="text-white" href="#" id="creditcardDropdown" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
									<!-- Dropdown Icon -->
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<circle fill="currentColor" cx="12.5" cy="3.5" r="2.5"></circle>
										<circle fill="currentColor" opacity="0.5" cx="12.5" cy="11.5" r="2.5"></circle>
										<circle fill="currentColor" opacity="0.3" cx="12.5" cy="19.5" r="2.5"></circle>
									</svg>
								</a>               
								<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="creditcardDropdown">
									<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card-2-front-fill me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش کارت</font></font></a></li>
									<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کارت جدید اضافه کنید</font></font></a></li>
									<li><a class="dropdown-item" href="#"><i class="bi bi-arrow-bar-down me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پول برداشت</font></font></a></li>
									<li><a class="dropdown-item" href="#"><i class="bi bi-calculator me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبدل ارز</font></font></a></li>
								</ul>
							</div>
							<!-- Card action END -->
						</div>
						<div class="mt-4 text-white">
							<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اعتبار ولت شما</font></font></span>
							<h2 class="text-white mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo number_format($user['charge'] , 0 , "." , "," )?> تومان</font></font></h2>
						</div>
						<div class="mt-4 text-white">
							<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درآمد شما</font></font></span>
							<h2 class="text-white mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo number_format($user['Income'] , 0 , "." , "," )?> تومان</font></font></h2>
						</div>
						<h4 class="text-white mt-4"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  <?php echo $user['cardNumber']?></font></font></h4>
						<div class="d-flex justify-content-between text-white">
							<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالک حقیقی : <?php echo $user['title']?></font></font></span>
							<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بانک: <?php echo $user['bank']?></font></font></span>
						</div>
					</div>
				</div>
				<div class="mt-2">
					<a class="text-secondary" href="#"> <i class="bi bi-plus-square pe-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">افزودن روش پرداخت جدید</font></font></a>
				</div>
			</div>
			<!-- Credit card END -->

			<!-- Website and Darkmode settings START -->
			<div class="col-lg-6">
				
				<!-- Darkmode setting START -->
				<div class="card border mb-4">

					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات حالت تاریک - روشن</font></font></h5>
					</div>

					<!-- Card body START -->
					<div class="card-body">
						<!-- Mode with radio -->
						<div class="hstack gap-2 flex-wrap">
							<!-- Mode light -->
							<div class="form-check form-check-inline align-items-center">
								<input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" checked="">
								<label class="form-check-label" for="inlineRadio1">
									<img src="assets/images/icon/d-light.svg" class="rounded shadow w-80" alt="">
								</label>
								<div class="text-center mt-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">سبک</font></font></div>
							</div>
							<!-- Mode dark -->
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
								<label class="form-check-label" for="inlineRadio2">
									<img src="assets/images/icon/d-dark.svg" class="rounded shadow w-80" alt="">
								</label>
								<div class="text-center mt-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریک</font></font></div>
							</div>
							<!-- Mode system -->
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3">
								<label class="form-check-label" for="inlineRadio3">
									<img src="assets/images/icon/d-default.svg" class="rounded shadow w-80" alt="">
								</label>
								<div class="text-center mt-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات سیستم</font></font></div>
							</div>
						</div>

						<!-- Content -->
						<p class="mb-0 mt-3 small"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توجه:</font></font></b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> این فقط رابط کاربری تنظیمات حالت تم است. </font><font style="vertical-align: inherit;">این قابلیت کار نمی کند.</font></font></p>
					</div>
					<!-- Card body END -->
				</div>
				<!-- Darkmode setting END -->
				
				<!-- Website Settings START -->
				<div class="card border">

					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تنظیمات کیف پول</font></font></h5>
					</div>

					<!-- Card body START -->
					<div class="card-body">
						<form id="addCart" action="" method="POST" class="row g-4">
							<!-- Input item -->
							<div class="col-lg-6">
								<label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام تجاری بانک</font></font></label>
								<input name="bank" type="text" class="form-control" placeholder="نام بانک">
								<div class="form-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام وب سایت را وارد کنید </font><font style="vertical-align: inherit;">در وب سایت و ایمیل نمایش داده می شود.</font></font></div>
							</div>
							<!-- Input item -->
							<div class="col-lg-6">
								<label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام و نام خانوادگی مالک قانونی</font></font></label>
								<input name="name" type="text" class="form-control" placeholder="نام مالک">
								<div class="form-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">استفاده برای تماس و ارسال ایمیل</font></font></div>
							</div>
				
							<!-- Input item -->
							<div class="col-lg-6">
								<label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شماره کارت</font></font></label>
								<input name="number" type="text" class="form-control" placeholder="شماره کارت">
								<div class="form-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">استفاده برای تماس و پشتیبانی</font></font></div>
							</div>
				
			
			
							<!-- Save button -->
							<div class="d-sm-flex justify-content-end">
							<button id="addCartSub" type="submit" class="btn btn-primary mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به روز رسانی</font></font></button>
							</div>
						</form>
                        <script>
                            $(document).ready(function(){
                                $("#addCart").on("submit", function(event){
                                    event.preventDefault();
                                    $('#addCartSub').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    var formValues= $('#addCart').serialize();

                                    $.post("../../index.php?controller=account&method=edit&mode=4", formValues, function(data){
                                        // Display the returned data in browser
                                        $('#addCartSub').html('ذخیره شد');
                                    });
                                });
                            });
                        </script>
					</div>
					<!-- Card body END -->
				</div>
				<!-- Website Settings END -->
			</div>
			<!-- Website and Darkmode settings START -->

			<!-- Activity logs -->
			<div class="col-lg-6">
				<div class="bg-light rounded-3 p-4 mb-3">
					<div class="d-md-flex justify-content-between align-items-center">
						<!-- Content -->
						<div>
							<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارش های فعالیت</font></font></h6>
							<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">می توانید تمام گزارش های فعالیت خود از جمله فعالیت غیرمعمول شناسایی شده را ذخیره کنید.</font></font></p>
						</div>
						<!-- Switch -->
						<div class="form-check form-switch form-check-md mb-0">
							<input class="form-check-input" type="checkbox" id="checkPrivacy6" checked="">
						</div>
					</div>
				</div>

				<!-- Change password -->
				<div class="bg-light rounded-3 p-4 mb-3">
					<!-- Content -->
						<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درامد شما تا این لحظه</font></font></h6>
						<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> واریز درامد شما از سایت 24 تا 72 ساعت ممکن است به طول بینجامد درصورت تمایل درخواست واریز را بزنید</font></font></p>
						<br>
						<small>درآمد محاسبه شده با انتصاب 10 درصد مالیات پیپرلاین است</small>

						<?php
						if($user['payRQ'] == 1){
							?>
							<br>
							<br>
							<div class="alert alert-dark" role="alert">
							<div id="displayCode">درخواست شما مبنی بر دریافت درآمد دریافت شد و اما در حال برسی آن هستیم تا از واقعی بودن درآمدتان اطمینان حاصل کنیم و سپس آن را برای شما ارسال خواهیم کرد</div>
							</div>
							<?php
						}elseif($user['payRQ'] == 2){
							?>
							<br>
							<br>
							<div class="alert alert-danger" role="alert">
							<div id="displayCode">
								<h4>درخواست شما تایید نشد</h4>
								<small><?php echo $user['payRQD']?></small>
							</div>
							</div>
							<?php
						}else{
							?>
							<br>
							<br>
							<div id="displayCode"></div>

							<?php
						}
						?>
						<!-- Button -->
					<div class="d-sm-flex gap-3 align-items-center mt-3">
						<a href="#" class="btn btn-primary mb-1" id="sbus"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">درخواست واریز</font></font></a>
						<?php
						$x = 15;
						$y = $user['Income'];
						$res = ($x*$y)/100;
						$math = $y-$res;
						?>
						<p class="mb-0 small h6"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo number_format($user['Income'] , 0 , "." , "," )?>  تومان</font></font></p>
		
					</div>
				</div>

											<script>
                                            $('#sbus').click(function(event){
                                            event.preventDefault();
                                            $('#sbus').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال درخواست...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=payRQ",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#sbus').html('ارسال شد');
                                                $('#displayCode').html(data);
                                                })

                                            })
                                            </script>

				<!-- 2 Step Verification -->
				<div class="bg-light rounded-3 p-4">
					<div class="d-md-flex justify-content-between align-items-center">
						<!-- Content -->
						<div>
							<h6 class="h5"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تایید 2 مرحله ای</font></font></h6>
							<p class="mb-1 mb-md-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حساب خود را با امنیت ۲ مرحله ای ایمن کنید. </font><font style="vertical-align: inherit;">هنگامی که فعال شد، نه تنها رمز عبور خود، بلکه یک کد خاص را نیز با استفاده از برنامه باید وارد کنید. </font><font style="vertical-align: inherit;">شما می توانید این کد را در اپلیکیشن موبایل دریافت کنید.</font></font></p>
						</div>
						<!-- Switch -->
						<div class="form-check form-switch form-check-md mb-0">
							<input class="form-check-input" type="checkbox" id="checkPrivacy13" checked="">
						</div>
					</div>
				</div>

				<!-- Activity log START -->
				<div class="card border mt-4">

					<!-- Card header -->
					<div class="card-header border-bottom p-3">
						<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارش فعالیت حساب</font></font></h5>
					</div>

					<!-- Card body START -->
					<div class="card-body">
						<!-- Table START -->
						<div class="table-responsive border-0">
							<table class="table align-middle p-4 mb-0 table-hover">
								<!-- Table head -->
								<thead class="table-dark">
									<tr>
										<th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرورگر</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">IP</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">زمان</font></font></th>
										<th scope="col" class="border-0 rounded-end"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عمل</font></font></th>
									</tr>
								</thead>
								<!-- Table body START -->
								<tbody class="border-top-0">
									<!-- Table row -->
									<tr>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Chrome On Window</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">173.238.198.108</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">12 نوامبر 2021</font></font></td>
										<td><button class="btn btn-sm btn-danger-soft me-1 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></button></td>
									</tr>
									<!-- Table row -->
									<tr>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موزیلا در پنجره</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">107.222.146.90</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08 نوامبر 2021</font></font></td>
										<td><button class="btn btn-sm btn-danger-soft me-1 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></button></td>
									</tr>
									<!-- Table row -->
									<tr>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Chrome در iMac</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">231.213.125.55</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">06 نوامبر 2021</font></font></td>
										<td><button class="btn btn-sm btn-danger-soft me-1 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></button></td>
									</tr>
									<!-- Table row -->
									<tr>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موزیلا در پنجره</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">37.242.105.138</font></font></td>
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">02 نوامبر 2021</font></font></td>
										<td><button class="btn btn-sm btn-danger-soft me-1 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">خروج از سیستم</font></font></button></td>
									</tr>
								</tbody>
								<!-- Table body END -->
							</table>
						</div>
						<!-- Table END -->
					</div>
					<!-- Card body END -->
				</div>
			</div>
			<!-- Activity log END -->
		</div>
 	</div>
</section>