                <title>قابلیت دسترسی سازمانی - پیپرلاین</title>
                   <br>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/fingerprint-5064272-4222070.png?f=avif" style="width: 200px;" alt="">
                        <h2>قابلیت دسترسی سازمانی</h2>
                        <small>همه اعضای سازمان خوئ را به حساب سازمانی خود متصل کنید و برای مدیریت بهتر سازمان خود حساب خود را به حساب تجاری یا سازمانی تغییر وضعیت دهید ما بستری را فراهم کرده ایم تا در محیطی ایمن کارکنان سازمان شما بتوانند با سازمان شما مشارکت کرده و و جامعه توسعه دهندگی خود را ایفا کنند</small>
                        </div>
                        <!-- End Title -->
                        <br>
                        <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?controller=home&amp;method=con">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">امنیت جامعه محور</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/business-person-saving-password-of-account-3391058-2829984.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4 mb-3 mb-lg-0">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=apps-store">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">مدیریت تیم و سازمان</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/employees-working-on-content-creation-3391050-2829976.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>

                        <div class="col-md-6 col-lg-4">
                            <!-- Card -->
                            <a class="card card-bg-light h-100 shadow-none overflow-hidden transition-3d-hover" href="index.php?connect=music">
                            <div class="row align-items-center">
                                <div class="col-8 col-md-6">
                                <div class="py-3 pl-4">
                                    <h2 class="h4">اتصالات و ابزار ها</h2>
                                    <span class="font-size-1 font-weight-bold">بیشتر بخوانید <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                                </div>
                                </div>
                                <div class="col-4 col-md-6 px-0">
                                <img class="img-fluid" src="https://cdni.iconscout.com/illustration/premium/thumb/business-person-chatting-on-mobile-3391061-2829987.png?f=avif" alt="SVG">
                                </div>
                            </div>
                            </a>
                            <!-- End Card -->
                        </div>
                        </div>
                    </div>


    <section class="pb-4">
        <div class="container">
            <div class="row g-4">
                    <?php
                    if(strlen($user['ACC-KEY']) > 5){
                        $date = date('Y-m-d');
                        if($user['Date_End_Suite'] > $date){
                            ?>
                            <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="container-fluid">
                                <h6> <img src="https://cdn3d.iconscout.com/3d/premium/thumb/accessibility-setting-8672711-6945091.png?f=avif" style="width: 30px;" alt="">  
                                شما یک اشتراک فعال دارید<br></h6>
                                <br>
                                <small>تاریخ اتمام اشتراک: <?php echo $user['Date_End_Suite']?> </small>

                                </div>
                                
                    
                                </div>                               
                            </div>

                            <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="container-fluid">
                                <h6> <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-asterisk" viewBox="0 0 16 16">
                                <path d="M8 0a1 1 0 0 1 1 1v5.268l4.562-2.634a1 1 0 1 1 1 1.732L10 8l4.562 2.634a1 1 0 1 1-1 1.732L9 9.732V15a1 1 0 1 1-2 0V9.732l-4.562 2.634a1 1 0 1 1-1-1.732L6 8 1.438 5.366a1 1 0 0 1 1-1.732L7 6.268V1a1 1 0 0 1 1-1z"/>
                                </svg>
                                وضعیت کنونی را فعال یا غیر فعال کنید<br></h6>
                                <br>

                                <?php
                                if($user['Suite'] == 1){
                                    ?>
                                                                                    <div class="list-group-item">
                                                                                    <!-- Form Switch -->
                                                                                    <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                                        <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5" checked="">
                                                                                        <span class="d-block"> Business Suite </span>
                                                                                        <span class="d-block small">در زمانی که این قسمت را غیر فعال کنید همه رمزینه ها معلق شده و با فعال کردن مجدد آن همان رمزینه های پیشین فعال میشوند</span>
                                                                                    </label>
                                                                                    <!-- End Form Switch -->
                                                                                    </div>
                                    <?php
                                }else{
                                    ?>
                                                                                    <div class="list-group-item">
                                                                                    <!-- Form Switch -->
                                                                                    <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                                        <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox" id="accountNotificationSwitch5">
                                                                                        <span class="d-block"> Business Suite </span>
                                                                                        <span class="d-block small">در زمانی که این قسمت را غیر فعال کنید همه رمزینه ها معلق شده و با فعال کردن مجدد آن همان رمزینه های پیشین فعال میشوند</span>
                                                                                    </label>
                                                                                    <!-- End Form Switch -->
                                                                                    </div>

                                                                            
                                    <?php
                                }
                                ?>
                                <script>
                                                        $('#statusON').click(function(event){
                                                        
                                                        
                                                        $.ajax({
                                                            method: "POST",
                                                            url: "../../index.php?controller=account&method=suite&mode=4",
                                                            data: { code: "1"}
                                                        })
                                                            .done(function(data){
                                                            $('#show_pv').html(data);
                                                            })

                                                        })
                                </script>
                                </div>
                                
                    
                                </div>                               
                            </div>


                            <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="container-fluid">
                                <h6> <img src="https://cdn3d.iconscout.com/3d/premium/thumb/access-password-5000469-4164983.png?f=avif" style="width: 50px;" alt="">  
                                رمزینه یا ACC-KEY فعلی شما برای همرسانی<br></h6>
                                <div class="form-group">
                                    <h4><a id="reflesh" class="btn btn-xs btn-outline-indigo" href="#">
                                    <img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">
                                </a> ACC-KEY</h4>
                                    <textarea id="displayAPIKEY" style="height: 150px;" class="form-control" placeholder="Disabled textarea" disabled=""><?php echo $user['ACC-KEY']?></textarea>
                                </div>
                                <br>
                                <h6>محدودیت های امنیتی این رمزینه</h6>
                                <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-wrench-adjustable"></i> ویرایش اطلاعات حساب </a>
                                <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-wrench-adjustable"></i>  مدیریت محدود پست ها</a>
                                <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-wrench-adjustable"></i>  نشان دادن فعالیت های هر کاربر با این رمزینه</a>
                                <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-wrench-adjustable"></i>  دسترسی ناپذیری به بخش مدیریت مالی</a>
                                <a href="#" class="list-group-item list-group-item-action"><i class="bi bi-wrench-adjustable"></i>  کنترل همه اعمالی که طبق دستورالعمل مجاز به انجام آن شده است</a>
                                </div>
                                            <script>
                                            $('#reflesh').click(function(event){
                                            event.preventDefault();
                                            $('#reflesh').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=suite&mode=5",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#reflesh').html('<img style="width: 20px; height: 20px;" src="https://cdn.iconscout.com/icon/free/png-256/refresh-reload-retry-loading-try-interface-again-4-13955.png" alt="">');
                                                $('#displayAPIKEY').html(data);
                                                })

                                            })
                                            </script>

                    
                                </div>                               
                            </div>


                            <br>
                            <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="bg-light rounded-2 p-1 mb-1">
                                <div class="container-fluid">
                                <h6> <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-incognito" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="m4.736 1.968-.892 3.269-.014.058C2.113 5.568 1 6.006 1 6.5 1 7.328 4.134 8 8 8s7-.672 7-1.5c0-.494-1.113-.932-2.83-1.205a1.032 1.032 0 0 0-.014-.058l-.892-3.27c-.146-.533-.698-.849-1.239-.734C9.411 1.363 8.62 1.5 8 1.5c-.62 0-1.411-.136-2.025-.267-.541-.115-1.093.2-1.239.735Zm.015 3.867a.25.25 0 0 1 .274-.224c.9.092 1.91.143 2.975.143a29.58 29.58 0 0 0 2.975-.143.25.25 0 0 1 .05.498c-.918.093-1.944.145-3.025.145s-2.107-.052-3.025-.145a.25.25 0 0 1-.224-.274ZM3.5 10h2a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 1-3 0v-1a.5.5 0 0 1 .5-.5Zm-1.5.5c0-.175.03-.344.085-.5H2a.5.5 0 0 1 0-1h3.5a1.5 1.5 0 0 1 1.488 1.312 3.5 3.5 0 0 1 2.024 0A1.5 1.5 0 0 1 10.5 9H14a.5.5 0 0 1 0 1h-.085c.055.156.085.325.085.5v1a2.5 2.5 0 0 1-5 0v-.14l-.21-.07a2.5 2.5 0 0 0-1.58 0l-.21.07v.14a2.5 2.5 0 0 1-5 0v-1Zm8.5-.5h2a.5.5 0 0 1 .5.5v1a1.5 1.5 0 0 1-3 0v-1a.5.5 0 0 1 .5-.5Z"/>
                                </svg><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-link-45deg" viewBox="0 0 16 16">
                                <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z"/>
                                <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z"/>
                                </svg>
                                پیوند یکتا برای کارمندان شما<br></h6>
                                <div class="form-group">
                                    <h4><i class="bi bi-link-45deg"></i> پیوند</h4>
                                    <textarea id="displayAPIKEY" style="height: 150px;" class="form-control" placeholder="Disabled textarea" disabled=""><?php echo 'https://www.piperline.ir/core/rtl/index.php?content=loginToACC&id='.$user['iduser'].'';?></textarea>
                                </div>
                                </div>
                                
                    
                                </div>                               
                            </div>
                            <?php
                        }else{
                            ?>
                                                                            <div class="list-group-item">
                                                                            <!-- Form Switch -->
                                                                            <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                                <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox">
                                                                                <span class="d-block"> Business Suite </span>
                                                                                <span class="d-block small">سرویس اشتراک بیزنس شما پایان یافته و اکنون سرویس برای شما فعال نیست</span>
                                                                            </label>
                                                                            <!-- End Form Switch -->
                                                                            </div>
                            <br>
                            <div class="alert alert-secondary" role="alert">
                            <i class="bi bi-info-circle"></i> اشتراک سابق شما پایان یافته است و دیگر همه رمزینه های این حساب غیر فعال خواهد شد در صورت نیاز به این سرویس آنرا مجدد فعال کنید 
                            </div>
                            <br>

                            <div class="container">
                            <div class="row">
                                <!-- Article -->
                                <article class="col-lg-6 mb-3 mb-sm-5 mb-lg-0">
                                <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wizify/../public/img/logo/graphics-6.svg);" data-aos="fade-up" data-bs-toggle="modal" data-bs-target="#staticBackdrop1">
                                    <div class="card-body">
                                    <h2 class="text-white">اشتراک 6 ماهه</h2>
                                    <h4 style="color: #ffffff;">300,000 تومان</h4>
                                    <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                    </div>
                                </a>
                                </article>
                                <!-- End Article -->

                                <!-- Article -->
                                <article class="col-sm-6 col-lg-3 mb-3 mb-sm-0">
                                <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wiziff/../public/img/logo/graphics-7.svg);" data-aos="fade-up" data-aos-delay="100"  data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
                                    <div class="card-body">
                                    <h2 class="text-white">اشتراک 3 ماهه</h2>
                                    <h4 style="color: #ffffff;">150,000 تومان</h4>
                                    <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                    </div>
                                </a>
                                </article>
                                <!-- End Article -->

                                <!-- Article -->
                                <article class="col-sm-6 col-lg-3">
                                <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wizify/../public/img/logo/graphics-4.svg);" data-aos="fade-up" data-aos-delay="150" data-bs-toggle="modal" data-bs-target="#staticBackdrop3">
                                    <div class="card-body">
                                    <h2 class="text-white">اشتراک 1 ماهه</h2>
                                    <h4 style="color: #ffffff;">50,000 تومان</h4>
                                    <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                    </div>
                                </a>
                                </article>
                                <!-- End Article -->
                            </div>
                            </div>


                            
                            <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                <div class="modal-body">
                                    <div id="displayNowAds1"></div>

                                    <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                    <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                    </svg><br> سرویس تجاری میخواهد مبلغ 300,000 تومان را بابت فعالسازی اشتراک 6 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                    <button type="button" class="btn btn-primary-soft" id="ByPlan1">پرداخت و خرید</button>
                                </div>
                                </div>
                            </div>
                            </div>

                                                <script>
                                                $('#ByPlan1').click(function(event){
                                                event.preventDefault();
                                                $('#ByPlan1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                                
                                                $.ajax({
                                                    method: "POST",
                                                    url: "../../index.php?controller=account&method=suite&mode=1",
                                                    data: { code: "1"}
                                                })
                                                    .done(function(data){
                                                    $('#ByPlan1').html('خرید');
                                                    $('#displayNowAds1').html(data);
                                                    })

                                                })
                                                </script>

                            <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                <div class="modal-body">
                                    <div id="displayNowAds2"></div>

                                    <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                    <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                    </svg><br> سرویس تجاری میخواهد مبلغ 150,000 تومان را بابت فعالسازی اشتراک 3 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                    <button type="button" class="btn btn-primary-soft" id="ByPlan2">پرداخت و خرید</button>
                                </div>
                                </div>
                            </div>
                            </div>

                                                <script>
                                                $('#ByPlan2').click(function(event){
                                                event.preventDefault();
                                                $('#ByPlan2').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                                
                                                $.ajax({
                                                    method: "POST",
                                                    url: "../../index.php?controller=account&method=suite&mode=2",
                                                    data: { code: "1"}
                                                })
                                                    .done(function(data){
                                                    $('#ByPlan2').html('خرید');
                                                    $('#displayNowAds2').html(data);
                                                    })

                                                })
                                                </script>


                            <div class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                <div class="modal-body">
                                    <div id="displayNowAds3"></div>

                                    <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                    <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                    </svg><br> سرویس تجاری میخواهد مبلغ 50,000 تومان را بابت فعالسازی اشتراک 1 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                    <button type="button" class="btn btn-primary-soft" id="ByPlan3">پرداخت و خرید</button>
                                </div>
                                </div>
                            </div>
                            </div>

                                                <script>
                                                $('#ByPlan3').click(function(event){
                                                event.preventDefault();
                                                $('#ByPlan3').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                                
                                                $.ajax({
                                                    method: "POST",
                                                    url: "../../index.php?controller=account&method=suite&mode=3",
                                                    data: { code: "1"}
                                                })
                                                    .done(function(data){
                                                    $('#ByPlan3').html('خرید');
                                                    $('#displayNowAds3').html(data);
                                                    })

                                                })
                                                </script>
                            <?php
                        }
                    }else{
                        ?>
                                                                        <div class="list-group-item">
                                                                        <!-- Form Switch -->
                                                                        <label class="form-check form-switch" for="accountNotificationSwitch5">
                                                                            <input name="info" id="statusON" class="form-check-input mt-0" type="checkbox">
                                                                            <span class="d-block"> Business Suite </span>
                                                                            <span class="d-block small">اکنون برای شما غیر فعال است و تا کنون هم از این سرویس استفاده نکرده اید آیا میخواهید از این سرویس استقاده کنید</span>
                                                                        </label>
                                                                        <!-- End Form Switch -->
                                                                        </div>
                        <br>

                        <div class="container">
                        <div class="row">
                            <!-- Article -->
                            <article class="col-lg-6 mb-3 mb-sm-5 mb-lg-0">
                            <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wizify/../public/img/logo/graphics-6.svg);" data-aos="fade-up" data-bs-toggle="modal" data-bs-target="#staticBackdrop1">
                                <div class="card-body">
                                <h2 class="text-white">اشتراک 6 ماهه</h2>
                                <h4 style="color: #ffffff;">300,000 تومان</h4>
                                <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                </div>
                            </a>
                            </article>
                            <!-- End Article -->

                            <!-- Article -->
                            <article class="col-sm-6 col-lg-3 mb-3 mb-sm-0">
                            <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wiziff/../public/img/logo/graphics-7.svg);" data-aos="fade-up" data-aos-delay="100"  data-bs-toggle="modal" data-bs-target="#staticBackdrop2">
                                <div class="card-body">
                                <h2 class="text-white">اشتراک 3 ماهه</h2>
                                <h4 style="color: #ffffff;">150,000 تومان</h4>
                                <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                </div>
                            </a>
                            </article>
                            <!-- End Article -->

                            <!-- Article -->
                            <article class="col-sm-6 col-lg-3">
                            <a class="card align-items-end flex-wrap flex-row bg-img-hero text-white h-100 min-h-380rem transition-3d-hover aos-init aos-animate" href="#" style="background-image: url(https://www.spacify.ir/Wizify/../public/img/logo/graphics-4.svg);" data-aos="fade-up" data-aos-delay="150" data-bs-toggle="modal" data-bs-target="#staticBackdrop3">
                                <div class="card-body">
                                <h2 class="text-white">اشتراک 1 ماهه</h2>
                                <h4 style="color: #ffffff;">50,000 تومان</h4>
                                <span class="font-size-1 font-weight-bold">پرداخت و فعالسازی <i class="bi bi-paypal"></i></span>
                                </div>
                            </a>
                            </article>
                            <!-- End Article -->
                        </div>
                        </div>


                        
                        <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                            <div class="modal-body">
                                <div id="displayNowAds1"></div>

                                <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                </svg><br> سرویس تجاری میخواهد مبلغ 300,000 تومان را بابت فعالسازی اشتراک 6 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                <button type="button" class="btn btn-primary-soft" id="ByPlan1">پرداخت و خرید</button>
                            </div>
                            </div>
                        </div>
                        </div>

                                            <script>
                                            $('#ByPlan1').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=suite&mode=1",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan1').html('خرید');
                                                $('#displayNowAds1').html(data);
                                                })

                                            })
                                            </script>

                        <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                            <div class="modal-body">
                                <div id="displayNowAds2"></div>

                                <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                </svg><br> سرویس تجاری میخواهد مبلغ 150,000 تومان را بابت فعالسازی اشتراک 3 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                <button type="button" class="btn btn-primary-soft" id="ByPlan2">پرداخت و خرید</button>
                            </div>
                            </div>
                        </div>
                        </div>

                                            <script>
                                            $('#ByPlan2').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan2').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=suite&mode=2",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan2').html('خرید');
                                                $('#displayNowAds2').html(data);
                                                })

                                            })
                                            </script>


                        <div class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                            <div class="modal-body">
                                <div id="displayNowAds3"></div>

                                <small><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                                <path d="M14.06 3.713c.12-1.071-.093-1.832-.702-2.526C12.628.356 11.312 0 9.626 0H4.734a.7.7 0 0 0-.691.59L2.005 13.509a.42.42 0 0 0 .415.486h2.756l-.202 1.28a.628.628 0 0 0 .62.726H8.14c.429 0 .793-.31.862-.731l.025-.13.48-3.043.03-.164.001-.007a.351.351 0 0 1 .348-.297h.38c1.266 0 2.425-.256 3.345-.91.379-.27.712-.603.993-1.005a4.942 4.942 0 0 0 .88-2.195c.242-1.246.13-2.356-.57-3.154a2.687 2.687 0 0 0-.76-.59l-.094-.061ZM6.543 8.82a.695.695 0 0 1 .321-.079H8.3c2.82 0 5.027-1.144 5.672-4.456l.003-.016c.217.124.4.27.548.438.546.623.679 1.535.45 2.71-.272 1.397-.866 2.307-1.663 2.874-.802.57-1.842.815-3.043.815h-.38a.873.873 0 0 0-.863.734l-.03.164-.48 3.043-.024.13-.001.004a.352.352 0 0 1-.348.296H5.595a.106.106 0 0 1-.105-.123l.208-1.32.845-5.214Z"/>
                                </svg><br> سرویس تجاری میخواهد مبلغ 50,000 تومان را بابت فعالسازی اشتراک 1 ماهه خدمات خود از ولت شما کسر کند آیا مایلید؟ </small>


                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-dark-soft" data-bs-dismiss="modal">بازگشت</button>
                                <button type="button" class="btn btn-primary-soft" id="ByPlan3">پرداخت و خرید</button>
                            </div>
                            </div>
                        </div>
                        </div>

                                            <script>
                                            $('#ByPlan3').click(function(event){
                                            event.preventDefault();
                                            $('#ByPlan3').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ...');

                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=suite&mode=3",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#ByPlan3').html('خرید');
                                                $('#displayNowAds3').html(data);
                                                })

                                            })
                                            </script>
                        <?php
                    }
                    ?>
        
            </div>
        </div>
    </section>
