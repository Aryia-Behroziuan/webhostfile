<?php
if(! isset($_GET['id'])){
    die();
}

$query12 = mysqli_query($con, 'select * from posts where idPost="'.$_GET['id'].'"');
$post = mysqli_fetch_assoc($query12);

if(! $post){
    die();
}
?>
<section class="pt-3 pt-lg-5">
	<div class="container">
		<div class="row">
      <!-- Title -->
      <div class="mb-4">
        <h2 class="m-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/download-folder-5568716-4644433.mp4" type="video/mp4" autoplay="autoplay" style="width: 100px;" loop="loop"></video> فایل ها</font></font></h2>
      </div>

      
		<div class="card border bg-transparent rounded-1">
		
					<!-- Card body START -->
					<div class="card-body p-3">

						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							
														<!-- Blog item -->
							<div class="col-12">
								<div class="d-flex align-items-center position-relative">
										<img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
									<div class="ms-3">
										<a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
										<p class="small mb-0"><i class="far fa-eye me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['views']?> بازدید</font></font></p>
										<p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['doc']?></font></font></p>
									</div>
								</div>
							</div>

							<!-- Select option -->
							
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						
						<!-- Blog list table END -->

						<!-- Pagination START -->
						
						<!-- Pagination END -->
					</div>
		</div>

			<!-- Filter START -->
			
			<!-- Filter END -->

			<!-- Main part START -->
			<div class="col-xl-9">
            <br>
				<!-- Search filter START -->
				<form action="" method="POST" class="row g-2 g-xl-4 mb-4">
					<!-- Search -->
					<div class="col-xl-6">
                         <div class="rounded position-relative">
							<input class="form-control pe-5" name="search" type="search" placeholder="جستجوی محصولات بر اساس نام یا کلمه کلیدی..." aria-label="جستجو کردن">
							<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="bi bi-search fs-5"> </i></button>
						</div>
					</div>
					<!-- Select -->
					<div class="col-md-4 col-xl-3">
                        <a href="../../core/rtl/dashboard.php?content=createFile&amp;id=<?php echo $_GET['id']?>" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ایجاد فایل جدید</a>

					</div>

					<!-- Select -->
					<div class="col-md-4 col-xl-3">
						<select class="form-select" aria-label="نمونه انتخاب پیش فرض">
							<option selected=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرتب سازی بر اساس</font></font></option>
							<option value="1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام</font></font></option>
							<option value="2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قیمت کم به بالا</font></font></option>
							<option value="3"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ارتفاع به قیمت پایین</font></font></option>
						</select>
					</div>

          <div class="col-md-4 col-xl-3 d-grid d-xl-none">
            <!-- Filter offcanvas button -->
						<button class="btn btn-primary-soft btn-primary-check mb-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar" aria-controls="offcanvasSidebar">
							<i class="fas fa-sliders-h me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش فیلتر
						</font></font></button>
          </div>
				</form>
				<!-- Search filter END -->

				<!-- Product START -->
				<div class="row g-4">


                    <?php
                    if(isset($_POST['search'])){
                        $query_1212 = mysqli_query($con, 'SELECT * FROM `books` WHERE (`idBook` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%" or `doc` LIKE "%'.$_POST['search'].'%" or `file` LIKE "%'.$_POST['search'].'%") and userId="'.$_SESSION['id'].'" order by createDate Desc');
                        $file_hash = mysqli_query($con, 'SELECT * FROM `books` WHERE (`idBook` LIKE "%'.$_POST['search'].'%" or `name` LIKE "%'.$_POST['search'].'%" or `doc` LIKE "%'.$_POST['search'].'%" or `file` LIKE "%'.$_POST['search'].'%") and userId="'.$_SESSION['id'].'" order by createDate Desc');
                        $file = mysqli_fetch_assoc($query_1212);
                    }else{
                        $query_1212 = mysqli_query($con, 'select * from books where userId="'.$user['iduser'].'" and piperlineId="'.$post['idPost'].'" order by createDate Desc');
                        $file_hash = mysqli_query($con, 'select * from books where userId="'.$_SESSION['id'].'" and piperlineId="'.$post['idPost'].'" order by createDate Desc');
                        $file = mysqli_fetch_assoc($query_1212);
                    }
                    if($file){
                        while($res=mysqli_fetch_assoc($file_hash)){
                            ?>
                            <!-- Product item START -->
                            <div class="col-sm-6 col-md-4">
                                <div class="card border p-3 h-100">
                                    <div class="position-relative">
                                        <!-- Image -->
                                        <?php
                                        if($res['type'] == 'folder'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/folder-5192234-4340239.mp4';
                                        }elseif($res['type'] == 'file'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/search-file-5192239-4340244.mp4';
                                        }elseif($res['type'] == 'img'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/media-4942155-4117115.mp4';
                                        }elseif($res['type'] == 'video'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/fast-forward-5192236-4340241.mp4';
                                        }elseif($res['type'] == 'zip'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/setting-5192257-4340262.mp4';
                                        }elseif($res['type'] == 'exe'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/setting-5192258-4340263.mp4';
                                        }elseif($res['type'] == 'audio'){
                                            $img = 'https://cdnl.iconscout.com/lottie/premium/thumb/music-app-5192252-4340257.mp4';
                                        }
                                        ?>
                                        <a href="shop-detail.html" class="position-relative z-index-9"><video loading="lazy" muted="muted" src="<?php echo $img?>" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video></a>
                                        <!-- Overlay -->
                                        <div class="card-img-overlay p-0">
                                            <div> <span class="badge text-bg-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <?php echo $res['type']?></font></font></span></div>
                                        </div>
                                    </div>
                
                                    <!-- Card body -->
                                    <div class="card-body text-center p-3 px-0">
                                        <!-- Badge and price -->
                                        <div class="d-flex justify-content-center mb-2">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
                                                <li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
                                                <li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
                                                <li class="list-inline-item me-0 small"><i class="fas fa-star text-warning"></i></li>
                                                <li class="list-inline-item me-0 small"><i class="fas fa-star-half-alt text-warning"></i></li>
                                            </ul>
                                        </div>
                                        <!-- Title -->
                                        <h5 class="card-title"><a href="shop-detail.html"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['name']?></font></font></a></h5>
                                        <?php
                                        if($res['pass'] == '0'){
                                            $pass = '';
                                        }else{
                                            $pass = 'فایل قفل شد';
                                        }
                                        ?>
                                        <h6 class="mb-0 text-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?PHP echo $pass?></font></font></h6>
                                    
                                    </div>
                
                                    <!-- Card footer -->
                                    <div class="card-footer text-center p-0">
                                        <!-- Button -->
                                        <a href="../../index.php?controller=create&method=deleteFile&id=<?php echo $res['idBook']?>" class="btn btn-sm btn-secondary mb-0"><i class="bi bi-x-lg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">حذف</font></font></a>&nbsp
                                        <a href="../../core/rtl/dashboard.php?content=editFile&id=<?php echo $res['idBook']?>" class="btn btn-sm btn-primary-soft mb-0"><i class="bi bi-pencil"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش</font></font></a>&nbsp
                                        <a href="<?php echo $res['file']?>" class="btn btn-sm btn-primary-soft mb-0"><i class="bi bi-cart me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">باز کنید</font></font></a>
                                    </div>
                                </div>
                            </div>
                            <!-- Product item END -->
                            <?php
                        }
                    }
                    ?>



		

		


					<!-- Pagination START -->
					<div class="col-12">
						<nav class="d-flex justify-content-center" aria-label="جهت یابی">
							<!-- Pagination 1 2 3  -->
							<ul class="pagination pagination-bordered justify-content-center d-inline-block d-lg-flex">
								<li class="page-item">
									<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">اولین</font></font></a>
								</li>
								<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
								<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
								<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
								<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">22</font></font></a></li>
								<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">23</font></font></a></li>
								<li class="page-item">
									<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخر</font></font></a>
								</li>
							</ul>
						</nav>
					</div>
					<!-- Pagination END -->
				</div>
				<!-- Product END -->

			</div>
			<!-- Main part END -->
		</div>
	</div>
</section>