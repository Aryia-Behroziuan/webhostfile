<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/alert-bomb-8789121-7122206.png?f=webp" style="width: 50px;" alt=""> میتوانید افرادی که گزارش داده اند را ببینید</h1>
			</div>
		</div>


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						

                    <?php 
							$posts = '1';
							$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$posts = $posts.','.$res['idPost'];
								}
							}
							?>


                                <?php
                                $query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "report" and `data` IN ('.$posts.')');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                        $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['data'].'"'));
                                        $order = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where name="order" and userId='.$res['userId'].' and piperline='.$post['idPost'].''));
                                        if($order){
                                            $cos = 'مشتری';
                                        }else{
                                            $cos = '';
                                        }
                                        ?>
                        
                                        <!-- Notif item -->
											<a href="dashboard.php?content=openRep&id=<?php echo $post['idPost']?>" style="color: black;"><small><?php echo $post['title']?></small></a>

                                            <div class="list-group-item-action border-0 border-bottom d-flex p-3">
												
                                            <div class="me-3">
                                                <div class="avatar avatar-sm">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                                    <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"/>
                                                    </svg>                           
                                                </div>
                                            </div>
											
                                            <div>
                                                <?php
                                                if($res['rol'] == '1'){
                                                    $status = 'برسی شده';
                                                }elseif($res['rol'] == '2'){
                                                    $status = 'مجددا کاربر اعلام مشکل کرد';
                                                }else{
                                                    $status = '';
                                                } 
                                                ?>
                                                <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">"<a href='index.php?content=profile&id=<?php echo $us['iduser']?>'><?php echo $us['username']?></a>"</font> گزارشی برای مخزن شما نوشت</font><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" ><?php echo $cos?></font></font></span> <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="status<?php echo $res['id']?>"><?php echo $status?></font></font></span></h6>
                                                <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['wiki']?> </font></font></span>
                                                <?php
                                                $message = 'سلام من '.$user['username'].' هستم بابت گزارشتون روی مخزن '.$post['title'].' مزاحمتون میشم:';
                                                
                                                ?>
                                                <a href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">

                                                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                            نوشتن پیام
                                                </a>
                                                <?php
                                                if($res['rol'] == '1'){
                                                }else{
                                                    ?>
                                                    <a id="inter<?php echo $res['id']?>" href="dashboard.php?content=sendMessage&id=<?php echo $us['iduser']?>&msg=<?php echo $message?>" class="btn btn-light btn-sm">

                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-eyeglasses" viewBox="0 0 16 16">
                                                        <path d="M4 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm2.625.547a3 3 0 0 0-5.584.953H.5a.5.5 0 0 0 0 1h.541A3 3 0 0 0 7 8a1 1 0 0 1 2 0 3 3 0 0 0 5.959.5h.541a.5.5 0 0 0 0-1h-.541a3 3 0 0 0-5.584-.953A1.993 1.993 0 0 0 8 6c-.532 0-1.016.208-1.375.547zM14 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
                                                        </svg>
                                                    رسیدگی شد 
                                                    </a>

                                                    
                                                    <script>
                                                    $('#inter<?php echo $res['id']?>').click(function(event){
                                                    event.preventDefault();
                                                    $('#inter<?php echo $res['id']?>').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');
                                                    
                                                    $.ajax({
                                                        method: "POST",
                                                        url: "../../index.php?controller=message&method=seeRep&id=<?php echo $res['id']?>",
                                                        data: { code: "1"}
                                                    })
                                                        .done(function(data){
                                                        $('#status<?php echo $res['id']?>').html(data);
                                                        $('#inter<?php echo $res['id']?>').html('');

                                                        })

                                                    })
                                                    </script>
                                                    <?php
                                                } 
                                                ?>
                                    
                                                </div>
												
    
                                            </div>
                                        <!-- Notif item -->
                                        <?php

                                    }
                                }else{
									?>
									<section class="overflow-hidden">
										<div class="container">
											<div class="row">
										<div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
											<!-- SVG shape START -->
											<figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
											<svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
												<g>
												<path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
												<path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
												<path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
												<path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
												<path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
												<path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
												<path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
												<path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
												<path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
												<path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
												c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
												</g>
											</svg>
											</figure>
											<!-- SVG shape START -->
											<!-- Content -->
											<h1 class="display-1 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="bi bi-eyeglasses"></i></font></font></h1>
											<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گزارشی یافت نشد</font></font></h2>
											
										</div>
										</div>
										</div>
									</section>
									<?php
								}
                                ?>


					</div>
					<!-- Card body END -->


					</div>
					<!-- Card Footer END -->
				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    
	
</section>