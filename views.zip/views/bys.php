<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
					<h1 class="mb-0 h2"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/alert-bomb-8789121-7122206.png?f=webp" style="width: 50px;" alt=""> مشتریان شما تا کنون</h1>
			</div>
		</div>


		

        <div class="row g-4">
			<div class="col-12">
				<!-- Card START -->
				<div class="card border">
					<!-- Card header START -->
					<div class="card-header border-bottom p-3">
						<!-- Search and select START -->
						
						<!-- Search and select END -->
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3 pb-0">
						

                             <?php 
							$posts = '1';
							$query_1212 = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file_hash = mysqli_query($con, 'select * from posts where idUser="'.$_SESSION['id'].'" and published="1" order by date Desc');
							$file = mysqli_fetch_assoc($query_1212);
							if($file){
								while($res=mysqli_fetch_assoc($file_hash)){
									$posts = $posts.','.$res['idPost'];
								}
							}
							?>

                                <?php
                                $query_1212 = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "order" and `piperline` IN ('.$posts.') order by createDate Desc limit 0,500');
                                $file_hash = mysqli_query($con, 'SELECT * FROM `session` WHERE `name` = "order" and `piperline` IN ('.$posts.') order by createDate Desc limit 0,500');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"'));
                                        $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['piperline'].'"'));
                                        $some_time = strtotime($res['createDate']);
                                        ?>

                                                  
                                        <!-- Notif item -->
                                        <a href="dashboard.php?content=costomer&id=<?php echo $post['idPost']?>" style="color: black;"><small><?php echo $post['title']?></small></a>

                                        <div class="list-group-item-action border-0 border-bottom d-flex p-3">
                                            
                                        <div class="me-3">
                                            <div class="avatar avatar-sm">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-flag" viewBox="0 0 16 16">
                                                <path d="M14.778.085A.5.5 0 0 1 15 .5V8a.5.5 0 0 1-.314.464L14.5 8l.186.464-.003.001-.006.003-.023.009a12.435 12.435 0 0 1-.397.15c-.264.095-.631.223-1.047.35-.816.252-1.879.523-2.71.523-.847 0-1.548-.28-2.158-.525l-.028-.01C7.68 8.71 7.14 8.5 6.5 8.5c-.7 0-1.638.23-2.437.477A19.626 19.626 0 0 0 3 9.342V15.5a.5.5 0 0 1-1 0V.5a.5.5 0 0 1 1 0v.282c.226-.079.496-.17.79-.26C4.606.272 5.67 0 6.5 0c.84 0 1.524.277 2.121.519l.043.018C9.286.788 9.828 1 10.5 1c.7 0 1.638-.23 2.437-.477a19.587 19.587 0 0 0 1.349-.476l.019-.007.004-.002h.001M14 1.221c-.22.078-.48.167-.766.255-.81.252-1.872.523-2.734.523-.886 0-1.592-.286-2.203-.534l-.008-.003C7.662 1.21 7.139 1 6.5 1c-.669 0-1.606.229-2.415.478A21.294 21.294 0 0 0 3 1.845v6.433c.22-.078.48-.167.766-.255C4.576 7.77 5.638 7.5 6.5 7.5c.847 0 1.548.28 2.158.525l.028.01C9.32 8.29 9.86 8.5 10.5 8.5c.668 0 1.606-.229 2.415-.478A21.317 21.317 0 0 0 14 7.655V1.222z"></path>
                                                </svg>                           
                                            </div>
                                        </div>

                                        <div>
                                                                                            <h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">"<a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>"><?php echo $us['username']?></a>"</font> سفارشی برای مخزن شما ایجاد کرد</font><span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشتری</font></font></span> <span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="status2621">برسی شده</font></font></span></h6>
                                            <span class="small"> <i class="bi bi-link-45deg"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('Y, d F', $some_time)?> </font></font></span>
                                                                                            <a href="dashboard.php?content=sendMessage&amp;id=<?php echo $us['iduser']?>" class="btn btn-light btn-sm">

                                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Facebook_Messenger_logo_2020.svg/1024px-Facebook_Messenger_logo_2020.svg.png" style="width: 20px;" alt="Avatar">

                                                        نوشتن پیام
                                            </a>
                                                                                
                                            </div>
                                            

                                        </div>
                                        <!-- Notif item -->

                                        <?php
                                    }
                                }
                                ?>
                    

    
                                        

					</div>
					<!-- Card body END -->


					</div>
					<!-- Card Footer END -->
				</div>
				<!-- Card END -->
			</div>
			
	
		</div>
    
	
</section>