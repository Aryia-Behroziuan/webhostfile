<section class="py-2" id="displayNowStep">
	<div class="container">
        <?php
        $math = ($user['step']/7)*100;
        ?>

        <div class="row pb-2">
              <!-- Card START -->
              <div class="card card-body border h-100">
                 <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-person-down" viewBox="0 0 16 16">
                    <path d="M12.5 9a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Zm.354 5.854 1.5-1.5a.5.5 0 0 0-.708-.708l-.646.647V10.5a.5.5 0 0 0-1 0v2.793l-.646-.647a.5.5 0 0 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
                    <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"/>
                    </svg> راه اندازی حساب</font></font></h3>
                 <div>
                  <div class="d-flex">
                    <h6 class="mt-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ستاپ کردن حساب شما</font></font></h6>
                    <span class="ms-auto"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $user['step']?> مرحله از 6 مرحله</font></font></span>
                  </div>
                  <div class="progress progress-percent-bg progress-md">
                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" style="width: <?php echo $math?>%" aria-valuenow="<?php echo $math?>" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <!-- Card END -->
                </div>
              </div>

        </div>


        <?php
        if($user['step'] == 0){
            ?>
            <form id="data1" action="" method="POST">
                <!-- Profile START -->
                <div class="card border mb-4">
                <div class="card-header border-bottom p-3">
                    <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مشخصات</font></font></h5>
                </div>
                <div class="card-body">
                    <!-- Full name -->
                    <div class="mb-3">
                    <label class="form-label" style="display: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" style="display: none;">نام نمایشی و نام حقیقی</font></font></label>
                    <div class="input-group">
                        <input type="text" class="form-control" name="username" value="<?php echo $user['username']?>" placeholder="نام کوچک" style="display: none;">
                        <input type="text" class="form-control" name="title" value="<?php echo $user['title']?>" placeholder="نام خانوادگی" style="display: none;">
                    </div>
                    </div>
                    <!-- Username -->
                    <div class="mb-3" style="display: none;">
                    <label class="form-label" style="display: none;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام کاربری</font></font></label>
                    <div class="input-group">
                        <span class="input-group-text" style="display: none;">piperline.com</span>
                        <input type="text" class="form-control" value="<?php echo $user['username']?>">
                    </div>
                    </div>
                    <!-- Profile picture -->
                    <div class="mb-3">
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عکس پروفایل</font></font></label>
                    <!-- Avatar upload START -->
                    <div class="d-flex align-items-center">
                        <div class="position-relative me-3">
                        <!-- Avatar edit -->
                        <div class="position-absolute top-0 end-0  z-index-9">
                            <a class="btn btn-sm btn-light btn-round mb-0 mt-n1 me-n1" href="#"> <i class="bi bi-pencil"></i> </a>
                        </div>
                        <!-- Avatar preview -->
                        <div class="avatar avatar-xl">
                            <img class="avatar-img rounded-circle border border-white border-3 shadow" src="<?php echo $user['avatar']?>" alt="">
                        </div>
                        </div>
                        <!-- Avatar remove button -->
                        <div class="avatar-remove">
                        <input type="text" name="avatar" class="form-control" value="<?php echo $user['avatar']?>" placeholder="لینک عکس">
                        <a href="https://up.20script.ir/index.php" class="btn btn-light"><font style="vertical-align: inherit;" target="_blank"><font style="vertical-align: inherit;">آپلود</font></font></a>
                        </div>
                    </div>
                    <!-- Avatar upload END -->
                    </div>
                    <!-- Job title -->
                    <div class="mb-3">
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عنوان شغلی</font></font></label>
                    <input class="form-control" name="job" type="text" value="<?php echo $user['job']?>">
                    </div>
                    <!-- Location -->
                    <div class="mb-3">
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">محل</font></font></label>
                    <input class="form-control" name="address" type="text" value="<?php echo $user['address']?>">
                    </div>
                    <!-- Bio -->
                    <div class="mb-3">
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> درباره شما</font></font></label>
                    <textarea class="form-control" name="about" rows="3"><?php echo $user['about']?></textarea>
                    <div class="form-text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">توضیحات مختصری برای پروفایل شما</font></font></div> 
                    </div>
                    <!-- Birthday -->
                    <div>
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> لینک رزومه شما</font></font></label>
                    <input type="text" name="resume" class="form-control flatpickr-input" value="<?php echo $user['codefoxs']?>">
                    </div>
                    <div>
                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وبسایت شما</font></font></label>
                    <input type="text" name="url" class="form-control flatpickr-input" value="<?php echo $user['url']?>">
                    </div>
                    <!-- Save button -->
                    <div class="d-flex justify-content-end mt-4">
                    <a href="#" class="btn text-secondary border-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">دور انداختن</font></font></a>
                    <button id="data1SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                    </div>
                </div>
                </div>
                <!-- Profile END -->
            </form>
            <script>
                    $(document).ready(function(){
                        $("#data1").on("submit", function(event){
                            event.preventDefault();
                            $('#data1SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                            var formValues= $('#data1').serialize();

                            $.post("../../index.php?controller=account&method=edit&mode=1", formValues, function(data){
                                // Display the returned data in browser
                                $('#data1SUB').html('ذخیره شد');
                            });
                        });
                    });
            </script>

            <?php
        }elseif($user['step'] == 1){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-security-5000473-4164979.png?f=avif" style="width: 150px;" alt="">  
                        <br>

                            <li class="avatar">
                                <img class="avatar-img rounded-circle" src="<?php echo $user['avatar']?>" alt="avatar">
                            </li>
                            <li class="avatar">
                                <img class="avatar-img rounded-circle" src="https://up.20script.ir/file/bd66-Screenshot-26-.png" alt="avatar">
                            </li>
                    
                            <li class="avatar">
                                <div class="avatar-img rounded-circle bg-primary"><i class="fas fa-plus text-white position-absolute top-50 start-50 translate-middle"></i></div>
                            </li>

                        <h2>امنیت حساب شما</h2>
                        <small>حساب شما اکنون توسط سرویس حساب های کوییت سورس یعنی کیوپس آیدی نگهداری میشود لطفا به شما در تکمیل اطلاعات برای بالابردن سطح امنیتی حسابتان کمک کنید اطلاعات ورودی شما به سرویس کیوپس آیدی منتقل شده به وصله های امنیتی حسابتان پیوند میشود <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>

                    <form id="data2" action="" method="POST">
                        <!-- Personal information START -->
                        <div class="card border mb-4">
                     
                        <div class="card-body">
                            <!-- Skype -->
                            <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://winaero.com/blog/wp-content/uploads/2020/04/Skype-Icon-Logo-Big-256-2020.png" style="width: 30px;" alt=""> اتصال به skype</font></font></label>
                            <input class="form-control"  type="text" value="skypeID">
                            </div>

                            <!-- Address -->
                            <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img src="https://cdn3d.iconscout.com/3d/premium/thumb/firewall-security-5000466-4164984.png?f=avif" style="width: 40px;" alt=""> شماره تلفن</font></font></label>
                            <div class="input-group input-group-lg">
                            <input type="number" name="phone" value="<?php echo $user['phoneNumber']?>" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                            <input class="input-group-text" id="inputGroup-sizing-lg" type="text" value="+98">
                            </div>
                            </div>
                 

                       
                                                        <!-- Save button -->
                            <div class="d-flex justify-content-end mt-4">
                            <button id="data2SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                            </div>
                        </div>
                        </div>
                        <!-- Personal information END -->
                    </form>
                    <script>
                            $(document).ready(function(){
                                $("#data2").on("submit", function(event){
                                    event.preventDefault();
                                    $('#data2SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    var formValues= $('#data2').serialize();

                                    $.post("../../index.php?controller=account&method=edit&mode=2", formValues, function(data){
                                        // Display the returned data in browser
                                        $('#data2SUB').html('ذخیره شد');
                                    });
                                });
                            });
                    </script>
            <?php
        }elseif($user['step'] == 2){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/firewall-security-5000466-4164984.png?f=avif" style="width: 150px;" alt="">  
                        <br>



                        <h2>ایالات شما</h2>
                        <small>  بعضی از خدمات ما و سیاستنامه های ما نیاز به موقعیت مکانی دارد ما کشور شما را هوشمندانه پیدا کردیم حالا ایالات محل زندگی خود را به ما بگویید ما آنها را وصله حساب کیوپس آیدی شما خواهیم کرد   <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>

                    <form id="locSend" action="" method="POST">
                        <!-- Personal information START -->
                        <div class="card border mb-4">
                        <div class="card-header border-bottom p-3">
                            <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">موقعیت مکانی</font></font></h5>
                        </div>
                        <div class="card-body">
                            <!-- Skype -->
                            <div class="mb-3">
                            <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ایالات خود را انتخاب کنید</font></font></label>
                            
                            
                            <select class="form-select" name="loc" multiple aria-label="multiple select example">

                            <?php
                            if(strlen($user['loc']) >= 2){
                                ?>
                                <option value="<?php echo $user['loc']?>" selected>"<?php echo $user['loc']?>" انتخاب شده</option>

                                <?php
                            }else{
                                ?>
                                <option value="" selected>برای فعالسازی منطقه را انتخاب کنید</option>

                                <?php
                            }

                            ?>
                                <br>
                                <option value="تهران">تهران</option>
                                <br>
                                <option value="گیلان">گیلان</option>
                                <option value="آذربایجان شرقی">آذربایجان شرقی</option>
                                <option value="خوزستان">خوزستان</option>
                                <option value="فارس">فارس</option>
                                <option value="اصفهان">اصفهان</option>
                                <option value="خراسان رضوی">خراسان رضوی</option>
                                <option value="قزوین">قزوین</option>
                                <option value="سمنان">سمنان</option>
                                <option value="قم">قم</option>
                                <option value="مرکزی">مرکزی</option>
                                <option value="زنجان">زنجان</option>
                                <option value="مازندران">مازندران</option>
                                <option value="گلستان">گلستان</option>
                                <option value="اردبیل">اردبیل</option>
                                <option value="آذربایجان غربی">آذربایجان غربی</option>
                                <option value="همدان">همدان</option>
                                <option value="کردستان">کردستان</option>
                                <option value="کرمانشاه">کرمانشاه</option>
                                <option value="لرستان">لرستان</option>
                                <option value="بوشهر">بوشهر</option>
                                <option value="کرمان">کرمان</option>
                                <option value="هرمزگان">هرمزگان</option>
                                <option value="چهارمحال و بختیاری">چهارمحال و بختیاری</option>
                                <option value="یزد">یزد</option>
                                <option value="سیستان و بلوچستان">سیستان و بلوچستان</option>
                                <option value="ایلام">ایلام</option>
                                <option value="کهگلویه و بویراحمد">کهگلویه و بویراحمد</option>
                                <option value="خراسان شمالی">خراسان شمالی</option>
                                <option value="خراسان جنوبی">خراسان جنوبی</option>
                                <option value="البرز">البرز</option>


                            </select> 
                            <small><font style="vertical-align: inherit;">کاربر گرامی لطفا ایالات خود را انتخاب کنید تا بتوانیم  داده هایی که بر اساس منطقه چیده میشوند و سرویس هایی که محدودیت مکانی دارند را برای شما پردازش کنیم</font></small>


                            </div>

                        
                            <!-- Save button -->
                            <div class="d-flex justify-content-end mt-4">
                            <button id="data2SUB1" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                            </div>
                        </div>
                        </div>
                        <!-- Personal information END -->
                    </form>
                    <script>
                            $(document).ready(function(){
                                $("#locSend").on("submit", function(event){
                                    event.preventDefault();
                                    $('#data2SUB1').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                    var formValues= $('#locSend').serialize();

                                    $.post("../../index.php?controller=account&method=edit&mode=5", formValues, function(data){
                                        // Display the returned data in browser
                                        $('#data2SUB1').html(data);
                                    });
                                });
                            });
                    </script>
            <?php
        }elseif($user['step'] == 3){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/fingerprint-lock-5000414-4164986.png?f=avif" style="width: 150px;" alt="">  
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/access-password-5000469-4164983.png?f=avif" style="width: 150px;" alt="">  
                        <br>



                        <h2>اتصالات حساب</h2>
                        <small> پیپرلاین توسط شرکت دانش بینیان کوییت سورس توسعه یافته است و حساب های آن متصل به سرویس مادر حساب های کاربری کوییت سورس یعنی کیوپس آیدی است و اکنون شما یک شناسه کیوپس آیدی دارید که میتوانید آن را به سایر پلتفرم ها متصل کنید <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>
                    <div class="row mx-n2 mx-lg-n3">
                    <div class="col-sm-6 col-lg-4 px-2 px-lg-3 mb-3 mb-lg-0 aos-init aos-animate" data-aos="fade-up">
                        <!-- Card -->
                        <a class="card bg-primary text-left h-100 transition-3d-hover" href="./documentation/index.html">
                        <div class="card-body">
                            <div class="mb-5">
                            <h3 class="text-white">Documentation</h3>
                            <p class="text-white">Discover how to build and maintain coding systems using our documentation.</p>
                            </div>
                        </div>
                        <div class="card-footer border-0 bg-transparent pt-0">
                            <span class="font-size-1 text-white font-weight-bold">Learn more <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                        </div>
                        </a>
                        <!-- End Card -->
                    </div>

                    <div class="col-sm-6 col-lg-4 px-2 px-lg-3 mb-3 mb-lg-0 aos-init aos-animate" data-aos="fade-up" data-aos-delay="150">
                        <!-- Card -->
                        <a class="card bg-dark text-left h-100 transition-3d-hover" href="./snippets/index.html">
                        <div class="card-body">
                            <div class="mb-5">
                            <h3 class="text-white">Snippets</h3>
                            <p class="text-white">Start browsing our snippets pages with copy-to-clipboard snippets to match Bootstrap's level of quality.</p>
                            </div>
                        </div>
                        <div class="card-footer border-0 bg-transparent pt-0">
                            <span class="font-size-1 text-white font-weight-bold">Start building <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                        </div>
                        </a>
                        <!-- End Card -->
                    </div>

                    <div class="col-sm-6 col-lg-4 px-2 px-lg-3 aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
                        <!-- Card -->
                        <a class="js-go-to card bg-warning text-left h-100 transition-3d-hover" href="javascript:;" data-hs-go-to-options="{
                            &quot;targetSelector&quot;: &quot;#demoExamplesSection&quot;,
                            &quot;offsetTop&quot;: 0,
                            &quot;position&quot;: null,
                            &quot;animationIn&quot;: false,
                            &quot;animationOut&quot;: false
                        }">
                        <div class="card-body">
                            <div class="mb-5">
                            <h3 class="text-white">Layout options</h3>
                            <p class="text-white">Apart from 70+ HTML-pages, the theme comes with 3 ready-to-use and stand-alone demo options.</p>
                            </div>
                        </div>
                        <div class="card-footer border-0 bg-transparent pt-0">
                            <span class="font-size-1 text-white font-weight-bold">View examples <i class="fas fa-angle-right fa-sm ml-1"></i></span>
                        </div>
                        </a>
                        <!-- End Card -->
                    </div>
                    </div>
                    <br>

                    <div class="card bg-transparent border rounded-3 mt-4">
							<!-- Card header -->
							<div class="card-header bg-transparent border-bottom p-3">
								<h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مرکز کنترل حساب</font></font></h5>
							</div>
							<!-- Card body START -->
							<div class="card-body">
								<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><i class="fab fa-google text-google-icon"></i></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">گوگل</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شما با موفقیت به حساب Google خود متصل شدید</font></font></p>
										<!-- Button -->
										<button type="button" class="btn btn-sm btn-danger mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">فراخوانی کنید</font></font></button>
										<a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>


									<!-- Google -->
									<div class="position-relative mb-3 mt-3 d-sm-flex bg-success bg-opacity-10 border border-success p-3 rounded">
									<!-- Title and content -->
									<h2 class="fs-1 mb-0 me-3"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
									<path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
									<path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
									<path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
									<path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
									</svg></h2>
									<div>
										<div class="position-absolute top-0 start-100 translate-middle bg-white rounded-circle lh-1 h-20px">
										<i class="bi bi-check-circle-fill text-success fs-5"></i>
										</div>
										<h6 class="mb-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">QPassID</font></font></h6>
										<p class="mb-1 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کیوپس آیدی تکنولوژی مدیریت حساب های شرکت کوییت سورس است که برای استفاده از سرویس های شرکت کوییت سورس باید شناسه کیوپس آیدی داشته باشید شما با ورود به هر یک از سرویس های مجموعه کوییت سورس حساب کیوپس آیدی خود را راه اندازی میکنید و برای مدیریت حساب و مرکز کنترل اصلی به سایت رسمی کیوپس آیدی بروید</font></font></p>
										<!-- Button -->
										<a href="https://www.qitsource.ir" class="btn btn-sm btn-primary mb-0 me-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">به مرکز کنترل بروید</font></font>
																				</a><a href="#" class="btn btn-sm btn-link text-body mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بیشتر بدانید</font></font></a>
									</div>
									</div>

									<!-- Blogger -->
									<!-- Blogger -->
									

							
								</div>
								<!-- Card body END -->
							</div>
                            <form id="data3" action="" method="POST">
                                <!-- Social links START -->
                                <div class="card border mb-4">
                                <div class="card-header border-bottom p-3">
                                    <h5 class="card-header-title mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-slack" viewBox="0 0 16 16">
                                    <path d="M3.362 10.11c0 .926-.756 1.681-1.681 1.681S0 11.036 0 10.111C0 9.186.756 8.43 1.68 8.43h1.682v1.68zm.846 0c0-.924.756-1.68 1.681-1.68s1.681.756 1.681 1.68v4.21c0 .924-.756 1.68-1.68 1.68a1.685 1.685 0 0 1-1.682-1.68v-4.21zM5.89 3.362c-.926 0-1.682-.756-1.682-1.681S4.964 0 5.89 0s1.68.756 1.68 1.68v1.682H5.89zm0 .846c.924 0 1.68.756 1.68 1.681S6.814 7.57 5.89 7.57H1.68C.757 7.57 0 6.814 0 5.89c0-.926.756-1.682 1.68-1.682h4.21zm6.749 1.682c0-.926.755-1.682 1.68-1.682.925 0 1.681.756 1.681 1.681s-.756 1.681-1.68 1.681h-1.681V5.89zm-.848 0c0 .924-.755 1.68-1.68 1.68A1.685 1.685 0 0 1 8.43 5.89V1.68C8.43.757 9.186 0 10.11 0c.926 0 1.681.756 1.681 1.68v4.21zm-1.681 6.748c.926 0 1.682.756 1.682 1.681S11.036 16 10.11 16s-1.681-.756-1.681-1.68v-1.682h1.68zm0-.847c-.924 0-1.68-.755-1.68-1.68 0-.925.756-1.681 1.68-1.681h4.21c.924 0 1.68.756 1.68 1.68 0 .926-.756 1.681-1.68 1.681h-4.21z"/>
                                    </svg> پیوندهای اجتماعی</font></font></h5>
                                </div>
                                <div class="card-body" style="text-align: left;">
                                    <!-- Skype -->
                                    <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Meta Instagram & Threads <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                                    <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                                    </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-meta" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8.217 5.243C9.145 3.988 10.171 3 11.483 3 13.96 3 16 6.153 16.001 9.907c0 2.29-.986 3.725-2.757 3.725-1.543 0-2.395-.866-3.924-3.424l-.667-1.123-.118-.197a54.944 54.944 0 0 0-.53-.877l-1.178 2.08c-1.673 2.925-2.615 3.541-3.923 3.541C1.086 13.632 0 12.217 0 9.973 0 6.388 1.995 3 4.598 3c.319 0 .625.039.924.122.31.086.611.22.913.407.577.359 1.154.915 1.782 1.714Zm1.516 2.224c-.252-.41-.494-.787-.727-1.133L9 6.326c.845-1.305 1.543-1.954 2.372-1.954 1.723 0 3.102 2.537 3.102 5.653 0 1.188-.39 1.877-1.195 1.877-.773 0-1.142-.51-2.61-2.87l-.937-1.565ZM4.846 4.756c.725.1 1.385.634 2.34 2.001A212.13 212.13 0 0 0 5.551 9.3c-1.357 2.126-1.826 2.603-2.581 2.603-.777 0-1.24-.682-1.24-1.9 0-2.602 1.298-5.264 2.846-5.264.091 0 .181.006.27.018Z"/>
                                    </svg></font></font></label>
                                    <input class="form-control" name="meta" type="text" value="<?php echo $user['instagram']?>" style="text-align: left;">
                                    </div>
                                    <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Facebook & messanger <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                                    <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                                    </svg>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-messenger" viewBox="0 0 16 16">
                                    <path d="M0 7.76C0 3.301 3.493 0 8 0s8 3.301 8 7.76-3.493 7.76-8 7.76c-.81 0-1.586-.107-2.316-.307a.639.639 0 0 0-.427.03l-1.588.702a.64.64 0 0 1-.898-.566l-.044-1.423a.639.639 0 0 0-.215-.456C.956 12.108 0 10.092 0 7.76zm5.546-1.459-2.35 3.728c-.225.358.214.761.551.506l2.525-1.916a.48.48 0 0 1 .578-.002l1.869 1.402a1.2 1.2 0 0 0 1.735-.32l2.35-3.728c.226-.358-.214-.761-.551-.506L9.728 7.381a.48.48 0 0 1-.578.002L7.281 5.98a1.2 1.2 0 0 0-1.735.32z"/>
                                    </svg></font></font></label>
                                    <input class="form-control" name="facebook" type="text" value="<?php echo $user['facebook']?>" style="text-align: left;">
                                    </div>
                                    <!-- Email -->
                                    <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Linkedin <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
                                    <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/>
                                    </svg></font></font></label>
                                    <input class="form-control" name="linkdin"  type="text" value="<?php echo $user['linkdin']?>" style="text-align: left;">
                                    </div>
                                    <!-- Address -->
                                    <div class="mb-3">
                                    <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Twitter <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                                    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                                    </svg></font></font></label>
                                    <input class="form-control" name="towiter"  type="text" value="<?php echo $user['towitter']?>" style="text-align: left;">
                                    </div>
                                    <!-- Save button -->
                                    <div class="d-flex justify-content-end mt-4">
                                    <button id="data3SUB" type="submit" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ذخیره تغییرات</font></font></button>
                                    </div>
                                </div>
                                </div>
                                <!-- Social links END -->
                            </form>
                            <script>
                                    $(document).ready(function(){
                                        $("#data3").on("submit", function(event){
                                            event.preventDefault();
                                            $('#data3SUB').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                            var formValues= $('#data3').serialize();

                                            $.post("../../index.php?controller=account&method=edit&mode=3", formValues, function(data){
                                                // Display the returned data in browser
                                                $('#data3SUB').html('ذخیره شد');
                                            });
                                        });
                                    });
                            </script>

            <?php
        }elseif($user['step'] == 4){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://cdn3d.iconscout.com/3d/premium/thumb/user-security-5000473-4164979.png?f=avif" style="width: 150px;" alt="">  
                        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a1/Wallet_App_icon_iOS_12.png" style="width: 150px;" alt="">  
                        <br>



                        <h2>فعال سازی ولت دیجیتال</h2>
                        <small> برای راه اندازی ولت دیجیتال خود در پیپرلاین یک حساب بانکی به آن متصل کنید تا برای امنیت بیشتر تمام داد و ستد های ما و شما از طریق همین حساب پشتیبان ولت صورت گیرد این اطلاعات جزو حریم شخصی شماست و ما به سیاستنامه حریم شخصی خود پایبندیم <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>
                    <div class="card border-6 mb-4">
								<div class="bg-primary p-5 rounded-4">
									<div class="d-flex justify-content-between align-items-start text-white">
										<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-fingerprint" viewBox="0 0 16 16">
										<path d="M8.06 6.5a.5.5 0 0 1 .5.5v.776a11.5 11.5 0 0 1-.552 3.519l-1.331 4.14a.5.5 0 0 1-.952-.305l1.33-4.141a10.5 10.5 0 0 0 .504-3.213V7a.5.5 0 0 1 .5-.5Z"></path>
										<path d="M6.06 7a2 2 0 1 1 4 0 .5.5 0 1 1-1 0 1 1 0 1 0-2 0v.332c0 .409-.022.816-.066 1.221A.5.5 0 0 1 6 8.447c.04-.37.06-.742.06-1.115V7Zm3.509 1a.5.5 0 0 1 .487.513 11.5 11.5 0 0 1-.587 3.339l-1.266 3.8a.5.5 0 0 1-.949-.317l1.267-3.8a10.5 10.5 0 0 0 .535-3.048A.5.5 0 0 1 9.569 8Zm-3.356 2.115a.5.5 0 0 1 .33.626L5.24 14.939a.5.5 0 1 1-.955-.296l1.303-4.199a.5.5 0 0 1 .625-.329Z"></path>
										<path d="M4.759 5.833A3.501 3.501 0 0 1 11.559 7a.5.5 0 0 1-1 0 2.5 2.5 0 0 0-4.857-.833.5.5 0 1 1-.943-.334Zm.3 1.67a.5.5 0 0 1 .449.546 10.72 10.72 0 0 1-.4 2.031l-1.222 4.072a.5.5 0 1 1-.958-.287L4.15 9.793a9.72 9.72 0 0 0 .363-1.842.5.5 0 0 1 .546-.449Zm6 .647a.5.5 0 0 1 .5.5c0 1.28-.213 2.552-.632 3.762l-1.09 3.145a.5.5 0 0 1-.944-.327l1.089-3.145c.382-1.105.578-2.266.578-3.435a.5.5 0 0 1 .5-.5Z"></path>
										<path d="M3.902 4.222a4.996 4.996 0 0 1 5.202-2.113.5.5 0 0 1-.208.979 3.996 3.996 0 0 0-4.163 1.69.5.5 0 0 1-.831-.556Zm6.72-.955a.5.5 0 0 1 .705-.052A4.99 4.99 0 0 1 13.059 7v1.5a.5.5 0 1 1-1 0V7a3.99 3.99 0 0 0-1.386-3.028.5.5 0 0 1-.051-.705ZM3.68 5.842a.5.5 0 0 1 .422.568c-.029.192-.044.39-.044.59 0 .71-.1 1.417-.298 2.1l-1.14 3.923a.5.5 0 1 1-.96-.279L2.8 8.821A6.531 6.531 0 0 0 3.058 7c0-.25.019-.496.054-.736a.5.5 0 0 1 .568-.422Zm8.882 3.66a.5.5 0 0 1 .456.54c-.084 1-.298 1.986-.64 2.934l-.744 2.068a.5.5 0 0 1-.941-.338l.745-2.07a10.51 10.51 0 0 0 .584-2.678.5.5 0 0 1 .54-.456Z"></path>
										<path d="M4.81 1.37A6.5 6.5 0 0 1 14.56 7a.5.5 0 1 1-1 0 5.5 5.5 0 0 0-8.25-4.765.5.5 0 0 1-.5-.865Zm-.89 1.257a.5.5 0 0 1 .04.706A5.478 5.478 0 0 0 2.56 7a.5.5 0 0 1-1 0c0-1.664.626-3.184 1.655-4.333a.5.5 0 0 1 .706-.04ZM1.915 8.02a.5.5 0 0 1 .346.616l-.779 2.767a.5.5 0 1 1-.962-.27l.778-2.767a.5.5 0 0 1 .617-.346Zm12.15.481a.5.5 0 0 1 .49.51c-.03 1.499-.161 3.025-.727 4.533l-.07.187a.5.5 0 0 1-.936-.351l.07-.187c.506-1.35.634-2.74.663-4.202a.5.5 0 0 1 .51-.49Z"></path>
										</svg>
										<!-- Card action START -->
										<div class="dropdown">
                                    <form action="" method="POST" id="sendCartTo">

                                             <button class="btn btn-primary" type="submit" id="creditcardDropdownCode">
												ذخیره
											</button> 
											<a class="text-white" href="#" id="creditcardDropdown" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
												<!-- Dropdown Icon -->
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<circle fill="currentColor" cx="12.5" cy="3.5" r="2.5"></circle>
													<circle fill="currentColor" opacity="0.5" cx="12.5" cy="11.5" r="2.5"></circle>
													<circle fill="currentColor" opacity="0.3" cx="12.5" cy="19.5" r="2.5"></circle>
												</svg>
											</a> 
                                             
											<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="creditcardDropdown">
												<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card-2-front-fill me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">ویرایش کارت</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-credit-card me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">کارت جدید اضافه کنید</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-arrow-bar-down me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پول برداشت</font></font></a></li>
												<li><a class="dropdown-item" href="#"><i class="bi bi-calculator me-2 fw-icon"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مبدل ارز</font></font></a></li>
											</ul>
										</div>
										<!-- Card action END -->
									</div>
									<div class="mt-4 text-white">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">شماره کارت</font></font></span>
										<h2 class="text-white mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <input required="" id="con-name" name="number" type="text" class="form-control" style="background: none; border: none; color: #ffffff;" placeholder="شماره کارت"></font></font></h2>
									</div>
									<div class="d-flex justify-content-between text-white">
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">مالک حقیقی : <input required="" id="con-name" name="name" type="text" class="form-control" style="background: none; border: none;  color: #ffffff;" placeholder="نام مالک"> </font></font></span>
										<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> بانک :</font> <input required="" id="con-name" name="bank" type="text" class="form-control" style="background: none; border: none;  color: #ffffff;" placeholder="نام بانک">  </font></span>
									</div>
                                    </form> 
                                    <script>
                                            $(document).ready(function(){
                                                $("#sendCartTo").on("submit", function(event){
                                                    event.preventDefault();
                                                    $('#creditcardDropdownCode').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp ارسال...');

                                                    var formValues= $('#sendCartTo').serialize();

                                                    $.post("../../index.php?controller=account&method=edit&mode=4", formValues, function(data){
                                                        // Display the returned data in browser
                                                        $('#creditcardDropdownCode').html('ذخیره شد');
                                                    });
                                                });
                                            });
                                    </script>
								</div>
							</div>
            <?php
        }elseif($user['step'] == 5){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/MetaMask_Fox.svg/1200px-MetaMask_Fox.svg.png" style="width: 150px;" alt="">  
                        <br>



                        <h2>اتصال ولت کریپتو</h2>
                        <small> برای راه اندازی ولت دیجیتال خود در پیپرلاین یک حساب بانکی به آن متصل کنید تا برای امنیت بیشتر تمام داد و ستد های ما و شما از طریق همین حساب پشتیبان ولت صورت گیرد این اطلاعات جزو حریم شخصی شماست و ما به سیاستنامه حریم شخصی خود پایبندیم <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>
                    <form action="" method="POST" id="GETBtcWallet">
                    <div class="input-group mb-3">
                    <small><img src="https://cdn3d.iconscout.com/3d/premium/thumb/bitcoin-sign-5339244-4466132.png" style="width: 50px;" alt=""> ولت بیت کوییت </small><br>
                    <input type="text" class="form-control" name="BTC" placeholder="کلید خارجی ولت خود را وارد کنید" aria-label="Example text with button addon" value="<?php echo $user['BTC_Wallet']?>" aria-describedby="button-addon1">
                    <button class="btn btn-outline-secondary" type="submit" id="SubBTCWAllet"><i class="bi bi-link-45deg"></i> اتصال </button>
                    </div>
                    </form>
                    <script>
                    $(document).ready(function(){
                        $("#GETBtcWallet").on("submit", function(event){
                            event.preventDefault();
                            $('#SubBTCWAllet').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp');

                            var formValues= $('#GETBtcWallet').serialize();

                            $.post("../../index.php?controller=account&method=saveBTCwallet", formValues, function(data){
                                // Display the returned data in browser
                                $('#SubBTCWAllet').html('متصل شد');
                            });
                        });
                    });
            </script>  
                    <br>
                    <br>
            <?php
        }elseif($user['step'] == 6){
            ?>
                    <div class="container space-2 space-lg-3">
                        <!-- Title -->
                        <div class="text-center mx-md-auto">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/MetaMask_Fox.svg/1200px-MetaMask_Fox.svg.png" style="width: 150px;" alt="">  
                        <br>



                        <h2>نصب برنامه و قبول قوانین</h2>
                        <small> نسخه اپلیکیشن آسان نصب شو ما را نصب کنید تا بتوانید از خدمات بیشتر در محیطی بهتر برخوردار شوید همین حالا از قسمت پایین برای نصب برنامه اقدام کن  <a href="https://www.qitsource.ir"><strong>QPassID</strong></a></small>
                        </div>
                        <!-- End Title -->

                    </div>
                    <br>


                             <div class="bg-light rounded-2 p-1 mb-1">
                            <div class="container-fluid">
                            <h6> <img src="https://cdn-icons-png.flaticon.com/512/732/732208.png" style="width: 30px;" alt="">  <img src="https://cdn-icons-png.flaticon.com/256/831/831327.png" style="width: 30px;" alt="">
                            نصب مستقیم پیپرلاین
                            <br>
                            <small>جدید ترین نسل برنامه را با برنامه پیپرلاین ساده و آسان و امنیت بالا میتوانید با یک دکمه آن را نصب کنید</small>
                            <br>
                            <br>
                            <a href=""><strong> <i class="bi bi-plus"></i>نصب برنامه </strong></a>
                            </div>
                            
                
                            </div>
                            <br>
                            <br>
                            <br>
                            <br>

                    <div class="alert alert-secondary" role="alert">
                    <i class="bi bi-info-circle-fill"></i><i class="bi bi-link-45deg"></i>  رفتن به مرحله بعد به معنای پذیرفتن قوانین <a href="index.php?content=privacy">سیاستنامه حریم خصوصی و دستورالعمل</a> , <a href="index.php?content=cookie">سیاستنامه کوکی  </a> میباشد
                    </div>
            <?php
        }
        ?>

            <form action="" method="POST" id="StepSave">
            <div class="col-md-12 text-start">
                <input type="text" style="display: none;" name="step" value="<?php echo $user['step']+1?>">
                <button class="btn btn-primary w-100" type="submit"><font style="vertical-align: inherit;" id="issetStep"><font style="vertical-align: inherit;" id="isset"> مرحله بعد <i class="bi bi-arrow-left"></i></font></font></button>
            </div>
            </form>
            <script>
                    $(document).ready(function(){
                        $("#StepSave").on("submit", function(event){
                            event.preventDefault();
                            $('#issetStep').html('<div style="width: 22px; height: 22px;" class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>&nbsp');

                            var formValues= $('#StepSave').serialize();

                            $.post("../../index.php?controller=account&method=SaveStepAcc", formValues, function(data){
                                // Display the returned data in browser
                                $('#displayNowStep').html(data);
                            });
                        });
                    });
            </script>   




    </div>
</section>
