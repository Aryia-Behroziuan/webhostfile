<?php
if(! isset($_SESSION['id'])){
    die();
}
if(! $_SESSION['id'] == 42){
    die();
}
?>
<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  درآمد  </font></font>
														</h5>
                            <br>
                            <?php
                                              $query_1212 = mysqli_query($con, 'select * from qitsource where id="1"');
                                              $file_hash = mysqli_query($con, 'select * from qitsource where id="1"');
                                              $file = mysqli_fetch_assoc($query_1212);
                                              
                                              echo number_format($file['pay'] , 0 , "." , "," )
                            ?>

							<a class="small" href="#" id="paymentByendScript"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1">برداشت</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

                                             <script>
                                            $('#paymentByendScript').click(function(event){
                                            event.preventDefault();
                                            $('#paymentByendScript').html('<div class="spinner-border text-primary" role="status" style="width: 80px; height: 80px;"><span class="sr-only"></span></div>');
                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=payAD",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#paymentByendScript').html(data);
                                                })

                                            })
                                            </script>

					<!-- Card body START -->
					
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>


<section class="py-4">
	<div class="container">
    
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">  درآمد محتوا محصول  </font></font>
														</h5>
                            <br>
                            <?php
                                            $account_admin = mysqli_query($con, 'select * from user where piperAdmin="1"');
                                            $account_admin_hash = mysqli_query($con, 'select * from user where piperAdmin="1"');
                                            $admins = mysqli_fetch_assoc($account_admin);
                                            
                                            if($admins){
                                                $pay=0;
                                                while($res=mysqli_fetch_assoc($account_admin_hash)){
                                                    $pay = $pay+$res['Income'];
                                                }
                                                echo number_format($pay , 0 , "." , "," );

                                            }
                            ?>

							<a class="small" href="#" id="paymentByendScript1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" id="deletenoti1">برداشت</font></font></a>						
						</div>
					</div>
					<!-- Card header END -->

                                             <script>
                                            $('#paymentByendScript1').click(function(event){
                                            event.preventDefault();
                                            $('#paymentByendScript1').html('<div class="spinner-border text-primary" role="status" style="width: 80px; height: 80px;"><span class="sr-only"></span></div>');
                                            
                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=account&method=payADUser",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#paymentByendScript1').html(data);
                                                })

                                            })
                                            </script>

					<!-- Card body START -->
					
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>