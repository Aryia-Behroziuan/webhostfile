<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaEasy.js">
<script>   
    xinha_options = 
    {
      xinha_plugins:  [ 
         'minimal', 
         { from: '/path/to/xinha-cdn/plugins', load: ['MootoolsFileManager', 'Linker'] }
      ],
      
      // This is where you set the other default configuration globally
      xinha_config:            function(xinha_config) 
      {
        
        // Configure the plugins as you normally would here (consult plugin documentation)
        
      }
    }

</script>
<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaCore.js">
<script type="text/javascript" src="../../inc/xinha-1.5.6/xinha/XinhaLoader.js">
    xinha_options =
    {
      xinha_editors:  'textarea.some-css-class'
    }
</script>
<?phP
if(isset($_GET['id'])){
    $resive = mysqli_query($con, 'SELECT * FROM `user` WHERE (`iduser` = "'.$_GET['id'].'"  or `email` LIKE "'.$_GET['id'].'") order by iduser Desc');
    $rsv = mysqli_fetch_assoc($resive);
    if(! $rsv){
        ?>
        <div class="alert alert-danger" role="alert">
        <i class="bi bi-info-circle"></i> متاسفانه حساب مورد نظر یافت نشد لطفا اطلاعات را دقیق تر وارد کنید 
        </div>
        <section class="py-4">
            <div class="container">
            <div class="row pb-4">
                    <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person-plus" viewBox="0 0 16 16">
                                <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                                <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
                                </svg>  انتخاب گیرنده</h1>
                    </div>
                </div>

                

                <br>

                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                    <!-- Form START -->
                    <form action="dashboard.php?content=sendMessage" method="GET">
                    <!-- Main form -->
                    <div class="row">
                        <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label">ایمیل یا شناسه کاربری گیرنده</label>
                            <input required="" id="con-name" style="display: none;" name="content" type="text" value="sendMessage" class="form-control" placeholder="فایل را وارد کنید">
                            <input required="" id="con-name" name="id" type="text" class="form-control" placeholder="فایل را وارد کنید">

                            <small>ایمیل یا شناسه کاربری گیرنده را وارد کنید و یا از لیست مخاطبین زیر مخاطب خود را انتخاب کنید</small>
                        </div>
                        </div>


                    <!-- Post type END -->
                    
                    <!-- Short description -->
                    

                        <!-- Post name -->
                        

                    <!-- Main toolbar -->



                        <!-- Post name -->
                        

                        <!-- Post name -->
                        


                        
                        
                        
                        
                                        
                        

                        


                        <!-- Post name -->
                        




                        
                        <!-- Create post button -->
                        <div class="col-md-12 text-start">
                            <a class="btn btn-outline-danger" href="dashboard.php?content=chats">بازگشت</a>
                            <button class="btn btn-primary" type="submit">انتخاب</button>
                        </div>
                    </div>
                    </form>
                    <!-- Form END -->
                            </div>
                        </div>
                        <!-- Chart END -->
                </div>
            </div>
            </div>
        </section>


        <section class="py-4">
            <div class="container">
            <div class="row pb-4">
                    <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/user-notification-3577657-3099057.mp4" type="video/mp4" style="width: 50px;" autoplay="autoplay" loop="loop"></video>انتخاب از مخاطبین</h1>
                    </div>
                </div>


                

                <div class="row g-4">
                    <div class="col-12">
                        <!-- Card START -->
                        <div class="card border">
                            <!-- Card header START -->
                            <div class="card-header border-bottom p-3">
                                <!-- Search and select START -->
                                <div class="row g-3 align-items-center justify-content-between">
                                    <!-- Search bar -->
                                    <div class="col-md-8">
                                        <form action="" method="POST" class="rounded position-relative">
                                            <input class="form-control bg-transparent" type="search" name="search" placeholder="جستجو شناسه" aria-label="Search">
                                            <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                        </form>
                                    </div>
                                    <!-- Tab buttons -->
                                    <div class="col-md-3">
                                        <!-- Tabs START -->
                                        <ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
                                            <!-- Grid tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
                                                    <i class="fas fa-fw fa-list-ul"></i>
                                                </a>
                                            </li>
                                            <!-- List tab -->
                                            <li class="nav-item" role="presentation">
                                                <a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
                                                    <i class="fas fa-fw fa-th-large"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <!-- Tabs end -->
                                    </div>
                                </div>
                                <!-- Search and select END -->
                            </div>
                            <!-- Card header END -->

                            <!-- Card body START -->
                            <div class="card-body p-3 pb-0">
                                <!-- Tabs content START -->
                                <div class="tab-content py-0 my-0">
                                    <?php
                                    if(isset($_POST['search'])){
                                        $query_1212 = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file_hash = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }else{
                                        $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                        $file = mysqli_fetch_assoc($query_1212);
                                    }

                                    if($file){
                                        ?>
                                            <!-- Tabs content item START -->
                                            <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                                <!-- Table START -->
                                                <div class="table-responsive border-0">
                                                    <table class="table align-middle p-4 mb-0 table-hover">
                                                        <!-- Table head -->
                                                        <thead class="table-dark">
                                                            <tr>
                                                                <th scope="col" class="border-0 rounded-start">نام مخاطب</th>
                                                                <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                            </tr>
                                                        </thead>

                                                        <!-- Table body START -->
                                                        <tbody class="border-top-0">


                                                        <?php
                
                                                        while($res=mysqli_fetch_assoc($file_hash)){
                                                            $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
                                                            if($userData){
                                                                ?>
                                                                <!-- Table row -->
                                                                <tr>
                                                                    <!-- Table data -->
                                                                    <td>
                                                                        <div class="d-flex align-items-center position-relative">
                                                                            <!-- Image -->
                                                                            <div class="avatar avatar-md">
                                                                                <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                            </div>
                                                                            <div class="mb-0 ms-2">
                                                                                <!-- Title -->
                                                                                <h6 class="mb-0"><a href="dashboard.php?content=sendMessage&id=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                        
                                                            
                                                        
                                                                    <td>
                                                                        <div class="d-flex gap-2">
                                                                            <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
                                                                            <i class="bi bi-link-45deg"></i>
                                                                            </a>
                                                                            <a href="https://www.spacify.ir/index.php?controller=user&method=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-send"></i>
                                                                            </a>
                                                                            <a href="dashboard.php?content=sendMessage&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                            <i class="bi bi-box-arrow-up-right"></i>
                                                                            </a>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }else{
            
                                                            }
                                                        }
                                                        
                                                        ?>
                        

                                            


                                                        </tbody>
                                                        <!-- Table body END -->
                                                    </table>
                                                </div>
                                                <!-- Table END -->
                                            </div>
                                            <!-- Tabs content item END -->
                                        <?php
                                    }else{

                                    }
                                    ?>


                

                                </div>
                                <!-- Tabs content END -->
                            </div>
                            <!-- Card body END -->

                        </div>
                        <!-- Card END -->
                    </div>
                    
            
                </div>
            </div>
            </div>
        </section>

        <?php
    }else{
        ?>
        <section class="py-4">
            <div class="container">
            <div class="row pb-4">
                    <div class="col-12">
                <!-- Title -->
                            <h1 class="mb-0 h2"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-envelope-at" viewBox="0 0 16 16">
                            <path d="M2 2a2 2 0 0 0-2 2v8.01A2 2 0 0 0 2 14h5.5a.5.5 0 0 0 0-1H2a1 1 0 0 1-.966-.741l5.64-3.471L8 9.583l7-4.2V8.5a.5.5 0 0 0 1 0V4a2 2 0 0 0-2-2H2Zm3.708 6.208L1 11.105V5.383l4.708 2.825ZM1 4.217V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v.217l-7 4.2-7-4.2Z"/>
                            <path d="M14.247 14.269c1.01 0 1.587-.857 1.587-2.025v-.21C15.834 10.43 14.64 9 12.52 9h-.035C10.42 9 9 10.36 9 12.432v.214C9 14.82 10.438 16 12.358 16h.044c.594 0 1.018-.074 1.237-.175v-.73c-.245.11-.673.18-1.18.18h-.044c-1.334 0-2.571-.788-2.571-2.655v-.157c0-1.657 1.058-2.724 2.64-2.724h.04c1.535 0 2.484 1.05 2.484 2.326v.118c0 .975-.324 1.39-.639 1.39-.232 0-.41-.148-.41-.42v-2.19h-.906v.569h-.03c-.084-.298-.368-.63-.954-.63-.778 0-1.259.555-1.259 1.4v.528c0 .892.49 1.434 1.26 1.434.471 0 .896-.227 1.014-.643h.043c.118.42.617.648 1.12.648Zm-2.453-1.588v-.227c0-.546.227-.791.573-.791.297 0 .572.192.572.708v.367c0 .573-.253.744-.564.744-.354 0-.581-.215-.581-.8Z"/>
                            </svg>  ویرایشگر ارسال</h1>
                    </div>
                </div>

                

                <br>

                <div class="row">
                    <div class="col-12">
                        <!-- Chart START -->
                        <div class="card border">
                            <!-- Card body -->
                            <div class="card-body">
                    <!-- Form START -->
                    <form action="../../index.php?controller=message&method=sendMessage" method="POST">
                    <!-- Main form -->
                    <div class="row">
                        <div class="col-12">
                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-send-check"></i> گیرندگان</label>
                            <div class="bg-light rounded-3 p-1 mb-3">
                                                    <div class="d-flex align-items-center position-relative">
                                                    <div class="avatar avatar-sm">
                                                        <img class="avatar-img rounded-circle" src="<?php echo $rsv['avatar']?>" alt="avatar">
                                                    </div>
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><a href="../../blogzine.webestica.com/rtl/dashboard.php?content=profile&amp;id=<?php echo $rsv['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $rsv['username']?></a></h6>
                                                    </div>
                                                    </div>
                                                    <input type="text" value="<?php echo $rsv['iduser']?>" name="rsv" style="display: none;">

                                                    
                            </div>
                        </div>
                        <hr>

                        <?php 
                        if(isset($_POST['idService'])){
                            $query1234 = mysqli_query($con, 'select * from posts where idPost="'.$_POST['idService'].'"');
                            $post = mysqli_fetch_assoc($query1234);
                            if($post){
                                $checkPTS = mysqli_fetch_assoc(mysqli_query($con, 'select * from session where userId="'.$_SESSION['id'].'" and piperline="'.$post['idPost'].'"'));
                                if($checkPTS){
                                    if($post['idUser'] == $_GET['id']){
                                        ?>
                                        <!-- Post name -->
                                        <div class="mb-3">
                                            <label class="form-label"><i class="bi bi-braces-asterisk"></i> افزونه ها </label>
                                            <br>
                                            <div class="bg-light rounded-3 p-1 mb-3">
                                                                    <!-- Blog item -->
                                                                    <div class="col-12">
                                                                        <div class="d-flex align-items-center position-relative">
                                                                                <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                                            <div class="ms-3">
                                                                                <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                                                <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">آخرین به روزرسانی <?php echo $post['dateEdit']?></font></font></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <input type="text" value="<?php echo $post['idPost']?>" name="idAction" style="display: none;">
                                                        
                                            </div>
                                        </div>
    
                                        <?php
                                    }else{
                                        die();
                                    }
                                }else{
                                    die();
                                }
                            }else{
                                die();
                            }
    
                        }
                        ?>

                        <!-- Post name -->
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-braces-asterisk"></i> ویرایشگر متن</label>
                            <br>
                            <?php
                            if(isset($_GET['msg'])){
                                $message= $_GET['msg'];
                            }else{
                                $message= '';
                            }?>
                            <textarea class="some-css-class" name="txt" style="width: 100%; height: 500px; border:none;"><?php echo $message?></textarea>
                        
                        </div>


                    <!-- Post type END -->
                    
                    <!-- Short description -->
                    

                        <!-- Post name -->
                        

                    <!-- Main toolbar -->



                        <!-- Post name -->
                        

                        <!-- Post name -->
                        


                        
                        
                        
                        
                                        
                        

                        


                        <!-- Post name -->
                        




                        
                        <!-- Create post button -->
                        <div class="col-md-12 text-start">
                            <a class="btn btn-outline-danger" href="dashboard.php?content=chats">صرف نظر</a>
                            <button class="btn btn-primary" type="submit">ارسال</button>
                        </div>
                    </div>
                    </form>
                    <!-- Form END -->
                            </div>
                        </div>
                        <!-- Chart END -->
                </div>
            </div>
            </div>
        </section>
        <?php
    }
}else{
    ?>
    <section class="py-4">
        <div class="container">
        <div class="row pb-4">
                <div class="col-12">
            <!-- Title -->
                        <h1 class="mb-0 h2"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person-plus" viewBox="0 0 16 16">
                            <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                            <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
                            </svg>  انتخاب گیرنده</h1>
                </div>
            </div>

            

            <br>

            <div class="row">
                <div class="col-12">
                    <!-- Chart START -->
                    <div class="card border">
                        <!-- Card body -->
                        <div class="card-body">
                <!-- Form START -->
                <form action="dashboard.php?content=sendMessage" method="GET">
                <!-- Main form -->
                <div class="row">
                    <div class="col-12">
                    <!-- Post name -->
                    <div class="mb-3">
                        <label class="form-label">ایمیل یا شناسه کاربری گیرنده</label>
                        <input required="" id="con-name" style="display: none;" name="content" type="text" value="sendMessage" class="form-control" placeholder="فایل را وارد کنید">
                        <input required="" id="con-name" name="id" type="text" class="form-control" placeholder="فایل را وارد کنید">

                        <small>ایمیل یا شناسه کاربری گیرنده را وارد کنید و یا از لیست مخاطبین زیر مخاطب خود را انتخاب کنید</small>
                    </div>
                    </div>


                <!-- Post type END -->
                
                <!-- Short description -->
                

                    <!-- Post name -->
                    

                <!-- Main toolbar -->



                    <!-- Post name -->
                    

                    <!-- Post name -->
                    


                    
                    
                    
                    
                                    
                    

                    


                    <!-- Post name -->
                    




                    
                    <!-- Create post button -->
                    <div class="col-md-12 text-start">
                        <a class="btn btn-outline-danger" href="dashboard.php?content=chats">بازگشت</a>
                        <button class="btn btn-primary" type="submit">انتخاب</button>
                    </div>
                </div>
                </form>
                <!-- Form END -->
                        </div>
                    </div>
                    <!-- Chart END -->
            </div>
        </div>
        </div>
    </section>






    <section class="py-4">
        <div class="container">
        <div class="row pb-4">
                <div class="col-12">
            <!-- Title -->
                        <h1 class="mb-0 h2"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/user-notification-3577657-3099057.mp4" type="video/mp4" style="width: 50px;" autoplay="autoplay" loop="loop"></video>انتخاب از مخاطبین</h1>
                </div>
            </div>


            

            <div class="row g-4">
                <div class="col-12">
                    <!-- Card START -->
                    <div class="card border">
                        <!-- Card header START -->
                        <div class="card-header border-bottom p-3">
                            <!-- Search and select START -->
                            <div class="row g-3 align-items-center justify-content-between">
                                <!-- Search bar -->
                                <div class="col-md-8">
                                    <form action="" method="POST" class="rounded position-relative">
                                        <input class="form-control bg-transparent" type="search" name="search" placeholder="جستجو شناسه" aria-label="Search">
                                        <button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
                                    </form>
                                </div>
                                <!-- Tab buttons -->
                                <div class="col-md-3">
                                    <!-- Tabs START -->
                                    <ul class="list-inline mb-0 nav nav-pills nav-pill-dark-soft border-0 justify-content-end" id="pills-tab" role="tablist">
                                        <!-- Grid tab -->
                                        <li class="nav-item" role="presentation">
                                            <a href="#nav-list-tab" class="nav-link mb-0 me-2 active" data-bs-toggle="tab" aria-selected="true" role="tab">
                                                <i class="fas fa-fw fa-list-ul"></i>
                                            </a>
                                        </li>
                                        <!-- List tab -->
                                        <li class="nav-item" role="presentation">
                                            <a href="#nav-grid-tab" class="nav-link mb-0" data-bs-toggle="tab" aria-selected="false" role="tab" tabindex="-1">
                                                <i class="fas fa-fw fa-th-large"></i>
                                            </a>
                                        </li>
                                    </ul>
                                    <!-- Tabs end -->
                                </div>
                            </div>
                            <!-- Search and select END -->
                        </div>
                        <!-- Card header END -->

                        <!-- Card body START -->
                        <div class="card-body p-3 pb-0">
                            <!-- Tabs content START -->
                            <div class="tab-content py-0 my-0">
                                <?php
                                if(isset($_POST['search'])){
                                    $query_1212 = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                    $file_hash = mysqli_query($con, 'SELECT * FROM `follow` WHERE user_id="'.$_SESSION['id'].'" and (`user_follow_id` LIKE "%'.$_POST['search'].'%") order by list Desc');
                                    $file = mysqli_fetch_assoc($query_1212);
                                }else{
                                    $query_1212 = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                    $file_hash = mysqli_query($con, 'select * from follow where user_id="'.$_SESSION['id'].'" order by list Desc');
                                    $file = mysqli_fetch_assoc($query_1212);
                                }

                                if($file){
                                    ?>
                                        <!-- Tabs content item START -->
                                        <div class="tab-pane fade active show" id="nav-list-tab" role="tabpanel">
                                            <!-- Table START -->
                                            <div class="table-responsive border-0">
                                                <table class="table align-middle p-4 mb-0 table-hover">
                                                    <!-- Table head -->
                                                    <thead class="table-dark">
                                                        <tr>
                                                            <th scope="col" class="border-0 rounded-start">نام مخاطب</th>
                                                            <th scope="col" class="border-0 rounded-end">گزینه ها</th>
                                                        </tr>
                                                    </thead>

                                                    <!-- Table body START -->
                                                    <tbody class="border-top-0">


                                                    <?php
            
                                                    while($res=mysqli_fetch_assoc($file_hash)){
                                                        $userData = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['user_follow_id'].'"'));
                                                        if($userData){
                                                            ?>
                                                            <!-- Table row -->
                                                            <tr>
                                                                <!-- Table data -->
                                                                <td>
                                                                    <div class="d-flex align-items-center position-relative">
                                                                        <!-- Image -->
                                                                        <div class="avatar avatar-md">
                                                                            <img src="<?php echo $userData['avatar']?>" class="rounded-circle" alt="">
                                                                        </div>
                                                                        <div class="mb-0 ms-2">
                                                                            <!-- Title -->
                                                                            <h6 class="mb-0"><a href="dashboard.php?content=sendMessage&id=<?php echo $userData['iduser']?>" class="stretched-link"><?php echo $userData['username']?></a></h6>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                    
                                                        
                                                    
                                                                <td>
                                                                    <div class="d-flex gap-2">
                                                                        <a href="dashboard.php?content=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Message" aria-label="Message">
                                                                        <i class="bi bi-link-45deg"></i>
                                                                        </a>
                                                                        <a href="https://www.spacify.ir/index.php?controller=user&method=profile&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-send"></i>
                                                                        </a>
                                                                        <a href="dashboard.php?content=sendMessage&id=<?php echo $userData['iduser']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Block" aria-label="Block">
                                                                        <i class="bi bi-box-arrow-up-right"></i>
                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        }else{
        
                                                        }
                                                    }
                                                    
                                                    ?>
                    

                                        


                                                    </tbody>
                                                    <!-- Table body END -->
                                                </table>
                                            </div>
                                            <!-- Table END -->
                                        </div>
                                        <!-- Tabs content item END -->
                                    <?php
                                }else{

                                }
                                ?>


            

                            </div>
                            <!-- Tabs content END -->
                        </div>
                        <!-- Card body END -->

                    </div>
                    <!-- Card END -->
                </div>
                
        
            </div>
        </div>
        </div>
    </section>
    <?php
}
?>