<section class="pt-lg-3">
	<div class="container"> 
		<div class="row">
      <!-- Title -->
      <div class="mb-4">
        <h2 class="m-0"><font style="vertical-align: inherit;"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/chat-5192263-4340268.mp4" type="video/mp4" style="width: 120px;" autoplay="autoplay" loop="loop"></video> <font style="vertical-align: inherit;">پیام رسان</font></font>
        <a href="../../core/rtl/dashboard.php?content=sendMessage" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i> ارسال پیام جدید</a></h2>
      </div>
        <div class="col-md-4 col-xl-3 d-grid d-xl-none">
            <!-- Filter offcanvas button -->
						<button class="btn btn-primary-soft btn-primary-check mb-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar" aria-controls="offcanvasSidebar">
                            <i class="bi bi-chat"></i> پیام ها
						</button>
        </div>
			
			<!-- Filter START -->
			<aside class="col-xl-4 col-xxl-3">
				<!-- Responsive offcanvas body START -->
				<div class="offcanvas-xl offcanvas-end" tabindex="-1" id="offcanvasSidebar" aria-labelledby="offcanvasSidebarLabel">
					<div class="offcanvas-header bg-light">
						<h5 class="offcanvas-title" id="offcanvasSidebarLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیام ها</font></font></h5>
						<button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar" aria-label="نزدیک"></button>
					</div>
                    
					<div class="offcanvas-body flex-column p-3 p-xl-0">
						<form class="border rounded-2">





                        <style>
                            .scroll-example {
                                overflow: auto;
                                scrollbar-width: none; /* Firefox */
                                -ms-overflow-style: none; /* IE 10+ */
                            }

                            .scroll-example::-webkit-scrollbar {
                                    width: 0px;
                                    background: transparent; /* Chrome/Safari/Webkit */
                            }
                        </style>


							<!-- Availability START -->
							<div class="card-body">	
								<!-- Title -->
								<h6 class="mb-3 mt-3">&nbsp&nbsp&nbsp<font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیام ها</font></font></h6>
                                <div class="list-group scroll-example" style="height: 700px; overflow-y:scroll; overflow-x:scroll;">
            
                                <?php
                                $query_1212 = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                $file_hash = mysqli_query($con, 'select * from session where name="MESSAGE_PV"and data="'.$_SESSION['id'].'" and piperline="1" order by createDate Desc');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    ?>
                                    <button id="MESSAGE_PV_<?php echo $_SESSION['id']?>" type="button" class="list-group-item list-group-item-action" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar">
                                                <div class="avatar avatar-sm p-0" href="#" id="profileDropdown" role="button" data-bs-auto-close="outside" data-bs-display="static" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <img class="avatar-img rounded-circle" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2kO-icK_EeRI4hsstqHW1iHAUmDR0Ii1H5a8uptfpFOjs3MlrQxo8CGjMi4jVOgZysnk&usqp=CAU" alt="آواتار">
                                    
                                                </div> 

                                                <strong>پیام های ذخیره شده</strong>
             
                                            
                                    </button>

                                    <script>
                                            $('#MESSAGE_PV_<?php echo $_SESSION['id']?>').click(function(event){
                                            event.preventDefault();
                                            $('#sppiner_se').html('<div class="spinner-border text-primary" role="status" style="width: 80px; height: 80px;"><span class="sr-only"></span></div>');
                                            $('#sppiner_se1').html('در حال بارگیری');
                                            $('#sppiner_se2').html('');
        

                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=message&method=saveMS&id=<?php echo $_SESSION['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#show_pv').html(data);
                                                })

                                            })
                                            </script>


                                    <?php
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $user_hash = mysqli_query($con, 'select * from user where iduser="'.$res['userId'].'"');
                                        $user1 = mysqli_fetch_assoc($user_hash);
                                        if($user1){
                                            ?>
                                            <button id="MESSAGE_PV_<?php echo $res['id']?>" type="button" class="list-group-item list-group-item-action" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasSidebar">
                                                <div class="avatar avatar-sm p-0" href="#" id="profileDropdown" role="button" data-bs-auto-close="outside" data-bs-display="static" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <img class="avatar-img rounded-circle" src="<?php echo $user1['avatar']?>" alt="آواتار">
                                                    <?php
                                                    if($res['connect'] > 0){
                                                        ?>
                                                        <span id="newMess<?php echo $res['id']?>" class="notif-badge animation-blink"></span>
                                                        <?php
                                                    }
                                                    ?>
                                                </div> 

                                            <?php echo $user1['username']?><?php 
                                                                    if($user1['piperAdmin'] == 1){
                                                                        ?>
                                                                        <img src="https://cdn-icons-png.flaticon.com/512/5253/5253968.png" style="width: 20px;" alt="">
                                                                        <?php
                                                                    }?> <?php 
                                                                    if($user1['admin'] == 1){
                                                                        ?>
                                                                        <i class="bi bi-patch-check-fill text-info small"></i>
                                                                        <?php
                                                                    }?> 
                                            <?php
                                            if($res['connect'] > 0){
                                                ?>
                                                <br>
                                                <small id="newMess1<?php echo $res['id']?>">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $res['connect']?> پیام جدید</small>

                                                <?php
                                            }
                                            ?>
                                            
                                            </button>
                                            <script>
                                            $('#MESSAGE_PV_<?php echo $res['id']?>').click(function(event){
                                            event.preventDefault();
                                            $('#sppiner_se').html('<div class="spinner-border text-primary" role="status" style="width: 80px; height: 80px;"><span class="sr-only"></span></div>');
                                            $('#sppiner_se1').html('در حال بارگیری');
                                            $('#sppiner_se2').html('');
                                            <?php
                        
                                            if($res['connect'] > 0){
                                                ?>
                                                document.getElementById('newMess<?php echo $res['id']?>').style.display = "none";
                                                document.getElementById('newMess1<?php echo $res['id']?>').style.display = "none";

                                                <?php
                                            }
                                            ?>

                                            $.ajax({
                                                method: "POST",
                                                url: "../../index.php?controller=message&method=showPv&id=<?php echo $res['id']?>",
                                                data: { code: "1"}
                                            })
                                                .done(function(data){
                                                $('#show_pv').html(data);
                                                })

                                            })
                                            </script>

                                            <?php
                                        }

                                    }
                                }else{
                                    ?>
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 id="sppiner_se" class="display-1 text-primary"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/search-email-5192238-4340243.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video></h1>
                                        <h2 id="sppiner_se1">پیامی یافت نشد</h2>
                                    </div>
                                    <?php
                                }
                                ?>


                                </div>
								
							</div>
							<!-- Availability END -->

							<hr class="my-0"> <!-- Divider -->

		
					

						</form><!-- Form End -->
					</div>
					<!-- Buttons -->
					<div class="d-flex justify-content-between p-2 p-xl-0 mt-xl-3">
						<button class="btn btn-link p-0 mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">همه را پاک کن</font></font></button>
						<button class="btn btn-primary mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نتیجه فیلتر</font></font></button>
					</div>
				</div>
				<!-- Responsive offcanvas body END -->
			</aside>
			<!-- Filter END -->

			<!-- Main part START -->
			<div class="col-xl-9">



                <div class="card border">
                    <!-- Card body -->
                    <div class="card-body scroll-example" style="height: 700px; overflow-y:scroll; overflow-x:scroll;">
                        <!-- Product START -->
                        <div class="row g-4 scroll-example" id="show_pv">



                            <?php
                            if(isset($_GET['pv'])){
                                $query = mysqli_query($con, 'select * from session where id="'.$_GET['pv'].'"');
                                $pv = mysqli_fetch_assoc($query);
                                if($pv){
                                    $query12 = mysqli_query($con, 'select * from user where iduser="'.$pv['userId'].'"');
                                    $account = mysqli_fetch_assoc($query12);
                                    if($account){
                                        $query121223 = mysqli_fetch_assoc(mysqli_query($con, 'select * from comment where (creatorId="'.$pv['userId'].'" OR creatorId="'.$user['iduser'].'") and (userId="'.$_SESSION['id'].'" OR userId="'.$pv['userId'].'") order by idComment Desc'));
                                        $query1212 = mysqli_query($con, 'select * from comment where (creatorId="'.$pv['userId'].'" OR creatorId="'.$user['iduser'].'") and (userId="'.$_SESSION['id'].'" OR userId="'.$pv['userId'].'") order by idComment Desc');
                                        if($query121223){
                                            ?>
                                            <div class="card-body p-3">
                                                <div class="d-flex align-items-center position-relative">
                                                    <div class="avatar avatar-sm">
                                                        <img class="avatar-img rounded-circle" src="<?php echo $account['avatar']?>" alt="آواتار">
                                                    </div>
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><font style="vertical-align: inherit;"><?php echo $account['username']?></font><?php 
                                                                    if($account['piperAdmin'] == 1){
                                                                        ?>
                                                                        <img src="https://cdn-icons-png.flaticon.com/512/5253/5253968.png" style="width: 20px;" alt="">
                                                                        <?php
                                                                    }?> <?php 
                                                                    if($account['admin'] == 1){
                                                                        ?>
                                                                        <i class="bi bi-patch-check-fill text-info small"></i>
                                                                        <?php
                                                                    }?> </h6>
                                                        <button id="deletePV" type="button" class="btn btn-light btn-xs"><i class="bi bi-x-lg"></i> حذف تاریخچه</button>
                                                        <a href="../../core/rtl/dashboard.php?content=profile&id=<?php echo $account['iduser']?>" class="btn btn-light btn-xs"><i class="bi bi-person"></i> </a>
                                                        <a href="../../core/rtl/dashboard.php?content=sendPay&id=<?php echo $account['iduser']?>" class="btn btn-light btn-xs"><i class="bi bi-paypal"></i> </a>
                                                    </div>
                                                </div>
                                                <hr>
                                            </div>
                                            <?php
                                                            while($res=mysqli_fetch_assoc($query1212)){
                                                                if($res['creatorId'] == $res['userId']){
                                                                }else{
                                                                    $us = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));
                                                                    $post = mysqli_fetch_assoc(mysqli_query($con, 'select * from posts where idPost="'.$res['idCustomet'].'"'));
                                                                    $some_time = strtotime($res['time']);
                                    
                                                                    if($post){
                                                                        ?>
                                                                                                        <!-- Blog item -->
                                                                                                        <div class="col-12">
                                                                                                            <div class="d-flex align-items-center position-relative">
                                                                                                                    <img class="w-60 rounded" src="<?php echo $post['art']?>" alt="تولید - محصول">
                                                                                                                <div class="ms-3">
                                                                                                                    <a href="#" class="h6 stretched-link"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $post['title']?></font></font></a>
                                                                                                                    <p class="small mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">پیام مشتری مربوط به این خدمات است</font></font></p>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <br>
                                                                        <?php
                                                                    }
                                    
                                    
                                                                    ?>
                                    
                                    
                                    
                                    
                                    
                                                                                    <div class="card border">
                                                                                        <!-- Card header START -->
                                                                                        <div class="card-header border-bottom p-3">
                                                                                            <!-- Search and select START -->
                                                                                            
                                                                
                                                                                                
                                                                                            <div class="d-sm-flex justify-content-sm-between align-items-center">
                                        
                                                                                                <h5 class="mb-2 mb-sm-0"><div class="nav-link">
                                                                                                    <div class="d-flex align-items-center position-relative">
                                                                                                        <div class="avatar avatar-xs">
                                                                                                            <img class="avatar-img rounded-circle" src="<?php echo $us['avatar']?>" alt="avatar">
                                                                                                        </div>
                                                                                                        <span class="ms-3"><a href="index.php?content=profile&amp;id=<?php echo $us['iduser']?>" class="stretched-link text-reset btn-link"><?php echo $us['username']?></a>   <?php 
                                                                                                        if($us['piperAdmin'] == 1){
                                                                                                            ?>
                                                                                                            <img src="https://cdn-icons-png.flaticon.com/512/5253/5253968.png" style="width: 20px;" alt="">
                                                                                                            <?php
                                                                                                        }?> <?php 
                                                                                                        if($us['admin'] == 1){
                                                                                                            ?>
                                                                                                            <i class="bi bi-patch-check-fill text-info small"></i>
                                                                                                            <?php
                                                                                                        }?>   <br><small></small></span>
                                                                                                    </div>
                                                                                                </div>
                                                                                                </h5>
                                        
                                                                                                                                                                
                                                                                                       
                                        
                                                                                        
                                        
                                                                                            </div>	
                                                                                            
                                                                                            <!-- Search and select END -->
                                                                                        </div>
                                                                                        <!-- Card header END -->
                                        
                                                                                        <!-- Card body START -->
                                                                                        <div class="card-body p-3 pb-0">
                                        
                                                                
                                                                                            
                                                                                            
                                                                                            <a href="#" class="badge text-bg-primary mb-2"><i class="fas fa-circle me-2 small fw-bold"></i><i class="bi bi-calendar-plus"></i>&nbsp; <?php echo date('Y, d F', $some_time)?></a>
                                                                                            <!-- Tabs content START -->
                                                                                            <br>
                                                                                            <?php echo $res['comment']?>
                                                                                            <hr>
                                        
                                                                                        
                                                                                            <a href="index.php?content=homeACC&amp;idBlog=3568" class="btn btn-light btn-sm" id="replayToMess<?php echo $res['idcomment']?>">
                                        
                                                                                            <img src="https://cdn3d.iconscout.com/3d/free/thumb/free-macos-home-logo-2978368-2476745.png" style="width: 20px;" alt="Avatar">
                                        
                                                                                            پاسخ...
                                                                                            </a>
                                                                                        </div>
                                                                                        <!-- Card body END -->
                                        
                                                                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                                               
                                                                    <div class="row g-4" id="displayReplay<?php echo $res['idcomment']?>" style="display: none;">
                                                    
                                                                        <div class="col-12">
                                                                            <!-- Blog list table START -->
                                                                            <div class="card border bg-transparent rounded-3">
                                                                                <!-- Card header START -->
                                                                                <div class="card-header bg-transparent border-bottom p-2">
                                                                                    <div class="d-sm-flex align-items-center">
                                                                                        <h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> پاسخ </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></span></h5>
                                                                                        <a id="image_button<?php echo $res['idcomment']?>" href="#" class="btn btn-xs btn-dark-soft mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-image" viewBox="0 0 16 16">
                                                                                        <path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
                                                                                        <path d="M1.5 2A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13zm13 1a.5.5 0 0 1 .5.5v6l-3.775-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12v.54A.505.505 0 0 1 1 12.5v-9a.5.5 0 0 1 .5-.5h13z"/>
                                                                                        </svg></font></font></a>
                                                                                        &nbsp;
                                                                                        <a id="video_button<?php echo $res['idcomment']?>" class="btn btn-xs btn-dark-soft mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-earmark-play-fill" viewBox="0 0 16 16">
                                                                                        <path d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0zM9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1zM6 6.883a.5.5 0 0 1 .757-.429l3.528 2.117a.5.5 0 0 1 0 .858l-3.528 2.117a.5.5 0 0 1-.757-.43V6.884z"/>
                                                                                        </svg></font></font></a>
                                                                                        &nbsp;
                                                                                        <a id="audio_button<?php echo $res['idcomment']?>" class="btn btn-xs btn-dark-soft mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-mic" viewBox="0 0 16 16">
                                                                                        <path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/>
                                                                                        <path d="M10 8a2 2 0 1 1-4 0V3a2 2 0 1 1 4 0v5zM8 0a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V3a3 3 0 0 0-3-3z"/>
                                                                                        </svg></font></font></a>
                                                                                        &nbsp;
                                                                                        <a id="file_button<?php echo $res['idcomment']?>" class="btn btn-xs btn-dark-soft mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-earmark-lock-fill" viewBox="0 0 16 16">
                                                                                        <path d="M7 7a1 1 0 0 1 2 0v1H7V7zM6 9.3c0-.042.02-.107.105-.175A.637.637 0 0 1 6.5 9h3a.64.64 0 0 1 .395.125c.085.068.105.133.105.175v2.4c0 .042-.02.107-.105.175A.637.637 0 0 1 9.5 12h-3a.637.637 0 0 1-.395-.125C6.02 11.807 6 11.742 6 11.7V9.3z"/>
                                                                                        <path d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0zM9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1zM10 7v1.076c.54.166 1 .597 1 1.224v2.4c0 .816-.781 1.3-1.5 1.3h-3c-.719 0-1.5-.484-1.5-1.3V9.3c0-.627.46-1.058 1-1.224V7a2 2 0 1 1 4 0z"/>
                                                                                        </svg></font></a>
                                                                                        &nbsp;
                                                                                        <a id="close_button<?php echo $res['idcomment']?>" style="display: none;" class="btn btn-xs btn-danger mb-0"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
                                                                                        <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                                                                                        </svg><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"></font></font></a>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- Card header END -->
                                        
                                                                                <!-- Card body START -->
                                                                                <div class="card-body p-3">
                                                                                
                                        
                                                                                <div>
                                                                                    <form action="../../index.php?controller=message&method=rep&mode=message" method="POST">
                                        
                                                                                        <div id="image_fileSHOW<?php echo $res['idcomment']?>" style="display: none;" class="mb-3">
                                                                                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن عکس </font></font></label>
                                                                                                <input name="image" type="text" class="form-control" placeholder=" لینک عکس را وارد کنید  ">
                                                                                        </div>
                                                                                        <input name="idComment" type="text" style="display: none;" class="form-control" value="2758" placeholder=" لینک عکس را وارد کنید  ">
                                        
                                                                                        <div id="video_fileSHOW<?php echo $res['idcomment']?>" style="display: none;" class="mb-3">
                                                                                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن ویدیو </font></font></label>
                                                                                                <input name="video" type="text" class="form-control" placeholder=" لینک ویدیو را وارد کنید  ">
                                                                                        </div>
                                        
                                                                                        <div id="audio_fileSHOW<?php echo $res['idcomment']?>" style="display: none;" class="mb-3">
                                                                                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن صوت </font></font></label>
                                                                                                <input name="audio" type="text" class="form-control" placeholder=" لینک صوت را وارد کنید  ">
                                                                                        </div>
                                        
                                                                                        
                                                                                        <div id="file_fileSHOW<?php echo $res['idcomment']?>" style="display: none;" class="mb-3">
                                                                                                <label class="form-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> افزودن فایل </font></font></label>
                                                                                                <input name="file" type="text" class="form-control" placeholder=" لینک فایل را وارد کنید  ">
                                                                                        </div>
                                                                                        <input name="idPV" style="display: none;" value="<?php echo $_GET['id']?>" type="text" class="form-control" placeholder=" لینک فایل را وارد کنید  ">
                                                                                        <input name="idComment" style="display: none;" value="<?php echo $res['idcomment']?>" type="text" class="form-control" placeholder=" لینک فایل را وارد کنید  ">
                                        
                                                                                        <script>
                                                                                                    $(document).ready(function(){
                                                                                                            $("#image_button<?php echo $res['idcomment']?>").on("click", function(event){
                                                                                                                event.preventDefault();
                                                            
                                                                                                                document.getElementById('image_fileSHOW<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('close_button<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('video_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('audio_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('file_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                
                                                                                                            });
                                                                                                        });
                                                                                        </script>
                                        
                                                                                        <script>
                                                                                                    $(document).ready(function(){
                                                                                                            $("#video_button<?php echo $res['idcomment']?>").on("click", function(event){
                                                                                                                event.preventDefault();
                                        
                                                                                                                document.getElementById('close_button<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('video_fileSHOW<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('image_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('audio_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('file_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                            });
                                                                                                        });
                                                                                        </script>
                                        
                                                                                        <script>
                                                                                                    $(document).ready(function(){
                                                                                                            $("#audio_button<?php echo $res['idcomment']?>").on("click", function(event){
                                                                                                                event.preventDefault();
                                        
                                                                                                                document.getElementById('close_button<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('audio_fileSHOW<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('image_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('video_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('file_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                            });
                                                                                                        });
                                                                                        </script>
                                        
                                                                                        <script>
                                                                                                    $(document).ready(function(){
                                                                                                            $("#file_button<?php echo $res['idcomment']?>").on("click", function(event){
                                                                                                                event.preventDefault();
                                                            
                                                                                                                document.getElementById('file_fileSHOW<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('image_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('close_button<?php echo $res['idcomment']?>').style.display = "flex";
                                                                                                                document.getElementById('video_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('audio_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                            });
                                                                                                        });
                                                                                        </script>
                                                                                        
                                                                                        <script>
                                                                                                    $(document).ready(function(){
                                                                                                            $("#close_button<?php echo $res['idcomment']?>").on("click", function(event){
                                                                                                                event.preventDefault();
                                        
                                                                                                                document.getElementById('close_button<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('video_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('image_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('audio_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                                document.getElementById('file_fileSHOW<?php echo $res['idcomment']?>').style.display = "none";
                                                                                                            });
                                                                                                        });
                                                                                        </script>
                                        
                                                                                        <div class="col-12">
                                                                                            <label class="form-label"> پاسخ شما *</label>
                                                                                            <textarea class="form-control" rows="3" name="txt"></textarea>
                                                                                        </div>
                                                                                        <small>در این قسمت میتوانید همانند یک فایل هر چه میخواهید از کد های html گرفته تا پیام های شخصی سازی شده و اینهادر قالب پاسخ پست نمایش داده میشود</small>
                                                                                        <br>
                                                                                        <div class="col-12">
                                                                                            <button type="submit" class="btn btn-danger-soft" id="cancelReplay<?php echo $res['idcomment']?>"><i class="bi bi-x"></i> لغو </button>
                                                                                            <button type="submit" class="btn btn-primary">ارسال پیام </button>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                                                                </div>
                                                                            </div>
                                                                            <!-- Blog list table END -->
                                                                        </div>
                                                                    </div>
                                    
                                    
                                    
                                                                                <script>
                                                                                $('#replayToMess<?php echo $res['idcomment']?>').click(function(event){
                                                                                event.preventDefault();
                                                                             
                                                                                
                                                                             
                                                                                document.getElementById('displayReplay<?php echo $res['idcomment']?>').style.display = "flex";
                                    
                                                                             
                                                                    
                                    
                                                                                })
                                                                                </script>
                                                                                <script>
                                                                                $('#cancelReplay<?php echo $res['idcomment']?>').click(function(event){
                                                                                event.preventDefault();
                                                                             
                                                                                
                                                                             
                                                                                document.getElementById('displayReplay<?php echo $res['idcomment']?>').style.display = "none";
                                    
                                                                             
                                                                    
                                    
                                                                                })
                                                                                </script>
                                                                    <?php
                                                                }
                                        
                                                            }
                                        }
                    
                                    }else{
                                        die();
                                    }
                                }
                            }else{
                                ?>
                                <div class="row">
                                    <div class="col-md-9 text-center mx-auto my-0 my-md-5 py-0 py-lg-5 position-relative z-index-9">
                                        <!-- SVG shape START -->
                                        <figure class="position-absolute top-50 start-50 translate-middle opacity-7 z-index-n9">
                                        <svg width="650" height="379" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 510 297">
                                            <g>
                                            <path class="fill-primary opacity-1" d="M121,147.4c0,6-4.8,10.8-10.8,10.8H47.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V147.4z"></path>
                                            <path class="fill-primary opacity-1" d="M179.4,90.2c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V78.7c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V90.2z"></path>
                                            <path class="fill-primary opacity-1" d="M459.1,26.3c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V14.8c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V26.3z"></path>
                                            <path class="fill-primary opacity-1" d="M422.1,66.9c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8V55.3c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V66.9z"></path>
                                            <path class="fill-primary opacity-1" d="M275.8,282.6c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V282.6z"></path>
                                            <path class="fill-primary opacity-1" d="M87.7,42.9c0,5.9-4.8,10.8-10.8,10.8H14.3c-6,0-10.8-4.8-10.8-10.8V31.4c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V42.9z"></path>
                                            <path class="fill-primary opacity-1" d="M505.9,123.4c0,6-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V123.4z"></path>
                                            <path class="fill-primary opacity-1" d="M482.5,204.9c0,5.9-4.8,10.8-10.8,10.8h-62.6c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c5.9,0,10.8,4.8,10.8,10.8V204.9z"></path>
                                            <path class="fill-primary opacity-1" d="M408.3,258.8c0,5.9-4.8,10.8-10.8,10.8H335c-6,0-10.8-4.8-10.8-10.8v-11.5c0-6,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V258.8z"></path>
                                            <path class="fill-primary opacity-1" d="M147,252.5c0,5.9-4.8,10.8-10.8,10.8H73.6c-6,0-10.8-4.8-10.8-10.8V241c0-5.9,4.8-10.8,10.8-10.8h62.6
                                            c6,0,10.8,4.8,10.8,10.8V252.5z"></path>
                                            </g>
                                        </svg>
                                        </figure>
                                        <!-- SVG shape START -->
                                        <!-- Content -->
                                        <h1 id="sppiner_se" class="display-1 text-primary"><video loading="lazy" muted="muted" src="https://cdnl.iconscout.com/lottie/premium/thumb/chat-5192226-4340232.mp4" style="width: 100px;" type="video/mp4" autoplay="autoplay" loop="loop"></video></h1>
                                        <h2 id="sppiner_se1">هنوز گفتگویی انتخاب نکرده اید</h2>
                                        <p id="sppiner_se2">از منو گفتگو ها در سمت راست تصویر و یا برای موبایل در گزینه پیام ها یک گفتگو را انتخاب کنید</p>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>












                        </div>
                        <!-- Product END -->
                    </div>
                </div>
			</div>
			<!-- Main part END -->
		</div>
	</div>
</section>