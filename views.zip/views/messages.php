<section class="py-4">
	<div class="container">
    <div class="row pb-4">
			<div class="col-12">
        <!-- Title -->
				<div class="d-sm-flex justify-content-sm-between align-items-center">
					<h1 class="mb-2 mb-sm-0 h2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><img style="width: 70px;" src="https://cdn3d.iconscout.com/3d/premium/thumb/message-notification-4967430-4137423.png" style="width: 70px; height: 70px;" type="video/mp4"/>  پیام ها</font></font></h1>			
				</div>
			</div>
		</div>
		<div class="row g-4">
			

			

			
	
			

			

            
			

			
			
			<div class="col-12">
				<!-- Blog list table START -->
				<div class="card border bg-transparent rounded-3">
					<!-- Card header START -->
					<div class="card-header bg-transparent border-bottom p-3">
						<div class="d-sm-flex justify-content-sm-between align-items-center">
							<h5 class="mb-2 mb-sm-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نظرات و پیام ها </font></font><span class="badge bg-primary bg-opacity-10 text-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">105</font></font></span></h5>
							<a href="#" class="btn btn-sm btn-primary mb-0"><i class="fas fa-plus me-2"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">یک پست ایجاد کنید</font></font></a>
						</div>
					</div>
					<!-- Card header END -->

					<!-- Card body START -->
					<div class="card-body p-3">

						<!-- Search and select START -->
						<div class="row g-3 align-items-center justify-content-between mb-3">
							<!-- Search -->
							<div class="col-md-8">
								<form class="rounded position-relative">
									<input class="form-control pe-5 bg-transparent" type="search" placeholder="جستجو کردن" aria-label="جستجو کردن">
									<button class="btn bg-transparent border-0 px-2 py-0 position-absolute top-50 end-0 translate-middle-y" type="submit"><i class="fas fa-search fs-6 "></i></button>
								</form>
							</div>

							<!-- Select option -->
							<div class="col-md-3">
								<!-- Short by filter -->
								<form>
									<select class="form-select z-index-9 bg-transparent" aria-label=".form-sect-sm">
										<option value="">مرتب سازی بر اساس</option>
										<option>رایگان</option>
										<option>جدیدترین</option>
										<option>قدیمی ترین</option>
									</select>
								</form>
							</div>
						</div>
						<!-- Search and select END -->

						<!-- Blog list table START -->
						<div class="table-responsive border-0">
							<table class="table table-dark-gray align-middle p-4 mb-0 table-hover table-shrink">
								<!-- Table head -->
								<thead>
									<tr>
										<th scope="col" class="border-0 rounded-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام پست</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نام نویسنده</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">تاریخ انتشار</font></font></th>
										<th scope="col" class="border-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">وضعیت</font></font></th>
										<th scope="col" class="border-0 rounded-end"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">عمل</font></font></th>
									</tr>
								</thead>

								<!-- Table body START -->
								<tbody>

                                <?php
                                if(! isset($_GET['id'])){
                                    die();
                                }
                                $query_1212 = mysqli_query($con, 'select * from comment where piperlinePost="'.$_GET['id'].'" and privet="0" order by time Desc limit 0,1000');
                                $file_hash = mysqli_query($con, 'select * from comment where piperlinePost="'.$_GET['id'].'" and privet="0" order by time Desc limit 0,1000');
                                $file = mysqli_fetch_assoc($query_1212);
                                if($file){
                                    while($res=mysqli_fetch_assoc($file_hash)){
                                        $programmer_user = mysqli_fetch_assoc(mysqli_query($con, 'select * from user where iduser="'.$res['creatorId'].'"'));
										$some_time = strtotime($res['time']);

                                ?>
									<!-- Table item -->
									<tr>
										<!-- Table data -->
										<td>
											<h6 class="course-title mt-2 mt-md-0 mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $res['comment']?></font></font></a></h6>
										</td>
										<!-- Table data -->
										<td>
											<h6 class="mb-0"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $programmer_user['username']?></font></font></a></h6>
										</td>
										<!-- Table data -->
										<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo date('Y, d F', $some_time)?> </font></font></td>
										<!-- Table data -->
										<!-- Table data -->
										<td>
											<span class="badge bg-success bg-opacity-10 text-success mb-2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">زنده</font></font></span>
										</td>
										<!-- Table data -->
										<td>
                                        <div class="d-flex gap-2">
                                            <a href="../../index.php?controller=message&method=deleteComment&id=<?php echo $res['idcomment']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="حذف"><i class="bi bi-trash"></i></a>
                                            <a href="dashboard.php?content=openMessage&id=<?php echo $res['idcomment']?>" class="btn btn-light btn-round mb-0" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="ویرایش کنید"><i class="bi bi-pencil-square"></i></a>
                                        </div>
										</td>
									</tr>
                                <?php
                                    }
                                }
                                ?>

								</tbody>
								<!-- Table body END -->
							</table>
						</div>
						<!-- Blog list table END -->

						<!-- Pagination START -->
						<div class="d-sm-flex justify-content-sm-between align-items-sm-center mt-4 mt-sm-3">
							<!-- Content -->
							<p class="mb-sm-0 text-center text-sm-start"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">نمایش 1 تا 8 از 20 ورودی</font></font></p>
							<!-- Pagination -->
							<nav class="mb-sm-0 d-flex justify-content-center" aria-label="جهت یابی">
								<ul class="pagination pagination-sm pagination-bordered mb-0">
									<li class="page-item disabled">
										<a class="page-link" href="#" tabindex="-1" aria-disabled="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">قبلی</font></font></a>
									</li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1</font></font></a></li>
									<li class="page-item active"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2</font></font></a></li>
									<li class="page-item disabled"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">..</font></font></a></li>
									<li class="page-item"><a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15</font></font></a></li>
									<li class="page-item">
										<a class="page-link" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">بعد</font></font></a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- Pagination END -->
					</div>
				</div>
				<!-- Blog list table END -->
			</div>
		</div>
	</div>
</section>